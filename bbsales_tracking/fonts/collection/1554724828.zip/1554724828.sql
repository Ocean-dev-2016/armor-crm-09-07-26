

CREATE TABLE `activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `user_type` varchar(50) DEFAULT NULL,
  `table_name` varchar(50) DEFAULT NULL,
  `ip` varchar(50) DEFAULT NULL,
  `ref_id` int(11) NOT NULL DEFAULT '0',
  `activity_type` varchar(50) DEFAULT NULL,
  `activity_description` text,
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `activity_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `admin_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `slug` varchar(50) DEFAULT NULL,
  `department_id` int(11) NOT NULL DEFAULT '0',
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `adate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO admin_type VALUES("0","Super Admin","","0","0","2017-04-22 00:00:00","1","0","","","2017-04-22 00:00:00","");
INSERT INTO admin_type VALUES("2","Super Stockist","super_stockist","0","0","2017-04-22 00:00:00","1","0","","","2017-04-22 00:00:00","");
INSERT INTO admin_type VALUES("3","Outlets","outlets","0","0","2017-04-22 00:00:00","1","0","","","2017-04-22 00:00:00","");
INSERT INTO admin_type VALUES("4","Dealer Distributor","dealer","0","0","2017-04-22 00:00:00","1","0","","","2017-04-22 00:00:00","");
INSERT INTO admin_type VALUES("5","dispatch","","19","1","2017-05-27 12:08:57","1","0","1","0","2017-05-27 12:08:57","2017-05-27 12:09:08");
INSERT INTO admin_type VALUES("6","vcb","","0","1","2017-06-30 16:15:11","1","0","1","0","2017-06-30 16:15:11","2017-06-30 16:16:11");





CREATE TABLE `api_key_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `api_key` text,
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `adate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO api_key_table VALUES("1","1226","0","2016-10-18 00:00:00");





CREATE TABLE `api_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `api_slug` varchar(100) DEFAULT NULL,
  `api_title` varchar(100) DEFAULT NULL,
  `api_description` text,
  `api_url` text,
  `author` varchar(100) DEFAULT NULL,
  `last_modification_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=latin1 COMMENT='// Contains Android and IOS JSON API Infromation ';

INSERT INTO api_table VALUES("2","sales_executive_login","Sales Executive Login","To Login Sales Executive","service_sales_executive.php?key=1226&s=2&username=hardip&password=123456&imei=123456789123456&refreshToken=1559865893","sejal patel","2016-10-20 02:02:00","0","1","0","","","0000-00-00 00:00:00","");
INSERT INTO api_table VALUES("3","get_product","Get Product List","Get Product List","service_sales_executive.php?key=1226&s=3","sejal patel","2016-10-20 02:02:00","0","1","0","","","0000-00-00 00:00:00","");
INSERT INTO api_table VALUES("4","get_category_product_discount_detail","Get Product List with discount with executive type","Get Product List with discount with executive type","service_sales_executive.php?key=1226&s=4&uid=2&p_required=1","sejal patel","2016-10-20 02:02:00","0","1","0","","","0000-00-00 00:00:00","");
INSERT INTO api_table VALUES("5","get_class","get Class name List","get Class name List","service_sales_executive.php?key=1226&s=5","sejal patel","2016-10-20 02:02:00","0","1","0","","","0000-00-00 00:00:00","");
INSERT INTO api_table VALUES("6","get_area","get Area Detail List","get Area Detail List","service_sales_executive.php?key=1226&s=6","sejal patel","2016-10-20 02:02:00","0","1","0","","","0000-00-00 00:00:00","");
INSERT INTO api_table VALUES("7","get_area_usingclass_id","get Area list using class id","get Area list using class id","service_sales_executive.php?key=1226&s=7&class_id=1","sejal patel","2016-10-20 02:02:00","0","1","0","","","0000-00-00 00:00:00","");
INSERT INTO api_table VALUES("8","get_outlet_list","get Outlets list","<p>get Outlets list</p>","service_sales_executive.php?key=1226&s=8&sales_executive_id=6","sejal patel","2016-10-20 02:02:00","0","1","0","1","0","0000-00-00 00:00:00","2017-07-10 10:55:40");
INSERT INTO api_table VALUES("9","get_orders","get Orders list","get Orders list","service_sales_executive.php?key=1226&s=9&sales_id=4","sejal patel","2016-10-20 02:02:00","0","1","0","","","0000-00-00 00:00:00","");
INSERT INTO api_table VALUES("10","add_order_detail","Add Orders","<p>Add Orders</p>","service_sales_executive.php?key=1226&s=10&customer_type=1&customer_name=jay kishn&contact_number=9090909090&address=sdf&city=sdf&state=sfd&country=sd&email=g@gmail.com&customer_id=6&sales_id=4&grand_total=3000&discount=20&discount_type=1&total_amount=5000&total_qty=20&product=[{\"name\":\"product111\",\"id\":\"33\",\"weight_id\":\"19\",\"qty\":\"50\"},{\"name\":\"masala soda\",\"id\":\"34\",\"weight_id\":\"19\",\"qty\":\"50\"}]","sejal patel","2017-10-09 16:27:08","0","1","0","1,1","0,0","0000-00-00 00:00:00","2017-10-06 13:04:26,2017-10-09 16:27:08");
INSERT INTO api_table VALUES("11","update_order_detail","Update Order Detail","Update Order Detail","service_sales_executive.php?key=1226&s=11&id=1&customer_id=6&sales_id=4&grand_total=3000&discount=10&discount_type=1&total_amount=5000&total_qty=20&product=[{\"name\":\"mirch masala\",\"id\":\"35\",\"weight_id\":\"3\",\"price\":\"1325\",\"qty\":\"50\"},{\"name\":\"masala mix soda\",\"id\":\"34\",\"weight_id\":\"5\",\"price\":\"1325\",\"qty\":\"50\"}]","sejal patel","2016-10-20 02:02:00","0","1","0","","","0000-00-00 00:00:00","");
INSERT INTO api_table VALUES("12","get_customer","Get Customer","<p>Get Customer</p>","service_sales_executive.php?key=1226&s=12&sales_executive_id=31","sejal patel","2016-10-20 02:02:00","0","1","0","1","0","0000-00-00 00:00:00","2017-07-10 14:58:04");
INSERT INTO api_table VALUES("13","sales_executive_change_password","Sales Executive Change Password","Sales Executive Change Password","service_sales_executive.php?key=1226&s=13&id=4&password=1234&new_password=tejash","sejal patel","2016-10-20 02:02:00","0","1","0","","","0000-00-00 00:00:00","");
INSERT INTO api_table VALUES("14","get_orders_item","Get oreder Item using order id ","Get oreder Item using order id ","service_sales_executive.php?key=1226&s=14&order_id=3","sejal patel","2016-10-20 02:02:00","0","1","0","","","0000-00-00 00:00:00","");
INSERT INTO api_table VALUES("15","sales_executive_forgot_password","Sales Executive Forgot Password","Sales Executive Forgot Password","service_sales_executive.php?key=1226&s=15&username=varun","sejal patel","2016-10-20 02:02:00","0","1","0","","","0000-00-00 00:00:00","");
INSERT INTO api_table VALUES("16","sales_executive_change_forget_password","sales Executive Change Forget Password","sales Executive Change Forget Password","service_sales_executive.php?key=1226&s=16&username=varun&password=123456","sejal patel","2016-10-20 02:02:00","0","1","0","","","0000-00-00 00:00:00","");
INSERT INTO api_table VALUES("17","sales_executive_check_security","Check Security For forget Password","Check Security For forget Password","service_sales_executive.php?key=1226&s=17&username=varun&otp=715537","sejal patel","2016-10-20 02:02:00","0","1","0","","","0000-00-00 00:00:00","");
INSERT INTO api_table VALUES("18","sales_executive_tracking","Add Sales Executive Tracking Details","Add Sales Executive Tracking Details","service_sales_executive.php?key=1226&s=18&sales_executive_id=1&longitude=1.2558&latitude=10.25464","sejal patel","2016-10-20 02:02:00","0","1","0","","","0000-00-00 00:00:00","");
INSERT INTO api_table VALUES("19","get_report","Get  Report sales Order Detail","<p>Get sales Order Detail</p>","service_sales_executive.php?key=1226&s=19&sales_id=1&from_date=1-5-2017&to_date=30-5-2017","sejal patel","2016-10-20 02:02:00","0","1","0","1","0","0000-00-00 00:00:00","2017-07-12 12:08:34");
INSERT INTO api_table VALUES("20","add_attendance","Add Attendence Inforamation","Add Attendence Inforamation","service_sales_executive.php?key=1226&s=20&sales_id=1&imei=352929080782455","sejal patel","2016-10-20 02:02:00","0","1","0","","","0000-00-00 00:00:00","");
INSERT INTO api_table VALUES("21","add_expense","Add Expense Inforamation","Add Expense Inforamation","service_sales_executive.php?key=1226&s=21&sales_executive_id=3&expense_date=10-5-2017&DA=100&TA=100&MOA=100&NA=100&extra=100&total=400","sejal patel","2016-10-20 02:02:00","0","1","0","","","0000-00-00 00:00:00","");
INSERT INTO api_table VALUES("22","get_expense","Get Expense Inforamation","Get Expense Inforamation","service_sales_executive.php?key=1226&s=22&sales_executive_id=1","sejal patel","2016-10-20 02:02:00","0","1","0","","","0000-00-00 00:00:00","");
INSERT INTO api_table VALUES("23","delete_order_item","Delete Order Item","Delete Order Item","service_sales_executive.php?key=1226&s=23&id=2$customer_id=4&sales_id=6&product=[{\"name\":\"Regular Kasmiry Soda (Box Pack)(20grm)\",\"id\":\"1\"}]","sejal patel","2016-10-20 02:02:00","0","1","0","","","0000-00-00 00:00:00","");
INSERT INTO api_table VALUES("24","get_all_product_list","Get Product List","Get Product List","service_sales_executive.php?key=1226&s=24","sejal patel","2016-10-20 02:02:00","0","1","0","","","0000-00-00 00:00:00","");
INSERT INTO api_table VALUES("25","get_weight_list","Get Weight List","Get Weight List","service_sales_executive.php?key=1226&s=25","sejal patel","0000-00-00 00:00:00","0","1","0","","","0000-00-00 00:00:00","");
INSERT INTO api_table VALUES("26","get_product_weight_price","Get Product Weight Prise","Get Product Weight Prise","service_sales_executive.php?key=1226&s=26","sajal patel","0000-00-00 00:00:00","0","1","0","","","0000-00-00 00:00:00","");
INSERT INTO api_table VALUES("27","get_country","get_country","get all country","service_system.php?key=1226&s=27","Jai Acharya","0000-00-00 00:00:00","0","1","0","","","0000-00-00 00:00:00","");
INSERT INTO api_table VALUES("28","get_state","get_state","get all state","service_system.php?key=1226&s=28","Jai Acharya","0000-00-00 00:00:00","0","1","0","","","0000-00-00 00:00:00","");
INSERT INTO api_table VALUES("29","update_orders","Update order form application sync service<span class=\'pull-right bold text-warning\'>*Updated</span>","<p>Update order form application sync service</p>","service_genral.php?key=1226&s=29","Jai Acharya","0000-00-00 00:00:00","0","1","0","1,1,1,1,1","0,0,0,0,0","0000-00-00 00:00:00","2017-08-02 15:44:59,2017-08-02 15:48:42,2017-08-02 15:49:14,2017-08-02 15:51:05,2017-08-02 15:52:15");
INSERT INTO api_table VALUES("30","get_update_info","get_update_info","get update info","service_system.php?key=1226&s=30","Jai Acharya","0000-00-00 00:00:00","0","1","0","","","0000-00-00 00:00:00","");
INSERT INTO api_table VALUES("31","get_updates","get_updates","get_updates","service_system.php?key=1226&s=31","Jai Acharya","0000-00-00 00:00:00","0","1","0","","","0000-00-00 00:00:00","");
INSERT INTO api_table VALUES("32","add_sales_executive_tracking","Insert Sales Executive Traking","Insert Sales Executive Traking","service_sales_executive.php?key=1226&s=32&sales_id=5&tracking=[{\"date\":\"2017-05-02 15:00\",\"lat\":\"12.021\",\"long\":\"12.021\"},{\"date\":\"2017-05-02 15:00\",\"lat\":\"12.021\",\"long\":\"12.021\"},{\"date\":\"2017-05-02 15:00\",\"lat\":\"12.021\",\"long\":\"12.021\"}]","sejal patel","0000-00-00 00:00:00","0","1","0","","","0000-00-00 00:00:00","");
INSERT INTO api_table VALUES("33","Get Notification","Get Notification","<p>Get Notification</p>","service_sales_executive.php?key=1226&s=33&user_id=1&ul=0&ll=2","sejal patel","0000-00-00 00:00:00","0","1","0","1,1,1","0,0,0","2017-07-07 10:56:25","2017-07-07 11:36:42,2017-07-07 11:37:15,2017-07-08 10:52:27");
INSERT INTO api_table VALUES("34","Get Rejected Expense","Get Rejected Expense","<p>Get Rejected Expense</p>","service_sales_executive.php?key=1226&s=34&sales_executive_id=9&FromDate=1-6-2017&ToDate=30-6-2017","sejal patel","0000-00-00 00:00:00","0","1","0","1,1,1,1","0,0,0,0","2017-07-07 10:56:25","2017-07-07 11:36:42,2017-07-07 11:37:15,2017-07-08 10:52:27,2017-07-08 12:18:28");
INSERT INTO api_table VALUES("35","get_class","Get Class<span class=\'pull-right bold text-danger\'>*New</span>","<p>Get Class</p>","service_system.php?key=1226&s=35","Jai Acharya","0000-00-00 00:00:00","0","1","0","1","0","0000-00-00 00:00:00","2017-07-31 15:15:32");
INSERT INTO api_table VALUES("36","get_area","Get Area <span class=\'pull-right bold text-danger\'>*New</span>","<p>Fetch All Areas</p>\n\n<p>&nbsp;</p>\n\n<p>&nbsp;</p>","service_system.php?key=1226&s=36","Jai Acharya","0000-00-00 00:00:00","0","1","0","1,1,1,1,1,1,1,1,1","0,0,0,0,0,0,0,0,0","2017-07-31 15:11:05","2017-07-31 15:11:47,2017-07-31 15:12:03,2017-07-31 15:12:42,2017-07-31 15:13:04,2017-07-31 15:13:25,2017-07-31 15:13:38,2017-07-31 15:14:08,2017-07-31 15:15:08,2017-07-31 15:15:18");
INSERT INTO api_table VALUES("37","create_update_customer","Create and Update Customer<span class=\'pull-right bold text-danger\'>*New</span>","<p>Create and Update Customer</p>\n\n<p>for add send mode=add and for update send mode=edit and also send customer id as cid=1</p>","service_genral.php?key=1226&s=37&cname=compalsary&phone=9978078494&type_of_executive=outlet&company_type=0&company_name=Craftbox&address=XYZ&zip=360005&super_stockist_id=0&dealer_distributor_id=0&city=XTZ&state=1&country=1&email=aka@g.cm&gst=120200107015&vat=12121212&excise=12&class_id=1&area_id=12&discount=12.12&mode=add","Jai Acharya","0000-00-00 00:00:00","0","1","0","1,1","0,0","2017-08-02 15:32:13","2017-08-02 15:32:51,2017-08-02 15:36:45");
INSERT INTO api_table VALUES("38","get_city","Get City<span class=\'pull-right bold text-danger\'>*New</span>","","service_genral.php?key=1226&s=38","Jai Acharya","0000-00-00 00:00:00","0","1","0","1,1,1,1","0,0,0,0","2017-08-02 15:50:08","2017-08-02 15:50:29,2017-08-02 15:50:47,2017-08-02 15:51:36,2017-08-02 15:51:45");
INSERT INTO api_table VALUES("39","sync_offline_customers","Sync Offline Customers<span class=\'pull-right bold text-danger\'>*New</span>","<p>Sync Offline Customers</p>\n\n<p>customers=</p>\n\n<p>[<br />\n{<br />\n&quot;cname&quot;:&quot;compalsary1&quot;,<br />\n&quot;phone&quot;:&quot;9978078494&quot;,<br />\n&quot;type_of_executive&quot;:&quot;outlet&quot;,<br />\n&quot;company_type&quot;:&quot;0&quot;,<br />\n&quot;company_name&quot;:&quot;Craftbox&quot;,<br />\n&quot;address&quot;:&quot;XYZ&quot;,<br />\n&quot;zip&quot;:&quot;360005&quot;,<br />\n&quot;super_stockist_id&quot;:&quot;0&quot;,<br />\n&quot;dealer_distributor_id&quot;:&quot;0&quot;,<br />\n&quot;city&quot;:&quot;XTZ&quot;,<br />\n&quot;state&quot;:&quot;1&quot;,<br />\n&quot;country&quot;:&quot;1&quot;,<br />\n&quot;email&quot;:&quot;aka@g.cm&quot;,<br />\n&quot;gst&quot;:&quot;120200107015&quot;,<br />\n&quot;vat&quot;:&quot;12121212&quot;,<br />\n&quot;excise&quot;:&quot;12&quot;,<br />\n&quot;class_id&quot;:&quot;1&quot;,<br />\n&quot;area_id&quot;:&quot;12&quot;,<br />\n&quot;discount&quot;:&quot;12.12&quot;,<br />\n&quot;server_id&quot;:&quot;0&quot;,<br />\n&quot;local_id&quot;:&quot;0&quot;<br />\n},<br />\n{<br />\n&quot;cname&quot;:&quot;compalsary2&quot;,<br />\n&quot;phone&quot;:&quot;9978078494&quot;,<br />\n&quot;type_of_executive&quot;:&quot;outlet&quot;,<br />\n&quot;company_type&quot;:&quot;0&quot;,<br />\n&quot;company_name&quot;:&quot;Craftbox&quot;,<br />\n&quot;address&quot;:&quot;XYZ&quot;,<br />\n&quot;zip&quot;:&quot;360005&quot;,<br />\n&quot;super_stockist_id&quot;:&quot;0&quot;,<br />\n&quot;dealer_distributor_id&quot;:&quot;0&quot;,<br />\n&quot;city&quot;:&quot;XTZ&quot;,<br />\n&quot;state&quot;:&quot;1&quot;,<br />\n&quot;country&quot;:&quot;1&quot;,<br />\n&quot;email&quot;:&quot;aka@g.cm&quot;,<br />\n&quot;gst&quot;:&quot;120200107015&quot;,<br />\n&quot;vat&quot;:&quot;12121212&quot;,<br />\n&quot;excise&quot;:&quot;12&quot;,<br />\n&quot;class_id&quot;:&quot;1&quot;,<br />\n&quot;area_id&quot;:&quot;12&quot;,<br />\n&quot;discount&quot;:&quot;12.12&quot;,<br />\n&quot;server_id&quot;:&quot;0&quot;,<br />\n&quot;local_id&quot;:&quot;0&quot;},<br />\n]</p>","service_genral.php?key=1226&s=39","Jai Acharya","0000-00-00 00:00:00","0","1","0","1,1,1,1","0,0,0,0","2017-08-02 15:56:05","2017-08-02 15:56:26,2017-08-02 16:33:30,2017-08-02 16:34:19,2017-08-02 16:34:50");
INSERT INTO api_table VALUES("40","list_order_inquiry","List Order Inquiry","","http://24.24.24.216/keshav/service/service_salse_executive.php?key=1226&s=38&id=1","Jay Acharya","0000-00-00 00:00:00","0","1","0","","","2017-08-04 17:47:53","");
INSERT INTO api_table VALUES("41","add_no_order_inquiry","add no order inquiry","","http://24.24.24.216/keshav/service/service_sales_executive.php?key=1226&s=38&id=1","Jai Acharya","0000-00-00 00:00:00","0","1","0","","","2017-08-04 18:18:47","");
INSERT INTO api_table VALUES("42","update_no_order_inquiry","update no order inquiry","","http://24.24.24.216/keshav/service/service_sales_executive.php?key=1226&s=38&id=1","Jai Acharya","0000-00-00 00:00:00","0","1","0","","","2017-08-04 18:21:14","");
INSERT INTO api_table VALUES("43","delete_no_order_inquiry","delete no order inquiry","","http://24.24.24.216/keshav/service/service_sales_executive.php?key=1226&s=38&id=1&id=1","Jai Acharya","0000-00-00 00:00:00","0","1","0","","","2017-08-04 18:23:12","");
INSERT INTO api_table VALUES("44","get_action","Get No Order Inquiry Action","","http://24.24.24.216/keshav/service/service_genral.php?key=1226&s=44","Jai Acharya","0000-00-00 00:00:00","0","1","0","","","2017-08-04 18:30:58","");
INSERT INTO api_table VALUES("45","update_inquiry_sync","Update Inquiry Sync","","service_genral.php?key=1226&s=45","Jai Acharya","0000-00-00 00:00:00","0","1","0","","","2017-08-05 11:28:18","");
INSERT INTO api_table VALUES("46","get_inquiry_report","Inquiry Report","<p>Get Sales Executive List for Inquiry</p>","service_sales_executive.php?key=1226&s=46&sales_id=1&from_date=1-5-2017&to_date=30-5-2017","Jai Avcharya","0000-00-00 00:00:00","0","1","0","1","0","2017-08-08 16:08:15","2017-08-08 16:08:31");
INSERT INTO api_table VALUES("47","Get Inquiry List From Sales Executive ID","get_no_order_inquiry","<p>Get Inquiry List From Sales ID</p>","service_sales_executive.php?key=1226&s=47&sales_id=4","Jai Acharya","0000-00-00 00:00:00","0","1","0","","","2017-08-08 17:19:21","");
INSERT INTO api_table VALUES("48","get_active_app","Get Active App ","<p>Get Active App Info</p>","service_sales_executive.php?key=1226&s=48","Jai Acharya","0000-00-00 00:00:00","0","1","0","","","2017-08-08 17:19:21","");
INSERT INTO api_table VALUES("49","add_area","Add Area","<p>Add Area</p>","service_sales_executive.php?key=1226&s=49&areas=[{\"local_id\":\"1\",\"name\":\"Rajkot\",\"class_id\":\"1\"},{\"local_id\":\"2\",\"name\":\"Jamnagar\",\"class_id\":\"1\"}]","Jai Acharya","0000-00-00 00:00:00","0","1","0","","","2017-08-08 17:19:21","");
INSERT INTO api_table VALUES("50","Followup_Notification","Followup_Notification","Followup_Notification","service_genral.php?s=50&key=1226","","0000-00-00 00:00:00","0","1","0","","","0000-00-00 00:00:00","");
INSERT INTO api_table VALUES("51","update_executive_area","Update Executive Area","<p>service_user.php?key=1226&amp;s=50&amp;areas=[{&quot;local_id&quot;:1,&quot;area_id&quot;:1,&quot;class_id&quot;:1,&quot;executive_id&quot;:1}]</p>","sales_executive.php?key=1226&s=50&areas=[{","Jai Acharya","0000-00-00 00:00:00","0","1","0","1,1,1","0,0,0","2017-09-30 16:24:04","2017-09-30 16:24:16,2017-09-30 16:27:07,2017-09-30 16:48:06");
INSERT INTO api_table VALUES("52","get_product","Get Product","<ul>\n	<li>Get all product by ul (Upper Limit ) &amp; ll (Lower Limit)&nbsp;</li>\n	<li>Get all product of given cid (category id)</li>\n</ul>","service_genral.php?key=1226&s=51&ul=0&ll=2&cid=1","Grishma","2017-10-06 12:22:46","0","1","0","1,1,1,1","0,0,0,0","2017-10-05 11:58:03","2017-10-05 12:32:16,2017-10-06 12:02:17,2017-10-06 12:05:01,2017-10-06 12:22:46");
INSERT INTO api_table VALUES("53","login_customer","Login Customer","<p>Login Customer</p>","service_customer.php?key=1226&s=52&email=harvi@gmail.com&password=admin&refreshToken=cieXLhQXUXM:APA91bHBjDih9o78RKwkpG_d4CsKM-VkVo7bHZooikLmUYlXZKvFQS5aZBx62LZVB_4Od2W1YtNPh9_Ur85PDI3iZ-WtkJ_FhdmziEsYyzNGr0uYD2NAUmi3OoWdQZ0_CAp7GxhV3TNb&imei=","Grishma","0000-00-00 00:00:00","0","1","0","1,1,1","0,0,0","2017-10-05 15:14:53","2017-10-05 15:44:11,2017-10-05 15:45:20,2017-10-05 15:46:33");
INSERT INTO api_table VALUES("54","get_order_detail","Get Order Detail of Customer","<p>Get Order Detail of Customer</p>","service_sales_executive.php?key=1226&s=53&customer_id=1&customer_type=normal_user&ul=0&ll=2&from_date=5-10-2017&to_date=20-10-2017","Grishma","2017-12-07 10:58:54","0","1","0","1,1,1,1,1,1,1","0,0,0,0,0,0,0","2017-10-06 12:13:33","2017-10-06 12:14:40,2017-10-06 12:15:26,2017-10-06 12:15:59,2017-10-06 12:16:21,2017-10-09 17:32:32,2017-10-09 18:03:15,2017-12-07 10:58:54");
INSERT INTO api_table VALUES("55","get_order_item_detail","Get Order Item Detail of Customer","<p>Get Order Item Detail of Customer</p>","service_sales_executive.php?key=1226&s=54&order_id=23","Grishma","2017-10-09 18:32:19","0","1","0","1","0","2017-10-09 18:09:57","2017-10-09 18:32:19");
INSERT INTO api_table VALUES("56","cancel_order_of_customer","Cancel Order of Customer","<p>Cancel Order of Customer</p>","service_sales_executive.php?key=1226&s=55&order_id=22&reason=hsdf","Grishma","2017-10-09 18:54:59","0","1","0","1","0","2017-10-09 18:54:23","2017-10-09 18:54:59");
INSERT INTO api_table VALUES("57","get_top_category","Get TOP Category","","service_genral.php?key=1226&s=57","Jai","2017-10-11 10:32:26","0","1","0","1","0","2017-10-11 10:32:19","2017-10-11 10:32:26");
INSERT INTO api_table VALUES("58","get_category","Get Categoery","","service_genral.php?key=1226&s=58","Jai","2017-10-11 10:34:42","0","1","0","1","0","2017-10-11 10:34:01","2017-10-11 10:34:42");
INSERT INTO api_table VALUES("59","get_notification","Get Notification By Employee","<p>Get Notification By Employee</p>","service_genral.php?key=1226&s=59&user_id=3&user_type=customer","Grishma","2017-10-12 14:14:02","0","1","0","1,1","0,0","2017-10-12 12:50:16","2017-10-12 12:54:28,2017-10-12 14:14:02");
INSERT INTO api_table VALUES("60","get_banner","Get Banner","<p>Get Banner</p>","service_genral.php?key=1226&s=60","Grishma","2017-10-12 16:35:30","0","1","0","1","0","2017-10-12 16:31:30","2017-10-12 16:35:30");
INSERT INTO api_table VALUES("61","register_customer","Register Customer","<p>Register Customer</p>","service_customer.php?key=1226&s=61&email=gkn@gmail.com&password=admin&name=grishma&mobile=7353220934&address=sdff&locality=ddfgdfg&pincode=36001&city=rjt&state=Gj&country=india","Grishma","2017-12-23 12:59:21","0","1","0","1,1,1,1","0,0,0,0","2017-10-12 17:16:17","2017-10-12 17:19:26,2017-10-12 17:28:39,2017-10-12 19:06:36,2017-12-23 12:59:21");
INSERT INTO api_table VALUES("62","forget_password","Forget Password","<p>Forget Password</p>","service_customer.php?key=1226&s=62&email=grishma.craftbox@gmail.com","Grishma","2017-10-12 17:55:20","0","1","0","1","0","2017-10-12 17:44:19","2017-10-12 17:55:20");
INSERT INTO api_table VALUES("63","change_password","Change Password Of Customer","<p>Change Password Of Customer</p>","service_customer.php?key=1226&s=63&email=grishma.craftbox@gmail.com&password=admin","Grishma","2017-10-12 18:03:47","1","1","0","1,1,1","0,0,0","2017-10-12 17:58:32","2017-10-12 17:59:19,2017-10-12 18:03:47,2017-10-13 11:52:26");
INSERT INTO api_table VALUES("64","update_customer_profile","Update Customer Profile","<p>Update Customer Profile</p>","service_customer.php?key=1226&s=64&id=12&phone=9090909090&name=grishma&address=sfdsdf&locality=zxczc&zip=435353&country=india&state=gujrat&city=rajkot","Grishma","2017-10-13 10:47:21","0","1","0","1,1,1","0,0,0","2017-10-12 18:11:37","2017-10-12 18:26:13,2017-10-13 10:44:54,2017-10-13 10:47:21");
INSERT INTO api_table VALUES("65","customer_change_new_password","Change New  Password Of Customer","<p>Change New&nbsp; Password Of Customer</p>","service_customer.php?key=1226&s=65&id=12&password=admin&new_password=12345","Grishma","2017-10-13 10:55:03","0","1","0","1","0","2017-10-13 10:53:38","2017-10-13 10:55:03");
INSERT INTO api_table VALUES("66","customer_order_request","Add Customer order request","<p>Add Customer order request</p>","service_genral.php?key=1226&s=66&cid=1&products=[{\"pid\":\"3\",\"qty\":\"10\",\"weight_id\":\"1\"},{\"pid\":\"2\",\"qty\":\"20\",\"weight_id\":\"2\"},{\"pid\":\"4\",\"qty\":\"30\",\"weight_id\":\"2\"}]","Sarika","2017-12-01 16:49:36","0","1","0","1,1","0,0","2017-11-30 16:40:41","2017-11-30 16:42:33,2017-12-01 16:49:36");
INSERT INTO api_table VALUES("67","accept_invoice_order","Accept Invoice & create order","<p>Accept Invoice &amp; create order</p>","service_genral.php?key=1226&s=67&invoice_id=1","Sarika","2017-12-01 16:53:04","0","1","0","","","2017-12-01 16:53:04","");
INSERT INTO api_table VALUES("68","reject_invoice_order","Reject Invoice Order","<p>Reject Invoice Order</p>","service_sales_executive.php?key=1226&s=68&invoice_id=1&remarks=dfgdggdfgfdgdfgdfg","Sarika","2017-12-01 18:33:38","0","1","0","","","2017-12-01 18:33:38","");
INSERT INTO api_table VALUES("69","get_order_request_history","Request History","Request History","service_genral.php?key=1226&s=69&cid=1","Jai","2017-12-01 18:33:38","0","1","0","","","2017-12-01 18:33:38","");
INSERT INTO api_table VALUES("70","order_request_history_detail","Request History Detail","<p>Request History Detail</p>","service_genral.php?key=1226&s=70&id=1","Jai","2017-12-04 12:06:57","0","1","0","1","0","2017-12-01 18:33:38","2017-12-04 12:06:57");
INSERT INTO api_table VALUES("71","get_performa_history","Performa History","Performa History","service_genral.php?key=1226&s=71&cid=1","Jai","2017-12-01 18:33:38","0","1","0","","","2017-12-01 18:33:38","");
INSERT INTO api_table VALUES("72","performa_history_detail","Perfoma History Detail","<p>Performa History Detail</p>","service_genral.php?key=1226&s=72&id=1","Jai","2017-12-04 12:06:57","0","1","0","1","0","2017-12-01 18:33:38","2017-12-04 12:06:57");
INSERT INTO api_table VALUES("73","get_dispatch_detail","Get Dispatch Detail","<p>Get Dispatch Detail</p>","service_genral.php?key=1226&s=73&dispatch_id=1","Sarika","2018-01-18 10:33:51","0","1","0","","","2018-01-18 10:33:51","");
INSERT INTO api_table VALUES("74","get_dispatched_order","Get Dispatched Order","<p>Get Dispatched Order</p>","service_genral.php?key=1226&s=74&order_id=1","Sarika","2018-01-18 10:35:18","0","1","0","1","0","2018-01-18 10:35:03","2018-01-18 10:35:18");





CREATE TABLE `application_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version_name` varchar(150) NOT NULL,
  `version_code` varchar(150) NOT NULL,
  `type` varchar(150) NOT NULL,
  `file` text NOT NULL,
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text NOT NULL,
  `modified_by_type` text NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `area` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `class_id` int(11) NOT NULL DEFAULT '0',
  `area_slug` varchar(150) NOT NULL,
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO area VALUES("1","Virpur","1","","0","1","1","0","","","2017-09-26 10:56:38","");
INSERT INTO area VALUES("2","Gondal","1","","0","1","1","0","","","2017-09-26 10:56:38","");
INSERT INTO area VALUES("3","Rajkot","1","","0","1","1","0","","","2017-09-26 10:56:39","");





CREATE TABLE `attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sales_id` int(11) NOT NULL DEFAULT '0',
  `imei` text,
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `inout_status` varchar(50) DEFAULT NULL,
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;

INSERT INTO attendance VALUES("1","1","866462030739861","2017-12-28 14:38:00","In","0","5895","712","","","2017-12-28 14:38:38","");
INSERT INTO attendance VALUES("2","1","866462030739861","2017-12-28 14:41:00","Out","0","5895","712","","","2017-12-28 14:41:57","");
INSERT INTO attendance VALUES("3","1","866462030739861","2017-12-28 14:42:00","In","0","5895","712","","","2017-12-28 14:42:25","");
INSERT INTO attendance VALUES("4","1","352929080782455","2017-12-28 15:06:00","In","0","5895","712","","","2017-12-28 15:06:26","");
INSERT INTO attendance VALUES("5","1","866462030739861","2017-12-28 15:08:00","Out","0","5895","712","","","2017-12-28 15:08:33","");
INSERT INTO attendance VALUES("6","1","352929080782455","2017-12-28 15:08:00","Out","0","5895","712","","","2017-12-28 15:08:50","");
INSERT INTO attendance VALUES("7","1","866462030739861","2017-12-28 15:09:00","In","0","5895","712","","","2017-12-28 15:09:01","");
INSERT INTO attendance VALUES("8","1","352929080782455","2017-12-28 15:40:00","In","0","5895","712","","","2017-12-28 15:40:25","");
INSERT INTO attendance VALUES("9","1","866462030739861","2017-12-28 18:07:00","In","0","5895","712","","","2017-12-28 18:07:28","");
INSERT INTO attendance VALUES("10","1","866462030739861","2017-12-28 18:09:00","Out","0","5895","712","","","2017-12-28 18:09:52","");
INSERT INTO attendance VALUES("11","1","866462030739861","2017-12-30 14:53:00","In","0","5895","712","","","2017-12-30 14:53:26","");
INSERT INTO attendance VALUES("12","1","866462030739861","2018-01-01 16:25:00","In","0","5895","712","","","2018-01-01 16:25:35","");
INSERT INTO attendance VALUES("13","1","866462030739861","2018-01-01 16:25:00","Out","0","5895","712","","","2018-01-01 16:25:42","");
INSERT INTO attendance VALUES("14","1","866462030739861","2018-01-01 16:52:00","In","0","5895","712","","","2018-01-01 16:52:35","");
INSERT INTO attendance VALUES("15","1","866462030739861","2018-01-01 17:03:00","Out","0","5895","712","","","2018-01-01 17:03:58","");
INSERT INTO attendance VALUES("16","1","866462030739861","2018-01-01 17:04:00","In","0","5895","712","","","2018-01-01 17:04:26","");
INSERT INTO attendance VALUES("17","1","866462030739861","2018-01-01 17:06:00","Out","0","5895","712","","","2018-01-01 17:06:54","");
INSERT INTO attendance VALUES("18","1","866462030739861","2018-01-01 17:16:00","In","0","5895","712","","","2018-01-01 17:16:26","");
INSERT INTO attendance VALUES("19","1","866462030739861","2018-01-05 18:32:00","In","0","5895","712","","","2018-01-05 18:32:31","");
INSERT INTO attendance VALUES("20","1","866462030739861","2018-01-09 10:23:00","In","0","5895","712","","","2018-01-09 10:23:53","");
INSERT INTO attendance VALUES("21","1","866462030739861","2018-01-09 15:29:00","Out","0","5895","712","","","2018-01-09 15:29:48","");
INSERT INTO attendance VALUES("22","1","866462030739861","2018-01-09 15:30:00","In","0","5895","712","","","2018-01-09 15:30:21","");
INSERT INTO attendance VALUES("23","1","866462030739861","2018-01-09 16:19:00","Out","0","5895","712","","","2018-01-09 16:19:33","");
INSERT INTO attendance VALUES("24","1","866462030739861","2018-01-12 10:58:00","In","0","5895","712","","","2018-01-12 10:58:51","");
INSERT INTO attendance VALUES("25","1","866462030739861","2018-01-12 14:06:00","Out","0","5895","712","","","2018-01-12 14:06:54","");
INSERT INTO attendance VALUES("26","1","866462030739861","2018-01-12 15:05:00","In","0","5895","712","","","2018-01-12 15:05:14","");
INSERT INTO attendance VALUES("27","1","866462030739861","2018-01-12 15:07:00","Out","0","5895","712","","","2018-01-12 15:07:19","");
INSERT INTO attendance VALUES("28","1","866248030801169","2018-01-12 15:44:00","In","0","5895","712","","","2018-01-12 15:44:44","");
INSERT INTO attendance VALUES("29","1","866248030801169","2018-01-12 16:18:00","Out","0","5895","712","","","2018-01-12 16:18:48","");
INSERT INTO attendance VALUES("30","2","866248030801169","2018-01-12 16:21:00","In","0","5895","712","","","2018-01-12 16:21:42","");
INSERT INTO attendance VALUES("31","2","866248030801169","2018-01-12 16:22:00","Out","0","5895","712","","","2018-01-12 16:22:48","");
INSERT INTO attendance VALUES("32","1","866248030801169","2018-01-12 16:23:00","In","0","5895","712","","","2018-01-12 16:23:26","");
INSERT INTO attendance VALUES("33","1","352929080782455","2018-01-18 15:36:00","In","0","5895","712","","","2018-01-18 15:36:07","");
INSERT INTO attendance VALUES("34","1","352929080782455","2018-01-19 16:30:00","In","0","5895","712","","","2018-01-19 16:30:32","");
INSERT INTO attendance VALUES("35","1","352929080782455","2018-02-07 12:51:00","In","0","5895","712","","","2018-02-07 12:51:45","");
INSERT INTO attendance VALUES("36","1","868922033316262","2018-12-07 19:20:00","In","0","5895","712","","","2018-12-07 19:20:19","");
INSERT INTO attendance VALUES("37","1","868922033316262","2018-12-08 10:01:00","In","0","5895","712","","","2018-12-08 10:01:39","");
INSERT INTO attendance VALUES("38","1","868922033316262","2018-12-08 10:13:00","Out","0","5895","712","","","2018-12-08 10:13:38","");
INSERT INTO attendance VALUES("39","4","868922033316262","2018-12-08 10:14:00","Out","0","5895","712","","","2018-12-08 10:14:40","");
INSERT INTO attendance VALUES("40","4","868922033316262","2018-12-08 10:14:00","In","0","5895","712","","","2018-12-08 10:14:51","");
INSERT INTO attendance VALUES("41","1","352929080782455","2018-12-08 11:03:00","In","0","5895","712","","","2018-12-08 11:03:56","");
INSERT INTO attendance VALUES("42","1","352929080782455","2018-12-08 12:33:00","Out","0","5895","712","","","2018-12-08 12:33:02","");





CREATE TABLE `category_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcid` int(11) NOT NULL,
  `cid` int(11) NOT NULL COMMENT 'cid=category table id',
  `name` varchar(100) DEFAULT NULL,
  `isDelete` tinyint(4) NOT NULL DEFAULT '0',
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO category_master VALUES("1","1","0","PLAIN FITTING","0","1","1","0","","","2017-10-10 17:55:28","");
INSERT INTO category_master VALUES("2","1","0","BRASS FITTINGS","0","1","1","0","","","2017-10-10 17:55:52","");
INSERT INTO category_master VALUES("3","1","0","SDR-13.5","0","1","1","0","","","2017-10-10 17:56:41","");
INSERT INTO category_master VALUES("4","1","0","SDR-11","0","1","1","0","","","2017-10-10 17:56:54","");
INSERT INTO category_master VALUES("5","1","0","C-PVC ADHESIVE","0","1","1","0","","","2017-10-10 18:11:01","");





CREATE TABLE `city` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pincode` int(11) NOT NULL DEFAULT '0',
  `country_id` int(11) NOT NULL DEFAULT '0',
  `state_id` int(11) NOT NULL DEFAULT '0',
  `city` varchar(150) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `area_type` int(11) NOT NULL DEFAULT '0',
  `isDelivery` int(11) NOT NULL DEFAULT '0',
  `isCOD` int(11) NOT NULL DEFAULT '0',
  `isDelete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2882 DEFAULT CHARSET=latin1;

INSERT INTO city VALUES("1","0","1","1","Ahmedabad ","Ahmedabad ","0","1","1","0");
INSERT INTO city VALUES("2","0","1","1","Ahwa ","Ahwa ","0","1","1","0");
INSERT INTO city VALUES("3","0","1","1","Amod ","Amod ","0","1","1","0");
INSERT INTO city VALUES("4","0","1","1","Amreli ","Amreli ","0","1","1","0");
INSERT INTO city VALUES("5","0","1","1","Anand ","Anand ","0","1","1","0");
INSERT INTO city VALUES("6","0","1","1","Anjar ","Anjar ","0","1","1","0");
INSERT INTO city VALUES("7","0","1","1","Ankaleshwar ","Ankaleshwar ","0","1","1","0");
INSERT INTO city VALUES("8","0","1","1","Babra ","Babra ","0","1","1","0");
INSERT INTO city VALUES("9","0","1","1","Balasinor ","Balasinor ","0","1","1","0");
INSERT INTO city VALUES("10","0","1","1","Banaskantha ","Banaskantha ","0","1","1","0");
INSERT INTO city VALUES("11","0","1","1","Bansada ","Bansada ","0","1","1","0");
INSERT INTO city VALUES("12","0","1","1","Bardoli ","Bardoli ","0","1","1","0");
INSERT INTO city VALUES("13","0","1","1","Bareja ","Bareja ","0","1","1","0");
INSERT INTO city VALUES("14","0","1","1","Baroda ","Baroda ","0","1","1","0");
INSERT INTO city VALUES("15","0","1","1","Barwala ","Barwala ","0","1","1","0");
INSERT INTO city VALUES("16","0","1","1","Bayad ","Bayad ","0","1","1","0");
INSERT INTO city VALUES("17","0","1","1","Bhachav ","Bhachav ","0","1","1","0");
INSERT INTO city VALUES("18","0","1","1","Bhanvad ","Bhanvad ","0","1","1","0");
INSERT INTO city VALUES("19","0","1","1","Bharuch ","Bharuch ","0","1","1","0");
INSERT INTO city VALUES("20","0","1","1","Bhavnagar ","Bhavnagar ","0","1","1","0");
INSERT INTO city VALUES("21","0","1","1","Bhiloda ","Bhiloda ","0","1","1","0");
INSERT INTO city VALUES("22","0","1","1","Bhuj ","Bhuj ","0","1","1","0");
INSERT INTO city VALUES("23","0","1","1","Billimora ","Billimora ","0","1","1","0");
INSERT INTO city VALUES("24","0","1","1","Borsad ","Borsad ","0","1","1","0");
INSERT INTO city VALUES("25","0","1","1","Botad ","Botad ","0","1","1","0");
INSERT INTO city VALUES("26","0","1","1","Chanasma ","Chanasma ","0","1","1","0");
INSERT INTO city VALUES("27","0","1","1","Chhota Udaipur ","Chhota Udaipur ","0","1","1","0");
INSERT INTO city VALUES("28","0","1","1","Chotila ","Chotila ","0","1","1","0");
INSERT INTO city VALUES("29","0","1","1","Dabhoi ","Dabhoi ","0","1","1","0");
INSERT INTO city VALUES("30","0","1","1","Dahod ","Dahod ","0","1","1","0");
INSERT INTO city VALUES("31","0","1","1","Damnagar ","Damnagar ","0","1","1","0");
INSERT INTO city VALUES("32","0","1","1","Dang ","Dang ","0","1","1","0");
INSERT INTO city VALUES("33","0","1","1","Danta ","Danta ","0","1","1","0");
INSERT INTO city VALUES("34","0","1","1","Dasada ","Dasada ","0","1","1","0");
INSERT INTO city VALUES("35","0","1","1","Dediapada ","Dediapada ","0","1","1","0");
INSERT INTO city VALUES("36","0","1","1","Deesa ","Deesa ","0","1","1","0");
INSERT INTO city VALUES("37","0","1","1","Dehgam ","Dehgam ","0","1","1","0");
INSERT INTO city VALUES("38","0","1","1","Deodar ","Deodar ","0","1","1","0");
INSERT INTO city VALUES("39","0","1","1","Devgadhbaria ","Devgadhbaria ","0","1","1","0");
INSERT INTO city VALUES("40","0","1","1","Dhandhuka ","Dhandhuka ","0","1","1","0");
INSERT INTO city VALUES("41","0","1","1","Dhanera ","Dhanera ","0","1","1","0");
INSERT INTO city VALUES("42","0","1","1","Dharampur ","Dharampur ","0","1","1","0");
INSERT INTO city VALUES("43","0","1","1","Dhari ","Dhari ","0","1","1","0");
INSERT INTO city VALUES("44","0","1","1","Dholka ","Dholka ","0","1","1","0");
INSERT INTO city VALUES("45","0","1","1","Dhoraji ","Dhoraji ","0","1","1","0");
INSERT INTO city VALUES("46","0","1","1","Dhrangadhra ","Dhrangadhra ","0","1","1","0");
INSERT INTO city VALUES("47","0","1","1","Dhrol ","Dhrol ","0","1","1","0");
INSERT INTO city VALUES("48","0","1","1","Dwarka ","Dwarka ","0","1","1","0");
INSERT INTO city VALUES("49","0","1","1","Fortsongadh ","Fortsongadh ","0","1","1","0");
INSERT INTO city VALUES("50","0","1","1","Gadhada ","Gadhada ","0","1","1","0");
INSERT INTO city VALUES("51","0","1","1","Gandhi Nagar ","Gandhi Nagar ","0","1","1","0");
INSERT INTO city VALUES("52","0","1","1","Gariadhar ","Gariadhar ","0","1","1","0");
INSERT INTO city VALUES("53","0","1","1","Godhra ","Godhra ","0","1","1","0");
INSERT INTO city VALUES("54","0","1","1","Gogodar ","Gogodar ","0","1","1","0");
INSERT INTO city VALUES("55","0","1","1","Gondal ","Gondal ","0","1","1","0");
INSERT INTO city VALUES("56","0","1","1","Halol ","Halol ","0","1","1","0");
INSERT INTO city VALUES("57","0","1","1","Halvad ","Halvad ","0","1","1","0");
INSERT INTO city VALUES("58","0","1","1","Harij ","Harij ","0","1","1","0");
INSERT INTO city VALUES("59","0","1","1","Himatnagar ","Himatnagar ","0","1","1","0");
INSERT INTO city VALUES("60","0","1","1","Idar ","Idar ","0","1","1","0");
INSERT INTO city VALUES("61","0","1","1","Jambusar ","Jambusar ","0","1","1","0");
INSERT INTO city VALUES("62","0","1","1","Jamjodhpur ","Jamjodhpur ","0","1","1","0");
INSERT INTO city VALUES("63","0","1","1","Jamkalyanpur ","Jamkalyanpur ","0","1","1","0");
INSERT INTO city VALUES("64","0","1","1","Jamnagar ","Jamnagar ","0","1","1","0");
INSERT INTO city VALUES("65","0","1","1","Jasdan ","Jasdan ","0","1","1","0");
INSERT INTO city VALUES("66","0","1","1","Jetpur ","Jetpur ","0","1","1","0");
INSERT INTO city VALUES("67","0","1","1","Jhagadia ","Jhagadia ","0","1","1","0");
INSERT INTO city VALUES("68","0","1","1","Jhalod ","Jhalod ","0","1","1","0");
INSERT INTO city VALUES("69","0","1","1","Jodia ","Jodia ","0","1","1","0");
INSERT INTO city VALUES("70","0","1","1","Junagadh ","Junagadh ","0","1","1","0");
INSERT INTO city VALUES("71","0","1","1","Junagarh ","Junagarh ","0","1","1","0");
INSERT INTO city VALUES("72","0","1","1","Kalawad ","Kalawad ","0","1","1","0");
INSERT INTO city VALUES("73","0","1","1","Kalol ","Kalol ","0","1","1","0");
INSERT INTO city VALUES("74","0","1","1","Kapad Wanj ","Kapad Wanj ","0","1","1","0");
INSERT INTO city VALUES("75","0","1","1","Keshod ","Keshod ","0","1","1","0");
INSERT INTO city VALUES("76","0","1","1","Khambat ","Khambat ","0","1","1","0");
INSERT INTO city VALUES("77","0","1","1","Khambhalia ","Khambhalia ","0","1","1","0");
INSERT INTO city VALUES("78","0","1","1","Khavda ","Khavda ","0","1","1","0");
INSERT INTO city VALUES("79","0","1","1","Kheda ","Kheda ","0","1","1","0");
INSERT INTO city VALUES("80","0","1","1","Khedbrahma ","Khedbrahma ","0","1","1","0");
INSERT INTO city VALUES("81","0","1","1","Kheralu ","Kheralu ","0","1","1","0");
INSERT INTO city VALUES("82","0","1","1","Kodinar ","Kodinar ","0","1","1","0");
INSERT INTO city VALUES("83","0","1","1","Kotdasanghani ","Kotdasanghani ","0","1","1","0");
INSERT INTO city VALUES("84","0","1","1","Kunkawav ","Kunkawav ","0","1","1","0");
INSERT INTO city VALUES("85","0","1","1","Kutch ","Kutch ","0","1","1","0");
INSERT INTO city VALUES("86","0","1","1","Kutchmandvi ","Kutchmandvi ","0","1","1","0");
INSERT INTO city VALUES("87","0","1","1","Kutiyana ","Kutiyana ","0","1","1","0");
INSERT INTO city VALUES("88","0","1","1","Lakhpat ","Lakhpat ","0","1","1","0");
INSERT INTO city VALUES("89","0","1","1","Lakhtar ","Lakhtar ","0","1","1","0");
INSERT INTO city VALUES("90","0","1","1","Lalpur ","Lalpur ","0","1","1","0");
INSERT INTO city VALUES("91","0","1","1","Limbdi ","Limbdi ","0","1","1","0");
INSERT INTO city VALUES("92","0","1","1","Limkheda ","Limkheda ","0","1","1","0");
INSERT INTO city VALUES("93","0","1","1","Lunavada ","Lunavada ","0","1","1","0");
INSERT INTO city VALUES("94","0","1","1","M.M.Mangrol ","M.M.Mangrol ","0","1","1","0");
INSERT INTO city VALUES("95","0","1","1","Mahuva ","Mahuva ","0","1","1","0");
INSERT INTO city VALUES("96","0","1","1","Malia-Hatina ","Malia-Hatina ","0","1","1","0");
INSERT INTO city VALUES("98","0","1","1","Maliya ","Maliya ","0","1","1","0");
INSERT INTO city VALUES("99","0","1","1","Malpur ","Malpur ","0","1","1","0");
INSERT INTO city VALUES("100","0","1","1","Manavadar ","Manavadar ","0","1","1","0");
INSERT INTO city VALUES("101","0","1","1","Mandvi ","Mandvi ","0","1","1","0");
INSERT INTO city VALUES("102","0","1","1","Mangrol ","Mangrol ","0","1","1","0");
INSERT INTO city VALUES("103","0","1","1","Mehmedabad ","Mehmedabad ","0","1","1","0");
INSERT INTO city VALUES("104","0","1","1","Mehsana ","Mehsana ","0","1","1","0");
INSERT INTO city VALUES("105","0","1","1","Miyagam ","Miyagam ","0","1","1","0");
INSERT INTO city VALUES("106","0","1","1","Modasa ","Modasa ","0","1","1","0");
INSERT INTO city VALUES("107","0","1","1","Morvi ","Morvi ","0","1","1","0");
INSERT INTO city VALUES("108","0","1","1","Muli ","Muli ","0","1","1","0");
INSERT INTO city VALUES("109","0","1","1","Mundra ","Mundra ","0","1","1","0");
INSERT INTO city VALUES("110","0","1","1","Nadiad ","Nadiad ","0","1","1","0");
INSERT INTO city VALUES("111","0","1","1","Nakhatrana ","Nakhatrana ","0","1","1","0");
INSERT INTO city VALUES("112","0","1","1","Nalia ","Nalia ","0","1","1","0");
INSERT INTO city VALUES("113","0","1","1","Narmada ","Narmada ","0","1","1","0");
INSERT INTO city VALUES("114","0","1","1","Naswadi ","Naswadi ","0","1","1","0");
INSERT INTO city VALUES("115","0","1","1","Navasari ","Navasari ","0","1","1","0");
INSERT INTO city VALUES("116","0","1","1","Nizar ","Nizar ","0","1","1","0");
INSERT INTO city VALUES("117","0","1","1","Okha ","Okha ","0","1","1","0");
INSERT INTO city VALUES("118","0","1","1","Paddhari ","Paddhari ","0","1","1","0");
INSERT INTO city VALUES("119","0","1","1","Padra ","Padra ","0","1","1","0");
INSERT INTO city VALUES("120","0","1","1","Palanpur ","Palanpur ","0","1","1","0");
INSERT INTO city VALUES("121","0","1","1","Palitana ","Palitana ","0","1","1","0");
INSERT INTO city VALUES("122","0","1","1","Panchmahals ","Panchmahals ","0","1","1","0");
INSERT INTO city VALUES("123","0","1","1","Patan ","Patan ","0","1","1","0");
INSERT INTO city VALUES("124","0","1","1","Pavijetpur ","Pavijetpur ","0","1","1","0");
INSERT INTO city VALUES("125","0","1","1","Porbandar ","Porbandar ","0","1","1","0");
INSERT INTO city VALUES("126","0","1","1","Prantij ","Prantij ","0","1","1","0");
INSERT INTO city VALUES("127","0","1","1","Radhanpur ","Radhanpur ","0","1","1","0");
INSERT INTO city VALUES("128","0","1","1","Rahpar ","Rahpar ","0","1","1","0");
INSERT INTO city VALUES("129","0","1","1","Rajaula ","Rajaula ","0","1","1","0");
INSERT INTO city VALUES("130","0","1","1","Rajkot ","Rajkot ","0","1","1","0");
INSERT INTO city VALUES("131","0","1","1","Rajpipla ","Rajpipla ","0","1","1","0");
INSERT INTO city VALUES("132","0","1","1","Ranavav ","Ranavav ","0","1","1","0");
INSERT INTO city VALUES("133","0","1","1","Sabarkantha ","Sabarkantha ","0","1","1","0");
INSERT INTO city VALUES("134","0","1","1","Sanand ","Sanand ","0","1","1","0");
INSERT INTO city VALUES("135","0","1","1","Sankheda ","Sankheda ","0","1","1","0");
INSERT INTO city VALUES("136","0","1","1","Santalpur ","Santalpur ","0","1","1","0");
INSERT INTO city VALUES("137","0","1","1","Santrampur ","Santrampur ","0","1","1","0");
INSERT INTO city VALUES("138","0","1","1","Savarkundla ","Savarkundla ","0","1","1","0");
INSERT INTO city VALUES("139","0","1","1","Savli ","Savli ","0","1","1","0");
INSERT INTO city VALUES("140","0","1","1","Sayan ","Sayan ","0","1","1","0");
INSERT INTO city VALUES("141","0","1","1","Sayla ","Sayla ","0","1","1","0");
INSERT INTO city VALUES("142","0","1","1","Shehra ","Shehra ","0","1","1","0");
INSERT INTO city VALUES("143","0","1","1","Sidhpur ","Sidhpur ","0","1","1","0");
INSERT INTO city VALUES("144","0","1","1","Sihor ","Sihor ","0","1","1","0");
INSERT INTO city VALUES("145","0","1","1","Sojitra ","Sojitra ","0","1","1","0");
INSERT INTO city VALUES("146","0","1","1","Sumrasar ","Sumrasar ","0","1","1","0");
INSERT INTO city VALUES("147","0","1","1","Surat ","Surat ","0","1","1","0");
INSERT INTO city VALUES("148","0","1","1","Surendranagar ","Surendranagar ","0","1","1","0");
INSERT INTO city VALUES("149","0","1","1","Talaja ","Talaja ","0","1","1","0");
INSERT INTO city VALUES("150","0","1","1","Thara ","Thara ","0","1","1","0");
INSERT INTO city VALUES("151","0","1","1","Tharad ","Tharad ","0","1","1","0");
INSERT INTO city VALUES("152","0","1","1","Thasra ","Thasra ","0","1","1","0");
INSERT INTO city VALUES("153","0","1","1","Una-Diu ","Una-Diu ","0","1","1","0");
INSERT INTO city VALUES("154","0","1","1","Upleta ","Upleta ","0","1","1","0");
INSERT INTO city VALUES("155","0","1","1","Vadgam ","Vadgam ","0","1","1","0");
INSERT INTO city VALUES("156","0","1","1","Vadodara ","Vadodara ","0","1","1","0");
INSERT INTO city VALUES("157","0","1","1","Valia ","Valia ","0","1","1","0");
INSERT INTO city VALUES("158","0","1","1","Vallabhipur ","Vallabhipur ","0","1","1","0");
INSERT INTO city VALUES("159","0","1","1","Valod ","Valod ","0","1","1","0");
INSERT INTO city VALUES("160","0","1","1","Valsad ","Valsad ","0","1","1","0");
INSERT INTO city VALUES("161","0","1","1","Vanthali ","Vanthali ","0","1","1","0");
INSERT INTO city VALUES("162","0","1","1","Vapi ","Vapi ","0","1","1","0");
INSERT INTO city VALUES("163","0","1","1","Vav ","Vav ","0","1","1","0");
INSERT INTO city VALUES("164","0","1","1","Veraval ","Veraval ","0","1","1","0");
INSERT INTO city VALUES("165","0","1","1","Vijapur ","Vijapur ","0","1","1","0");
INSERT INTO city VALUES("166","0","1","1","Viramgam ","Viramgam ","0","1","1","0");
INSERT INTO city VALUES("167","0","1","1","Visavadar ","Visavadar ","0","1","1","0");
INSERT INTO city VALUES("168","0","1","1","Visnagar ","Visnagar ","0","1","1","0");
INSERT INTO city VALUES("169","0","1","1","Vyara ","Vyara ","0","1","1","0");
INSERT INTO city VALUES("170","0","1","1","Waghodia ","Waghodia ","0","1","1","0");
INSERT INTO city VALUES("171","0","1","1","Wankaner","Wankaner","0","1","1","0");
INSERT INTO city VALUES("172","0","1","2","Along ","Along ","0","0","0","0");
INSERT INTO city VALUES("173","0","1","2","Anini ","Anini ","0","0","0","0");
INSERT INTO city VALUES("174","0","1","2","Anjaw ","Anjaw ","0","0","0","0");
INSERT INTO city VALUES("175","0","1","2","Bameng ","Bameng ","0","0","0","0");
INSERT INTO city VALUES("176","0","1","2","Basar ","Basar ","0","0","0","0");
INSERT INTO city VALUES("177","0","1","2","Changlang ","Changlang ","0","0","0","0");
INSERT INTO city VALUES("178","0","1","2","Chowkhem ","Chowkhem ","0","0","0","0");
INSERT INTO city VALUES("179","0","1","2","Daporizo ","Daporizo ","0","0","0","0");
INSERT INTO city VALUES("180","0","1","2","Dibang Valley ","Dibang Valley ","0","0","0","0");
INSERT INTO city VALUES("181","0","1","2","Dirang ","Dirang ","0","0","0","0");
INSERT INTO city VALUES("182","0","1","2","Hayuliang ","Hayuliang ","0","0","0","0");
INSERT INTO city VALUES("183","0","1","2","Huri ","Huri ","0","0","0","0");
INSERT INTO city VALUES("184","0","1","2","Itanagar ","Itanagar ","0","0","0","0");
INSERT INTO city VALUES("185","0","1","2","Jairampur ","Jairampur ","0","0","0","0");
INSERT INTO city VALUES("186","0","1","2","Kalaktung ","Kalaktung ","0","0","0","0");
INSERT INTO city VALUES("187","0","1","2","Kameng ","Kameng ","0","0","0","0");
INSERT INTO city VALUES("188","0","1","2","Khonsa ","Khonsa ","0","0","0","0");
INSERT INTO city VALUES("189","0","1","2","Kolaring ","Kolaring ","0","0","0","0");
INSERT INTO city VALUES("190","0","1","2","Kurung Kumey ","Kurung Kumey ","0","0","0","0");
INSERT INTO city VALUES("191","0","1","2","Lohit ","Lohit ","0","0","0","0");
INSERT INTO city VALUES("192","0","1","2","Lower Dibang Valley ","Lower Dibang Valley ","0","0","0","0");
INSERT INTO city VALUES("193","0","1","2","Lower Subansiri ","Lower Subansiri ","0","0","0","0");
INSERT INTO city VALUES("194","0","1","2","Mariyang ","Mariyang ","0","0","0","0");
INSERT INTO city VALUES("195","0","1","2","Mechuka ","Mechuka ","0","0","0","0");
INSERT INTO city VALUES("196","0","1","2","Miao ","Miao ","0","0","0","0");
INSERT INTO city VALUES("197","0","1","2","Nefra ","Nefra ","0","0","0","0");
INSERT INTO city VALUES("198","0","1","2","Pakkekesang ","Pakkekesang ","0","0","0","0");
INSERT INTO city VALUES("199","0","1","2","Pangin ","Pangin ","0","0","0","0");
INSERT INTO city VALUES("200","0","1","2","Papum Pare ","Papum Pare ","0","0","0","0");
INSERT INTO city VALUES("201","0","1","2","Passighat ","Passighat ","0","0","0","0");
INSERT INTO city VALUES("202","0","1","2","Roing ","Roing ","0","0","0","0");
INSERT INTO city VALUES("203","0","1","2","Sagalee ","Sagalee ","0","0","0","0");
INSERT INTO city VALUES("204","0","1","2","Seppa ","Seppa ","0","0","0","0");
INSERT INTO city VALUES("205","0","1","2","Siang ","Siang ","0","0","0","0");
INSERT INTO city VALUES("206","0","1","2","Tali ","Tali ","0","0","0","0");
INSERT INTO city VALUES("207","0","1","2","Taliha ","Taliha ","0","0","0","0");
INSERT INTO city VALUES("208","0","1","2","Tawang ","Tawang ","0","0","0","0");
INSERT INTO city VALUES("209","0","1","2","Tezu ","Tezu ","0","0","0","0");
INSERT INTO city VALUES("210","0","1","2","Tirap ","Tirap ","0","0","0","0");
INSERT INTO city VALUES("211","0","1","2","Tuting ","Tuting ","0","0","0","0");
INSERT INTO city VALUES("212","0","1","2","Upper Siang ","Upper Siang ","0","0","0","0");
INSERT INTO city VALUES("213","0","1","2","Upper Subansiri ","Upper Subansiri ","0","0","0","0");
INSERT INTO city VALUES("214","0","1","2","Yiang Kiag","Yiang Kiag","0","0","0","0");
INSERT INTO city VALUES("215","0","1","3","Abhayapuri ","Abhayapuri ","0","0","0","0");
INSERT INTO city VALUES("216","0","1","3","Baithalangshu ","Baithalangshu ","0","0","0","0");
INSERT INTO city VALUES("217","0","1","3","Barama ","Barama ","0","0","0","0");
INSERT INTO city VALUES("218","0","1","3","Barpeta Road ","Barpeta Road ","0","0","0","0");
INSERT INTO city VALUES("219","0","1","3","Bihupuria ","Bihupuria ","0","0","0","0");
INSERT INTO city VALUES("220","0","1","3","Bijni ","Bijni ","0","0","0","0");
INSERT INTO city VALUES("221","0","1","3","Bilasipara ","Bilasipara ","0","0","0","0");
INSERT INTO city VALUES("222","0","1","3","Bokajan ","Bokajan ","0","0","0","0");
INSERT INTO city VALUES("223","0","1","3","Bokakhat ","Bokakhat ","0","0","0","0");
INSERT INTO city VALUES("224","0","1","3","Boko ","Boko ","0","0","0","0");
INSERT INTO city VALUES("225","0","1","3","Bongaigaon ","Bongaigaon ","0","0","0","0");
INSERT INTO city VALUES("226","0","1","3","Cachar ","Cachar ","0","0","0","0");
INSERT INTO city VALUES("227","0","1","3","Cachar Hills ","Cachar Hills ","0","0","0","0");
INSERT INTO city VALUES("228","0","1","3","Darrang ","Darrang ","0","0","0","0");
INSERT INTO city VALUES("229","0","1","3","Dhakuakhana ","Dhakuakhana ","0","0","0","0");
INSERT INTO city VALUES("230","0","1","3","Dhemaji ","Dhemaji ","0","0","0","0");
INSERT INTO city VALUES("231","0","1","3","Dhubri ","Dhubri ","0","0","0","0");
INSERT INTO city VALUES("232","0","1","3","Dibrugarh ","Dibrugarh ","0","0","0","0");
INSERT INTO city VALUES("233","0","1","3","Digboi ","Digboi ","0","0","0","0");
INSERT INTO city VALUES("234","0","1","3","Diphu ","Diphu ","0","0","0","0");
INSERT INTO city VALUES("235","0","1","3","Goalpara ","Goalpara ","0","0","0","0");
INSERT INTO city VALUES("236","0","1","3","Gohpur ","Gohpur ","0","0","0","0");
INSERT INTO city VALUES("237","0","1","3","Golaghat ","Golaghat ","0","0","0","0");
INSERT INTO city VALUES("238","0","1","3","Guwahati ","Guwahati ","0","0","0","0");
INSERT INTO city VALUES("239","0","1","3","Hailakandi ","Hailakandi ","0","0","0","0");
INSERT INTO city VALUES("240","0","1","3","Hajo ","Hajo ","0","0","0","0");
INSERT INTO city VALUES("241","0","1","3","Halflong ","Halflong ","0","0","0","0");
INSERT INTO city VALUES("242","0","1","3","Hojai ","Hojai ","0","0","0","0");
INSERT INTO city VALUES("243","0","1","3","Howraghat ","Howraghat ","0","0","0","0");
INSERT INTO city VALUES("244","0","1","3","Jorhat ","Jorhat ","0","0","0","0");
INSERT INTO city VALUES("245","0","1","3","Kamrup ","Kamrup ","0","0","0","0");
INSERT INTO city VALUES("246","0","1","3","Karbi Anglong ","Karbi Anglong ","0","0","0","0");
INSERT INTO city VALUES("247","0","1","3","Karimganj ","Karimganj ","0","0","0","0");
INSERT INTO city VALUES("248","0","1","3","Kokarajhar ","Kokarajhar ","0","0","0","0");
INSERT INTO city VALUES("249","0","1","3","Kokrajhar ","Kokrajhar ","0","0","0","0");
INSERT INTO city VALUES("250","0","1","3","Lakhimpur ","Lakhimpur ","0","0","0","0");
INSERT INTO city VALUES("251","0","1","3","Maibong ","Maibong ","0","0","0","0");
INSERT INTO city VALUES("252","0","1","3","Majuli ","Majuli ","0","0","0","0");
INSERT INTO city VALUES("253","0","1","3","Mangaldoi ","Mangaldoi ","0","0","0","0");
INSERT INTO city VALUES("254","0","1","3","Mariani ","Mariani ","0","0","0","0");
INSERT INTO city VALUES("255","0","1","3","Marigaon ","Marigaon ","0","0","0","0");
INSERT INTO city VALUES("256","0","1","3","Moranhat ","Moranhat ","0","0","0","0");
INSERT INTO city VALUES("257","0","1","3","Morigaon ","Morigaon ","0","0","0","0");
INSERT INTO city VALUES("258","0","1","3","Nagaon ","Nagaon ","0","0","0","0");
INSERT INTO city VALUES("259","0","1","3","Nalbari ","Nalbari ","0","0","0","0");
INSERT INTO city VALUES("260","0","1","3","Rangapara ","Rangapara ","0","0","0","0");
INSERT INTO city VALUES("261","0","1","3","Sadiya ","Sadiya ","0","0","0","0");
INSERT INTO city VALUES("262","0","1","3","Sibsagar ","Sibsagar ","0","0","0","0");
INSERT INTO city VALUES("263","0","1","3","Silchar ","Silchar ","0","0","0","0");
INSERT INTO city VALUES("264","0","1","3","Sivasagar ","Sivasagar ","0","0","0","0");
INSERT INTO city VALUES("265","0","1","3","Sonitpur ","Sonitpur ","0","0","0","0");
INSERT INTO city VALUES("266","0","1","3","Tarabarihat ","Tarabarihat ","0","0","0","0");
INSERT INTO city VALUES("267","0","1","3","Tezpur ","Tezpur ","0","0","0","0");
INSERT INTO city VALUES("268","0","1","3","Tinsukia ","Tinsukia ","0","0","0","0");
INSERT INTO city VALUES("269","0","1","3","Udalgiri ","Udalgiri ","0","0","0","0");
INSERT INTO city VALUES("270","0","1","3","Udalguri ","Udalguri ","0","0","0","0");
INSERT INTO city VALUES("271","0","1","3","UdarbondhBarpeta","UdarbondhBarpeta","0","0","0","0");
INSERT INTO city VALUES("272","0","1","4","Adhaura ","Adhaura ","0","0","0","0");
INSERT INTO city VALUES("273","0","1","4","Amarpur ","Amarpur ","0","0","0","0");
INSERT INTO city VALUES("274","0","1","4","Araria ","Araria ","0","0","0","0");
INSERT INTO city VALUES("275","0","1","4","Areraj ","Areraj ","0","0","0","0");
INSERT INTO city VALUES("276","0","1","4","Arrah ","Arrah ","0","0","0","0");
INSERT INTO city VALUES("277","0","1","4","Arwal ","Arwal ","0","0","0","0");
INSERT INTO city VALUES("278","0","1","4","Aurangabad ","Aurangabad ","0","0","0","0");
INSERT INTO city VALUES("279","0","1","4","Bagaha ","Bagaha ","0","0","0","0");
INSERT INTO city VALUES("280","0","1","4","Banka ","Banka ","0","0","0","0");
INSERT INTO city VALUES("281","0","1","4","Banmankhi ","Banmankhi ","0","0","0","0");
INSERT INTO city VALUES("282","0","1","4","Barachakia ","Barachakia ","0","0","0","0");
INSERT INTO city VALUES("283","0","1","4","Barauni ","Barauni ","0","0","0","0");
INSERT INTO city VALUES("284","0","1","4","Barh ","Barh ","0","0","0","0");
INSERT INTO city VALUES("285","0","1","4","Barosi ","Barosi ","0","0","0","0");
INSERT INTO city VALUES("286","0","1","4","Begusarai ","Begusarai ","0","0","0","0");
INSERT INTO city VALUES("287","0","1","4","Benipatti ","Benipatti ","0","0","0","0");
INSERT INTO city VALUES("288","0","1","4","Benipur ","Benipur ","0","0","0","0");
INSERT INTO city VALUES("289","0","1","4","Bettiah ","Bettiah ","0","0","0","0");
INSERT INTO city VALUES("290","0","1","4","Bhabhua ","Bhabhua ","0","0","0","0");
INSERT INTO city VALUES("291","0","1","4","Bhagalpur ","Bhagalpur ","0","0","0","0");
INSERT INTO city VALUES("292","0","1","4","Bhojpur ","Bhojpur ","0","0","0","0");
INSERT INTO city VALUES("293","0","1","4","Bidupur ","Bidupur ","0","0","0","0");
INSERT INTO city VALUES("294","0","1","4","Biharsharif ","Biharsharif ","0","0","0","0");
INSERT INTO city VALUES("295","0","1","4","Bikram ","Bikram ","0","0","0","0");
INSERT INTO city VALUES("296","0","1","4","Bikramganj ","Bikramganj ","0","0","0","0");
INSERT INTO city VALUES("297","0","1","4","Birpur ","Birpur ","0","0","0","0");
INSERT INTO city VALUES("298","0","1","4","Buxar ","Buxar ","0","0","0","0");
INSERT INTO city VALUES("299","0","1","4","Chakai ","Chakai ","0","0","0","0");
INSERT INTO city VALUES("300","0","1","4","Champaran ","Champaran ","0","0","0","0");
INSERT INTO city VALUES("301","0","1","4","Chapara ","Chapara ","0","0","0","0");
INSERT INTO city VALUES("302","0","1","4","Dalsinghsarai ","Dalsinghsarai ","0","0","0","0");
INSERT INTO city VALUES("303","0","1","4","Danapur ","Danapur ","0","0","0","0");
INSERT INTO city VALUES("304","0","1","4","Darbhanga ","Darbhanga ","0","0","0","0");
INSERT INTO city VALUES("305","0","1","4","Daudnagar ","Daudnagar ","0","0","0","0");
INSERT INTO city VALUES("306","0","1","4","Dhaka ","Dhaka ","0","0","0","0");
INSERT INTO city VALUES("307","0","1","4","Dhamdaha ","Dhamdaha ","0","0","0","0");
INSERT INTO city VALUES("308","0","1","4","Dumraon ","Dumraon ","0","0","0","0");
INSERT INTO city VALUES("309","0","1","4","Ekma ","Ekma ","0","0","0","0");
INSERT INTO city VALUES("310","0","1","4","Forbesganj ","Forbesganj ","0","0","0","0");
INSERT INTO city VALUES("311","0","1","4","Gaya ","Gaya ","0","0","0","0");
INSERT INTO city VALUES("312","0","1","4","Gogri ","Gogri ","0","0","0","0");
INSERT INTO city VALUES("313","0","1","4","Gopalganj ","Gopalganj ","0","0","0","0");
INSERT INTO city VALUES("314","0","1","4","H.Kharagpur ","H.Kharagpur ","0","0","0","0");
INSERT INTO city VALUES("315","0","1","4","Hajipur ","Hajipur ","0","0","0","0");
INSERT INTO city VALUES("316","0","1","4","Hathua ","Hathua ","0","0","0","0");
INSERT INTO city VALUES("317","0","1","4","Hilsa ","Hilsa ","0","0","0","0");
INSERT INTO city VALUES("318","0","1","4","Imamganj ","Imamganj ","0","0","0","0");
INSERT INTO city VALUES("319","0","1","4","Jahanabad ","Jahanabad ","0","0","0","0");
INSERT INTO city VALUES("320","0","1","4","Jainagar ","Jainagar ","0","0","0","0");
INSERT INTO city VALUES("321","0","1","4","Jamshedpur ","Jamshedpur ","0","0","0","0");
INSERT INTO city VALUES("322","0","1","4","Jamui ","Jamui ","0","0","0","0");
INSERT INTO city VALUES("323","0","1","4","Jehanabad ","Jehanabad ","0","0","0","0");
INSERT INTO city VALUES("324","0","1","4","Jhajha ","Jhajha ","0","0","0","0");
INSERT INTO city VALUES("325","0","1","4","Jhanjharpur ","Jhanjharpur ","0","0","0","0");
INSERT INTO city VALUES("326","0","1","4","Kahalgaon ","Kahalgaon ","0","0","0","0");
INSERT INTO city VALUES("327","0","1","4","Kaimur (Bhabua) ","Kaimur (Bhabua) ","0","0","0","0");
INSERT INTO city VALUES("328","0","1","4","Katihar ","Katihar ","0","0","0","0");
INSERT INTO city VALUES("329","0","1","4","Katoria ","Katoria ","0","0","0","0");
INSERT INTO city VALUES("330","0","1","4","Khagaria ","Khagaria ","0","0","0","0");
INSERT INTO city VALUES("331","0","1","4","Kishanganj ","Kishanganj ","0","0","0","0");
INSERT INTO city VALUES("332","0","1","4","Korha ","Korha ","0","0","0","0");
INSERT INTO city VALUES("333","0","1","4","Lakhisarai ","Lakhisarai ","0","0","0","0");
INSERT INTO city VALUES("334","0","1","4","Madhepura ","Madhepura ","0","0","0","0");
INSERT INTO city VALUES("335","0","1","4","Madhubani ","Madhubani ","0","0","0","0");
INSERT INTO city VALUES("336","0","1","4","Maharajganj ","Maharajganj ","0","0","0","0");
INSERT INTO city VALUES("337","0","1","4","Mahua ","Mahua ","0","0","0","0");
INSERT INTO city VALUES("338","0","1","4","Mairwa ","Mairwa ","0","0","0","0");
INSERT INTO city VALUES("339","0","1","4","Mallehpur ","Mallehpur ","0","0","0","0");
INSERT INTO city VALUES("340","0","1","4","Masrakh ","Masrakh ","0","0","0","0");
INSERT INTO city VALUES("341","0","1","4","Mohania ","Mohania ","0","0","0","0");
INSERT INTO city VALUES("342","0","1","4","Monghyr ","Monghyr ","0","0","0","0");
INSERT INTO city VALUES("343","0","1","4","Motihari ","Motihari ","0","0","0","0");
INSERT INTO city VALUES("344","0","1","4","Motipur ","Motipur ","0","0","0","0");
INSERT INTO city VALUES("345","0","1","4","Munger ","Munger ","0","0","0","0");
INSERT INTO city VALUES("346","0","1","4","Muzaffarpur ","Muzaffarpur ","0","0","0","0");
INSERT INTO city VALUES("347","0","1","4","Nabinagar ","Nabinagar ","0","0","0","0");
INSERT INTO city VALUES("348","0","1","4","Nalanda ","Nalanda ","0","0","0","0");
INSERT INTO city VALUES("349","0","1","4","Narkatiaganj ","Narkatiaganj ","0","0","0","0");
INSERT INTO city VALUES("350","0","1","4","Naugachia ","Naugachia ","0","0","0","0");
INSERT INTO city VALUES("351","0","1","4","Nawada ","Nawada ","0","0","0","0");
INSERT INTO city VALUES("352","0","1","4","Pakribarwan ","Pakribarwan ","0","0","0","0");
INSERT INTO city VALUES("353","0","1","4","Pakridayal ","Pakridayal ","0","0","0","0");
INSERT INTO city VALUES("354","0","1","4","Patna ","Patna ","0","0","0","0");
INSERT INTO city VALUES("355","0","1","4","Phulparas ","Phulparas ","0","0","0","0");
INSERT INTO city VALUES("356","0","1","4","Piro ","Piro ","0","0","0","0");
INSERT INTO city VALUES("357","0","1","4","Pupri ","Pupri ","0","0","0","0");
INSERT INTO city VALUES("358","0","1","4","Purena ","Purena ","0","0","0","0");
INSERT INTO city VALUES("359","0","1","4","Purnia ","Purnia ","0","0","0","0");
INSERT INTO city VALUES("360","0","1","4","Rafiganj ","Rafiganj ","0","0","0","0");
INSERT INTO city VALUES("361","0","1","4","Rajauli ","Rajauli ","0","0","0","0");
INSERT INTO city VALUES("362","0","1","4","Ramnagar ","Ramnagar ","0","0","0","0");
INSERT INTO city VALUES("363","0","1","4","Raniganj ","Raniganj ","0","0","0","0");
INSERT INTO city VALUES("364","0","1","4","Raxaul ","Raxaul ","0","0","0","0");
INSERT INTO city VALUES("365","0","1","4","Rohtas ","Rohtas ","0","0","0","0");
INSERT INTO city VALUES("366","0","1","4","Rosera ","Rosera ","0","0","0","0");
INSERT INTO city VALUES("367","0","1","4","S.Bakhtiarpur ","S.Bakhtiarpur ","0","0","0","0");
INSERT INTO city VALUES("368","0","1","4","Saharsa ","Saharsa ","0","0","0","0");
INSERT INTO city VALUES("369","0","1","4","Samastipur ","Samastipur ","0","0","0","0");
INSERT INTO city VALUES("370","0","1","4","Saran ","Saran ","0","0","0","0");
INSERT INTO city VALUES("371","0","1","4","Sasaram ","Sasaram ","0","0","0","0");
INSERT INTO city VALUES("372","0","1","4","Seikhpura ","Seikhpura ","0","0","0","0");
INSERT INTO city VALUES("373","0","1","4","Sheikhpura ","Sheikhpura ","0","0","0","0");
INSERT INTO city VALUES("374","0","1","4","Sheohar ","Sheohar ","0","0","0","0");
INSERT INTO city VALUES("375","0","1","4","Sherghati ","Sherghati ","0","0","0","0");
INSERT INTO city VALUES("376","0","1","4","Sidhawalia ","Sidhawalia ","0","0","0","0");
INSERT INTO city VALUES("377","0","1","4","Singhwara ","Singhwara ","0","0","0","0");
INSERT INTO city VALUES("378","0","1","4","Sitamarhi ","Sitamarhi ","0","0","0","0");
INSERT INTO city VALUES("379","0","1","4","Siwan ","Siwan ","0","0","0","0");
INSERT INTO city VALUES("380","0","1","4","Sonepur ","Sonepur ","0","0","0","0");
INSERT INTO city VALUES("381","0","1","4","Supaul ","Supaul ","0","0","0","0");
INSERT INTO city VALUES("382","0","1","4","Thakurganj ","Thakurganj ","0","0","0","0");
INSERT INTO city VALUES("383","0","1","4","Triveniganj ","Triveniganj ","0","0","0","0");
INSERT INTO city VALUES("384","0","1","4","Udakishanganj ","Udakishanganj ","0","0","0","0");
INSERT INTO city VALUES("385","0","1","4","Vaishali ","Vaishali ","0","0","0","0");
INSERT INTO city VALUES("386","0","1","4","Wazirganj","Wazirganj","0","0","0","0");
INSERT INTO city VALUES("387","0","1","5","Ambikapur ","Ambikapur ","0","0","0","0");
INSERT INTO city VALUES("388","0","1","5","Antagarh ","Antagarh ","0","0","0","0");
INSERT INTO city VALUES("389","0","1","5","Arang ","Arang ","0","0","0","0");
INSERT INTO city VALUES("390","0","1","5","Bacheli ","Bacheli ","0","0","0","0");
INSERT INTO city VALUES("391","0","1","5","Bagbahera ","Bagbahera ","0","0","0","0");
INSERT INTO city VALUES("392","0","1","5","Bagicha ","Bagicha ","0","0","0","0");
INSERT INTO city VALUES("393","0","1","5","Baikunthpur ","Baikunthpur ","0","0","0","0");
INSERT INTO city VALUES("394","0","1","5","Balod ","Balod ","0","0","0","0");
INSERT INTO city VALUES("395","0","1","5","Balodabazar ","Balodabazar ","0","0","0","0");
INSERT INTO city VALUES("396","0","1","5","Balrampur ","Balrampur ","0","0","0","0");
INSERT INTO city VALUES("397","0","1","5","Barpalli ","Barpalli ","0","0","0","0");
INSERT INTO city VALUES("398","0","1","5","Basana ","Basana ","0","0","0","0");
INSERT INTO city VALUES("399","0","1","5","Bastanar ","Bastanar ","0","0","0","0");
INSERT INTO city VALUES("400","0","1","5","Bastar ","Bastar ","0","0","0","0");
INSERT INTO city VALUES("401","0","1","5","Bderajpur ","Bderajpur ","0","0","0","0");
INSERT INTO city VALUES("402","0","1","5","Bemetara ","Bemetara ","0","0","0","0");
INSERT INTO city VALUES("403","0","1","5","Berla ","Berla ","0","0","0","0");
INSERT INTO city VALUES("404","0","1","5","Bhairongarh ","Bhairongarh ","0","0","0","0");
INSERT INTO city VALUES("405","0","1","5","Bhanupratappur ","Bhanupratappur ","0","0","0","0");
INSERT INTO city VALUES("406","0","1","5","Bharathpur ","Bharathpur ","0","0","0","0");
INSERT INTO city VALUES("407","0","1","5","Bhatapara ","Bhatapara ","0","0","0","0");
INSERT INTO city VALUES("408","0","1","5","Bhilai ","Bhilai ","0","0","0","0");
INSERT INTO city VALUES("409","0","1","5","Bhilaigarh ","Bhilaigarh ","0","0","0","0");
INSERT INTO city VALUES("410","0","1","5","Bhopalpatnam ","Bhopalpatnam ","0","0","0","0");
INSERT INTO city VALUES("411","0","1","5","Bijapur ","Bijapur ","0","0","0","0");
INSERT INTO city VALUES("412","0","1","5","Bilaspur ","Bilaspur ","0","0","0","0");
INSERT INTO city VALUES("413","0","1","5","Bodla ","Bodla ","0","0","0","0");
INSERT INTO city VALUES("414","0","1","5","Bokaband ","Bokaband ","0","0","0","0");
INSERT INTO city VALUES("415","0","1","5","Chandipara ","Chandipara ","0","0","0","0");
INSERT INTO city VALUES("416","0","1","5","Chhinagarh ","Chhinagarh ","0","0","0","0");
INSERT INTO city VALUES("417","0","1","5","Chhuriakala ","Chhuriakala ","0","0","0","0");
INSERT INTO city VALUES("418","0","1","5","Chingmut ","Chingmut ","0","0","0","0");
INSERT INTO city VALUES("419","0","1","5","Chuikhadan ","Chuikhadan ","0","0","0","0");
INSERT INTO city VALUES("420","0","1","5","Dabhara ","Dabhara ","0","0","0","0");
INSERT INTO city VALUES("421","0","1","5","Dallirajhara ","Dallirajhara ","0","0","0","0");
INSERT INTO city VALUES("422","0","1","5","Dantewada ","Dantewada ","0","0","0","0");
INSERT INTO city VALUES("423","0","1","5","Deobhog ","Deobhog ","0","0","0","0");
INSERT INTO city VALUES("424","0","1","5","Dhamda ","Dhamda ","0","0","0","0");
INSERT INTO city VALUES("425","0","1","5","Dhamtari ","Dhamtari ","0","0","0","0");
INSERT INTO city VALUES("426","0","1","5","Dharamjaigarh ","Dharamjaigarh ","0","0","0","0");
INSERT INTO city VALUES("427","0","1","5","Dongargarh ","Dongargarh ","0","0","0","0");
INSERT INTO city VALUES("428","0","1","5","Durg ","Durg ","0","0","0","0");
INSERT INTO city VALUES("429","0","1","5","Durgakondal ","Durgakondal ","0","0","0","0");
INSERT INTO city VALUES("430","0","1","5","Fingeshwar ","Fingeshwar ","0","0","0","0");
INSERT INTO city VALUES("431","0","1","5","Gariaband ","Gariaband ","0","0","0","0");
INSERT INTO city VALUES("432","0","1","5","Garpa ","Garpa ","0","0","0","0");
INSERT INTO city VALUES("433","0","1","5","Gharghoda ","Gharghoda ","0","0","0","0");
INSERT INTO city VALUES("434","0","1","5","Gogunda ","Gogunda ","0","0","0","0");
INSERT INTO city VALUES("435","0","1","5","Ilamidi ","Ilamidi ","0","0","0","0");
INSERT INTO city VALUES("436","0","1","5","Jagdalpur ","Jagdalpur ","0","0","0","0");
INSERT INTO city VALUES("437","0","1","5","Janjgir ","Janjgir ","0","0","0","0");
INSERT INTO city VALUES("438","0","1","5","Janjgir-Champa ","Janjgir-Champa ","0","0","0","0");
INSERT INTO city VALUES("439","0","1","5","Jarwa ","Jarwa ","0","0","0","0");
INSERT INTO city VALUES("440","0","1","5","Jashpur ","Jashpur ","0","0","0","0");
INSERT INTO city VALUES("441","0","1","5","Jashpurnagar ","Jashpurnagar ","0","0","0","0");
INSERT INTO city VALUES("442","0","1","5","Kabirdham-Kawardha ","Kabirdham-Kawardha ","0","0","0","0");
INSERT INTO city VALUES("443","0","1","5","Kanker ","Kanker ","0","0","0","0");
INSERT INTO city VALUES("444","0","1","5","Kasdol ","Kasdol ","0","0","0","0");
INSERT INTO city VALUES("445","0","1","5","Kathdol ","Kathdol ","0","0","0","0");
INSERT INTO city VALUES("446","0","1","5","Kathghora ","Kathghora ","0","0","0","0");
INSERT INTO city VALUES("447","0","1","5","Kawardha ","Kawardha ","0","0","0","0");
INSERT INTO city VALUES("448","0","1","5","Keskal ","Keskal ","0","0","0","0");
INSERT INTO city VALUES("449","0","1","5","Khairgarh ","Khairgarh ","0","0","0","0");
INSERT INTO city VALUES("450","0","1","5","Kondagaon ","Kondagaon ","0","0","0","0");
INSERT INTO city VALUES("451","0","1","5","Konta ","Konta ","0","0","0","0");
INSERT INTO city VALUES("452","0","1","5","Korba ","Korba ","0","0","0","0");
INSERT INTO city VALUES("453","0","1","5","Korea ","Korea ","0","0","0","0");
INSERT INTO city VALUES("454","0","1","5","Kota ","Kota ","0","0","0","0");
INSERT INTO city VALUES("455","0","1","5","Koyelibeda ","Koyelibeda ","0","0","0","0");
INSERT INTO city VALUES("456","0","1","5","Kuakunda ","Kuakunda ","0","0","0","0");
INSERT INTO city VALUES("457","0","1","5","Kunkuri ","Kunkuri ","0","0","0","0");
INSERT INTO city VALUES("458","0","1","5","Kurud ","Kurud ","0","0","0","0");
INSERT INTO city VALUES("459","0","1","5","Lohadigundah ","Lohadigundah ","0","0","0","0");
INSERT INTO city VALUES("460","0","1","5","Lormi ","Lormi ","0","0","0","0");
INSERT INTO city VALUES("461","0","1","5","Luckwada ","Luckwada ","0","0","0","0");
INSERT INTO city VALUES("462","0","1","5","Mahasamund ","Mahasamund ","0","0","0","0");
INSERT INTO city VALUES("463","0","1","5","Makodi ","Makodi ","0","0","0","0");
INSERT INTO city VALUES("464","0","1","5","Manendragarh ","Manendragarh ","0","0","0","0");
INSERT INTO city VALUES("465","0","1","5","Manpur ","Manpur ","0","0","0","0");
INSERT INTO city VALUES("466","0","1","5","Marwahi ","Marwahi ","0","0","0","0");
INSERT INTO city VALUES("467","0","1","5","Mohla ","Mohla ","0","0","0","0");
INSERT INTO city VALUES("468","0","1","5","Mungeli ","Mungeli ","0","0","0","0");
INSERT INTO city VALUES("469","0","1","5","Nagri ","Nagri ","0","0","0","0");
INSERT INTO city VALUES("470","0","1","5","Narainpur ","Narainpur ","0","0","0","0");
INSERT INTO city VALUES("471","0","1","5","Narayanpur ","Narayanpur ","0","0","0","0");
INSERT INTO city VALUES("472","0","1","5","Neora ","Neora ","0","0","0","0");
INSERT INTO city VALUES("473","0","1","5","Netanar ","Netanar ","0","0","0","0");
INSERT INTO city VALUES("474","0","1","5","Odgi ","Odgi ","0","0","0","0");
INSERT INTO city VALUES("475","0","1","5","Padamkot Pakhanjur ","Padamkot Pakhanjur ","0","0","0","0");
INSERT INTO city VALUES("476","0","1","5","Pali ","Pali ","0","0","0","0");
INSERT INTO city VALUES("477","0","1","5","Pandaria ","Pandaria ","0","0","0","0");
INSERT INTO city VALUES("478","0","1","5","Pandishankar ","Pandishankar ","0","0","0","0");
INSERT INTO city VALUES("479","0","1","5","Parasgaon ","Parasgaon ","0","0","0","0");
INSERT INTO city VALUES("480","0","1","5","Pasan ","Pasan ","0","0","0","0");
INSERT INTO city VALUES("481","0","1","5","Patan ","Patan ","0","0","0","0");
INSERT INTO city VALUES("482","0","1","5","Pathalgaon ","Pathalgaon ","0","0","0","0");
INSERT INTO city VALUES("483","0","1","5","Pendra ","Pendra ","0","0","0","0");
INSERT INTO city VALUES("484","0","1","5","Pratappur ","Pratappur ","0","0","0","0");
INSERT INTO city VALUES("485","0","1","5","Premnagar ","Premnagar ","0","0","0","0");
INSERT INTO city VALUES("486","0","1","5","Raigarh ","Raigarh ","0","0","0","0");
INSERT INTO city VALUES("487","0","1","5","Raipur ","Raipur ","0","0","0","0");
INSERT INTO city VALUES("488","0","1","5","Rajnandgaon ","Rajnandgaon ","0","0","0","0");
INSERT INTO city VALUES("489","0","1","5","Rajpur ","Rajpur ","0","0","0","0");
INSERT INTO city VALUES("490","0","1","5","Ramchandrapur ","Ramchandrapur ","0","0","0","0");
INSERT INTO city VALUES("491","0","1","5","Saraipali ","Saraipali ","0","0","0","0");
INSERT INTO city VALUES("492","0","1","5","Saranggarh ","Saranggarh ","0","0","0","0");
INSERT INTO city VALUES("493","0","1","5","Sarona ","Sarona ","0","0","0","0");
INSERT INTO city VALUES("494","0","1","5","Semaria ","Semaria ","0","0","0","0");
INSERT INTO city VALUES("495","0","1","5","Shakti ","Shakti ","0","0","0","0");
INSERT INTO city VALUES("496","0","1","5","Sitapur ","Sitapur ","0","0","0","0");
INSERT INTO city VALUES("497","0","1","5","Sukma ","Sukma ","0","0","0","0");
INSERT INTO city VALUES("498","0","1","5","Surajpur ","Surajpur ","0","0","0","0");
INSERT INTO city VALUES("499","0","1","5","Surguja ","Surguja ","0","0","0","0");
INSERT INTO city VALUES("500","0","1","5","Tapkara ","Tapkara ","0","0","0","0");
INSERT INTO city VALUES("501","0","1","5","Toynar ","Toynar ","0","0","0","0");
INSERT INTO city VALUES("502","0","1","5","Udaipur ","Udaipur ","0","0","0","0");
INSERT INTO city VALUES("503","0","1","5","Uproda ","Uproda ","0","0","0","0");
INSERT INTO city VALUES("504","0","1","5","Wadrainagar","Wadrainagar","0","0","0","0");
INSERT INTO city VALUES("505","0","1","6","Canacona ","Canacona ","0","0","0","0");
INSERT INTO city VALUES("506","0","1","6","Candolim ","Candolim ","0","0","0","0");
INSERT INTO city VALUES("507","0","1","6","Chinchinim ","Chinchinim ","0","0","0","0");
INSERT INTO city VALUES("508","0","1","6","Cortalim ","Cortalim ","0","0","0","0");
INSERT INTO city VALUES("509","0","1","6","Goa ","Goa ","0","0","0","0");
INSERT INTO city VALUES("510","0","1","6","Jua ","Jua ","0","0","0","0");
INSERT INTO city VALUES("511","0","1","6","Madgaon ","Madgaon ","0","0","0","0");
INSERT INTO city VALUES("512","0","1","6","Mahem ","Mahem ","0","0","0","0");
INSERT INTO city VALUES("513","0","1","6","Mapuca ","Mapuca ","0","0","0","0");
INSERT INTO city VALUES("514","0","1","6","Marmagao ","Marmagao ","0","0","0","0");
INSERT INTO city VALUES("515","0","1","6","Panji ","Panji ","0","0","0","0");
INSERT INTO city VALUES("516","0","1","6","Ponda ","Ponda ","0","0","0","0");
INSERT INTO city VALUES("517","0","1","6","Sanvordem ","Sanvordem ","0","0","0","0");
INSERT INTO city VALUES("518","0","1","6","Terekhol ","Terekhol ","0","0","0","0");
INSERT INTO city VALUES("519","0","1","7","Achampet ","Achampet ","0","0","0","0");
INSERT INTO city VALUES("520","0","1","7","Adilabad ","Adilabad ","0","0","0","0");
INSERT INTO city VALUES("521","0","1","7","Adoni ","Adoni ","0","0","0","0");
INSERT INTO city VALUES("522","0","1","7","Alampur ","Alampur ","0","0","0","0");
INSERT INTO city VALUES("523","0","1","7","Allagadda ","Allagadda ","0","0","0","0");
INSERT INTO city VALUES("524","0","1","7","Alur ","Alur ","0","0","0","0");
INSERT INTO city VALUES("525","0","1","7","Amalapuram ","Amalapuram ","0","0","0","0");
INSERT INTO city VALUES("526","0","1","7","Amangallu ","Amangallu ","0","0","0","0");
INSERT INTO city VALUES("527","0","1","7","Anakapalle ","Anakapalle ","0","0","0","0");
INSERT INTO city VALUES("528","0","1","7","Anantapur ","Anantapur ","0","0","0","0");
INSERT INTO city VALUES("529","0","1","7","Andole ","Andole ","0","0","0","0");
INSERT INTO city VALUES("530","0","1","7","Araku ","Araku ","0","0","0","0");
INSERT INTO city VALUES("531","0","1","7","Armoor ","Armoor ","0","0","0","0");
INSERT INTO city VALUES("532","0","1","7","Asifabad ","Asifabad ","0","0","0","0");
INSERT INTO city VALUES("533","0","1","7","Aswaraopet ","Aswaraopet ","0","0","0","0");
INSERT INTO city VALUES("534","0","1","7","Atmakur ","Atmakur ","0","0","0","0");
INSERT INTO city VALUES("535","0","1","7","B. Kothakota ","B. Kothakota ","0","0","0","0");
INSERT INTO city VALUES("536","0","1","7","Badvel ","Badvel ","0","0","0","0");
INSERT INTO city VALUES("537","0","1","7","Banaganapalle ","Banaganapalle ","0","0","0","0");
INSERT INTO city VALUES("538","0","1","7","Bandar ","Bandar ","0","0","0","0");
INSERT INTO city VALUES("539","0","1","7","Bangarupalem ","Bangarupalem ","0","0","0","0");
INSERT INTO city VALUES("540","0","1","7","Banswada ","Banswada ","0","0","0","0");
INSERT INTO city VALUES("541","0","1","7","Bapatla ","Bapatla ","0","0","0","0");
INSERT INTO city VALUES("542","0","1","7","Bellampalli ","Bellampalli ","0","0","0","0");
INSERT INTO city VALUES("543","0","1","7","Bhadrachalam ","Bhadrachalam ","0","0","0","0");
INSERT INTO city VALUES("544","0","1","7","Bhainsa ","Bhainsa ","0","0","0","0");
INSERT INTO city VALUES("545","0","1","7","Bheemunipatnam ","Bheemunipatnam ","0","0","0","0");
INSERT INTO city VALUES("546","0","1","7","Bhimadole ","Bhimadole ","0","0","0","0");
INSERT INTO city VALUES("547","0","1","7","Bhimavaram ","Bhimavaram ","0","0","0","0");
INSERT INTO city VALUES("548","0","1","7","Bhongir ","Bhongir ","0","0","0","0");
INSERT INTO city VALUES("549","0","1","7","Bhooragamphad ","Bhooragamphad ","0","0","0","0");
INSERT INTO city VALUES("550","0","1","7","Boath ","Boath ","0","0","0","0");
INSERT INTO city VALUES("551","0","1","7","Bobbili ","Bobbili ","0","0","0","0");
INSERT INTO city VALUES("552","0","1","7","Bodhan ","Bodhan ","0","0","0","0");
INSERT INTO city VALUES("553","0","1","7","Chandoor ","Chandoor ","0","0","0","0");
INSERT INTO city VALUES("554","0","1","7","Chavitidibbalu ","Chavitidibbalu ","0","0","0","0");
INSERT INTO city VALUES("555","0","1","7","Chejerla ","Chejerla ","0","0","0","0");
INSERT INTO city VALUES("556","0","1","7","Chepurupalli ","Chepurupalli ","0","0","0","0");
INSERT INTO city VALUES("557","0","1","7","Cherial ","Cherial ","0","0","0","0");
INSERT INTO city VALUES("558","0","1","7","Chevella ","Chevella ","0","0","0","0");
INSERT INTO city VALUES("559","0","1","7","Chinnor ","Chinnor ","0","0","0","0");
INSERT INTO city VALUES("560","0","1","7","Chintalapudi ","Chintalapudi ","0","0","0","0");
INSERT INTO city VALUES("561","0","1","7","Chintapalle ","Chintapalle ","0","0","0","0");
INSERT INTO city VALUES("562","0","1","7","Chirala ","Chirala ","0","0","0","0");
INSERT INTO city VALUES("563","0","1","7","Chittoor ","Chittoor ","0","0","0","0");
INSERT INTO city VALUES("564","0","1","7","Chodavaram ","Chodavaram ","0","0","0","0");
INSERT INTO city VALUES("565","0","1","7","Cuddapah ","Cuddapah ","0","0","0","0");
INSERT INTO city VALUES("566","0","1","7","Cumbum ","Cumbum ","0","0","0","0");
INSERT INTO city VALUES("567","0","1","7","Darsi ","Darsi ","0","0","0","0");
INSERT INTO city VALUES("568","0","1","7","Devarakonda ","Devarakonda ","0","0","0","0");
INSERT INTO city VALUES("569","0","1","7","Dharmavaram ","Dharmavaram ","0","0","0","0");
INSERT INTO city VALUES("570","0","1","7","Dichpalli ","Dichpalli ","0","0","0","0");
INSERT INTO city VALUES("571","0","1","7","Divi ","Divi ","0","0","0","0");
INSERT INTO city VALUES("572","0","1","7","Donakonda ","Donakonda ","0","0","0","0");
INSERT INTO city VALUES("573","0","1","7","Dronachalam ","Dronachalam ","0","0","0","0");
INSERT INTO city VALUES("574","0","1","7","East Godavari ","East Godavari ","0","0","0","0");
INSERT INTO city VALUES("575","0","1","7","Eluru ","Eluru ","0","0","0","0");
INSERT INTO city VALUES("576","0","1","7","Eturnagaram ","Eturnagaram ","0","0","0","0");
INSERT INTO city VALUES("577","0","1","7","Gadwal ","Gadwal ","0","0","0","0");
INSERT INTO city VALUES("578","0","1","7","Gajapathinagaram ","Gajapathinagaram ","0","0","0","0");
INSERT INTO city VALUES("579","0","1","7","Gajwel ","Gajwel ","0","0","0","0");
INSERT INTO city VALUES("580","0","1","7","Garladinne ","Garladinne ","0","0","0","0");
INSERT INTO city VALUES("581","0","1","7","Giddalur ","Giddalur ","0","0","0","0");
INSERT INTO city VALUES("582","0","1","7","Godavari ","Godavari ","0","0","0","0");
INSERT INTO city VALUES("583","0","1","7","Gooty ","Gooty ","0","0","0","0");
INSERT INTO city VALUES("584","0","1","7","Gudivada ","Gudivada ","0","0","0","0");
INSERT INTO city VALUES("585","0","1","7","Gudur ","Gudur ","0","0","0","0");
INSERT INTO city VALUES("586","0","1","7","Guntur ","Guntur ","0","0","0","0");
INSERT INTO city VALUES("587","0","1","7","Hindupur ","Hindupur ","0","0","0","0");
INSERT INTO city VALUES("588","0","1","7","Hunsabad ","Hunsabad ","0","0","0","0");
INSERT INTO city VALUES("589","0","1","7","Huzurabad ","Huzurabad ","0","0","0","0");
INSERT INTO city VALUES("590","0","1","7","Huzurnagar ","Huzurnagar ","0","0","0","0");
INSERT INTO city VALUES("591","0","1","7","Hyderabad ","Hyderabad ","0","0","0","0");
INSERT INTO city VALUES("592","0","1","7","Ibrahimpatnam ","Ibrahimpatnam ","0","0","0","0");
INSERT INTO city VALUES("593","0","1","7","Jaggayyapet ","Jaggayyapet ","0","0","0","0");
INSERT INTO city VALUES("594","0","1","7","Jagtial ","Jagtial ","0","0","0","0");
INSERT INTO city VALUES("595","0","1","7","Jammalamadugu ","Jammalamadugu ","0","0","0","0");
INSERT INTO city VALUES("596","0","1","7","Jangaon ","Jangaon ","0","0","0","0");
INSERT INTO city VALUES("597","0","1","7","Jangareddygudem ","Jangareddygudem ","0","0","0","0");
INSERT INTO city VALUES("598","0","1","7","Jannaram ","Jannaram ","0","0","0","0");
INSERT INTO city VALUES("599","0","1","7","Kadiri ","Kadiri ","0","0","0","0");
INSERT INTO city VALUES("600","0","1","7","Kaikaluru ","Kaikaluru ","0","0","0","0");
INSERT INTO city VALUES("601","0","1","7","Kakinada ","Kakinada ","0","0","0","0");
INSERT INTO city VALUES("602","0","1","7","Kalwakurthy ","Kalwakurthy ","0","0","0","0");
INSERT INTO city VALUES("603","0","1","7","Kalyandurg ","Kalyandurg ","0","0","0","0");
INSERT INTO city VALUES("604","0","1","7","Kamalapuram ","Kamalapuram ","0","0","0","0");
INSERT INTO city VALUES("605","0","1","7","Kamareddy ","Kamareddy ","0","0","0","0");
INSERT INTO city VALUES("606","0","1","7","Kambadur ","Kambadur ","0","0","0","0");
INSERT INTO city VALUES("607","0","1","7","Kanaganapalle ","Kanaganapalle ","0","0","0","0");
INSERT INTO city VALUES("608","0","1","7","Kandukuru ","Kandukuru ","0","0","0","0");
INSERT INTO city VALUES("609","0","1","7","Kanigiri ","Kanigiri ","0","0","0","0");
INSERT INTO city VALUES("610","0","1","7","Karimnagar ","Karimnagar ","0","0","0","0");
INSERT INTO city VALUES("611","0","1","7","Kavali ","Kavali ","0","0","0","0");
INSERT INTO city VALUES("612","0","1","7","Khammam ","Khammam ","0","0","0","0");
INSERT INTO city VALUES("613","0","1","7","Khanapur (AP) ","Khanapur (AP) ","0","0","0","0");
INSERT INTO city VALUES("614","0","1","7","Kodangal ","Kodangal ","0","0","0","0");
INSERT INTO city VALUES("615","0","1","7","Koduru ","Koduru ","0","0","0","0");
INSERT INTO city VALUES("616","0","1","7","Koilkuntla ","Koilkuntla ","0","0","0","0");
INSERT INTO city VALUES("617","0","1","7","Kollapur ","Kollapur ","0","0","0","0");
INSERT INTO city VALUES("618","0","1","7","Kothagudem ","Kothagudem ","0","0","0","0");
INSERT INTO city VALUES("619","0","1","7","Kovvur ","Kovvur ","0","0","0","0");
INSERT INTO city VALUES("620","0","1","7","Krishna ","Krishna ","0","0","0","0");
INSERT INTO city VALUES("621","0","1","7","Krosuru ","Krosuru ","0","0","0","0");
INSERT INTO city VALUES("622","0","1","7","Kuppam ","Kuppam ","0","0","0","0");
INSERT INTO city VALUES("623","0","1","7","Kurnool ","Kurnool ","0","0","0","0");
INSERT INTO city VALUES("624","0","1","7","Lakkireddipalli ","Lakkireddipalli ","0","0","0","0");
INSERT INTO city VALUES("625","0","1","7","Madakasira ","Madakasira ","0","0","0","0");
INSERT INTO city VALUES("626","0","1","7","Madanapalli ","Madanapalli ","0","0","0","0");
INSERT INTO city VALUES("627","0","1","7","Madhira ","Madhira ","0","0","0","0");
INSERT INTO city VALUES("628","0","1","7","Madnur ","Madnur ","0","0","0","0");
INSERT INTO city VALUES("629","0","1","7","Mahabubabad ","Mahabubabad ","0","0","0","0");
INSERT INTO city VALUES("630","0","1","7","Mahabubnagar ","Mahabubnagar ","0","0","0","0");
INSERT INTO city VALUES("631","0","1","7","Mahadevapur ","Mahadevapur ","0","0","0","0");
INSERT INTO city VALUES("632","0","1","7","Makthal ","Makthal ","0","0","0","0");
INSERT INTO city VALUES("633","0","1","7","Mancherial ","Mancherial ","0","0","0","0");
INSERT INTO city VALUES("634","0","1","7","Mandapeta ","Mandapeta ","0","0","0","0");
INSERT INTO city VALUES("635","0","1","7","Mangalagiri ","Mangalagiri ","0","0","0","0");
INSERT INTO city VALUES("636","0","1","7","Manthani ","Manthani ","0","0","0","0");
INSERT INTO city VALUES("637","0","1","7","Markapur ","Markapur ","0","0","0","0");
INSERT INTO city VALUES("638","0","1","7","Marturu ","Marturu ","0","0","0","0");
INSERT INTO city VALUES("639","0","1","7","Medachal ","Medachal ","0","0","0","0");
INSERT INTO city VALUES("640","0","1","7","Medak ","Medak ","0","0","0","0");
INSERT INTO city VALUES("641","0","1","7","Medarmetla ","Medarmetla ","0","0","0","0");
INSERT INTO city VALUES("642","0","1","7","Metpalli ","Metpalli ","0","0","0","0");
INSERT INTO city VALUES("643","0","1","7","Mriyalguda ","Mriyalguda ","0","0","0","0");
INSERT INTO city VALUES("644","0","1","7","Mulug ","Mulug ","0","0","0","0");
INSERT INTO city VALUES("645","0","1","7","Mylavaram ","Mylavaram ","0","0","0","0");
INSERT INTO city VALUES("646","0","1","7","Nagarkurnool ","Nagarkurnool ","0","0","0","0");
INSERT INTO city VALUES("647","0","1","7","Nalgonda ","Nalgonda ","0","0","0","0");
INSERT INTO city VALUES("648","0","1","7","Nallacheruvu ","Nallacheruvu ","0","0","0","0");
INSERT INTO city VALUES("649","0","1","7","Nampalle ","Nampalle ","0","0","0","0");
INSERT INTO city VALUES("650","0","1","7","Nandigama ","Nandigama ","0","0","0","0");
INSERT INTO city VALUES("651","0","1","7","Nandikotkur ","Nandikotkur ","0","0","0","0");
INSERT INTO city VALUES("652","0","1","7","Nandyal ","Nandyal ","0","0","0","0");
INSERT INTO city VALUES("653","0","1","7","Narasampet ","Narasampet ","0","0","0","0");
INSERT INTO city VALUES("654","0","1","7","Narasaraopet ","Narasaraopet ","0","0","0","0");
INSERT INTO city VALUES("655","0","1","7","Narayanakhed ","Narayanakhed ","0","0","0","0");
INSERT INTO city VALUES("656","0","1","7","Narayanpet ","Narayanpet ","0","0","0","0");
INSERT INTO city VALUES("657","0","1","7","Narsapur ","Narsapur ","0","0","0","0");
INSERT INTO city VALUES("658","0","1","7","Narsipatnam ","Narsipatnam ","0","0","0","0");
INSERT INTO city VALUES("659","0","1","7","Nazvidu ","Nazvidu ","0","0","0","0");
INSERT INTO city VALUES("660","0","1","7","Nelloe ","Nelloe ","0","0","0","0");
INSERT INTO city VALUES("661","0","1","7","Nellore ","Nellore ","0","0","0","0");
INSERT INTO city VALUES("662","0","1","7","Nidamanur ","Nidamanur ","0","0","0","0");
INSERT INTO city VALUES("663","0","1","7","Nirmal ","Nirmal ","0","0","0","0");
INSERT INTO city VALUES("664","0","1","7","Nizamabad ","Nizamabad ","0","0","0","0");
INSERT INTO city VALUES("665","0","1","7","Nuguru ","Nuguru ","0","0","0","0");
INSERT INTO city VALUES("666","0","1","7","Ongole ","Ongole ","0","0","0","0");
INSERT INTO city VALUES("667","0","1","7","Outsarangapalle ","Outsarangapalle ","0","0","0","0");
INSERT INTO city VALUES("668","0","1","7","Paderu ","Paderu ","0","0","0","0");
INSERT INTO city VALUES("669","0","1","7","Pakala ","Pakala ","0","0","0","0");
INSERT INTO city VALUES("670","0","1","7","Palakonda ","Palakonda ","0","0","0","0");
INSERT INTO city VALUES("671","0","1","7","Paland ","Paland ","0","0","0","0");
INSERT INTO city VALUES("672","0","1","7","Palmaneru ","Palmaneru ","0","0","0","0");
INSERT INTO city VALUES("673","0","1","7","Pamuru ","Pamuru ","0","0","0","0");
INSERT INTO city VALUES("674","0","1","7","Pargi ","Pargi ","0","0","0","0");
INSERT INTO city VALUES("675","0","1","7","Parkal ","Parkal ","0","0","0","0");
INSERT INTO city VALUES("676","0","1","7","Parvathipuram ","Parvathipuram ","0","0","0","0");
INSERT INTO city VALUES("677","0","1","7","Pathapatnam ","Pathapatnam ","0","0","0","0");
INSERT INTO city VALUES("678","0","1","7","Pattikonda ","Pattikonda ","0","0","0","0");
INSERT INTO city VALUES("679","0","1","7","Peapalle ","Peapalle ","0","0","0","0");
INSERT INTO city VALUES("680","0","1","7","Peddapalli ","Peddapalli ","0","0","0","0");
INSERT INTO city VALUES("681","0","1","7","Peddapuram ","Peddapuram ","0","0","0","0");
INSERT INTO city VALUES("682","0","1","7","Penukonda ","Penukonda ","0","0","0","0");
INSERT INTO city VALUES("683","0","1","7","Piduguralla ","Piduguralla ","0","0","0","0");
INSERT INTO city VALUES("684","0","1","7","Piler ","Piler ","0","0","0","0");
INSERT INTO city VALUES("685","0","1","7","Pithapuram ","Pithapuram ","0","0","0","0");
INSERT INTO city VALUES("686","0","1","7","Podili ","Podili ","0","0","0","0");
INSERT INTO city VALUES("687","0","1","7","Polavaram ","Polavaram ","0","0","0","0");
INSERT INTO city VALUES("688","0","1","7","Prakasam ","Prakasam ","0","0","0","0");
INSERT INTO city VALUES("689","0","1","7","Proddatur ","Proddatur ","0","0","0","0");
INSERT INTO city VALUES("690","0","1","7","Pulivendla ","Pulivendla ","0","0","0","0");
INSERT INTO city VALUES("691","0","1","7","Punganur ","Punganur ","0","0","0","0");
INSERT INTO city VALUES("692","0","1","7","Putturu ","Putturu ","0","0","0","0");
INSERT INTO city VALUES("693","0","1","7","Rajahmundri ","Rajahmundri ","0","0","0","0");
INSERT INTO city VALUES("694","0","1","7","Rajampeta ","Rajampeta ","0","0","0","0");
INSERT INTO city VALUES("695","0","1","7","Ramachandrapuram ","Ramachandrapuram ","0","0","0","0");
INSERT INTO city VALUES("696","0","1","7","Ramannapet ","Ramannapet ","0","0","0","0");
INSERT INTO city VALUES("697","0","1","7","Rampachodavaram ","Rampachodavaram ","0","0","0","0");
INSERT INTO city VALUES("698","0","1","7","Rangareddy ","Rangareddy ","0","0","0","0");
INSERT INTO city VALUES("699","0","1","7","Rapur ","Rapur ","0","0","0","0");
INSERT INTO city VALUES("700","0","1","7","Rayachoti ","Rayachoti ","0","0","0","0");
INSERT INTO city VALUES("701","0","1","7","Rayadurg ","Rayadurg ","0","0","0","0");
INSERT INTO city VALUES("702","0","1","7","Razole ","Razole ","0","0","0","0");
INSERT INTO city VALUES("703","0","1","7","Repalle ","Repalle ","0","0","0","0");
INSERT INTO city VALUES("704","0","1","7","Saluru ","Saluru ","0","0","0","0");
INSERT INTO city VALUES("705","0","1","7","Sangareddy ","Sangareddy ","0","0","0","0");
INSERT INTO city VALUES("706","0","1","7","Sathupalli ","Sathupalli ","0","0","0","0");
INSERT INTO city VALUES("707","0","1","7","Sattenapalle ","Sattenapalle ","0","0","0","0");
INSERT INTO city VALUES("708","0","1","7","Satyavedu ","Satyavedu ","0","0","0","0");
INSERT INTO city VALUES("709","0","1","7","Shadnagar ","Shadnagar ","0","0","0","0");
INSERT INTO city VALUES("710","0","1","7","Siddavattam ","Siddavattam ","0","0","0","0");
INSERT INTO city VALUES("711","0","1","7","Siddipet ","Siddipet ","0","0","0","0");
INSERT INTO city VALUES("712","0","1","7","Sileru ","Sileru ","0","0","0","0");
INSERT INTO city VALUES("713","0","1","7","Sircilla ","Sircilla ","0","0","0","0");
INSERT INTO city VALUES("714","0","1","7","Sirpur Kagaznagar ","Sirpur Kagaznagar ","0","0","0","0");
INSERT INTO city VALUES("715","0","1","7","Sodam ","Sodam ","0","0","0","0");
INSERT INTO city VALUES("716","0","1","7","Sompeta ","Sompeta ","0","0","0","0");
INSERT INTO city VALUES("717","0","1","7","Srikakulam ","Srikakulam ","0","0","0","0");
INSERT INTO city VALUES("718","0","1","7","Srikalahasthi ","Srikalahasthi ","0","0","0","0");
INSERT INTO city VALUES("719","0","1","7","Srisailam ","Srisailam ","0","0","0","0");
INSERT INTO city VALUES("720","0","1","7","Srungavarapukota ","Srungavarapukota ","0","0","0","0");
INSERT INTO city VALUES("721","0","1","7","Sudhimalla ","Sudhimalla ","0","0","0","0");
INSERT INTO city VALUES("722","0","1","7","Sullarpet ","Sullarpet ","0","0","0","0");
INSERT INTO city VALUES("723","0","1","7","Tadepalligudem ","Tadepalligudem ","0","0","0","0");
INSERT INTO city VALUES("724","0","1","7","Tadipatri ","Tadipatri ","0","0","0","0");
INSERT INTO city VALUES("725","0","1","7","Tanduru ","Tanduru ","0","0","0","0");
INSERT INTO city VALUES("726","0","1","7","Tanuku ","Tanuku ","0","0","0","0");
INSERT INTO city VALUES("727","0","1","7","Tekkali ","Tekkali ","0","0","0","0");
INSERT INTO city VALUES("728","0","1","7","Tenali ","Tenali ","0","0","0","0");
INSERT INTO city VALUES("729","0","1","7","Thungaturthy ","Thungaturthy ","0","0","0","0");
INSERT INTO city VALUES("730","0","1","7","Tirivuru ","Tirivuru ","0","0","0","0");
INSERT INTO city VALUES("731","0","1","7","Tirupathi ","Tirupathi ","0","0","0","0");
INSERT INTO city VALUES("732","0","1","7","Tuni ","Tuni ","0","0","0","0");
INSERT INTO city VALUES("733","0","1","7","Udaygiri ","Udaygiri ","0","0","0","0");
INSERT INTO city VALUES("734","0","1","7","Ulvapadu ","Ulvapadu ","0","0","0","0");
INSERT INTO city VALUES("735","0","1","7","Uravakonda ","Uravakonda ","0","0","0","0");
INSERT INTO city VALUES("736","0","1","7","Utnor ","Utnor ","0","0","0","0");
INSERT INTO city VALUES("737","0","1","7","V.R. Puram ","V.R. Puram ","0","0","0","0");
INSERT INTO city VALUES("738","0","1","7","Vaimpalli ","Vaimpalli ","0","0","0","0");
INSERT INTO city VALUES("739","0","1","7","Vayalpad ","Vayalpad ","0","0","0","0");
INSERT INTO city VALUES("740","0","1","7","Venkatgiri ","Venkatgiri ","0","0","0","0");
INSERT INTO city VALUES("741","0","1","7","Venkatgirikota ","Venkatgirikota ","0","0","0","0");
INSERT INTO city VALUES("742","0","1","7","Vijayawada ","Vijayawada ","0","0","0","0");
INSERT INTO city VALUES("743","0","1","7","Vikrabad ","Vikrabad ","0","0","0","0");
INSERT INTO city VALUES("744","0","1","7","Vinjamuru ","Vinjamuru ","0","0","0","0");
INSERT INTO city VALUES("745","0","1","7","Vinukonda ","Vinukonda ","0","0","0","0");
INSERT INTO city VALUES("746","0","1","7","Visakhapatnam ","Visakhapatnam ","0","0","0","0");
INSERT INTO city VALUES("747","0","1","7","Vizayanagaram ","Vizayanagaram ","0","0","0","0");
INSERT INTO city VALUES("748","0","1","7","Vizianagaram ","Vizianagaram ","0","0","0","0");
INSERT INTO city VALUES("749","0","1","7","Vuyyuru ","Vuyyuru ","0","0","0","0");
INSERT INTO city VALUES("750","0","1","7","Wanaparthy ","Wanaparthy ","0","0","0","0");
INSERT INTO city VALUES("751","0","1","7","Warangal ","Warangal ","0","0","0","0");
INSERT INTO city VALUES("752","0","1","7","Wardhannapet ","Wardhannapet ","0","0","0","0");
INSERT INTO city VALUES("753","0","1","7","Yelamanchili ","Yelamanchili ","0","0","0","0");
INSERT INTO city VALUES("754","0","1","7","Yelavaram ","Yelavaram ","0","0","0","0");
INSERT INTO city VALUES("755","0","1","7","Yeleswaram ","Yeleswaram ","0","0","0","0");
INSERT INTO city VALUES("756","0","1","7","Yellandu ","Yellandu ","0","0","0","0");
INSERT INTO city VALUES("757","0","1","7","Yellanuru ","Yellanuru ","0","0","0","0");
INSERT INTO city VALUES("758","0","1","7","Yellareddy ","Yellareddy ","0","0","0","0");
INSERT INTO city VALUES("759","0","1","7","Yerragondapalem ","Yerragondapalem ","0","0","0","0");
INSERT INTO city VALUES("760","0","1","7","Zahirabad","Zahirabad","0","0","0","0");
INSERT INTO city VALUES("761","0","1","8","Adampur Mandi ","Adampur Mandi ","0","0","0","0");
INSERT INTO city VALUES("762","0","1","8","Ambala ","Ambala ","0","0","0","0");
INSERT INTO city VALUES("763","0","1","8","Assandh ","Assandh ","0","0","0","0");
INSERT INTO city VALUES("764","0","1","8","Bahadurgarh ","Bahadurgarh ","0","0","0","0");
INSERT INTO city VALUES("765","0","1","8","Barara ","Barara ","0","0","0","0");
INSERT INTO city VALUES("766","0","1","8","Barwala ","Barwala ","0","0","0","0");
INSERT INTO city VALUES("767","0","1","8","Bawal ","Bawal ","0","0","0","0");
INSERT INTO city VALUES("768","0","1","8","Bawanikhera ","Bawanikhera ","0","0","0","0");
INSERT INTO city VALUES("769","0","1","8","Bhiwani ","Bhiwani ","0","0","0","0");
INSERT INTO city VALUES("770","0","1","8","Charkhidadri ","Charkhidadri ","0","0","0","0");
INSERT INTO city VALUES("771","0","1","8","Cheeka ","Cheeka ","0","0","0","0");
INSERT INTO city VALUES("772","0","1","8","Chhachrauli ","Chhachrauli ","0","0","0","0");
INSERT INTO city VALUES("773","0","1","8","Dabwali ","Dabwali ","0","0","0","0");
INSERT INTO city VALUES("774","0","1","8","Ellenabad ","Ellenabad ","0","0","0","0");
INSERT INTO city VALUES("775","0","1","8","Faridabad ","Faridabad ","0","0","0","0");
INSERT INTO city VALUES("776","0","1","8","Fatehabad ","Fatehabad ","0","0","0","0");
INSERT INTO city VALUES("777","0","1","8","Ferojpur Jhirka ","Ferojpur Jhirka ","0","0","0","0");
INSERT INTO city VALUES("778","0","1","8","Gharaunda ","Gharaunda ","0","0","0","0");
INSERT INTO city VALUES("779","0","1","8","Gohana ","Gohana ","0","0","0","0");
INSERT INTO city VALUES("780","0","1","8","Gurgaon ","Gurgaon ","0","0","0","0");
INSERT INTO city VALUES("781","0","1","8","Hansi ","Hansi ","0","0","0","0");
INSERT INTO city VALUES("782","0","1","8","Hisar ","Hisar ","0","0","0","0");
INSERT INTO city VALUES("783","0","1","8","Jagadhari ","Jagadhari ","0","0","0","0");
INSERT INTO city VALUES("784","0","1","8","Jatusana ","Jatusana ","0","0","0","0");
INSERT INTO city VALUES("785","0","1","8","Jhajjar ","Jhajjar ","0","0","0","0");
INSERT INTO city VALUES("786","0","1","8","Jind ","Jind ","0","0","0","0");
INSERT INTO city VALUES("787","0","1","8","Julana ","Julana ","0","0","0","0");
INSERT INTO city VALUES("788","0","1","8","Kaithal ","Kaithal ","0","0","0","0");
INSERT INTO city VALUES("789","0","1","8","Kalanaur ","Kalanaur ","0","0","0","0");
INSERT INTO city VALUES("790","0","1","8","Kalanwali ","Kalanwali ","0","0","0","0");
INSERT INTO city VALUES("791","0","1","8","Kalka ","Kalka ","0","0","0","0");
INSERT INTO city VALUES("792","0","1","8","Karnal ","Karnal ","0","0","0","0");
INSERT INTO city VALUES("793","0","1","8","Kosli ","Kosli ","0","0","0","0");
INSERT INTO city VALUES("794","0","1","8","Kurukshetra ","Kurukshetra ","0","0","0","0");
INSERT INTO city VALUES("795","0","1","8","Loharu ","Loharu ","0","0","0","0");
INSERT INTO city VALUES("796","0","1","8","Mahendragarh ","Mahendragarh ","0","0","0","0");
INSERT INTO city VALUES("797","0","1","8","Meham ","Meham ","0","0","0","0");
INSERT INTO city VALUES("798","0","1","8","Mewat ","Mewat ","0","0","0","0");
INSERT INTO city VALUES("799","0","1","8","Mohindergarh ","Mohindergarh ","0","0","0","0");
INSERT INTO city VALUES("800","0","1","8","Naraingarh ","Naraingarh ","0","0","0","0");
INSERT INTO city VALUES("801","0","1","8","Narnaul ","Narnaul ","0","0","0","0");
INSERT INTO city VALUES("802","0","1","8","Narwana ","Narwana ","0","0","0","0");
INSERT INTO city VALUES("803","0","1","8","Nilokheri ","Nilokheri ","0","0","0","0");
INSERT INTO city VALUES("804","0","1","8","Nuh ","Nuh ","0","0","0","0");
INSERT INTO city VALUES("805","0","1","8","Palwal ","Palwal ","0","0","0","0");
INSERT INTO city VALUES("806","0","1","8","Panchkula ","Panchkula ","0","0","0","0");
INSERT INTO city VALUES("807","0","1","8","Panipat ","Panipat ","0","0","0","0");
INSERT INTO city VALUES("808","0","1","8","Pehowa ","Pehowa ","0","0","0","0");
INSERT INTO city VALUES("809","0","1","8","Ratia ","Ratia ","0","0","0","0");
INSERT INTO city VALUES("810","0","1","8","Rewari ","Rewari ","0","0","0","0");
INSERT INTO city VALUES("811","0","1","8","Rohtak ","Rohtak ","0","0","0","0");
INSERT INTO city VALUES("812","0","1","8","Safidon ","Safidon ","0","0","0","0");
INSERT INTO city VALUES("813","0","1","8","Sirsa ","Sirsa ","0","0","0","0");
INSERT INTO city VALUES("814","0","1","8","Siwani ","Siwani ","0","0","0","0");
INSERT INTO city VALUES("815","0","1","8","Sonipat ","Sonipat ","0","0","0","0");
INSERT INTO city VALUES("816","0","1","8","Tohana ","Tohana ","0","0","0","0");
INSERT INTO city VALUES("817","0","1","8","Tohsam ","Tohsam ","0","0","0","0");
INSERT INTO city VALUES("818","0","1","8","Yamunanagar ","Yamunanagar ","0","0","0","0");
INSERT INTO city VALUES("819","0","1","9","Amb ","Amb ","0","0","0","0");
INSERT INTO city VALUES("820","0","1","9","Arki ","Arki ","0","0","0","0");
INSERT INTO city VALUES("821","0","1","9","Banjar ","Banjar ","0","0","0","0");
INSERT INTO city VALUES("822","0","1","9","Bharmour ","Bharmour ","0","0","0","0");
INSERT INTO city VALUES("823","0","1","9","Bilaspur ","Bilaspur ","0","0","0","0");
INSERT INTO city VALUES("824","0","1","9","Chamba ","Chamba ","0","0","0","0");
INSERT INTO city VALUES("825","0","1","9","Churah ","Churah ","0","0","0","0");
INSERT INTO city VALUES("826","0","1","9","Dalhousie ","Dalhousie ","0","0","0","0");
INSERT INTO city VALUES("827","0","1","9","Dehra Gopipur ","Dehra Gopipur ","0","0","0","0");
INSERT INTO city VALUES("828","0","1","9","Hamirpur ","Hamirpur ","0","0","0","0");
INSERT INTO city VALUES("829","0","1","9","Jogindernagar ","Jogindernagar ","0","0","0","0");
INSERT INTO city VALUES("830","0","1","9","Kalpa ","Kalpa ","0","0","0","0");
INSERT INTO city VALUES("831","0","1","9","Kangra ","Kangra ","0","0","0","0");
INSERT INTO city VALUES("832","0","1","9","Kinnaur ","Kinnaur ","0","0","0","0");
INSERT INTO city VALUES("833","0","1","9","Kullu ","Kullu ","0","0","0","0");
INSERT INTO city VALUES("834","0","1","9","Lahaul ","Lahaul ","0","0","0","0");
INSERT INTO city VALUES("835","0","1","9","Mandi ","Mandi ","0","0","0","0");
INSERT INTO city VALUES("836","0","1","9","Nahan ","Nahan ","0","0","0","0");
INSERT INTO city VALUES("837","0","1","9","Nalagarh ","Nalagarh ","0","0","0","0");
INSERT INTO city VALUES("838","0","1","9","Nirmand ","Nirmand ","0","0","0","0");
INSERT INTO city VALUES("839","0","1","9","Nurpur ","Nurpur ","0","0","0","0");
INSERT INTO city VALUES("840","0","1","9","Palampur ","Palampur ","0","0","0","0");
INSERT INTO city VALUES("841","0","1","9","Pangi ","Pangi ","0","0","0","0");
INSERT INTO city VALUES("842","0","1","9","Paonta ","Paonta ","0","0","0","0");
INSERT INTO city VALUES("843","0","1","9","Pooh ","Pooh ","0","0","0","0");
INSERT INTO city VALUES("844","0","1","9","Rajgarh ","Rajgarh ","0","0","0","0");
INSERT INTO city VALUES("845","0","1","9","Rampur Bushahar ","Rampur Bushahar ","0","0","0","0");
INSERT INTO city VALUES("846","0","1","9","Rohru ","Rohru ","0","0","0","0");
INSERT INTO city VALUES("847","0","1","9","Shimla ","Shimla ","0","0","0","0");
INSERT INTO city VALUES("848","0","1","9","Sirmaur ","Sirmaur ","0","0","0","0");
INSERT INTO city VALUES("849","0","1","9","Solan ","Solan ","0","0","0","0");
INSERT INTO city VALUES("850","0","1","9","Spiti ","Spiti ","0","0","0","0");
INSERT INTO city VALUES("851","0","1","9","Sundernagar ","Sundernagar ","0","0","0","0");
INSERT INTO city VALUES("852","0","1","9","Theog ","Theog ","0","0","0","0");
INSERT INTO city VALUES("853","0","1","9","Udaipur ","Udaipur ","0","0","0","0");
INSERT INTO city VALUES("854","0","1","9","Una","Una","0","0","0","0");
INSERT INTO city VALUES("855","0","1","10","Akhnoor ","Akhnoor ","0","0","0","0");
INSERT INTO city VALUES("856","0","1","10","Anantnag ","Anantnag ","0","0","0","0");
INSERT INTO city VALUES("857","0","1","10","Badgam ","Badgam ","0","0","0","0");
INSERT INTO city VALUES("858","0","1","10","Bandipur ","Bandipur ","0","0","0","0");
INSERT INTO city VALUES("859","0","1","10","Baramulla ","Baramulla ","0","0","0","0");
INSERT INTO city VALUES("860","0","1","10","Basholi ","Basholi ","0","0","0","0");
INSERT INTO city VALUES("861","0","1","10","Bedarwah ","Bedarwah ","0","0","0","0");
INSERT INTO city VALUES("862","0","1","10","Budgam ","Budgam ","0","0","0","0");
INSERT INTO city VALUES("863","0","1","10","Doda ","Doda ","0","0","0","0");
INSERT INTO city VALUES("864","0","1","10","Gulmarg ","Gulmarg ","0","0","0","0");
INSERT INTO city VALUES("865","0","1","10","Jammu ","Jammu ","0","0","0","0");
INSERT INTO city VALUES("866","0","1","10","Kalakot ","Kalakot ","0","0","0","0");
INSERT INTO city VALUES("867","0","1","10","Kargil ","Kargil ","0","0","0","0");
INSERT INTO city VALUES("868","0","1","10","Karnah ","Karnah ","0","0","0","0");
INSERT INTO city VALUES("869","0","1","10","Kathua ","Kathua ","0","0","0","0");
INSERT INTO city VALUES("870","0","1","10","Kishtwar ","Kishtwar ","0","0","0","0");
INSERT INTO city VALUES("871","0","1","10","Kulgam ","Kulgam ","0","0","0","0");
INSERT INTO city VALUES("872","0","1","10","Kupwara ","Kupwara ","0","0","0","0");
INSERT INTO city VALUES("873","0","1","10","Leh ","Leh ","0","0","0","0");
INSERT INTO city VALUES("874","0","1","10","Mahore ","Mahore ","0","0","0","0");
INSERT INTO city VALUES("875","0","1","10","Nagrota ","Nagrota ","0","0","0","0");
INSERT INTO city VALUES("876","0","1","10","Nobra ","Nobra ","0","0","0","0");
INSERT INTO city VALUES("877","0","1","10","Nowshera ","Nowshera ","0","0","0","0");
INSERT INTO city VALUES("878","0","1","10","Nyoma ","Nyoma ","0","0","0","0");
INSERT INTO city VALUES("879","0","1","10","Padam ","Padam ","0","0","0","0");
INSERT INTO city VALUES("880","0","1","10","Pahalgam ","Pahalgam ","0","0","0","0");
INSERT INTO city VALUES("881","0","1","10","Patnitop ","Patnitop ","0","0","0","0");
INSERT INTO city VALUES("882","0","1","10","Poonch ","Poonch ","0","0","0","0");
INSERT INTO city VALUES("883","0","1","10","Pulwama ","Pulwama ","0","0","0","0");
INSERT INTO city VALUES("884","0","1","10","Rajouri ","Rajouri ","0","0","0","0");
INSERT INTO city VALUES("885","0","1","10","Ramban ","Ramban ","0","0","0","0");
INSERT INTO city VALUES("886","0","1","10","Ramnagar ","Ramnagar ","0","0","0","0");
INSERT INTO city VALUES("887","0","1","10","Reasi ","Reasi ","0","0","0","0");
INSERT INTO city VALUES("888","0","1","10","Samba ","Samba ","0","0","0","0");
INSERT INTO city VALUES("889","0","1","10","Srinagar ","Srinagar ","0","0","0","0");
INSERT INTO city VALUES("890","0","1","10","Udhampur ","Udhampur ","0","0","0","0");
INSERT INTO city VALUES("891","0","1","10","Vaishno Devi ","Vaishno Devi ","0","0","0","0");
INSERT INTO city VALUES("892","0","1","11","Bagodar ","Bagodar ","0","0","0","0");
INSERT INTO city VALUES("893","0","1","11","Baharagora ","Baharagora ","0","0","0","0");
INSERT INTO city VALUES("894","0","1","11","Balumath ","Balumath ","0","0","0","0");
INSERT INTO city VALUES("895","0","1","11","Barhi ","Barhi ","0","0","0","0");
INSERT INTO city VALUES("896","0","1","11","Barkagaon ","Barkagaon ","0","0","0","0");
INSERT INTO city VALUES("897","0","1","11","Barwadih ","Barwadih ","0","0","0","0");
INSERT INTO city VALUES("898","0","1","11","Basia ","Basia ","0","0","0","0");
INSERT INTO city VALUES("899","0","1","11","Bermo ","Bermo ","0","0","0","0");
INSERT INTO city VALUES("900","0","1","11","Bhandaria ","Bhandaria ","0","0","0","0");
INSERT INTO city VALUES("901","0","1","11","Bhawanathpur ","Bhawanathpur ","0","0","0","0");
INSERT INTO city VALUES("902","0","1","11","Bishrampur ","Bishrampur ","0","0","0","0");
INSERT INTO city VALUES("903","0","1","11","Bokaro ","Bokaro ","0","0","0","0");
INSERT INTO city VALUES("904","0","1","11","Bolwa ","Bolwa ","0","0","0","0");
INSERT INTO city VALUES("905","0","1","11","Bundu ","Bundu ","0","0","0","0");
INSERT INTO city VALUES("906","0","1","11","Chaibasa ","Chaibasa ","0","0","0","0");
INSERT INTO city VALUES("907","0","1","11","Chainpur ","Chainpur ","0","0","0","0");
INSERT INTO city VALUES("908","0","1","11","Chakardharpur ","Chakardharpur ","0","0","0","0");
INSERT INTO city VALUES("909","0","1","11","Chandil ","Chandil ","0","0","0","0");
INSERT INTO city VALUES("910","0","1","11","Chatra ","Chatra ","0","0","0","0");
INSERT INTO city VALUES("911","0","1","11","Chavparan ","Chavparan ","0","0","0","0");
INSERT INTO city VALUES("912","0","1","11","Daltonganj ","Daltonganj ","0","0","0","0");
INSERT INTO city VALUES("913","0","1","11","Deoghar ","Deoghar ","0","0","0","0");
INSERT INTO city VALUES("914","0","1","11","Dhanbad ","Dhanbad ","0","0","0","0");
INSERT INTO city VALUES("915","0","1","11","Dumka ","Dumka ","0","0","0","0");
INSERT INTO city VALUES("916","0","1","11","Dumri ","Dumri ","0","0","0","0");
INSERT INTO city VALUES("917","0","1","11","Garhwa ","Garhwa ","0","0","0","0");
INSERT INTO city VALUES("918","0","1","11","Garu ","Garu ","0","0","0","0");
INSERT INTO city VALUES("919","0","1","11","Ghaghra ","Ghaghra ","0","0","0","0");
INSERT INTO city VALUES("920","0","1","11","Ghatsila ","Ghatsila ","0","0","0","0");
INSERT INTO city VALUES("921","0","1","11","Giridih ","Giridih ","0","0","0","0");
INSERT INTO city VALUES("922","0","1","11","Godda ","Godda ","0","0","0","0");
INSERT INTO city VALUES("923","0","1","11","Gomia ","Gomia ","0","0","0","0");
INSERT INTO city VALUES("924","0","1","11","Govindpur ","Govindpur ","0","0","0","0");
INSERT INTO city VALUES("925","0","1","11","Gumla ","Gumla ","0","0","0","0");
INSERT INTO city VALUES("926","0","1","11","Hazaribagh ","Hazaribagh ","0","0","0","0");
INSERT INTO city VALUES("927","0","1","11","Hunterganj ","Hunterganj ","0","0","0","0");
INSERT INTO city VALUES("928","0","1","11","Ichak ","Ichak ","0","0","0","0");
INSERT INTO city VALUES("929","0","1","11","Itki ","Itki ","0","0","0","0");
INSERT INTO city VALUES("930","0","1","11","Jagarnathpur ","Jagarnathpur ","0","0","0","0");
INSERT INTO city VALUES("931","0","1","11","Jamshedpur ","Jamshedpur ","0","0","0","0");
INSERT INTO city VALUES("932","0","1","11","Jamtara ","Jamtara ","0","0","0","0");
INSERT INTO city VALUES("933","0","1","11","Japla ","Japla ","0","0","0","0");
INSERT INTO city VALUES("934","0","1","11","Jharmundi ","Jharmundi ","0","0","0","0");
INSERT INTO city VALUES("935","0","1","11","Jhinkpani ","Jhinkpani ","0","0","0","0");
INSERT INTO city VALUES("936","0","1","11","Jhumaritalaiya ","Jhumaritalaiya ","0","0","0","0");
INSERT INTO city VALUES("937","0","1","11","Kathikund ","Kathikund ","0","0","0","0");
INSERT INTO city VALUES("938","0","1","11","Kharsawa ","Kharsawa ","0","0","0","0");
INSERT INTO city VALUES("939","0","1","11","Khunti ","Khunti ","0","0","0","0");
INSERT INTO city VALUES("940","0","1","11","Koderma ","Koderma ","0","0","0","0");
INSERT INTO city VALUES("941","0","1","11","Kolebira ","Kolebira ","0","0","0","0");
INSERT INTO city VALUES("942","0","1","11","Latehar ","Latehar ","0","0","0","0");
INSERT INTO city VALUES("943","0","1","11","Lohardaga ","Lohardaga ","0","0","0","0");
INSERT INTO city VALUES("944","0","1","11","Madhupur ","Madhupur ","0","0","0","0");
INSERT INTO city VALUES("945","0","1","11","Mahagama ","Mahagama ","0","0","0","0");
INSERT INTO city VALUES("946","0","1","11","Maheshpur Raj ","Maheshpur Raj ","0","0","0","0");
INSERT INTO city VALUES("947","0","1","11","Mandar ","Mandar ","0","0","0","0");
INSERT INTO city VALUES("948","0","1","11","Mandu ","Mandu ","0","0","0","0");
INSERT INTO city VALUES("949","0","1","11","Manoharpur ","Manoharpur ","0","0","0","0");
INSERT INTO city VALUES("950","0","1","11","Muri ","Muri ","0","0","0","0");
INSERT INTO city VALUES("951","0","1","11","Nagarutatri ","Nagarutatri ","0","0","0","0");
INSERT INTO city VALUES("952","0","1","11","Nala ","Nala ","0","0","0","0");
INSERT INTO city VALUES("953","0","1","11","Noamundi ","Noamundi ","0","0","0","0");
INSERT INTO city VALUES("954","0","1","11","Pakur ","Pakur ","0","0","0","0");
INSERT INTO city VALUES("955","0","1","11","Palamu ","Palamu ","0","0","0","0");
INSERT INTO city VALUES("956","0","1","11","Palkot ","Palkot ","0","0","0","0");
INSERT INTO city VALUES("957","0","1","11","Patan ","Patan ","0","0","0","0");
INSERT INTO city VALUES("958","0","1","11","Rajdhanwar ","Rajdhanwar ","0","0","0","0");
INSERT INTO city VALUES("959","0","1","11","Rajmahal ","Rajmahal ","0","0","0","0");
INSERT INTO city VALUES("960","0","1","11","Ramgarh ","Ramgarh ","0","0","0","0");
INSERT INTO city VALUES("961","0","1","11","Ranchi ","Ranchi ","0","0","0","0");
INSERT INTO city VALUES("962","0","1","11","Sahibganj ","Sahibganj ","0","0","0","0");
INSERT INTO city VALUES("963","0","1","11","Saraikela ","Saraikela ","0","0","0","0");
INSERT INTO city VALUES("964","0","1","11","Simaria ","Simaria ","0","0","0","0");
INSERT INTO city VALUES("965","0","1","11","Simdega ","Simdega ","0","0","0","0");
INSERT INTO city VALUES("966","0","1","11","Singhbhum ","Singhbhum ","0","0","0","0");
INSERT INTO city VALUES("967","0","1","11","Tisri ","Tisri ","0","0","0","0");
INSERT INTO city VALUES("968","0","1","11","Torpa ","Torpa ","0","0","0","0");
INSERT INTO city VALUES("969","0","1","12","Afzalpur ","Afzalpur ","0","0","0","0");
INSERT INTO city VALUES("970","0","1","12","Ainapur ","Ainapur ","0","0","0","0");
INSERT INTO city VALUES("971","0","1","12","Aland ","Aland ","0","0","0","0");
INSERT INTO city VALUES("972","0","1","12","Alur ","Alur ","0","0","0","0");
INSERT INTO city VALUES("973","0","1","12","Anekal ","Anekal ","0","0","0","0");
INSERT INTO city VALUES("974","0","1","12","Ankola ","Ankola ","0","0","0","0");
INSERT INTO city VALUES("975","0","1","12","Arsikere ","Arsikere ","0","0","0","0");
INSERT INTO city VALUES("976","0","1","12","Athani ","Athani ","0","0","0","0");
INSERT INTO city VALUES("977","0","1","12","Aurad ","Aurad ","0","0","0","0");
INSERT INTO city VALUES("978","0","1","12","Bableshwar ","Bableshwar ","0","0","0","0");
INSERT INTO city VALUES("979","0","1","12","Badami ","Badami ","0","0","0","0");
INSERT INTO city VALUES("980","0","1","12","Bagalkot ","Bagalkot ","0","0","0","0");
INSERT INTO city VALUES("981","0","1","12","Bagepalli ","Bagepalli ","0","0","0","0");
INSERT INTO city VALUES("982","0","1","12","Bailhongal ","Bailhongal ","0","0","0","0");
INSERT INTO city VALUES("983","0","1","12","Bangalore ","Bangalore ","0","0","0","0");
INSERT INTO city VALUES("984","0","1","12","Bangalore Rural ","Bangalore Rural ","0","0","0","0");
INSERT INTO city VALUES("985","0","1","12","Bangarpet ","Bangarpet ","0","0","0","0");
INSERT INTO city VALUES("986","0","1","12","Bantwal ","Bantwal ","0","0","0","0");
INSERT INTO city VALUES("987","0","1","12","Basavakalyan ","Basavakalyan ","0","0","0","0");
INSERT INTO city VALUES("988","0","1","12","Basavanabagewadi ","Basavanabagewadi ","0","0","0","0");
INSERT INTO city VALUES("989","0","1","12","Basavapatna ","Basavapatna ","0","0","0","0");
INSERT INTO city VALUES("990","0","1","12","Belgaum ","Belgaum ","0","0","0","0");
INSERT INTO city VALUES("991","0","1","12","Bellary ","Bellary ","0","0","0","0");
INSERT INTO city VALUES("992","0","1","12","Belthangady ","Belthangady ","0","0","0","0");
INSERT INTO city VALUES("993","0","1","12","Belur ","Belur ","0","0","0","0");
INSERT INTO city VALUES("994","0","1","12","Bhadravati ","Bhadravati ","0","0","0","0");
INSERT INTO city VALUES("995","0","1","12","Bhalki ","Bhalki ","0","0","0","0");
INSERT INTO city VALUES("996","0","1","12","Bhatkal ","Bhatkal ","0","0","0","0");
INSERT INTO city VALUES("997","0","1","12","Bidar ","Bidar ","0","0","0","0");
INSERT INTO city VALUES("998","0","1","12","Bijapur ","Bijapur ","0","0","0","0");
INSERT INTO city VALUES("999","0","1","12","Biligi ","Biligi ","0","0","0","0");
INSERT INTO city VALUES("1000","0","1","12","Chadchan ","Chadchan ","0","0","0","0");
INSERT INTO city VALUES("1001","0","1","12","Challakere ","Challakere ","0","0","0","0");
INSERT INTO city VALUES("1002","0","1","12","Chamrajnagar ","Chamrajnagar ","0","0","0","0");
INSERT INTO city VALUES("1003","0","1","12","Channagiri ","Channagiri ","0","0","0","0");
INSERT INTO city VALUES("1004","0","1","12","Channapatna ","Channapatna ","0","0","0","0");
INSERT INTO city VALUES("1005","0","1","12","Channarayapatna ","Channarayapatna ","0","0","0","0");
INSERT INTO city VALUES("1006","0","1","12","Chickmagalur ","Chickmagalur ","0","0","0","0");
INSERT INTO city VALUES("1007","0","1","12","Chikballapur ","Chikballapur ","0","0","0","0");
INSERT INTO city VALUES("1008","0","1","12","Chikkaballapur ","Chikkaballapur ","0","0","0","0");
INSERT INTO city VALUES("1009","0","1","12","Chikkanayakanahalli ","Chikkanayakanahalli ","0","0","0","0");
INSERT INTO city VALUES("1010","0","1","12","Chikkodi ","Chikkodi ","0","0","0","0");
INSERT INTO city VALUES("1011","0","1","12","Chikmagalur ","Chikmagalur ","0","0","0","0");
INSERT INTO city VALUES("1012","0","1","12","Chincholi ","Chincholi ","0","0","0","0");
INSERT INTO city VALUES("1013","0","1","12","Chintamani ","Chintamani ","0","0","0","0");
INSERT INTO city VALUES("1014","0","1","12","Chitradurga ","Chitradurga ","0","0","0","0");
INSERT INTO city VALUES("1015","0","1","12","Chittapur ","Chittapur ","0","0","0","0");
INSERT INTO city VALUES("1016","0","1","12","Cowdahalli ","Cowdahalli ","0","0","0","0");
INSERT INTO city VALUES("1017","0","1","12","Davanagere ","Davanagere ","0","0","0","0");
INSERT INTO city VALUES("1018","0","1","12","Deodurga ","Deodurga ","0","0","0","0");
INSERT INTO city VALUES("1019","0","1","12","Devangere ","Devangere ","0","0","0","0");
INSERT INTO city VALUES("1020","0","1","12","Devarahippargi ","Devarahippargi ","0","0","0","0");
INSERT INTO city VALUES("1021","0","1","12","Dharwad ","Dharwad ","0","0","0","0");
INSERT INTO city VALUES("1022","0","1","12","Doddaballapur ","Doddaballapur ","0","0","0","0");
INSERT INTO city VALUES("1023","0","1","12","Gadag ","Gadag ","0","0","0","0");
INSERT INTO city VALUES("1024","0","1","12","Gangavathi ","Gangavathi ","0","0","0","0");
INSERT INTO city VALUES("1025","0","1","12","Gokak ","Gokak ","0","0","0","0");
INSERT INTO city VALUES("1026","0","1","12","Gowribdanpur ","Gowribdanpur ","0","0","0","0");
INSERT INTO city VALUES("1027","0","1","12","Gubbi ","Gubbi ","0","0","0","0");
INSERT INTO city VALUES("1028","0","1","12","Gulbarga ","Gulbarga ","0","0","0","0");
INSERT INTO city VALUES("1029","0","1","12","Gundlupet ","Gundlupet ","0","0","0","0");
INSERT INTO city VALUES("1030","0","1","12","H.B.Halli ","H.B.Halli ","0","0","0","0");
INSERT INTO city VALUES("1031","0","1","12","H.D. Kote ","H.D. Kote ","0","0","0","0");
INSERT INTO city VALUES("1032","0","1","12","Haliyal ","Haliyal ","0","0","0","0");
INSERT INTO city VALUES("1033","0","1","12","Hampi ","Hampi ","0","0","0","0");
INSERT INTO city VALUES("1034","0","1","12","Hangal ","Hangal ","0","0","0","0");
INSERT INTO city VALUES("1035","0","1","12","Harapanahalli ","Harapanahalli ","0","0","0","0");
INSERT INTO city VALUES("1036","0","1","12","Hassan ","Hassan ","0","0","0","0");
INSERT INTO city VALUES("1037","0","1","12","Haveri ","Haveri ","0","0","0","0");
INSERT INTO city VALUES("1038","0","1","12","Hebri ","Hebri ","0","0","0","0");
INSERT INTO city VALUES("1039","0","1","12","Hirekerur ","Hirekerur ","0","0","0","0");
INSERT INTO city VALUES("1040","0","1","12","Hiriyur ","Hiriyur ","0","0","0","0");
INSERT INTO city VALUES("1041","0","1","12","Holalkere ","Holalkere ","0","0","0","0");
INSERT INTO city VALUES("1042","0","1","12","Holenarsipur ","Holenarsipur ","0","0","0","0");
INSERT INTO city VALUES("1043","0","1","12","Honnali ","Honnali ","0","0","0","0");
INSERT INTO city VALUES("1044","0","1","12","Honnavar ","Honnavar ","0","0","0","0");
INSERT INTO city VALUES("1045","0","1","12","Hosadurga ","Hosadurga ","0","0","0","0");
INSERT INTO city VALUES("1046","0","1","12","Hosakote ","Hosakote ","0","0","0","0");
INSERT INTO city VALUES("1047","0","1","12","Hosanagara ","Hosanagara ","0","0","0","0");
INSERT INTO city VALUES("1048","0","1","12","Hospet ","Hospet ","0","0","0","0");
INSERT INTO city VALUES("1049","0","1","12","Hubli ","Hubli ","0","0","0","0");
INSERT INTO city VALUES("1050","0","1","12","Hukkeri ","Hukkeri ","0","0","0","0");
INSERT INTO city VALUES("1051","0","1","12","Humnabad ","Humnabad ","0","0","0","0");
INSERT INTO city VALUES("1052","0","1","12","Hungund ","Hungund ","0","0","0","0");
INSERT INTO city VALUES("1053","0","1","12","Hunsagi ","Hunsagi ","0","0","0","0");
INSERT INTO city VALUES("1054","0","1","12","Hunsur ","Hunsur ","0","0","0","0");
INSERT INTO city VALUES("1055","0","1","12","Huvinahadagali ","Huvinahadagali ","0","0","0","0");
INSERT INTO city VALUES("1056","0","1","12","Indi ","Indi ","0","0","0","0");
INSERT INTO city VALUES("1057","0","1","12","Jagalur ","Jagalur ","0","0","0","0");
INSERT INTO city VALUES("1058","0","1","12","Jamkhandi ","Jamkhandi ","0","0","0","0");
INSERT INTO city VALUES("1059","0","1","12","Jewargi ","Jewargi ","0","0","0","0");
INSERT INTO city VALUES("1060","0","1","12","Joida ","Joida ","0","0","0","0");
INSERT INTO city VALUES("1061","0","1","12","K.R. Nagar ","K.R. Nagar ","0","0","0","0");
INSERT INTO city VALUES("1062","0","1","12","Kadur ","Kadur ","0","0","0","0");
INSERT INTO city VALUES("1063","0","1","12","Kalghatagi ","Kalghatagi ","0","0","0","0");
INSERT INTO city VALUES("1064","0","1","12","Kamalapur ","Kamalapur ","0","0","0","0");
INSERT INTO city VALUES("1065","0","1","12","Kanakapura ","Kanakapura ","0","0","0","0");
INSERT INTO city VALUES("1066","0","1","12","Kannada ","Kannada ","0","0","0","0");
INSERT INTO city VALUES("1067","0","1","12","Kargal ","Kargal ","0","0","0","0");
INSERT INTO city VALUES("1068","0","1","12","Karkala ","Karkala ","0","0","0","0");
INSERT INTO city VALUES("1069","0","1","12","Karwar ","Karwar ","0","0","0","0");
INSERT INTO city VALUES("1070","0","1","12","Khanapur ","Khanapur ","0","0","0","0");
INSERT INTO city VALUES("1071","0","1","12","Kodagu ","Kodagu ","0","0","0","0");
INSERT INTO city VALUES("1072","0","1","12","Kolar ","Kolar ","0","0","0","0");
INSERT INTO city VALUES("1073","0","1","12","Kollegal ","Kollegal ","0","0","0","0");
INSERT INTO city VALUES("1074","0","1","12","Koppa ","Koppa ","0","0","0","0");
INSERT INTO city VALUES("1075","0","1","12","Koppal ","Koppal ","0","0","0","0");
INSERT INTO city VALUES("1076","0","1","12","Koratageri ","Koratageri ","0","0","0","0");
INSERT INTO city VALUES("1077","0","1","12","Krishnarajapet ","Krishnarajapet ","0","0","0","0");
INSERT INTO city VALUES("1078","0","1","12","Kudligi ","Kudligi ","0","0","0","0");
INSERT INTO city VALUES("1079","0","1","12","Kumta ","Kumta ","0","0","0","0");
INSERT INTO city VALUES("1080","0","1","12","Kundapur ","Kundapur ","0","0","0","0");
INSERT INTO city VALUES("1081","0","1","12","Kundgol ","Kundgol ","0","0","0","0");
INSERT INTO city VALUES("1082","0","1","12","Kunigal ","Kunigal ","0","0","0","0");
INSERT INTO city VALUES("1083","0","1","12","Kurugodu ","Kurugodu ","0","0","0","0");
INSERT INTO city VALUES("1084","0","1","12","Kustagi ","Kustagi ","0","0","0","0");
INSERT INTO city VALUES("1085","0","1","12","Lingsugur ","Lingsugur ","0","0","0","0");
INSERT INTO city VALUES("1086","0","1","12","Madikeri ","Madikeri ","0","0","0","0");
INSERT INTO city VALUES("1087","0","1","12","Madugiri ","Madugiri ","0","0","0","0");
INSERT INTO city VALUES("1088","0","1","12","Malavalli ","Malavalli ","0","0","0","0");
INSERT INTO city VALUES("1089","0","1","12","Malur ","Malur ","0","0","0","0");
INSERT INTO city VALUES("1090","0","1","12","Mandya ","Mandya ","0","0","0","0");
INSERT INTO city VALUES("1091","0","1","12","Mangalore ","Mangalore ","0","0","0","0");
INSERT INTO city VALUES("1092","0","1","12","Manipal ","Manipal ","0","0","0","0");
INSERT INTO city VALUES("1093","0","1","12","Manvi ","Manvi ","0","0","0","0");
INSERT INTO city VALUES("1094","0","1","12","Mashal ","Mashal ","0","0","0","0");
INSERT INTO city VALUES("1095","0","1","12","Molkalmuru ","Molkalmuru ","0","0","0","0");
INSERT INTO city VALUES("1096","0","1","12","Mudalgi ","Mudalgi ","0","0","0","0");
INSERT INTO city VALUES("1097","0","1","12","Muddebihal ","Muddebihal ","0","0","0","0");
INSERT INTO city VALUES("1098","0","1","12","Mudhol ","Mudhol ","0","0","0","0");
INSERT INTO city VALUES("1099","0","1","12","Mudigere ","Mudigere ","0","0","0","0");
INSERT INTO city VALUES("1100","0","1","12","Mulbagal ","Mulbagal ","0","0","0","0");
INSERT INTO city VALUES("1101","0","1","12","Mundagod ","Mundagod ","0","0","0","0");
INSERT INTO city VALUES("1102","0","1","12","Mundargi ","Mundargi ","0","0","0","0");
INSERT INTO city VALUES("1103","0","1","12","Murugod ","Murugod ","0","0","0","0");
INSERT INTO city VALUES("1104","0","1","12","Mysore ","Mysore ","0","0","0","0");
INSERT INTO city VALUES("1105","0","1","12","Nagamangala ","Nagamangala ","0","0","0","0");
INSERT INTO city VALUES("1106","0","1","12","Nanjangud ","Nanjangud ","0","0","0","0");
INSERT INTO city VALUES("1107","0","1","12","Nargund ","Nargund ","0","0","0","0");
INSERT INTO city VALUES("1108","0","1","12","Narsimrajapur ","Narsimrajapur ","0","0","0","0");
INSERT INTO city VALUES("1109","0","1","12","Navalgund ","Navalgund ","0","0","0","0");
INSERT INTO city VALUES("1110","0","1","12","Nelamangala ","Nelamangala ","0","0","0","0");
INSERT INTO city VALUES("1111","0","1","12","Nimburga ","Nimburga ","0","0","0","0");
INSERT INTO city VALUES("1112","0","1","12","Pandavapura ","Pandavapura ","0","0","0","0");
INSERT INTO city VALUES("1113","0","1","12","Pavagada ","Pavagada ","0","0","0","0");
INSERT INTO city VALUES("1114","0","1","12","Puttur ","Puttur ","0","0","0","0");
INSERT INTO city VALUES("1115","0","1","12","Raibag ","Raibag ","0","0","0","0");
INSERT INTO city VALUES("1116","0","1","12","Raichur ","Raichur ","0","0","0","0");
INSERT INTO city VALUES("1117","0","1","12","Ramdurg ","Ramdurg ","0","0","0","0");
INSERT INTO city VALUES("1118","0","1","12","Ranebennur ","Ranebennur ","0","0","0","0");
INSERT INTO city VALUES("1119","0","1","12","Ron ","Ron ","0","0","0","0");
INSERT INTO city VALUES("1120","0","1","12","Sagar ","Sagar ","0","0","0","0");
INSERT INTO city VALUES("1121","0","1","12","Sakleshpur ","Sakleshpur ","0","0","0","0");
INSERT INTO city VALUES("1122","0","1","12","Salkani ","Salkani ","0","0","0","0");
INSERT INTO city VALUES("1123","0","1","12","Sandur ","Sandur ","0","0","0","0");
INSERT INTO city VALUES("1124","0","1","12","Saundatti ","Saundatti ","0","0","0","0");
INSERT INTO city VALUES("1125","0","1","12","Savanur ","Savanur ","0","0","0","0");
INSERT INTO city VALUES("1126","0","1","12","Sedam ","Sedam ","0","0","0","0");
INSERT INTO city VALUES("1127","0","1","12","Shahapur ","Shahapur ","0","0","0","0");
INSERT INTO city VALUES("1128","0","1","12","Shankarnarayana ","Shankarnarayana ","0","0","0","0");
INSERT INTO city VALUES("1129","0","1","12","Shikaripura ","Shikaripura ","0","0","0","0");
INSERT INTO city VALUES("1130","0","1","12","Shimoga ","Shimoga ","0","0","0","0");
INSERT INTO city VALUES("1131","0","1","12","Shirahatti ","Shirahatti ","0","0","0","0");
INSERT INTO city VALUES("1132","0","1","12","Shorapur ","Shorapur ","0","0","0","0");
INSERT INTO city VALUES("1133","0","1","12","Siddapur ","Siddapur ","0","0","0","0");
INSERT INTO city VALUES("1134","0","1","12","Sidlaghatta ","Sidlaghatta ","0","0","0","0");
INSERT INTO city VALUES("1135","0","1","12","Sindagi ","Sindagi ","0","0","0","0");
INSERT INTO city VALUES("1136","0","1","12","Sindhanur ","Sindhanur ","0","0","0","0");
INSERT INTO city VALUES("1137","0","1","12","Sira ","Sira ","0","0","0","0");
INSERT INTO city VALUES("1138","0","1","12","Sirsi ","Sirsi ","0","0","0","0");
INSERT INTO city VALUES("1139","0","1","12","Siruguppa ","Siruguppa ","0","0","0","0");
INSERT INTO city VALUES("1140","0","1","12","Somwarpet ","Somwarpet ","0","0","0","0");
INSERT INTO city VALUES("1141","0","1","12","Sorab ","Sorab ","0","0","0","0");
INSERT INTO city VALUES("1142","0","1","12","Sringeri ","Sringeri ","0","0","0","0");
INSERT INTO city VALUES("1143","0","1","12","Sriniwaspur ","Sriniwaspur ","0","0","0","0");
INSERT INTO city VALUES("1144","0","1","12","Srirangapatna ","Srirangapatna ","0","0","0","0");
INSERT INTO city VALUES("1145","0","1","12","Sullia ","Sullia ","0","0","0","0");
INSERT INTO city VALUES("1146","0","1","12","T. Narsipur ","T. Narsipur ","0","0","0","0");
INSERT INTO city VALUES("1147","0","1","12","Tallak ","Tallak ","0","0","0","0");
INSERT INTO city VALUES("1148","0","1","12","Tarikere ","Tarikere ","0","0","0","0");
INSERT INTO city VALUES("1149","0","1","12","Telgi ","Telgi ","0","0","0","0");
INSERT INTO city VALUES("1150","0","1","12","Thirthahalli ","Thirthahalli ","0","0","0","0");
INSERT INTO city VALUES("1151","0","1","12","Tiptur ","Tiptur ","0","0","0","0");
INSERT INTO city VALUES("1152","0","1","12","Tumkur ","Tumkur ","0","0","0","0");
INSERT INTO city VALUES("1153","0","1","12","Turuvekere ","Turuvekere ","0","0","0","0");
INSERT INTO city VALUES("1154","0","1","12","Udupi ","Udupi ","0","0","0","0");
INSERT INTO city VALUES("1155","0","1","12","Virajpet ","Virajpet ","0","0","0","0");
INSERT INTO city VALUES("1156","0","1","12","Wadi ","Wadi ","0","0","0","0");
INSERT INTO city VALUES("1157","0","1","12","Yadgiri ","Yadgiri ","0","0","0","0");
INSERT INTO city VALUES("1158","0","1","12","Yelburga ","Yelburga ","0","0","0","0");
INSERT INTO city VALUES("1159","0","1","12","Yellapur ","Yellapur ","0","0","0","0");
INSERT INTO city VALUES("1160","0","1","13","Adimaly ","Adimaly ","0","0","0","0");
INSERT INTO city VALUES("1161","0","1","13","Adoor ","Adoor ","0","0","0","0");
INSERT INTO city VALUES("1162","0","1","13","Agathy ","Agathy ","0","0","0","0");
INSERT INTO city VALUES("1163","0","1","13","Alappuzha ","Alappuzha ","0","0","0","0");
INSERT INTO city VALUES("1164","0","1","13","Alathur ","Alathur ","0","0","0","0");
INSERT INTO city VALUES("1165","0","1","13","Alleppey ","Alleppey ","0","0","0","0");
INSERT INTO city VALUES("1166","0","1","13","Alwaye ","Alwaye ","0","0","0","0");
INSERT INTO city VALUES("1167","0","1","13","Amini ","Amini ","0","0","0","0");
INSERT INTO city VALUES("1168","0","1","13","Androth ","Androth ","0","0","0","0");
INSERT INTO city VALUES("1169","0","1","13","Attingal ","Attingal ","0","0","0","0");
INSERT INTO city VALUES("1170","0","1","13","Badagara ","Badagara ","0","0","0","0");
INSERT INTO city VALUES("1171","0","1","13","Bitra ","Bitra ","0","0","0","0");
INSERT INTO city VALUES("1172","0","1","13","Calicut ","Calicut ","0","0","0","0");
INSERT INTO city VALUES("1173","0","1","13","Cannanore ","Cannanore ","0","0","0","0");
INSERT INTO city VALUES("1174","0","1","13","Chetlet ","Chetlet ","0","0","0","0");
INSERT INTO city VALUES("1175","0","1","13","Ernakulam ","Ernakulam ","0","0","0","0");
INSERT INTO city VALUES("1176","0","1","13","Idukki ","Idukki ","0","0","0","0");
INSERT INTO city VALUES("1177","0","1","13","Irinjalakuda ","Irinjalakuda ","0","0","0","0");
INSERT INTO city VALUES("1178","0","1","13","Kadamath ","Kadamath ","0","0","0","0");
INSERT INTO city VALUES("1179","0","1","13","Kalpeni ","Kalpeni ","0","0","0","0");
INSERT INTO city VALUES("1180","0","1","13","Kalpetta ","Kalpetta ","0","0","0","0");
INSERT INTO city VALUES("1181","0","1","13","Kanhangad ","Kanhangad ","0","0","0","0");
INSERT INTO city VALUES("1182","0","1","13","Kanjirapally ","Kanjirapally ","0","0","0","0");
INSERT INTO city VALUES("1183","0","1","13","Kannur ","Kannur ","0","0","0","0");
INSERT INTO city VALUES("1184","0","1","13","Karungapally ","Karungapally ","0","0","0","0");
INSERT INTO city VALUES("1185","0","1","13","Kasargode ","Kasargode ","0","0","0","0");
INSERT INTO city VALUES("1186","0","1","13","Kavarathy ","Kavarathy ","0","0","0","0");
INSERT INTO city VALUES("1187","0","1","13","Kiltan ","Kiltan ","0","0","0","0");
INSERT INTO city VALUES("1188","0","1","13","Kochi ","Kochi ","0","0","0","0");
INSERT INTO city VALUES("1189","0","1","13","Koduvayur ","Koduvayur ","0","0","0","0");
INSERT INTO city VALUES("1190","0","1","13","Kollam ","Kollam ","0","0","0","0");
INSERT INTO city VALUES("1191","0","1","13","Kottayam ","Kottayam ","0","0","0","0");
INSERT INTO city VALUES("1192","0","1","13","Kovalam ","Kovalam ","0","0","0","0");
INSERT INTO city VALUES("1193","0","1","13","Kozhikode ","Kozhikode ","0","0","0","0");
INSERT INTO city VALUES("1194","0","1","13","Kunnamkulam ","Kunnamkulam ","0","0","0","0");
INSERT INTO city VALUES("1195","0","1","13","Malappuram ","Malappuram ","0","0","0","0");
INSERT INTO city VALUES("1196","0","1","13","Mananthodi ","Mananthodi ","0","0","0","0");
INSERT INTO city VALUES("1197","0","1","13","Manjeri ","Manjeri ","0","0","0","0");
INSERT INTO city VALUES("1198","0","1","13","Mannarghat ","Mannarghat ","0","0","0","0");
INSERT INTO city VALUES("1199","0","1","13","Mavelikkara ","Mavelikkara ","0","0","0","0");
INSERT INTO city VALUES("1200","0","1","13","Minicoy ","Minicoy ","0","0","0","0");
INSERT INTO city VALUES("1201","0","1","13","Munnar ","Munnar ","0","0","0","0");
INSERT INTO city VALUES("1202","0","1","13","Muvattupuzha ","Muvattupuzha ","0","0","0","0");
INSERT INTO city VALUES("1203","0","1","13","Nedumandad ","Nedumandad ","0","0","0","0");
INSERT INTO city VALUES("1204","0","1","13","Nedumgandam ","Nedumgandam ","0","0","0","0");
INSERT INTO city VALUES("1205","0","1","13","Nilambur ","Nilambur ","0","0","0","0");
INSERT INTO city VALUES("1206","0","1","13","Palai ","Palai ","0","0","0","0");
INSERT INTO city VALUES("1207","0","1","13","Palakkad ","Palakkad ","0","0","0","0");
INSERT INTO city VALUES("1208","0","1","13","Palghat ","Palghat ","0","0","0","0");
INSERT INTO city VALUES("1209","0","1","13","Pathaanamthitta ","Pathaanamthitta ","0","0","0","0");
INSERT INTO city VALUES("1210","0","1","13","Pathanamthitta ","Pathanamthitta ","0","0","0","0");
INSERT INTO city VALUES("1211","0","1","13","Payyanur ","Payyanur ","0","0","0","0");
INSERT INTO city VALUES("1212","0","1","13","Peermedu ","Peermedu ","0","0","0","0");
INSERT INTO city VALUES("1213","0","1","13","Perinthalmanna ","Perinthalmanna ","0","0","0","0");
INSERT INTO city VALUES("1214","0","1","13","Perumbavoor ","Perumbavoor ","0","0","0","0");
INSERT INTO city VALUES("1215","0","1","13","Punalur ","Punalur ","0","0","0","0");
INSERT INTO city VALUES("1216","0","1","13","Quilon ","Quilon ","0","0","0","0");
INSERT INTO city VALUES("1217","0","1","13","Ranni ","Ranni ","0","0","0","0");
INSERT INTO city VALUES("1218","0","1","13","Shertallai ","Shertallai ","0","0","0","0");
INSERT INTO city VALUES("1219","0","1","13","Shoranur ","Shoranur ","0","0","0","0");
INSERT INTO city VALUES("1220","0","1","13","Taliparamba ","Taliparamba ","0","0","0","0");
INSERT INTO city VALUES("1221","0","1","13","Tellicherry ","Tellicherry ","0","0","0","0");
INSERT INTO city VALUES("1222","0","1","13","Thiruvananthapuram ","Thiruvananthapuram ","0","0","0","0");
INSERT INTO city VALUES("1223","0","1","13","Thodupuzha ","Thodupuzha ","0","0","0","0");
INSERT INTO city VALUES("1224","0","1","13","Thrissur ","Thrissur ","0","0","0","0");
INSERT INTO city VALUES("1225","0","1","13","Tirur ","Tirur ","0","0","0","0");
INSERT INTO city VALUES("1226","0","1","13","Tiruvalla ","Tiruvalla ","0","0","0","0");
INSERT INTO city VALUES("1227","0","1","13","Trichur ","Trichur ","0","0","0","0");
INSERT INTO city VALUES("1228","0","1","13","Trivandrum ","Trivandrum ","0","0","0","0");
INSERT INTO city VALUES("1229","0","1","13","Uppala ","Uppala ","0","0","0","0");
INSERT INTO city VALUES("1230","0","1","13","Vadakkanchery ","Vadakkanchery ","0","0","0","0");
INSERT INTO city VALUES("1231","0","1","13","Vikom ","Vikom ","0","0","0","0");
INSERT INTO city VALUES("1232","0","1","13","Wayanad ","Wayanad ","0","0","0","0");
INSERT INTO city VALUES("1233","0","1","14","Agar ","Agar ","0","0","0","0");
INSERT INTO city VALUES("1234","0","1","14","Ajaigarh ","Ajaigarh ","0","0","0","0");
INSERT INTO city VALUES("1235","0","1","14","Alirajpur ","Alirajpur ","0","0","0","0");
INSERT INTO city VALUES("1236","0","1","14","Amarpatan ","Amarpatan ","0","0","0","0");
INSERT INTO city VALUES("1237","0","1","14","Amarwada ","Amarwada ","0","0","0","0");
INSERT INTO city VALUES("1238","0","1","14","Ambah ","Ambah ","0","0","0","0");
INSERT INTO city VALUES("1239","0","1","14","Anuppur ","Anuppur ","0","0","0","0");
INSERT INTO city VALUES("1240","0","1","14","Arone ","Arone ","0","0","0","0");
INSERT INTO city VALUES("1241","0","1","14","Ashoknagar ","Ashoknagar ","0","0","0","0");
INSERT INTO city VALUES("1242","0","1","14","Ashta ","Ashta ","0","0","0","0");
INSERT INTO city VALUES("1243","0","1","14","Atner ","Atner ","0","0","0","0");
INSERT INTO city VALUES("1244","0","1","14","Babaichichli ","Babaichichli ","0","0","0","0");
INSERT INTO city VALUES("1245","0","1","14","Badamalhera ","Badamalhera ","0","0","0","0");
INSERT INTO city VALUES("1246","0","1","14","Badarwsas ","Badarwsas ","0","0","0","0");
INSERT INTO city VALUES("1247","0","1","14","Badnagar ","Badnagar ","0","0","0","0");
INSERT INTO city VALUES("1248","0","1","14","Badnawar ","Badnawar ","0","0","0","0");
INSERT INTO city VALUES("1249","0","1","14","Badwani ","Badwani ","0","0","0","0");
INSERT INTO city VALUES("1250","0","1","14","Bagli ","Bagli ","0","0","0","0");
INSERT INTO city VALUES("1251","0","1","14","Baihar ","Baihar ","0","0","0","0");
INSERT INTO city VALUES("1252","0","1","14","Balaghat ","Balaghat ","0","0","0","0");
INSERT INTO city VALUES("1253","0","1","14","Baldeogarh ","Baldeogarh ","0","0","0","0");
INSERT INTO city VALUES("1254","0","1","14","Baldi ","Baldi ","0","0","0","0");
INSERT INTO city VALUES("1255","0","1","14","Bamori ","Bamori ","0","0","0","0");
INSERT INTO city VALUES("1256","0","1","14","Banda ","Banda ","0","0","0","0");
INSERT INTO city VALUES("1257","0","1","14","Bandhavgarh ","Bandhavgarh ","0","0","0","0");
INSERT INTO city VALUES("1258","0","1","14","Bareli ","Bareli ","0","0","0","0");
INSERT INTO city VALUES("1259","0","1","14","Baroda ","Baroda ","0","0","0","0");
INSERT INTO city VALUES("1260","0","1","14","Barwaha ","Barwaha ","0","0","0","0");
INSERT INTO city VALUES("1261","0","1","14","Barwani ","Barwani ","0","0","0","0");
INSERT INTO city VALUES("1262","0","1","14","Batkakhapa ","Batkakhapa ","0","0","0","0");
INSERT INTO city VALUES("1263","0","1","14","Begamganj ","Begamganj ","0","0","0","0");
INSERT INTO city VALUES("1264","0","1","14","Beohari ","Beohari ","0","0","0","0");
INSERT INTO city VALUES("1265","0","1","14","Berasia ","Berasia ","0","0","0","0");
INSERT INTO city VALUES("1266","0","1","14","Berchha ","Berchha ","0","0","0","0");
INSERT INTO city VALUES("1267","0","1","14","Betul ","Betul ","0","0","0","0");
INSERT INTO city VALUES("1268","0","1","14","Bhainsdehi ","Bhainsdehi ","0","0","0","0");
INSERT INTO city VALUES("1269","0","1","14","Bhander ","Bhander ","0","0","0","0");
INSERT INTO city VALUES("1270","0","1","14","Bhanpura ","Bhanpura ","0","0","0","0");
INSERT INTO city VALUES("1271","0","1","14","Bhikangaon ","Bhikangaon ","0","0","0","0");
INSERT INTO city VALUES("1272","0","1","14","Bhimpur ","Bhimpur ","0","0","0","0");
INSERT INTO city VALUES("1273","0","1","14","Bhind ","Bhind ","0","0","0","0");
INSERT INTO city VALUES("1274","0","1","14","Bhitarwar ","Bhitarwar ","0","0","0","0");
INSERT INTO city VALUES("1275","0","1","14","Bhopal ","Bhopal ","0","0","0","0");
INSERT INTO city VALUES("1276","0","1","14","Biaora ","Biaora ","0","0","0","0");
INSERT INTO city VALUES("1277","0","1","14","Bijadandi ","Bijadandi ","0","0","0","0");
INSERT INTO city VALUES("1278","0","1","14","Bijawar ","Bijawar ","0","0","0","0");
INSERT INTO city VALUES("1279","0","1","14","Bijaypur ","Bijaypur ","0","0","0","0");
INSERT INTO city VALUES("1280","0","1","14","Bina ","Bina ","0","0","0","0");
INSERT INTO city VALUES("1281","0","1","14","Birsa ","Birsa ","0","0","0","0");
INSERT INTO city VALUES("1282","0","1","14","Birsinghpur ","Birsinghpur ","0","0","0","0");
INSERT INTO city VALUES("1283","0","1","14","Budhni ","Budhni ","0","0","0","0");
INSERT INTO city VALUES("1284","0","1","14","Burhanpur ","Burhanpur ","0","0","0","0");
INSERT INTO city VALUES("1285","0","1","14","Buxwaha ","Buxwaha ","0","0","0","0");
INSERT INTO city VALUES("1286","0","1","14","Chachaura ","Chachaura ","0","0","0","0");
INSERT INTO city VALUES("1287","0","1","14","Chanderi ","Chanderi ","0","0","0","0");
INSERT INTO city VALUES("1288","0","1","14","Chaurai ","Chaurai ","0","0","0","0");
INSERT INTO city VALUES("1289","0","1","14","Chhapara ","Chhapara ","0","0","0","0");
INSERT INTO city VALUES("1290","0","1","14","Chhatarpur ","Chhatarpur ","0","0","0","0");
INSERT INTO city VALUES("1291","0","1","14","Chhindwara ","Chhindwara ","0","0","0","0");
INSERT INTO city VALUES("1292","0","1","14","Chicholi ","Chicholi ","0","0","0","0");
INSERT INTO city VALUES("1293","0","1","14","Chitrangi ","Chitrangi ","0","0","0","0");
INSERT INTO city VALUES("1294","0","1","14","Churhat ","Churhat ","0","0","0","0");
INSERT INTO city VALUES("1295","0","1","14","Dabra ","Dabra ","0","0","0","0");
INSERT INTO city VALUES("1296","0","1","14","Damoh ","Damoh ","0","0","0","0");
INSERT INTO city VALUES("1297","0","1","14","Datia ","Datia ","0","0","0","0");
INSERT INTO city VALUES("1298","0","1","14","Deori ","Deori ","0","0","0","0");
INSERT INTO city VALUES("1299","0","1","14","Deosar ","Deosar ","0","0","0","0");
INSERT INTO city VALUES("1300","0","1","14","Depalpur ","Depalpur ","0","0","0","0");
INSERT INTO city VALUES("1301","0","1","14","Dewas ","Dewas ","0","0","0","0");
INSERT INTO city VALUES("1302","0","1","14","Dhar ","Dhar ","0","0","0","0");
INSERT INTO city VALUES("1303","0","1","14","Dharampuri ","Dharampuri ","0","0","0","0");
INSERT INTO city VALUES("1304","0","1","14","Dindori ","Dindori ","0","0","0","0");
INSERT INTO city VALUES("1305","0","1","14","Gadarwara ","Gadarwara ","0","0","0","0");
INSERT INTO city VALUES("1306","0","1","14","Gairatganj ","Gairatganj ","0","0","0","0");
INSERT INTO city VALUES("1307","0","1","14","Ganjbasoda ","Ganjbasoda ","0","0","0","0");
INSERT INTO city VALUES("1308","0","1","14","Garoth ","Garoth ","0","0","0","0");
INSERT INTO city VALUES("1309","0","1","14","Ghansour ","Ghansour ","0","0","0","0");
INSERT INTO city VALUES("1310","0","1","14","Ghatia ","Ghatia ","0","0","0","0");
INSERT INTO city VALUES("1311","0","1","14","Ghatigaon ","Ghatigaon ","0","0","0","0");
INSERT INTO city VALUES("1312","0","1","14","Ghorandogri ","Ghorandogri ","0","0","0","0");
INSERT INTO city VALUES("1313","0","1","14","Ghughari ","Ghughari ","0","0","0","0");
INSERT INTO city VALUES("1314","0","1","14","Gogaon ","Gogaon ","0","0","0","0");
INSERT INTO city VALUES("1315","0","1","14","Gohad ","Gohad ","0","0","0","0");
INSERT INTO city VALUES("1316","0","1","14","Goharganj ","Goharganj ","0","0","0","0");
INSERT INTO city VALUES("1317","0","1","14","Gopalganj ","Gopalganj ","0","0","0","0");
INSERT INTO city VALUES("1318","0","1","14","Gotegaon ","Gotegaon ","0","0","0","0");
INSERT INTO city VALUES("1319","0","1","14","Gourihar ","Gourihar ","0","0","0","0");
INSERT INTO city VALUES("1320","0","1","14","Guna ","Guna ","0","0","0","0");
INSERT INTO city VALUES("1321","0","1","14","Gunnore ","Gunnore ","0","0","0","0");
INSERT INTO city VALUES("1322","0","1","14","Gwalior ","Gwalior ","0","0","0","0");
INSERT INTO city VALUES("1323","0","1","14","Gyraspur ","Gyraspur ","0","0","0","0");
INSERT INTO city VALUES("1324","0","1","14","Hanumana ","Hanumana ","0","0","0","0");
INSERT INTO city VALUES("1325","0","1","14","Harda ","Harda ","0","0","0","0");
INSERT INTO city VALUES("1326","0","1","14","Harrai ","Harrai ","0","0","0","0");
INSERT INTO city VALUES("1327","0","1","14","Harsud ","Harsud ","0","0","0","0");
INSERT INTO city VALUES("1328","0","1","14","Hatta ","Hatta ","0","0","0","0");
INSERT INTO city VALUES("1329","0","1","14","Hoshangabad ","Hoshangabad ","0","0","0","0");
INSERT INTO city VALUES("1330","0","1","14","Ichhawar ","Ichhawar ","0","0","0","0");
INSERT INTO city VALUES("1331","0","1","14","Indore ","Indore ","0","0","0","0");
INSERT INTO city VALUES("1332","0","1","14","Isagarh ","Isagarh ","0","0","0","0");
INSERT INTO city VALUES("1333","0","1","14","Itarsi ","Itarsi ","0","0","0","0");
INSERT INTO city VALUES("1334","0","1","14","Jabalpur ","Jabalpur ","0","0","0","0");
INSERT INTO city VALUES("1335","0","1","14","Jabera ","Jabera ","0","0","0","0");
INSERT INTO city VALUES("1336","0","1","14","Jagdalpur ","Jagdalpur ","0","0","0","0");
INSERT INTO city VALUES("1337","0","1","14","Jaisinghnagar ","Jaisinghnagar ","0","0","0","0");
INSERT INTO city VALUES("1338","0","1","14","Jaithari ","Jaithari ","0","0","0","0");
INSERT INTO city VALUES("1339","0","1","14","Jaitpur ","Jaitpur ","0","0","0","0");
INSERT INTO city VALUES("1340","0","1","14","Jaitwara ","Jaitwara ","0","0","0","0");
INSERT INTO city VALUES("1341","0","1","14","Jamai ","Jamai ","0","0","0","0");
INSERT INTO city VALUES("1342","0","1","14","Jaora ","Jaora ","0","0","0","0");
INSERT INTO city VALUES("1343","0","1","14","Jatara ","Jatara ","0","0","0","0");
INSERT INTO city VALUES("1344","0","1","14","Jawad ","Jawad ","0","0","0","0");
INSERT INTO city VALUES("1345","0","1","14","Jhabua ","Jhabua ","0","0","0","0");
INSERT INTO city VALUES("1346","0","1","14","Jobat ","Jobat ","0","0","0","0");
INSERT INTO city VALUES("1347","0","1","14","Jora ","Jora ","0","0","0","0");
INSERT INTO city VALUES("1348","0","1","14","Kakaiya ","Kakaiya ","0","0","0","0");
INSERT INTO city VALUES("1349","0","1","14","Kannod ","Kannod ","0","0","0","0");
INSERT INTO city VALUES("1350","0","1","14","Kannodi ","Kannodi ","0","0","0","0");
INSERT INTO city VALUES("1351","0","1","14","Karanjia ","Karanjia ","0","0","0","0");
INSERT INTO city VALUES("1352","0","1","14","Kareli ","Kareli ","0","0","0","0");
INSERT INTO city VALUES("1353","0","1","14","Karera ","Karera ","0","0","0","0");
INSERT INTO city VALUES("1354","0","1","14","Karhal ","Karhal ","0","0","0","0");
INSERT INTO city VALUES("1355","0","1","14","Karpa ","Karpa ","0","0","0","0");
INSERT INTO city VALUES("1356","0","1","14","Kasrawad ","Kasrawad ","0","0","0","0");
INSERT INTO city VALUES("1357","0","1","14","Katangi ","Katangi ","0","0","0","0");
INSERT INTO city VALUES("1358","0","1","14","Katni ","Katni ","0","0","0","0");
INSERT INTO city VALUES("1359","0","1","14","Keolari ","Keolari ","0","0","0","0");
INSERT INTO city VALUES("1360","0","1","14","Khachrod ","Khachrod ","0","0","0","0");
INSERT INTO city VALUES("1361","0","1","14","Khajuraho ","Khajuraho ","0","0","0","0");
INSERT INTO city VALUES("1362","0","1","14","Khakner ","Khakner ","0","0","0","0");
INSERT INTO city VALUES("1363","0","1","14","Khalwa ","Khalwa ","0","0","0","0");
INSERT INTO city VALUES("1364","0","1","14","Khandwa ","Khandwa ","0","0","0","0");
INSERT INTO city VALUES("1365","0","1","14","Khaniadhana ","Khaniadhana ","0","0","0","0");
INSERT INTO city VALUES("1366","0","1","14","Khargone ","Khargone ","0","0","0","0");
INSERT INTO city VALUES("1367","0","1","14","Khategaon ","Khategaon ","0","0","0","0");
INSERT INTO city VALUES("1368","0","1","14","Khetia ","Khetia ","0","0","0","0");
INSERT INTO city VALUES("1369","0","1","14","Khilchipur ","Khilchipur ","0","0","0","0");
INSERT INTO city VALUES("1370","0","1","14","Khirkiya ","Khirkiya ","0","0","0","0");
INSERT INTO city VALUES("1371","0","1","14","Khurai ","Khurai ","0","0","0","0");
INSERT INTO city VALUES("1372","0","1","14","Kolaras ","Kolaras ","0","0","0","0");
INSERT INTO city VALUES("1373","0","1","14","Kotma ","Kotma ","0","0","0","0");
INSERT INTO city VALUES("1374","0","1","14","Kukshi ","Kukshi ","0","0","0","0");
INSERT INTO city VALUES("1375","0","1","14","Kundam ","Kundam ","0","0","0","0");
INSERT INTO city VALUES("1376","0","1","14","Kurwai ","Kurwai ","0","0","0","0");
INSERT INTO city VALUES("1377","0","1","14","Kusmi ","Kusmi ","0","0","0","0");
INSERT INTO city VALUES("1378","0","1","14","Laher ","Laher ","0","0","0","0");
INSERT INTO city VALUES("1379","0","1","14","Lakhnadon ","Lakhnadon ","0","0","0","0");
INSERT INTO city VALUES("1380","0","1","14","Lamta ","Lamta ","0","0","0","0");
INSERT INTO city VALUES("1381","0","1","14","Lanji ","Lanji ","0","0","0","0");
INSERT INTO city VALUES("1382","0","1","14","Lateri ","Lateri ","0","0","0","0");
INSERT INTO city VALUES("1383","0","1","14","Laundi ","Laundi ","0","0","0","0");
INSERT INTO city VALUES("1384","0","1","14","Maheshwar ","Maheshwar ","0","0","0","0");
INSERT INTO city VALUES("1385","0","1","14","Mahidpurcity ","Mahidpurcity ","0","0","0","0");
INSERT INTO city VALUES("1386","0","1","14","Maihar ","Maihar ","0","0","0","0");
INSERT INTO city VALUES("1387","0","1","14","Majhagwan ","Majhagwan ","0","0","0","0");
INSERT INTO city VALUES("1388","0","1","14","Majholi ","Majholi ","0","0","0","0");
INSERT INTO city VALUES("1389","0","1","14","Malhargarh ","Malhargarh ","0","0","0","0");
INSERT INTO city VALUES("1390","0","1","14","Manasa ","Manasa ","0","0","0","0");
INSERT INTO city VALUES("1391","0","1","14","Manawar ","Manawar ","0","0","0","0");
INSERT INTO city VALUES("1392","0","1","14","Mandla ","Mandla ","0","0","0","0");
INSERT INTO city VALUES("1393","0","1","14","Mandsaur ","Mandsaur ","0","0","0","0");
INSERT INTO city VALUES("1394","0","1","14","Manpur ","Manpur ","0","0","0","0");
INSERT INTO city VALUES("1395","0","1","14","Mauganj ","Mauganj ","0","0","0","0");
INSERT INTO city VALUES("1396","0","1","14","Mawai ","Mawai ","0","0","0","0");
INSERT INTO city VALUES("1397","0","1","14","Mehgaon ","Mehgaon ","0","0","0","0");
INSERT INTO city VALUES("1398","0","1","14","Mhow ","Mhow ","0","0","0","0");
INSERT INTO city VALUES("1399","0","1","14","Morena ","Morena ","0","0","0","0");
INSERT INTO city VALUES("1400","0","1","14","Multai ","Multai ","0","0","0","0");
INSERT INTO city VALUES("1401","0","1","14","Mungaoli ","Mungaoli ","0","0","0","0");
INSERT INTO city VALUES("1402","0","1","14","Nagod ","Nagod ","0","0","0","0");
INSERT INTO city VALUES("1403","0","1","14","Nainpur ","Nainpur ","0","0","0","0");
INSERT INTO city VALUES("1404","0","1","14","Narsingarh ","Narsingarh ","0","0","0","0");
INSERT INTO city VALUES("1405","0","1","14","Narsinghpur ","Narsinghpur ","0","0","0","0");
INSERT INTO city VALUES("1406","0","1","14","Narwar ","Narwar ","0","0","0","0");
INSERT INTO city VALUES("1407","0","1","14","Nasrullaganj ","Nasrullaganj ","0","0","0","0");
INSERT INTO city VALUES("1408","0","1","14","Nateran ","Nateran ","0","0","0","0");
INSERT INTO city VALUES("1409","0","1","14","Neemuch ","Neemuch ","0","0","0","0");
INSERT INTO city VALUES("1410","0","1","14","Niwari ","Niwari ","0","0","0","0");
INSERT INTO city VALUES("1411","0","1","14","Niwas ","Niwas ","0","0","0","0");
INSERT INTO city VALUES("1412","0","1","14","Nowgaon ","Nowgaon ","0","0","0","0");
INSERT INTO city VALUES("1413","0","1","14","Pachmarhi ","Pachmarhi ","0","0","0","0");
INSERT INTO city VALUES("1414","0","1","14","Pandhana ","Pandhana ","0","0","0","0");
INSERT INTO city VALUES("1415","0","1","14","Pandhurna ","Pandhurna ","0","0","0","0");
INSERT INTO city VALUES("1416","0","1","14","Panna ","Panna ","0","0","0","0");
INSERT INTO city VALUES("1417","0","1","14","Parasia ","Parasia ","0","0","0","0");
INSERT INTO city VALUES("1418","0","1","14","Patan ","Patan ","0","0","0","0");
INSERT INTO city VALUES("1419","0","1","14","Patera ","Patera ","0","0","0","0");
INSERT INTO city VALUES("1420","0","1","14","Patharia ","Patharia ","0","0","0","0");
INSERT INTO city VALUES("1421","0","1","14","Pawai ","Pawai ","0","0","0","0");
INSERT INTO city VALUES("1422","0","1","14","Petlawad ","Petlawad ","0","0","0","0");
INSERT INTO city VALUES("1423","0","1","14","Pichhore ","Pichhore ","0","0","0","0");
INSERT INTO city VALUES("1424","0","1","14","Piparia ","Piparia ","0","0","0","0");
INSERT INTO city VALUES("1425","0","1","14","Pohari ","Pohari ","0","0","0","0");
INSERT INTO city VALUES("1426","0","1","14","Prabhapattan ","Prabhapattan ","0","0","0","0");
INSERT INTO city VALUES("1427","0","1","14","Punasa ","Punasa ","0","0","0","0");
INSERT INTO city VALUES("1428","0","1","14","Pushprajgarh ","Pushprajgarh ","0","0","0","0");
INSERT INTO city VALUES("1429","0","1","14","Raghogarh ","Raghogarh ","0","0","0","0");
INSERT INTO city VALUES("1430","0","1","14","Raghunathpur ","Raghunathpur ","0","0","0","0");
INSERT INTO city VALUES("1431","0","1","14","Rahatgarh ","Rahatgarh ","0","0","0","0");
INSERT INTO city VALUES("1432","0","1","14","Raisen ","Raisen ","0","0","0","0");
INSERT INTO city VALUES("1433","0","1","14","Rajgarh ","Rajgarh ","0","0","0","0");
INSERT INTO city VALUES("1434","0","1","14","Rajpur ","Rajpur ","0","0","0","0");
INSERT INTO city VALUES("1435","0","1","14","Ratlam ","Ratlam ","0","0","0","0");
INSERT INTO city VALUES("1436","0","1","14","Rehli ","Rehli ","0","0","0","0");
INSERT INTO city VALUES("1437","0","1","14","Rewa ","Rewa ","0","0","0","0");
INSERT INTO city VALUES("1438","0","1","14","Sabalgarh ","Sabalgarh ","0","0","0","0");
INSERT INTO city VALUES("1439","0","1","14","Sagar ","Sagar ","0","0","0","0");
INSERT INTO city VALUES("1440","0","1","14","Sailana ","Sailana ","0","0","0","0");
INSERT INTO city VALUES("1441","0","1","14","Sanwer ","Sanwer ","0","0","0","0");
INSERT INTO city VALUES("1442","0","1","14","Sarangpur ","Sarangpur ","0","0","0","0");
INSERT INTO city VALUES("1443","0","1","14","Sardarpur ","Sardarpur ","0","0","0","0");
INSERT INTO city VALUES("1444","0","1","14","Satna ","Satna ","0","0","0","0");
INSERT INTO city VALUES("1445","0","1","14","Saunsar ","Saunsar ","0","0","0","0");
INSERT INTO city VALUES("1446","0","1","14","Sehore ","Sehore ","0","0","0","0");
INSERT INTO city VALUES("1447","0","1","14","Sendhwa ","Sendhwa ","0","0","0","0");
INSERT INTO city VALUES("1448","0","1","14","Seondha ","Seondha ","0","0","0","0");
INSERT INTO city VALUES("1449","0","1","14","Seoni ","Seoni ","0","0","0","0");
INSERT INTO city VALUES("1450","0","1","14","Seonimalwa ","Seonimalwa ","0","0","0","0");
INSERT INTO city VALUES("1451","0","1","14","Shahdol ","Shahdol ","0","0","0","0");
INSERT INTO city VALUES("1452","0","1","14","Shahnagar ","Shahnagar ","0","0","0","0");
INSERT INTO city VALUES("1453","0","1","14","Shahpur ","Shahpur ","0","0","0","0");
INSERT INTO city VALUES("1454","0","1","14","Shajapur ","Shajapur ","0","0","0","0");
INSERT INTO city VALUES("1455","0","1","14","Sheopur ","Sheopur ","0","0","0","0");
INSERT INTO city VALUES("1456","0","1","14","Sheopurkalan ","Sheopurkalan ","0","0","0","0");
INSERT INTO city VALUES("1457","0","1","14","Shivpuri ","Shivpuri ","0","0","0","0");
INSERT INTO city VALUES("1458","0","1","14","Shujalpur ","Shujalpur ","0","0","0","0");
INSERT INTO city VALUES("1459","0","1","14","Sidhi ","Sidhi ","0","0","0","0");
INSERT INTO city VALUES("1460","0","1","14","Sihora ","Sihora ","0","0","0","0");
INSERT INTO city VALUES("1461","0","1","14","Silwani ","Silwani ","0","0","0","0");
INSERT INTO city VALUES("1462","0","1","14","Singrauli ","Singrauli ","0","0","0","0");
INSERT INTO city VALUES("1463","0","1","14","Sirmour ","Sirmour ","0","0","0","0");
INSERT INTO city VALUES("1464","0","1","14","Sironj ","Sironj ","0","0","0","0");
INSERT INTO city VALUES("1465","0","1","14","Sitamau ","Sitamau ","0","0","0","0");
INSERT INTO city VALUES("1466","0","1","14","Sohagpur ","Sohagpur ","0","0","0","0");
INSERT INTO city VALUES("1467","0","1","14","Sondhwa ","Sondhwa ","0","0","0","0");
INSERT INTO city VALUES("1468","0","1","14","Sonkatch ","Sonkatch ","0","0","0","0");
INSERT INTO city VALUES("1469","0","1","14","Susner ","Susner ","0","0","0","0");
INSERT INTO city VALUES("1470","0","1","14","Tamia ","Tamia ","0","0","0","0");
INSERT INTO city VALUES("1471","0","1","14","Tarana ","Tarana ","0","0","0","0");
INSERT INTO city VALUES("1472","0","1","14","Tendukheda ","Tendukheda ","0","0","0","0");
INSERT INTO city VALUES("1473","0","1","14","Teonthar ","Teonthar ","0","0","0","0");
INSERT INTO city VALUES("1474","0","1","14","Thandla ","Thandla ","0","0","0","0");
INSERT INTO city VALUES("1475","0","1","14","Tikamgarh ","Tikamgarh ","0","0","0","0");
INSERT INTO city VALUES("1476","0","1","14","Timarani ","Timarani ","0","0","0","0");
INSERT INTO city VALUES("1477","0","1","14","Udaipura ","Udaipura ","0","0","0","0");
INSERT INTO city VALUES("1478","0","1","14","Ujjain ","Ujjain ","0","0","0","0");
INSERT INTO city VALUES("1479","0","1","14","Umaria ","Umaria ","0","0","0","0");
INSERT INTO city VALUES("1480","0","1","14","Umariapan ","Umariapan ","0","0","0","0");
INSERT INTO city VALUES("1481","0","1","14","Vidisha ","Vidisha ","0","0","0","0");
INSERT INTO city VALUES("1482","0","1","14","Vijayraghogarh ","Vijayraghogarh ","0","0","0","0");
INSERT INTO city VALUES("1483","0","1","14","Waraseoni ","Waraseoni ","0","0","0","0");
INSERT INTO city VALUES("1484","0","1","14","Zhirnia","Zhirnia","0","0","0","0");
INSERT INTO city VALUES("1485","0","1","15","Achalpur ","Achalpur ","0","0","0","0");
INSERT INTO city VALUES("1486","0","1","15","Aheri ","Aheri ","0","0","0","0");
INSERT INTO city VALUES("1487","0","1","15","Ahmednagar ","Ahmednagar ","0","0","0","0");
INSERT INTO city VALUES("1488","0","1","15","Ahmedpur ","Ahmedpur ","0","0","0","0");
INSERT INTO city VALUES("1489","0","1","15","Ajara ","Ajara ","0","0","0","0");
INSERT INTO city VALUES("1490","0","1","15","Akkalkot ","Akkalkot ","0","0","0","0");
INSERT INTO city VALUES("1491","0","1","15","Akola ","Akola ","0","0","0","0");
INSERT INTO city VALUES("1492","0","1","15","Akole ","Akole ","0","0","0","0");
INSERT INTO city VALUES("1493","0","1","15","Akot ","Akot ","0","0","0","0");
INSERT INTO city VALUES("1494","0","1","15","Alibagh ","Alibagh ","0","0","0","0");
INSERT INTO city VALUES("1495","0","1","15","Amagaon ","Amagaon ","0","0","0","0");
INSERT INTO city VALUES("1496","0","1","15","Amalner ","Amalner ","0","0","0","0");
INSERT INTO city VALUES("1497","0","1","15","Ambad ","Ambad ","0","0","0","0");
INSERT INTO city VALUES("1498","0","1","15","Ambejogai ","Ambejogai ","0","0","0","0");
INSERT INTO city VALUES("1499","0","1","15","Amravati ","Amravati ","0","0","0","0");
INSERT INTO city VALUES("1500","0","1","15","Arjuni Merogaon ","Arjuni Merogaon ","0","0","0","0");
INSERT INTO city VALUES("1501","0","1","15","Arvi ","Arvi ","0","0","0","0");
INSERT INTO city VALUES("1502","0","1","15","Ashti ","Ashti ","0","0","0","0");
INSERT INTO city VALUES("1503","0","1","15","Atpadi ","Atpadi ","0","0","0","0");
INSERT INTO city VALUES("1504","0","1","15","Aurangabad ","Aurangabad ","0","0","0","0");
INSERT INTO city VALUES("1505","0","1","15","Ausa ","Ausa ","0","0","0","0");
INSERT INTO city VALUES("1506","0","1","15","Babhulgaon ","Babhulgaon ","0","0","0","0");
INSERT INTO city VALUES("1507","0","1","15","Balapur ","Balapur ","0","0","0","0");
INSERT INTO city VALUES("1508","0","1","15","Baramati ","Baramati ","0","0","0","0");
INSERT INTO city VALUES("1509","0","1","15","Barshi Takli ","Barshi Takli ","0","0","0","0");
INSERT INTO city VALUES("1510","0","1","15","Barsi ","Barsi ","0","0","0","0");
INSERT INTO city VALUES("1511","0","1","15","Basmatnagar ","Basmatnagar ","0","0","0","0");
INSERT INTO city VALUES("1512","0","1","15","Bassein ","Bassein ","0","0","0","0");
INSERT INTO city VALUES("1513","0","1","15","Beed ","Beed ","0","0","0","0");
INSERT INTO city VALUES("1514","0","1","15","Bhadrawati ","Bhadrawati ","0","0","0","0");
INSERT INTO city VALUES("1515","0","1","15","Bhamregadh ","Bhamregadh ","0","0","0","0");
INSERT INTO city VALUES("1516","0","1","15","Bhandara ","Bhandara ","0","0","0","0");
INSERT INTO city VALUES("1517","0","1","15","Bhir ","Bhir ","0","0","0","0");
INSERT INTO city VALUES("1518","0","1","15","Bhiwandi ","Bhiwandi ","0","0","0","0");
INSERT INTO city VALUES("1519","0","1","15","Bhiwapur ","Bhiwapur ","0","0","0","0");
INSERT INTO city VALUES("1520","0","1","15","Bhokar ","Bhokar ","0","0","0","0");
INSERT INTO city VALUES("1521","0","1","15","Bhokardan ","Bhokardan ","0","0","0","0");
INSERT INTO city VALUES("1522","0","1","15","Bhoom ","Bhoom ","0","0","0","0");
INSERT INTO city VALUES("1523","0","1","15","Bhor ","Bhor ","0","0","0","0");
INSERT INTO city VALUES("1524","0","1","15","Bhudargad ","Bhudargad ","0","0","0","0");
INSERT INTO city VALUES("1525","0","1","15","Bhusawal ","Bhusawal ","0","0","0","0");
INSERT INTO city VALUES("1526","0","1","15","Billoli ","Billoli ","0","0","0","0");
INSERT INTO city VALUES("1527","0","1","15","Brahmapuri ","Brahmapuri ","0","0","0","0");
INSERT INTO city VALUES("1528","0","1","15","Buldhana ","Buldhana ","0","0","0","0");
INSERT INTO city VALUES("1529","0","1","15","Butibori ","Butibori ","0","0","0","0");
INSERT INTO city VALUES("1530","0","1","15","Chalisgaon ","Chalisgaon ","0","0","0","0");
INSERT INTO city VALUES("1531","0","1","15","Chamorshi ","Chamorshi ","0","0","0","0");
INSERT INTO city VALUES("1532","0","1","15","Chandgad ","Chandgad ","0","0","0","0");
INSERT INTO city VALUES("1533","0","1","15","Chandrapur ","Chandrapur ","0","0","0","0");
INSERT INTO city VALUES("1534","0","1","15","Chandur ","Chandur ","0","0","0","0");
INSERT INTO city VALUES("1535","0","1","15","Chanwad ","Chanwad ","0","0","0","0");
INSERT INTO city VALUES("1536","0","1","15","Chhikaldara ","Chhikaldara ","0","0","0","0");
INSERT INTO city VALUES("1537","0","1","15","Chikhali ","Chikhali ","0","0","0","0");
INSERT INTO city VALUES("1538","0","1","15","Chinchwad ","Chinchwad ","0","0","0","0");
INSERT INTO city VALUES("1539","0","1","15","Chiplun ","Chiplun ","0","0","0","0");
INSERT INTO city VALUES("1540","0","1","15","Chopda ","Chopda ","0","0","0","0");
INSERT INTO city VALUES("1541","0","1","15","Chumur ","Chumur ","0","0","0","0");
INSERT INTO city VALUES("1542","0","1","15","Dahanu ","Dahanu ","0","0","0","0");
INSERT INTO city VALUES("1543","0","1","15","Dapoli ","Dapoli ","0","0","0","0");
INSERT INTO city VALUES("1544","0","1","15","Darwaha ","Darwaha ","0","0","0","0");
INSERT INTO city VALUES("1545","0","1","15","Daryapur ","Daryapur ","0","0","0","0");
INSERT INTO city VALUES("1546","0","1","15","Daund ","Daund ","0","0","0","0");
INSERT INTO city VALUES("1547","0","1","15","Degloor ","Degloor ","0","0","0","0");
INSERT INTO city VALUES("1548","0","1","15","Delhi Tanda ","Delhi Tanda ","0","0","0","0");
INSERT INTO city VALUES("1549","0","1","15","Deogad ","Deogad ","0","0","0","0");
INSERT INTO city VALUES("1550","0","1","15","Deolgaonraja ","Deolgaonraja ","0","0","0","0");
INSERT INTO city VALUES("1551","0","1","15","Deori ","Deori ","0","0","0","0");
INSERT INTO city VALUES("1552","0","1","15","Desaiganj ","Desaiganj ","0","0","0","0");
INSERT INTO city VALUES("1553","0","1","15","Dhadgaon ","Dhadgaon ","0","0","0","0");
INSERT INTO city VALUES("1554","0","1","15","Dhanora ","Dhanora ","0","0","0","0");
INSERT INTO city VALUES("1555","0","1","15","Dharani ","Dharani ","0","0","0","0");
INSERT INTO city VALUES("1556","0","1","15","Dhiwadi ","Dhiwadi ","0","0","0","0");
INSERT INTO city VALUES("1557","0","1","15","Dhule ","Dhule ","0","0","0","0");
INSERT INTO city VALUES("1558","0","1","15","Dhulia ","Dhulia ","0","0","0","0");
INSERT INTO city VALUES("1559","0","1","15","Digras ","Digras ","0","0","0","0");
INSERT INTO city VALUES("1560","0","1","15","Dindori ","Dindori ","0","0","0","0");
INSERT INTO city VALUES("1561","0","1","15","Edalabad ","Edalabad ","0","0","0","0");
INSERT INTO city VALUES("1562","0","1","15","Erandul ","Erandul ","0","0","0","0");
INSERT INTO city VALUES("1563","0","1","15","Etapalli ","Etapalli ","0","0","0","0");
INSERT INTO city VALUES("1564","0","1","15","Gadhchiroli ","Gadhchiroli ","0","0","0","0");
INSERT INTO city VALUES("1565","0","1","15","Gadhinglaj ","Gadhinglaj ","0","0","0","0");
INSERT INTO city VALUES("1566","0","1","15","Gaganbavada ","Gaganbavada ","0","0","0","0");
INSERT INTO city VALUES("1567","0","1","15","Gangakhed ","Gangakhed ","0","0","0","0");
INSERT INTO city VALUES("1568","0","1","15","Gangapur ","Gangapur ","0","0","0","0");
INSERT INTO city VALUES("1569","0","1","15","Gevrai ","Gevrai ","0","0","0","0");
INSERT INTO city VALUES("1570","0","1","15","Ghatanji ","Ghatanji ","0","0","0","0");
INSERT INTO city VALUES("1571","0","1","15","Golegaon ","Golegaon ","0","0","0","0");
INSERT INTO city VALUES("1572","0","1","15","Gondia ","Gondia ","0","0","0","0");
INSERT INTO city VALUES("1573","0","1","15","Gondpipri ","Gondpipri ","0","0","0","0");
INSERT INTO city VALUES("1574","0","1","15","Goregaon ","Goregaon ","0","0","0","0");
INSERT INTO city VALUES("1575","0","1","15","Guhagar ","Guhagar ","0","0","0","0");
INSERT INTO city VALUES("1576","0","1","15","Hadgaon ","Hadgaon ","0","0","0","0");
INSERT INTO city VALUES("1577","0","1","15","Hatkangale ","Hatkangale ","0","0","0","0");
INSERT INTO city VALUES("1578","0","1","15","Hinganghat ","Hinganghat ","0","0","0","0");
INSERT INTO city VALUES("1579","0","1","15","Hingoli ","Hingoli ","0","0","0","0");
INSERT INTO city VALUES("1580","0","1","15","Hingua ","Hingua ","0","0","0","0");
INSERT INTO city VALUES("1581","0","1","15","Igatpuri ","Igatpuri ","0","0","0","0");
INSERT INTO city VALUES("1582","0","1","15","Indapur ","Indapur ","0","0","0","0");
INSERT INTO city VALUES("1583","0","1","15","Islampur ","Islampur ","0","0","0","0");
INSERT INTO city VALUES("1584","0","1","15","Jalgaon ","Jalgaon ","0","0","0","0");
INSERT INTO city VALUES("1585","0","1","15","Jalna ","Jalna ","0","0","0","0");
INSERT INTO city VALUES("1586","0","1","15","Jamkhed ","Jamkhed ","0","0","0","0");
INSERT INTO city VALUES("1587","0","1","15","Jamner ","Jamner ","0","0","0","0");
INSERT INTO city VALUES("1588","0","1","15","Jath ","Jath ","0","0","0","0");
INSERT INTO city VALUES("1589","0","1","15","Jawahar ","Jawahar ","0","0","0","0");
INSERT INTO city VALUES("1590","0","1","15","Jintdor ","Jintdor ","0","0","0","0");
INSERT INTO city VALUES("1591","0","1","15","Junnar ","Junnar ","0","0","0","0");
INSERT INTO city VALUES("1592","0","1","15","Kagal ","Kagal ","0","0","0","0");
INSERT INTO city VALUES("1593","0","1","15","Kaij ","Kaij ","0","0","0","0");
INSERT INTO city VALUES("1594","0","1","15","Kalamb ","Kalamb ","0","0","0","0");
INSERT INTO city VALUES("1595","0","1","15","Kalamnuri ","Kalamnuri ","0","0","0","0");
INSERT INTO city VALUES("1596","0","1","15","Kallam ","Kallam ","0","0","0","0");
INSERT INTO city VALUES("1597","0","1","15","Kalmeshwar ","Kalmeshwar ","0","0","0","0");
INSERT INTO city VALUES("1598","0","1","15","Kalwan ","Kalwan ","0","0","0","0");
INSERT INTO city VALUES("1599","0","1","15","Kalyan ","Kalyan ","0","0","0","0");
INSERT INTO city VALUES("1600","0","1","15","Kamptee ","Kamptee ","0","0","0","0");
INSERT INTO city VALUES("1601","0","1","15","Kandhar ","Kandhar ","0","0","0","0");
INSERT INTO city VALUES("1602","0","1","15","Kankavali ","Kankavali ","0","0","0","0");
INSERT INTO city VALUES("1603","0","1","15","Kannad ","Kannad ","0","0","0","0");
INSERT INTO city VALUES("1604","0","1","15","Karad ","Karad ","0","0","0","0");
INSERT INTO city VALUES("1605","0","1","15","Karjat ","Karjat ","0","0","0","0");
INSERT INTO city VALUES("1606","0","1","15","Karmala ","Karmala ","0","0","0","0");
INSERT INTO city VALUES("1607","0","1","15","Katol ","Katol ","0","0","0","0");
INSERT INTO city VALUES("1608","0","1","15","Kavathemankal ","Kavathemankal ","0","0","0","0");
INSERT INTO city VALUES("1609","0","1","15","Kedgaon ","Kedgaon ","0","0","0","0");
INSERT INTO city VALUES("1610","0","1","15","Khadakwasala ","Khadakwasala ","0","0","0","0");
INSERT INTO city VALUES("1611","0","1","15","Khamgaon ","Khamgaon ","0","0","0","0");
INSERT INTO city VALUES("1612","0","1","15","Khed ","Khed ","0","0","0","0");
INSERT INTO city VALUES("1613","0","1","15","Khopoli ","Khopoli ","0","0","0","0");
INSERT INTO city VALUES("1614","0","1","15","Khultabad ","Khultabad ","0","0","0","0");
INSERT INTO city VALUES("1615","0","1","15","Kinwat ","Kinwat ","0","0","0","0");
INSERT INTO city VALUES("1616","0","1","15","Kolhapur ","Kolhapur ","0","0","0","0");
INSERT INTO city VALUES("1617","0","1","15","Kopargaon ","Kopargaon ","0","0","0","0");
INSERT INTO city VALUES("1618","0","1","15","Koregaon ","Koregaon ","0","0","0","0");
INSERT INTO city VALUES("1619","0","1","15","Kudal ","Kudal ","0","0","0","0");
INSERT INTO city VALUES("1620","0","1","15","Kuhi ","Kuhi ","0","0","0","0");
INSERT INTO city VALUES("1621","0","1","15","Kurkheda ","Kurkheda ","0","0","0","0");
INSERT INTO city VALUES("1622","0","1","15","Kusumba ","Kusumba ","0","0","0","0");
INSERT INTO city VALUES("1623","0","1","15","Lakhandur ","Lakhandur ","0","0","0","0");
INSERT INTO city VALUES("1624","0","1","15","Langa ","Langa ","0","0","0","0");
INSERT INTO city VALUES("1625","0","1","15","Latur ","Latur ","0","0","0","0");
INSERT INTO city VALUES("1626","0","1","15","Lonar ","Lonar ","0","0","0","0");
INSERT INTO city VALUES("1627","0","1","15","Lonavala ","Lonavala ","0","0","0","0");
INSERT INTO city VALUES("1628","0","1","15","Madangad ","Madangad ","0","0","0","0");
INSERT INTO city VALUES("1629","0","1","15","Madha ","Madha ","0","0","0","0");
INSERT INTO city VALUES("1630","0","1","15","Mahabaleshwar ","Mahabaleshwar ","0","0","0","0");
INSERT INTO city VALUES("1631","0","1","15","Mahad ","Mahad ","0","0","0","0");
INSERT INTO city VALUES("1632","0","1","15","Mahagaon ","Mahagaon ","0","0","0","0");
INSERT INTO city VALUES("1633","0","1","15","Mahasala ","Mahasala ","0","0","0","0");
INSERT INTO city VALUES("1634","0","1","15","Mahaswad ","Mahaswad ","0","0","0","0");
INSERT INTO city VALUES("1635","0","1","15","Malegaon ","Malegaon ","0","0","0","0");
INSERT INTO city VALUES("1636","0","1","15","Malgaon ","Malgaon ","0","0","0","0");
INSERT INTO city VALUES("1637","0","1","15","Malgund ","Malgund ","0","0","0","0");
INSERT INTO city VALUES("1638","0","1","15","Malkapur ","Malkapur ","0","0","0","0");
INSERT INTO city VALUES("1639","0","1","15","Malsuras ","Malsuras ","0","0","0","0");
INSERT INTO city VALUES("1640","0","1","15","Malwan ","Malwan ","0","0","0","0");
INSERT INTO city VALUES("1641","0","1","15","Mancher ","Mancher ","0","0","0","0");
INSERT INTO city VALUES("1642","0","1","15","Mangalwedha ","Mangalwedha ","0","0","0","0");
INSERT INTO city VALUES("1643","0","1","15","Mangaon ","Mangaon ","0","0","0","0");
INSERT INTO city VALUES("1644","0","1","15","Mangrulpur ","Mangrulpur ","0","0","0","0");
INSERT INTO city VALUES("1645","0","1","15","Manjalegaon ","Manjalegaon ","0","0","0","0");
INSERT INTO city VALUES("1646","0","1","15","Manmad ","Manmad ","0","0","0","0");
INSERT INTO city VALUES("1647","0","1","15","Maregaon ","Maregaon ","0","0","0","0");
INSERT INTO city VALUES("1648","0","1","15","Mehda ","Mehda ","0","0","0","0");
INSERT INTO city VALUES("1649","0","1","15","Mekhar ","Mekhar ","0","0","0","0");
INSERT INTO city VALUES("1650","0","1","15","Mohadi ","Mohadi ","0","0","0","0");
INSERT INTO city VALUES("1651","0","1","15","Mohol ","Mohol ","0","0","0","0");
INSERT INTO city VALUES("1652","0","1","15","Mokhada ","Mokhada ","0","0","0","0");
INSERT INTO city VALUES("1653","0","1","15","Morshi ","Morshi ","0","0","0","0");
INSERT INTO city VALUES("1654","0","1","15","Mouda ","Mouda ","0","0","0","0");
INSERT INTO city VALUES("1655","0","1","15","Mukhed ","Mukhed ","0","0","0","0");
INSERT INTO city VALUES("1656","0","1","15","Mul ","Mul ","0","0","0","0");
INSERT INTO city VALUES("1657","0","1","15","Mumbai ","Mumbai ","0","0","0","0");
INSERT INTO city VALUES("1658","0","1","15","Murbad ","Murbad ","0","0","0","0");
INSERT INTO city VALUES("1659","0","1","15","Murtizapur ","Murtizapur ","0","0","0","0");
INSERT INTO city VALUES("1660","0","1","15","Murud ","Murud ","0","0","0","0");
INSERT INTO city VALUES("1661","0","1","15","Nagbhir ","Nagbhir ","0","0","0","0");
INSERT INTO city VALUES("1662","0","1","15","Nagpur ","Nagpur ","0","0","0","0");
INSERT INTO city VALUES("1663","0","1","15","Nahavara ","Nahavara ","0","0","0","0");
INSERT INTO city VALUES("1664","0","1","15","Nanded ","Nanded ","0","0","0","0");
INSERT INTO city VALUES("1665","0","1","15","Nandgaon ","Nandgaon ","0","0","0","0");
INSERT INTO city VALUES("1666","0","1","15","Nandnva ","Nandnva ","0","0","0","0");
INSERT INTO city VALUES("1667","0","1","15","Nandurbar ","Nandurbar ","0","0","0","0");
INSERT INTO city VALUES("1668","0","1","15","Narkhed ","Narkhed ","0","0","0","0");
INSERT INTO city VALUES("1669","0","1","15","Nashik ","Nashik ","0","0","0","0");
INSERT INTO city VALUES("1670","0","1","15","Navapur ","Navapur ","0","0","0","0");
INSERT INTO city VALUES("1671","0","1","15","Ner ","Ner ","0","0","0","0");
INSERT INTO city VALUES("1672","0","1","15","Newasa ","Newasa ","0","0","0","0");
INSERT INTO city VALUES("1673","0","1","15","Nilanga ","Nilanga ","0","0","0","0");
INSERT INTO city VALUES("1674","0","1","15","Niphad ","Niphad ","0","0","0","0");
INSERT INTO city VALUES("1675","0","1","15","Omerga ","Omerga ","0","0","0","0");
INSERT INTO city VALUES("1676","0","1","15","Osmanabad ","Osmanabad ","0","0","0","0");
INSERT INTO city VALUES("1677","0","1","15","Pachora ","Pachora ","0","0","0","0");
INSERT INTO city VALUES("1678","0","1","15","Paithan ","Paithan ","0","0","0","0");
INSERT INTO city VALUES("1679","0","1","15","Palghar ","Palghar ","0","0","0","0");
INSERT INTO city VALUES("1680","0","1","15","Pali ","Pali ","0","0","0","0");
INSERT INTO city VALUES("1681","0","1","15","Pandharkawada ","Pandharkawada ","0","0","0","0");
INSERT INTO city VALUES("1682","0","1","15","Pandharpur ","Pandharpur ","0","0","0","0");
INSERT INTO city VALUES("1683","0","1","15","Panhala ","Panhala ","0","0","0","0");
INSERT INTO city VALUES("1684","0","1","15","Paranda ","Paranda ","0","0","0","0");
INSERT INTO city VALUES("1685","0","1","15","Parbhani ","Parbhani ","0","0","0","0");
INSERT INTO city VALUES("1686","0","1","15","Parner ","Parner ","0","0","0","0");
INSERT INTO city VALUES("1687","0","1","15","Parola ","Parola ","0","0","0","0");
INSERT INTO city VALUES("1688","0","1","15","Parseoni ","Parseoni ","0","0","0","0");
INSERT INTO city VALUES("1689","0","1","15","Partur ","Partur ","0","0","0","0");
INSERT INTO city VALUES("1690","0","1","15","Patan ","Patan ","0","0","0","0");
INSERT INTO city VALUES("1691","0","1","15","Pathardi ","Pathardi ","0","0","0","0");
INSERT INTO city VALUES("1692","0","1","15","Pathari ","Pathari ","0","0","0","0");
INSERT INTO city VALUES("1693","0","1","15","Patoda ","Patoda ","0","0","0","0");
INSERT INTO city VALUES("1694","0","1","15","Pauni ","Pauni ","0","0","0","0");
INSERT INTO city VALUES("1695","0","1","15","Peint ","Peint ","0","0","0","0");
INSERT INTO city VALUES("1696","0","1","15","Pen ","Pen ","0","0","0","0");
INSERT INTO city VALUES("1697","0","1","15","Phaltan ","Phaltan ","0","0","0","0");
INSERT INTO city VALUES("1698","0","1","15","Pimpalner ","Pimpalner ","0","0","0","0");
INSERT INTO city VALUES("1699","0","1","15","Pirangut ","Pirangut ","0","0","0","0");
INSERT INTO city VALUES("1700","0","1","15","Poladpur ","Poladpur ","0","0","0","0");
INSERT INTO city VALUES("1701","0","1","15","Pune ","Pune ","0","0","0","0");
INSERT INTO city VALUES("1702","0","1","15","Pusad ","Pusad ","0","0","0","0");
INSERT INTO city VALUES("1703","0","1","15","Pusegaon ","Pusegaon ","0","0","0","0");
INSERT INTO city VALUES("1704","0","1","15","Radhanagar ","Radhanagar ","0","0","0","0");
INSERT INTO city VALUES("1705","0","1","15","Rahuri ","Rahuri ","0","0","0","0");
INSERT INTO city VALUES("1706","0","1","15","Raigad ","Raigad ","0","0","0","0");
INSERT INTO city VALUES("1707","0","1","15","Rajapur ","Rajapur ","0","0","0","0");
INSERT INTO city VALUES("1708","0","1","15","Rajgurunagar ","Rajgurunagar ","0","0","0","0");
INSERT INTO city VALUES("1709","0","1","15","Rajura ","Rajura ","0","0","0","0");
INSERT INTO city VALUES("1710","0","1","15","Ralegaon ","Ralegaon ","0","0","0","0");
INSERT INTO city VALUES("1711","0","1","15","Ramtek ","Ramtek ","0","0","0","0");
INSERT INTO city VALUES("1712","0","1","15","Ratnagiri ","Ratnagiri ","0","0","0","0");
INSERT INTO city VALUES("1713","0","1","15","Raver ","Raver ","0","0","0","0");
INSERT INTO city VALUES("1714","0","1","15","Risod ","Risod ","0","0","0","0");
INSERT INTO city VALUES("1715","0","1","15","Roha ","Roha ","0","0","0","0");
INSERT INTO city VALUES("1716","0","1","15","Sakarwadi ","Sakarwadi ","0","0","0","0");
INSERT INTO city VALUES("1717","0","1","15","Sakoli ","Sakoli ","0","0","0","0");
INSERT INTO city VALUES("1718","0","1","15","Sakri ","Sakri ","0","0","0","0");
INSERT INTO city VALUES("1719","0","1","15","Salekasa ","Salekasa ","0","0","0","0");
INSERT INTO city VALUES("1720","0","1","15","Samudrapur ","Samudrapur ","0","0","0","0");
INSERT INTO city VALUES("1721","0","1","15","Sangamner ","Sangamner ","0","0","0","0");
INSERT INTO city VALUES("1722","0","1","15","Sanganeshwar ","Sanganeshwar ","0","0","0","0");
INSERT INTO city VALUES("1723","0","1","15","Sangli ","Sangli ","0","0","0","0");
INSERT INTO city VALUES("1724","0","1","15","Sangola ","Sangola ","0","0","0","0");
INSERT INTO city VALUES("1725","0","1","15","Sanguem ","Sanguem ","0","0","0","0");
INSERT INTO city VALUES("1726","0","1","15","Saoner ","Saoner ","0","0","0","0");
INSERT INTO city VALUES("1727","0","1","15","Saswad ","Saswad ","0","0","0","0");
INSERT INTO city VALUES("1728","0","1","15","Satana ","Satana ","0","0","0","0");
INSERT INTO city VALUES("1729","0","1","15","Satara ","Satara ","0","0","0","0");
INSERT INTO city VALUES("1730","0","1","15","Sawantwadi ","Sawantwadi ","0","0","0","0");
INSERT INTO city VALUES("1731","0","1","15","Seloo ","Seloo ","0","0","0","0");
INSERT INTO city VALUES("1732","0","1","15","Shahada ","Shahada ","0","0","0","0");
INSERT INTO city VALUES("1733","0","1","15","Shahapur ","Shahapur ","0","0","0","0");
INSERT INTO city VALUES("1734","0","1","15","Shahuwadi ","Shahuwadi ","0","0","0","0");
INSERT INTO city VALUES("1735","0","1","15","Shevgaon ","Shevgaon ","0","0","0","0");
INSERT INTO city VALUES("1736","0","1","15","Shirala ","Shirala ","0","0","0","0");
INSERT INTO city VALUES("1737","0","1","15","Shirol ","Shirol ","0","0","0","0");
INSERT INTO city VALUES("1738","0","1","15","Shirpur ","Shirpur ","0","0","0","0");
INSERT INTO city VALUES("1739","0","1","15","Shirur ","Shirur ","0","0","0","0");
INSERT INTO city VALUES("1740","0","1","15","Shirwal ","Shirwal ","0","0","0","0");
INSERT INTO city VALUES("1741","0","1","15","Sholapur ","Sholapur ","0","0","0","0");
INSERT INTO city VALUES("1742","0","1","15","Shri Rampur ","Shri Rampur ","0","0","0","0");
INSERT INTO city VALUES("1743","0","1","15","Shrigonda ","Shrigonda ","0","0","0","0");
INSERT INTO city VALUES("1744","0","1","15","Shrivardhan ","Shrivardhan ","0","0","0","0");
INSERT INTO city VALUES("1745","0","1","15","Sillod ","Sillod ","0","0","0","0");
INSERT INTO city VALUES("1746","0","1","15","Sinderwahi ","Sinderwahi ","0","0","0","0");
INSERT INTO city VALUES("1747","0","1","15","Sindhudurg ","Sindhudurg ","0","0","0","0");
INSERT INTO city VALUES("1748","0","1","15","Sindkheda ","Sindkheda ","0","0","0","0");
INSERT INTO city VALUES("1749","0","1","15","Sindkhedaraja ","Sindkhedaraja ","0","0","0","0");
INSERT INTO city VALUES("1750","0","1","15","Sinnar ","Sinnar ","0","0","0","0");
INSERT INTO city VALUES("1751","0","1","15","Sironcha ","Sironcha ","0","0","0","0");
INSERT INTO city VALUES("1752","0","1","15","Soyegaon ","Soyegaon ","0","0","0","0");
INSERT INTO city VALUES("1753","0","1","15","Surgena ","Surgena ","0","0","0","0");
INSERT INTO city VALUES("1754","0","1","15","Talasari ","Talasari ","0","0","0","0");
INSERT INTO city VALUES("1755","0","1","15","Talegaon S.Ji Pant ","Talegaon S.Ji Pant ","0","0","0","0");
INSERT INTO city VALUES("1756","0","1","15","Taloda ","Taloda ","0","0","0","0");
INSERT INTO city VALUES("1757","0","1","15","Tasgaon ","Tasgaon ","0","0","0","0");
INSERT INTO city VALUES("1758","0","1","15","Thane ","Thane ","0","0","0","0");
INSERT INTO city VALUES("1759","0","1","15","Tirora ","Tirora ","0","0","0","0");
INSERT INTO city VALUES("1760","0","1","15","Tiwasa ","Tiwasa ","0","0","0","0");
INSERT INTO city VALUES("1761","0","1","15","Trimbak ","Trimbak ","0","0","0","0");
INSERT INTO city VALUES("1762","0","1","15","Tuljapur ","Tuljapur ","0","0","0","0");
INSERT INTO city VALUES("1763","0","1","15","Tumsar ","Tumsar ","0","0","0","0");
INSERT INTO city VALUES("1764","0","1","15","Udgir ","Udgir ","0","0","0","0");
INSERT INTO city VALUES("1765","0","1","15","Umarkhed ","Umarkhed ","0","0","0","0");
INSERT INTO city VALUES("1766","0","1","15","Umrane ","Umrane ","0","0","0","0");
INSERT INTO city VALUES("1767","0","1","15","Umrer ","Umrer ","0","0","0","0");
INSERT INTO city VALUES("1768","0","1","15","Urlikanchan ","Urlikanchan ","0","0","0","0");
INSERT INTO city VALUES("1769","0","1","15","Vaduj ","Vaduj ","0","0","0","0");
INSERT INTO city VALUES("1770","0","1","15","Velhe ","Velhe ","0","0","0","0");
INSERT INTO city VALUES("1771","0","1","15","Vengurla ","Vengurla ","0","0","0","0");
INSERT INTO city VALUES("1772","0","1","15","Vijapur ","Vijapur ","0","0","0","0");
INSERT INTO city VALUES("1773","0","1","15","Vita ","Vita ","0","0","0","0");
INSERT INTO city VALUES("1774","0","1","15","Wada ","Wada ","0","0","0","0");
INSERT INTO city VALUES("1775","0","1","15","Wai ","Wai ","0","0","0","0");
INSERT INTO city VALUES("1776","0","1","15","Walchandnagar ","Walchandnagar ","0","0","0","0");
INSERT INTO city VALUES("1777","0","1","15","Wani ","Wani ","0","0","0","0");
INSERT INTO city VALUES("1778","0","1","15","Wardha ","Wardha ","0","0","0","0");
INSERT INTO city VALUES("1779","0","1","15","Warlydwarud ","Warlydwarud ","0","0","0","0");
INSERT INTO city VALUES("1780","0","1","15","Warora ","Warora ","0","0","0","0");
INSERT INTO city VALUES("1781","0","1","15","Washim ","Washim ","0","0","0","0");
INSERT INTO city VALUES("1782","0","1","15","Wathar ","Wathar ","0","0","0","0");
INSERT INTO city VALUES("1783","0","1","15","Yavatmal ","Yavatmal ","0","0","0","0");
INSERT INTO city VALUES("1784","0","1","15","Yawal ","Yawal ","0","0","0","0");
INSERT INTO city VALUES("1785","0","1","15","Yeola ","Yeola ","0","0","0","0");
INSERT INTO city VALUES("1786","0","1","15","Yeotmal ","Yeotmal ","0","0","0","0");
INSERT INTO city VALUES("1787","0","1","16","Bishnupur ","Bishnupur ","0","0","0","0");
INSERT INTO city VALUES("1788","0","1","16","Chakpikarong ","Chakpikarong ","0","0","0","0");
INSERT INTO city VALUES("1789","0","1","16","Chandel ","Chandel ","0","0","0","0");
INSERT INTO city VALUES("1790","0","1","16","Chattrik ","Chattrik ","0","0","0","0");
INSERT INTO city VALUES("1791","0","1","16","Churachandpur ","Churachandpur ","0","0","0","0");
INSERT INTO city VALUES("1792","0","1","16","Imphal ","Imphal ","0","0","0","0");
INSERT INTO city VALUES("1793","0","1","16","Jiribam ","Jiribam ","0","0","0","0");
INSERT INTO city VALUES("1794","0","1","16","Kakching ","Kakching ","0","0","0","0");
INSERT INTO city VALUES("1795","0","1","16","Kalapahar ","Kalapahar ","0","0","0","0");
INSERT INTO city VALUES("1796","0","1","16","Mao ","Mao ","0","0","0","0");
INSERT INTO city VALUES("1797","0","1","16","Mulam ","Mulam ","0","0","0","0");
INSERT INTO city VALUES("1798","0","1","16","Parbung ","Parbung ","0","0","0","0");
INSERT INTO city VALUES("1799","0","1","16","Sadarhills ","Sadarhills ","0","0","0","0");
INSERT INTO city VALUES("1800","0","1","16","Saibom ","Saibom ","0","0","0","0");
INSERT INTO city VALUES("1801","0","1","16","Sempang ","Sempang ","0","0","0","0");
INSERT INTO city VALUES("1802","0","1","16","Senapati ","Senapati ","0","0","0","0");
INSERT INTO city VALUES("1803","0","1","16","Sochumer ","Sochumer ","0","0","0","0");
INSERT INTO city VALUES("1804","0","1","16","Taloulong ","Taloulong ","0","0","0","0");
INSERT INTO city VALUES("1805","0","1","16","Tamenglong ","Tamenglong ","0","0","0","0");
INSERT INTO city VALUES("1806","0","1","16","Thinghat ","Thinghat ","0","0","0","0");
INSERT INTO city VALUES("1807","0","1","16","Thoubal ","Thoubal ","0","0","0","0");
INSERT INTO city VALUES("1808","0","1","16","Ukhrul ","Ukhrul ","0","0","0","0");
INSERT INTO city VALUES("1809","0","1","17","Amlaren ","Amlaren ","0","0","0","0");
INSERT INTO city VALUES("1810","0","1","17","Baghmara ","Baghmara ","0","0","0","0");
INSERT INTO city VALUES("1811","0","1","17","Cherrapunjee ","Cherrapunjee ","0","0","0","0");
INSERT INTO city VALUES("1812","0","1","17","Dadengiri ","Dadengiri ","0","0","0","0");
INSERT INTO city VALUES("1813","0","1","17","Garo Hills ","Garo Hills ","0","0","0","0");
INSERT INTO city VALUES("1814","0","1","17","Jaintia Hills ","Jaintia Hills ","0","0","0","0");
INSERT INTO city VALUES("1815","0","1","17","Jowai ","Jowai ","0","0","0","0");
INSERT INTO city VALUES("1816","0","1","17","Khasi Hills ","Khasi Hills ","0","0","0","0");
INSERT INTO city VALUES("1817","0","1","17","Khliehriat ","Khliehriat ","0","0","0","0");
INSERT INTO city VALUES("1818","0","1","17","Mariang ","Mariang ","0","0","0","0");
INSERT INTO city VALUES("1819","0","1","17","Mawkyrwat ","Mawkyrwat ","0","0","0","0");
INSERT INTO city VALUES("1820","0","1","17","Nongpoh ","Nongpoh ","0","0","0","0");
INSERT INTO city VALUES("1821","0","1","17","Nongstoin ","Nongstoin ","0","0","0","0");
INSERT INTO city VALUES("1822","0","1","17","Resubelpara ","Resubelpara ","0","0","0","0");
INSERT INTO city VALUES("1823","0","1","17","Ri Bhoi ","Ri Bhoi ","0","0","0","0");
INSERT INTO city VALUES("1824","0","1","17","Shillong ","Shillong ","0","0","0","0");
INSERT INTO city VALUES("1825","0","1","17","Tura ","Tura ","0","0","0","0");
INSERT INTO city VALUES("1826","0","1","17","Williamnagar ","Williamnagar ","0","0","0","0");
INSERT INTO city VALUES("1827","0","1","18","Aizawl ","Aizawl ","0","0","0","0");
INSERT INTO city VALUES("1828","0","1","18","Champhai ","Champhai ","0","0","0","0");
INSERT INTO city VALUES("1829","0","1","18","Demagiri ","Demagiri ","0","0","0","0");
INSERT INTO city VALUES("1830","0","1","18","Kolasib ","Kolasib ","0","0","0","0");
INSERT INTO city VALUES("1831","0","1","18","Lawngtlai ","Lawngtlai ","0","0","0","0");
INSERT INTO city VALUES("1832","0","1","18","Lunglei ","Lunglei ","0","0","0","0");
INSERT INTO city VALUES("1833","0","1","18","Mamit ","Mamit ","0","0","0","0");
INSERT INTO city VALUES("1834","0","1","18","Saiha ","Saiha ","0","0","0","0");
INSERT INTO city VALUES("1835","0","1","18","Serchhip ","Serchhip ","0","0","0","0");
INSERT INTO city VALUES("1836","0","1","19","Dimapur ","Dimapur ","0","0","0","0");
INSERT INTO city VALUES("1837","0","1","19","Jalukie ","Jalukie ","0","0","0","0");
INSERT INTO city VALUES("1838","0","1","19","Kiphire ","Kiphire ","0","0","0","0");
INSERT INTO city VALUES("1839","0","1","19","Kohima ","Kohima ","0","0","0","0");
INSERT INTO city VALUES("1840","0","1","19","Mokokchung ","Mokokchung ","0","0","0","0");
INSERT INTO city VALUES("1841","0","1","19","Mon ","Mon ","0","0","0","0");
INSERT INTO city VALUES("1842","0","1","19","Phek ","Phek ","0","0","0","0");
INSERT INTO city VALUES("1843","0","1","19","Tuensang ","Tuensang ","0","0","0","0");
INSERT INTO city VALUES("1844","0","1","19","Wokha ","Wokha ","0","0","0","0");
INSERT INTO city VALUES("1845","0","1","19","Zunheboto ","Zunheboto ","0","0","0","0");
INSERT INTO city VALUES("1846","0","1","20","Anandapur ","Anandapur ","0","0","0","0");
INSERT INTO city VALUES("1847","0","1","20","Angul ","Angul ","0","0","0","0");
INSERT INTO city VALUES("1848","0","1","20","Anugul ","Anugul ","0","0","0","0");
INSERT INTO city VALUES("1849","0","1","20","Aska ","Aska ","0","0","0","0");
INSERT INTO city VALUES("1850","0","1","20","Athgarh ","Athgarh ","0","0","0","0");
INSERT INTO city VALUES("1851","0","1","20","Athmallik ","Athmallik ","0","0","0","0");
INSERT INTO city VALUES("1852","0","1","20","Attabira ","Attabira ","0","0","0","0");
INSERT INTO city VALUES("1853","0","1","20","Bagdihi ","Bagdihi ","0","0","0","0");
INSERT INTO city VALUES("1854","0","1","20","Balangir ","Balangir ","0","0","0","0");
INSERT INTO city VALUES("1855","0","1","20","Balasore ","Balasore ","0","0","0","0");
INSERT INTO city VALUES("1856","0","1","20","Baleswar ","Baleswar ","0","0","0","0");
INSERT INTO city VALUES("1857","0","1","20","Baliguda ","Baliguda ","0","0","0","0");
INSERT INTO city VALUES("1858","0","1","20","Balugaon ","Balugaon ","0","0","0","0");
INSERT INTO city VALUES("1859","0","1","20","Banaigarh ","Banaigarh ","0","0","0","0");
INSERT INTO city VALUES("1860","0","1","20","Bangiriposi ","Bangiriposi ","0","0","0","0");
INSERT INTO city VALUES("1861","0","1","20","Barbil ","Barbil ","0","0","0","0");
INSERT INTO city VALUES("1862","0","1","20","Bargarh ","Bargarh ","0","0","0","0");
INSERT INTO city VALUES("1863","0","1","20","Baripada ","Baripada ","0","0","0","0");
INSERT INTO city VALUES("1864","0","1","20","Barkot ","Barkot ","0","0","0","0");
INSERT INTO city VALUES("1865","0","1","20","Basta ","Basta ","0","0","0","0");
INSERT INTO city VALUES("1866","0","1","20","Berhampur ","Berhampur ","0","0","0","0");
INSERT INTO city VALUES("1867","0","1","20","Betanati ","Betanati ","0","0","0","0");
INSERT INTO city VALUES("1868","0","1","20","Bhadrak ","Bhadrak ","0","0","0","0");
INSERT INTO city VALUES("1869","0","1","20","Bhanjanagar ","Bhanjanagar ","0","0","0","0");
INSERT INTO city VALUES("1870","0","1","20","Bhawanipatna ","Bhawanipatna ","0","0","0","0");
INSERT INTO city VALUES("1871","0","1","20","Bhubaneswar ","Bhubaneswar ","0","0","0","0");
INSERT INTO city VALUES("1872","0","1","20","Birmaharajpur ","Birmaharajpur ","0","0","0","0");
INSERT INTO city VALUES("1873","0","1","20","Bisam Cuttack ","Bisam Cuttack ","0","0","0","0");
INSERT INTO city VALUES("1874","0","1","20","Boriguma ","Boriguma ","0","0","0","0");
INSERT INTO city VALUES("1875","0","1","20","Boudh ","Boudh ","0","0","0","0");
INSERT INTO city VALUES("1876","0","1","20","Buguda ","Buguda ","0","0","0","0");
INSERT INTO city VALUES("1877","0","1","20","Chandbali ","Chandbali ","0","0","0","0");
INSERT INTO city VALUES("1878","0","1","20","Chhatrapur ","Chhatrapur ","0","0","0","0");
INSERT INTO city VALUES("1879","0","1","20","Chhendipada ","Chhendipada ","0","0","0","0");
INSERT INTO city VALUES("1880","0","1","20","Cuttack ","Cuttack ","0","0","0","0");
INSERT INTO city VALUES("1881","0","1","20","Daringbadi ","Daringbadi ","0","0","0","0");
INSERT INTO city VALUES("1882","0","1","20","Daspalla ","Daspalla ","0","0","0","0");
INSERT INTO city VALUES("1883","0","1","20","Deodgarh ","Deodgarh ","0","0","0","0");
INSERT INTO city VALUES("1884","0","1","20","Deogarh ","Deogarh ","0","0","0","0");
INSERT INTO city VALUES("1885","0","1","20","Dhanmandal ","Dhanmandal ","0","0","0","0");
INSERT INTO city VALUES("1886","0","1","20","Dharamgarh ","Dharamgarh ","0","0","0","0");
INSERT INTO city VALUES("1887","0","1","20","Dhenkanal ","Dhenkanal ","0","0","0","0");
INSERT INTO city VALUES("1888","0","1","20","Digapahandi ","Digapahandi ","0","0","0","0");
INSERT INTO city VALUES("1889","0","1","20","Dunguripali ","Dunguripali ","0","0","0","0");
INSERT INTO city VALUES("1890","0","1","20","G. Udayagiri ","G. Udayagiri ","0","0","0","0");
INSERT INTO city VALUES("1891","0","1","20","Gajapati ","Gajapati ","0","0","0","0");
INSERT INTO city VALUES("1892","0","1","20","Ganjam ","Ganjam ","0","0","0","0");
INSERT INTO city VALUES("1893","0","1","20","Ghatgaon ","Ghatgaon ","0","0","0","0");
INSERT INTO city VALUES("1894","0","1","20","Gudari ","Gudari ","0","0","0","0");
INSERT INTO city VALUES("1895","0","1","20","Gunupur ","Gunupur ","0","0","0","0");
INSERT INTO city VALUES("1896","0","1","20","Hemgiri ","Hemgiri ","0","0","0","0");
INSERT INTO city VALUES("1897","0","1","20","Hindol ","Hindol ","0","0","0","0");
INSERT INTO city VALUES("1898","0","1","20","Jagatsinghapur ","Jagatsinghapur ","0","0","0","0");
INSERT INTO city VALUES("1899","0","1","20","Jajpur ","Jajpur ","0","0","0","0");
INSERT INTO city VALUES("1900","0","1","20","Jamankira ","Jamankira ","0","0","0","0");
INSERT INTO city VALUES("1901","0","1","20","Jashipur ","Jashipur ","0","0","0","0");
INSERT INTO city VALUES("1902","0","1","20","Jayapatna ","Jayapatna ","0","0","0","0");
INSERT INTO city VALUES("1903","0","1","20","Jeypur ","Jeypur ","0","0","0","0");
INSERT INTO city VALUES("1904","0","1","20","Jharigan ","Jharigan ","0","0","0","0");
INSERT INTO city VALUES("1905","0","1","20","Jharsuguda ","Jharsuguda ","0","0","0","0");
INSERT INTO city VALUES("1906","0","1","20","Jujumura ","Jujumura ","0","0","0","0");
INSERT INTO city VALUES("1907","0","1","20","Kalahandi ","Kalahandi ","0","0","0","0");
INSERT INTO city VALUES("1908","0","1","20","Kalimela ","Kalimela ","0","0","0","0");
INSERT INTO city VALUES("1909","0","1","20","Kamakhyanagar ","Kamakhyanagar ","0","0","0","0");
INSERT INTO city VALUES("1910","0","1","20","Kandhamal ","Kandhamal ","0","0","0","0");
INSERT INTO city VALUES("1911","0","1","20","Kantabhanji ","Kantabhanji ","0","0","0","0");
INSERT INTO city VALUES("1912","0","1","20","Kantamal ","Kantamal ","0","0","0","0");
INSERT INTO city VALUES("1913","0","1","20","Karanjia ","Karanjia ","0","0","0","0");
INSERT INTO city VALUES("1914","0","1","20","Kashipur ","Kashipur ","0","0","0","0");
INSERT INTO city VALUES("1915","0","1","20","Kendrapara ","Kendrapara ","0","0","0","0");
INSERT INTO city VALUES("1916","0","1","20","Kendujhar ","Kendujhar ","0","0","0","0");
INSERT INTO city VALUES("1917","0","1","20","Keonjhar ","Keonjhar ","0","0","0","0");
INSERT INTO city VALUES("1918","0","1","20","Khalikote ","Khalikote ","0","0","0","0");
INSERT INTO city VALUES("1919","0","1","20","Khordha ","Khordha ","0","0","0","0");
INSERT INTO city VALUES("1920","0","1","20","Khurda ","Khurda ","0","0","0","0");
INSERT INTO city VALUES("1921","0","1","20","Komana ","Komana ","0","0","0","0");
INSERT INTO city VALUES("1922","0","1","20","Koraput ","Koraput ","0","0","0","0");
INSERT INTO city VALUES("1923","0","1","20","Kotagarh ","Kotagarh ","0","0","0","0");
INSERT INTO city VALUES("1924","0","1","20","Kuchinda ","Kuchinda ","0","0","0","0");
INSERT INTO city VALUES("1925","0","1","20","Lahunipara ","Lahunipara ","0","0","0","0");
INSERT INTO city VALUES("1926","0","1","20","Laxmipur ","Laxmipur ","0","0","0","0");
INSERT INTO city VALUES("1927","0","1","20","M. Rampur ","M. Rampur ","0","0","0","0");
INSERT INTO city VALUES("1928","0","1","20","Malkangiri ","Malkangiri ","0","0","0","0");
INSERT INTO city VALUES("1929","0","1","20","Mathili ","Mathili ","0","0","0","0");
INSERT INTO city VALUES("1930","0","1","20","Mayurbhanj ","Mayurbhanj ","0","0","0","0");
INSERT INTO city VALUES("1931","0","1","20","Mohana ","Mohana ","0","0","0","0");
INSERT INTO city VALUES("1932","0","1","20","Motu ","Motu ","0","0","0","0");
INSERT INTO city VALUES("1933","0","1","20","Nabarangapur ","Nabarangapur ","0","0","0","0");
INSERT INTO city VALUES("1934","0","1","20","Naktideul ","Naktideul ","0","0","0","0");
INSERT INTO city VALUES("1935","0","1","20","Nandapur ","Nandapur ","0","0","0","0");
INSERT INTO city VALUES("1936","0","1","20","Narlaroad ","Narlaroad ","0","0","0","0");
INSERT INTO city VALUES("1937","0","1","20","Narsinghpur ","Narsinghpur ","0","0","0","0");
INSERT INTO city VALUES("1938","0","1","20","Nayagarh ","Nayagarh ","0","0","0","0");
INSERT INTO city VALUES("1939","0","1","20","Nimapara ","Nimapara ","0","0","0","0");
INSERT INTO city VALUES("1940","0","1","20","Nowparatan ","Nowparatan ","0","0","0","0");
INSERT INTO city VALUES("1941","0","1","20","Nowrangapur ","Nowrangapur ","0","0","0","0");
INSERT INTO city VALUES("1942","0","1","20","Nuapada ","Nuapada ","0","0","0","0");
INSERT INTO city VALUES("1943","0","1","20","Padampur ","Padampur ","0","0","0","0");
INSERT INTO city VALUES("1944","0","1","20","Paikamal ","Paikamal ","0","0","0","0");
INSERT INTO city VALUES("1945","0","1","20","Palla Hara ","Palla Hara ","0","0","0","0");
INSERT INTO city VALUES("1946","0","1","20","Papadhandi ","Papadhandi ","0","0","0","0");
INSERT INTO city VALUES("1947","0","1","20","Parajang ","Parajang ","0","0","0","0");
INSERT INTO city VALUES("1948","0","1","20","Pardip ","Pardip ","0","0","0","0");
INSERT INTO city VALUES("1949","0","1","20","Parlakhemundi ","Parlakhemundi ","0","0","0","0");
INSERT INTO city VALUES("1950","0","1","20","Patnagarh ","Patnagarh ","0","0","0","0");
INSERT INTO city VALUES("1951","0","1","20","Pattamundai ","Pattamundai ","0","0","0","0");
INSERT INTO city VALUES("1952","0","1","20","Phiringia ","Phiringia ","0","0","0","0");
INSERT INTO city VALUES("1953","0","1","20","Phulbani ","Phulbani ","0","0","0","0");
INSERT INTO city VALUES("1954","0","1","20","Puri ","Puri ","0","0","0","0");
INSERT INTO city VALUES("1955","0","1","20","Puruna Katak ","Puruna Katak ","0","0","0","0");
INSERT INTO city VALUES("1956","0","1","20","R. Udayigiri ","R. Udayigiri ","0","0","0","0");
INSERT INTO city VALUES("1957","0","1","20","Rairakhol ","Rairakhol ","0","0","0","0");
INSERT INTO city VALUES("1958","0","1","20","Rairangpur ","Rairangpur ","0","0","0","0");
INSERT INTO city VALUES("1959","0","1","20","Rajgangpur ","Rajgangpur ","0","0","0","0");
INSERT INTO city VALUES("1960","0","1","20","Rajkhariar ","Rajkhariar ","0","0","0","0");
INSERT INTO city VALUES("1961","0","1","20","Rayagada ","Rayagada ","0","0","0","0");
INSERT INTO city VALUES("1962","0","1","20","Rourkela ","Rourkela ","0","0","0","0");
INSERT INTO city VALUES("1963","0","1","20","Sambalpur ","Sambalpur ","0","0","0","0");
INSERT INTO city VALUES("1964","0","1","20","Sohela ","Sohela ","0","0","0","0");
INSERT INTO city VALUES("1965","0","1","20","Sonapur ","Sonapur ","0","0","0","0");
INSERT INTO city VALUES("1966","0","1","20","Soro ","Soro ","0","0","0","0");
INSERT INTO city VALUES("1967","0","1","20","Subarnapur ","Subarnapur ","0","0","0","0");
INSERT INTO city VALUES("1968","0","1","20","Sunabeda ","Sunabeda ","0","0","0","0");
INSERT INTO city VALUES("1969","0","1","20","Sundergarh ","Sundergarh ","0","0","0","0");
INSERT INTO city VALUES("1970","0","1","20","Surada ","Surada ","0","0","0","0");
INSERT INTO city VALUES("1971","0","1","20","T. Rampur ","T. Rampur ","0","0","0","0");
INSERT INTO city VALUES("1972","0","1","20","Talcher ","Talcher ","0","0","0","0");
INSERT INTO city VALUES("1973","0","1","20","Telkoi ","Telkoi ","0","0","0","0");
INSERT INTO city VALUES("1974","0","1","20","Titlagarh ","Titlagarh ","0","0","0","0");
INSERT INTO city VALUES("1975","0","1","20","Tumudibandha ","Tumudibandha ","0","0","0","0");
INSERT INTO city VALUES("1976","0","1","20","Udala ","Udala ","0","0","0","0");
INSERT INTO city VALUES("1977","0","1","20","Umerkote","Umerkote","0","0","0","0");
INSERT INTO city VALUES("1978","0","1","21","Abohar ","Abohar ","0","0","0","0");
INSERT INTO city VALUES("1979","0","1","21","Ajnala ","Ajnala ","0","0","0","0");
INSERT INTO city VALUES("1980","0","1","21","Amritsar ","Amritsar ","0","0","0","0");
INSERT INTO city VALUES("1981","0","1","21","Balachaur ","Balachaur ","0","0","0","0");
INSERT INTO city VALUES("1982","0","1","21","Barnala ","Barnala ","0","0","0","0");
INSERT INTO city VALUES("1983","0","1","21","Batala ","Batala ","0","0","0","0");
INSERT INTO city VALUES("1984","0","1","21","Bathinda ","Bathinda ","0","0","0","0");
INSERT INTO city VALUES("1985","0","1","21","Chandigarh ","Chandigarh ","0","0","0","0");
INSERT INTO city VALUES("1986","0","1","21","Dasua ","Dasua ","0","0","0","0");
INSERT INTO city VALUES("1987","0","1","21","Dinanagar ","Dinanagar ","0","0","0","0");
INSERT INTO city VALUES("1988","0","1","21","Faridkot ","Faridkot ","0","0","0","0");
INSERT INTO city VALUES("1989","0","1","21","Fatehgarh Sahib ","Fatehgarh Sahib ","0","0","0","0");
INSERT INTO city VALUES("1990","0","1","21","Fazilka ","Fazilka ","0","0","0","0");
INSERT INTO city VALUES("1991","0","1","21","Ferozepur ","Ferozepur ","0","0","0","0");
INSERT INTO city VALUES("1992","0","1","21","Garhashanker ","Garhashanker ","0","0","0","0");
INSERT INTO city VALUES("1993","0","1","21","Goindwal ","Goindwal ","0","0","0","0");
INSERT INTO city VALUES("1994","0","1","21","Gurdaspur ","Gurdaspur ","0","0","0","0");
INSERT INTO city VALUES("1995","0","1","21","Guruharsahai ","Guruharsahai ","0","0","0","0");
INSERT INTO city VALUES("1996","0","1","21","Hoshiarpur ","Hoshiarpur ","0","0","0","0");
INSERT INTO city VALUES("1997","0","1","21","Jagraon ","Jagraon ","0","0","0","0");
INSERT INTO city VALUES("1998","0","1","21","Jalandhar ","Jalandhar ","0","0","0","0");
INSERT INTO city VALUES("1999","0","1","21","Jugial ","Jugial ","0","0","0","0");
INSERT INTO city VALUES("2000","0","1","21","Kapurthala ","Kapurthala ","0","0","0","0");
INSERT INTO city VALUES("2001","0","1","21","Kharar ","Kharar ","0","0","0","0");
INSERT INTO city VALUES("2002","0","1","21","Kotkapura ","Kotkapura ","0","0","0","0");
INSERT INTO city VALUES("2003","0","1","21","Ludhiana ","Ludhiana ","0","0","0","0");
INSERT INTO city VALUES("2004","0","1","21","Malaut ","Malaut ","0","0","0","0");
INSERT INTO city VALUES("2005","0","1","21","Malerkotla ","Malerkotla ","0","0","0","0");
INSERT INTO city VALUES("2006","0","1","21","Mansa ","Mansa ","0","0","0","0");
INSERT INTO city VALUES("2007","0","1","21","Moga ","Moga ","0","0","0","0");
INSERT INTO city VALUES("2008","0","1","21","Muktasar ","Muktasar ","0","0","0","0");
INSERT INTO city VALUES("2009","0","1","21","Nabha ","Nabha ","0","0","0","0");
INSERT INTO city VALUES("2010","0","1","21","Nakodar ","Nakodar ","0","0","0","0");
INSERT INTO city VALUES("2011","0","1","21","Nangal ","Nangal ","0","0","0","0");
INSERT INTO city VALUES("2012","0","1","21","Nawanshahar ","Nawanshahar ","0","0","0","0");
INSERT INTO city VALUES("2013","0","1","21","Nawanshahr ","Nawanshahr ","0","0","0","0");
INSERT INTO city VALUES("2014","0","1","21","Pathankot ","Pathankot ","0","0","0","0");
INSERT INTO city VALUES("2015","0","1","21","Patiala ","Patiala ","0","0","0","0");
INSERT INTO city VALUES("2016","0","1","21","Patti ","Patti ","0","0","0","0");
INSERT INTO city VALUES("2017","0","1","21","Phagwara ","Phagwara ","0","0","0","0");
INSERT INTO city VALUES("2018","0","1","21","Phillaur ","Phillaur ","0","0","0","0");
INSERT INTO city VALUES("2019","0","1","21","Phulmandi ","Phulmandi ","0","0","0","0");
INSERT INTO city VALUES("2020","0","1","21","Quadian ","Quadian ","0","0","0","0");
INSERT INTO city VALUES("2021","0","1","21","Rajpura ","Rajpura ","0","0","0","0");
INSERT INTO city VALUES("2022","0","1","21","Raman ","Raman ","0","0","0","0");
INSERT INTO city VALUES("2023","0","1","21","Rayya ","Rayya ","0","0","0","0");
INSERT INTO city VALUES("2024","0","1","21","Ropar ","Ropar ","0","0","0","0");
INSERT INTO city VALUES("2025","0","1","21","Rupnagar ","Rupnagar ","0","0","0","0");
INSERT INTO city VALUES("2026","0","1","21","Samana ","Samana ","0","0","0","0");
INSERT INTO city VALUES("2027","0","1","21","Samrala ","Samrala ","0","0","0","0");
INSERT INTO city VALUES("2028","0","1","21","Sangrur ","Sangrur ","0","0","0","0");
INSERT INTO city VALUES("2029","0","1","21","Sardulgarh ","Sardulgarh ","0","0","0","0");
INSERT INTO city VALUES("2030","0","1","21","Sarhind ","Sarhind ","0","0","0","0");
INSERT INTO city VALUES("2031","0","1","21","SAS Nagar ","SAS Nagar ","0","0","0","0");
INSERT INTO city VALUES("2032","0","1","21","Sultanpur Lodhi ","Sultanpur Lodhi ","0","0","0","0");
INSERT INTO city VALUES("2033","0","1","21","Sunam ","Sunam ","0","0","0","0");
INSERT INTO city VALUES("2034","0","1","21","Tanda Urmar ","Tanda Urmar ","0","0","0","0");
INSERT INTO city VALUES("2035","0","1","21","Taran Taran ","Taran Taran ","0","0","0","0");
INSERT INTO city VALUES("2036","0","1","21","Zira","Zira","0","0","0","0");
INSERT INTO city VALUES("2037","0","1","22","Abu Road ","Abu Road ","0","0","0","0");
INSERT INTO city VALUES("2038","0","1","22","Ahore ","Ahore ","0","0","0","0");
INSERT INTO city VALUES("2039","0","1","22","Ajmer ","Ajmer ","0","0","0","0");
INSERT INTO city VALUES("2040","0","1","22","Aklera ","Aklera ","0","0","0","0");
INSERT INTO city VALUES("2041","0","1","22","Alwar ","Alwar ","0","0","0","0");
INSERT INTO city VALUES("2042","0","1","22","Amber ","Amber ","0","0","0","0");
INSERT INTO city VALUES("2043","0","1","22","Amet ","Amet ","0","0","0","0");
INSERT INTO city VALUES("2044","0","1","22","Anupgarh ","Anupgarh ","0","0","0","0");
INSERT INTO city VALUES("2045","0","1","22","Asind ","Asind ","0","0","0","0");
INSERT INTO city VALUES("2046","0","1","22","Aspur ","Aspur ","0","0","0","0");
INSERT INTO city VALUES("2047","0","1","22","Atru ","Atru ","0","0","0","0");
INSERT INTO city VALUES("2048","0","1","22","Bagidora ","Bagidora ","0","0","0","0");
INSERT INTO city VALUES("2049","0","1","22","Bali ","Bali ","0","0","0","0");
INSERT INTO city VALUES("2050","0","1","22","Bamanwas ","Bamanwas ","0","0","0","0");
INSERT INTO city VALUES("2051","0","1","22","Banera ","Banera ","0","0","0","0");
INSERT INTO city VALUES("2052","0","1","22","Bansur ","Bansur ","0","0","0","0");
INSERT INTO city VALUES("2053","0","1","22","Banswara ","Banswara ","0","0","0","0");
INSERT INTO city VALUES("2054","0","1","22","Baran ","Baran ","0","0","0","0");
INSERT INTO city VALUES("2055","0","1","22","Bari ","Bari ","0","0","0","0");
INSERT INTO city VALUES("2056","0","1","22","Barisadri ","Barisadri ","0","0","0","0");
INSERT INTO city VALUES("2057","0","1","22","Barmer ","Barmer ","0","0","0","0");
INSERT INTO city VALUES("2058","0","1","22","Baseri ","Baseri ","0","0","0","0");
INSERT INTO city VALUES("2059","0","1","22","Bassi ","Bassi ","0","0","0","0");
INSERT INTO city VALUES("2060","0","1","22","Baswa ","Baswa ","0","0","0","0");
INSERT INTO city VALUES("2061","0","1","22","Bayana ","Bayana ","0","0","0","0");
INSERT INTO city VALUES("2062","0","1","22","Beawar ","Beawar ","0","0","0","0");
INSERT INTO city VALUES("2063","0","1","22","Begun ","Begun ","0","0","0","0");
INSERT INTO city VALUES("2064","0","1","22","Behror ","Behror ","0","0","0","0");
INSERT INTO city VALUES("2065","0","1","22","Bhadra ","Bhadra ","0","0","0","0");
INSERT INTO city VALUES("2066","0","1","22","Bharatpur ","Bharatpur ","0","0","0","0");
INSERT INTO city VALUES("2067","0","1","22","Bhilwara ","Bhilwara ","0","0","0","0");
INSERT INTO city VALUES("2068","0","1","22","Bhim ","Bhim ","0","0","0","0");
INSERT INTO city VALUES("2069","0","1","22","Bhinmal ","Bhinmal ","0","0","0","0");
INSERT INTO city VALUES("2070","0","1","22","Bikaner ","Bikaner ","0","0","0","0");
INSERT INTO city VALUES("2071","0","1","22","Bilara ","Bilara ","0","0","0","0");
INSERT INTO city VALUES("2072","0","1","22","Bundi ","Bundi ","0","0","0","0");
INSERT INTO city VALUES("2073","0","1","22","Chhabra ","Chhabra ","0","0","0","0");
INSERT INTO city VALUES("2074","0","1","22","Chhipaborad ","Chhipaborad ","0","0","0","0");
INSERT INTO city VALUES("2075","0","1","22","Chirawa ","Chirawa ","0","0","0","0");
INSERT INTO city VALUES("2076","0","1","22","Chittorgarh ","Chittorgarh ","0","0","0","0");
INSERT INTO city VALUES("2077","0","1","22","Chohtan ","Chohtan ","0","0","0","0");
INSERT INTO city VALUES("2078","0","1","22","Churu ","Churu ","0","0","0","0");
INSERT INTO city VALUES("2079","0","1","22","Dantaramgarh ","Dantaramgarh ","0","0","0","0");
INSERT INTO city VALUES("2080","0","1","22","Dausa ","Dausa ","0","0","0","0");
INSERT INTO city VALUES("2081","0","1","22","Deedwana ","Deedwana ","0","0","0","0");
INSERT INTO city VALUES("2082","0","1","22","Deeg ","Deeg ","0","0","0","0");
INSERT INTO city VALUES("2083","0","1","22","Degana ","Degana ","0","0","0","0");
INSERT INTO city VALUES("2084","0","1","22","Deogarh ","Deogarh ","0","0","0","0");
INSERT INTO city VALUES("2085","0","1","22","Deoli ","Deoli ","0","0","0","0");
INSERT INTO city VALUES("2086","0","1","22","Desuri ","Desuri ","0","0","0","0");
INSERT INTO city VALUES("2087","0","1","22","Dhariawad ","Dhariawad ","0","0","0","0");
INSERT INTO city VALUES("2088","0","1","22","Dholpur ","Dholpur ","0","0","0","0");
INSERT INTO city VALUES("2089","0","1","22","Digod ","Digod ","0","0","0","0");
INSERT INTO city VALUES("2090","0","1","22","Dudu ","Dudu ","0","0","0","0");
INSERT INTO city VALUES("2091","0","1","22","Dungarpur ","Dungarpur ","0","0","0","0");
INSERT INTO city VALUES("2092","0","1","22","Dungla ","Dungla ","0","0","0","0");
INSERT INTO city VALUES("2093","0","1","22","Fatehpur ","Fatehpur ","0","0","0","0");
INSERT INTO city VALUES("2094","0","1","22","Gangapur ","Gangapur ","0","0","0","0");
INSERT INTO city VALUES("2095","0","1","22","Gangdhar ","Gangdhar ","0","0","0","0");
INSERT INTO city VALUES("2096","0","1","22","Gerhi ","Gerhi ","0","0","0","0");
INSERT INTO city VALUES("2097","0","1","22","Ghatol ","Ghatol ","0","0","0","0");
INSERT INTO city VALUES("2098","0","1","22","Girwa ","Girwa ","0","0","0","0");
INSERT INTO city VALUES("2099","0","1","22","Gogunda ","Gogunda ","0","0","0","0");
INSERT INTO city VALUES("2100","0","1","22","Hanumangarh ","Hanumangarh ","0","0","0","0");
INSERT INTO city VALUES("2101","0","1","22","Hindaun ","Hindaun ","0","0","0","0");
INSERT INTO city VALUES("2102","0","1","22","Hindoli ","Hindoli ","0","0","0","0");
INSERT INTO city VALUES("2103","0","1","22","Hurda ","Hurda ","0","0","0","0");
INSERT INTO city VALUES("2104","0","1","22","Jahazpur ","Jahazpur ","0","0","0","0");
INSERT INTO city VALUES("2105","0","1","22","Jaipur ","Jaipur ","0","0","0","0");
INSERT INTO city VALUES("2106","0","1","22","Jaisalmer ","Jaisalmer ","0","0","0","0");
INSERT INTO city VALUES("2107","0","1","22","Jalore ","Jalore ","0","0","0","0");
INSERT INTO city VALUES("2108","0","1","22","Jhalawar ","Jhalawar ","0","0","0","0");
INSERT INTO city VALUES("2109","0","1","22","Jhunjhunu ","Jhunjhunu ","0","0","0","0");
INSERT INTO city VALUES("2110","0","1","22","Jodhpur ","Jodhpur ","0","0","0","0");
INSERT INTO city VALUES("2111","0","1","22","Kaman ","Kaman ","0","0","0","0");
INSERT INTO city VALUES("2112","0","1","22","Kapasan ","Kapasan ","0","0","0","0");
INSERT INTO city VALUES("2113","0","1","22","Karauli ","Karauli ","0","0","0","0");
INSERT INTO city VALUES("2114","0","1","22","Kekri ","Kekri ","0","0","0","0");
INSERT INTO city VALUES("2115","0","1","22","Keshoraipatan ","Keshoraipatan ","0","0","0","0");
INSERT INTO city VALUES("2116","0","1","22","Khandar ","Khandar ","0","0","0","0");
INSERT INTO city VALUES("2117","0","1","22","Kherwara ","Kherwara ","0","0","0","0");
INSERT INTO city VALUES("2118","0","1","22","Khetri ","Khetri ","0","0","0","0");
INSERT INTO city VALUES("2119","0","1","22","Kishanganj ","Kishanganj ","0","0","0","0");
INSERT INTO city VALUES("2120","0","1","22","Kishangarh ","Kishangarh ","0","0","0","0");
INSERT INTO city VALUES("2121","0","1","22","Kishangarhbas ","Kishangarhbas ","0","0","0","0");
INSERT INTO city VALUES("2122","0","1","22","Kolayat ","Kolayat ","0","0","0","0");
INSERT INTO city VALUES("2123","0","1","22","Kota ","Kota ","0","0","0","0");
INSERT INTO city VALUES("2124","0","1","22","Kotputli ","Kotputli ","0","0","0","0");
INSERT INTO city VALUES("2125","0","1","22","Kotra ","Kotra ","0","0","0","0");
INSERT INTO city VALUES("2126","0","1","22","Kotri ","Kotri ","0","0","0","0");
INSERT INTO city VALUES("2127","0","1","22","Kumbalgarh ","Kumbalgarh ","0","0","0","0");
INSERT INTO city VALUES("2128","0","1","22","Kushalgarh ","Kushalgarh ","0","0","0","0");
INSERT INTO city VALUES("2129","0","1","22","Ladnun ","Ladnun ","0","0","0","0");
INSERT INTO city VALUES("2130","0","1","22","Ladpura ","Ladpura ","0","0","0","0");
INSERT INTO city VALUES("2131","0","1","22","Lalsot ","Lalsot ","0","0","0","0");
INSERT INTO city VALUES("2132","0","1","22","Laxmangarh ","Laxmangarh ","0","0","0","0");
INSERT INTO city VALUES("2133","0","1","22","Lunkaransar ","Lunkaransar ","0","0","0","0");
INSERT INTO city VALUES("2134","0","1","22","Mahuwa ","Mahuwa ","0","0","0","0");
INSERT INTO city VALUES("2135","0","1","22","Malpura ","Malpura ","0","0","0","0");
INSERT INTO city VALUES("2136","0","1","22","Malvi ","Malvi ","0","0","0","0");
INSERT INTO city VALUES("2137","0","1","22","Mandal ","Mandal ","0","0","0","0");
INSERT INTO city VALUES("2138","0","1","22","Mandalgarh ","Mandalgarh ","0","0","0","0");
INSERT INTO city VALUES("2139","0","1","22","Mandawar ","Mandawar ","0","0","0","0");
INSERT INTO city VALUES("2140","0","1","22","Mangrol ","Mangrol ","0","0","0","0");
INSERT INTO city VALUES("2141","0","1","22","Marwar-Jn ","Marwar-Jn ","0","0","0","0");
INSERT INTO city VALUES("2142","0","1","22","Merta ","Merta ","0","0","0","0");
INSERT INTO city VALUES("2143","0","1","22","Nadbai ","Nadbai ","0","0","0","0");
INSERT INTO city VALUES("2144","0","1","22","Nagaur ","Nagaur ","0","0","0","0");
INSERT INTO city VALUES("2145","0","1","22","Nainwa ","Nainwa ","0","0","0","0");
INSERT INTO city VALUES("2146","0","1","22","Nasirabad ","Nasirabad ","0","0","0","0");
INSERT INTO city VALUES("2147","0","1","22","Nathdwara ","Nathdwara ","0","0","0","0");
INSERT INTO city VALUES("2148","0","1","22","Nawa ","Nawa ","0","0","0","0");
INSERT INTO city VALUES("2149","0","1","22","Neem Ka Thana ","Neem Ka Thana ","0","0","0","0");
INSERT INTO city VALUES("2150","0","1","22","Newai ","Newai ","0","0","0","0");
INSERT INTO city VALUES("2151","0","1","22","Nimbahera ","Nimbahera ","0","0","0","0");
INSERT INTO city VALUES("2152","0","1","22","Nohar ","Nohar ","0","0","0","0");
INSERT INTO city VALUES("2153","0","1","22","Nokha ","Nokha ","0","0","0","0");
INSERT INTO city VALUES("2154","0","1","22","Onli ","Onli ","0","0","0","0");
INSERT INTO city VALUES("2155","0","1","22","Osian ","Osian ","0","0","0","0");
INSERT INTO city VALUES("2156","0","1","22","Pachpadara ","Pachpadara ","0","0","0","0");
INSERT INTO city VALUES("2157","0","1","22","Pachpahar ","Pachpahar ","0","0","0","0");
INSERT INTO city VALUES("2158","0","1","22","Padampur ","Padampur ","0","0","0","0");
INSERT INTO city VALUES("2159","0","1","22","Pali ","Pali ","0","0","0","0");
INSERT INTO city VALUES("2160","0","1","22","Parbatsar ","Parbatsar ","0","0","0","0");
INSERT INTO city VALUES("2161","0","1","22","Phagi ","Phagi ","0","0","0","0");
INSERT INTO city VALUES("2162","0","1","22","Phalodi ","Phalodi ","0","0","0","0");
INSERT INTO city VALUES("2163","0","1","22","Pilani ","Pilani ","0","0","0","0");
INSERT INTO city VALUES("2164","0","1","22","Pindwara ","Pindwara ","0","0","0","0");
INSERT INTO city VALUES("2165","0","1","22","Pipalda ","Pipalda ","0","0","0","0");
INSERT INTO city VALUES("2166","0","1","22","Pirawa ","Pirawa ","0","0","0","0");
INSERT INTO city VALUES("2167","0","1","22","Pokaran ","Pokaran ","0","0","0","0");
INSERT INTO city VALUES("2168","0","1","22","Pratapgarh ","Pratapgarh ","0","0","0","0");
INSERT INTO city VALUES("2169","0","1","22","Raipur ","Raipur ","0","0","0","0");
INSERT INTO city VALUES("2170","0","1","22","Raisinghnagar ","Raisinghnagar ","0","0","0","0");
INSERT INTO city VALUES("2171","0","1","22","Rajgarh ","Rajgarh ","0","0","0","0");
INSERT INTO city VALUES("2172","0","1","22","Rajsamand ","Rajsamand ","0","0","0","0");
INSERT INTO city VALUES("2173","0","1","22","Ramganj Mandi ","Ramganj Mandi ","0","0","0","0");
INSERT INTO city VALUES("2174","0","1","22","Ramgarh ","Ramgarh ","0","0","0","0");
INSERT INTO city VALUES("2175","0","1","22","Rashmi ","Rashmi ","0","0","0","0");
INSERT INTO city VALUES("2176","0","1","22","Ratangarh ","Ratangarh ","0","0","0","0");
INSERT INTO city VALUES("2177","0","1","22","Reodar ","Reodar ","0","0","0","0");
INSERT INTO city VALUES("2178","0","1","22","Rupbas ","Rupbas ","0","0","0","0");
INSERT INTO city VALUES("2179","0","1","22","Sadulshahar ","Sadulshahar ","0","0","0","0");
INSERT INTO city VALUES("2180","0","1","22","Sagwara ","Sagwara ","0","0","0","0");
INSERT INTO city VALUES("2181","0","1","22","Sahabad ","Sahabad ","0","0","0","0");
INSERT INTO city VALUES("2182","0","1","22","Salumber ","Salumber ","0","0","0","0");
INSERT INTO city VALUES("2183","0","1","22","Sanchore ","Sanchore ","0","0","0","0");
INSERT INTO city VALUES("2184","0","1","22","Sangaria ","Sangaria ","0","0","0","0");
INSERT INTO city VALUES("2185","0","1","22","Sangod ","Sangod ","0","0","0","0");
INSERT INTO city VALUES("2186","0","1","22","Sapotra ","Sapotra ","0","0","0","0");
INSERT INTO city VALUES("2187","0","1","22","Sarada ","Sarada ","0","0","0","0");
INSERT INTO city VALUES("2188","0","1","22","Sardarshahar ","Sardarshahar ","0","0","0","0");
INSERT INTO city VALUES("2189","0","1","22","Sarwar ","Sarwar ","0","0","0","0");
INSERT INTO city VALUES("2190","0","1","22","Sawai Madhopur ","Sawai Madhopur ","0","0","0","0");
INSERT INTO city VALUES("2191","0","1","22","Shahapura ","Shahapura ","0","0","0","0");
INSERT INTO city VALUES("2192","0","1","22","Sheo ","Sheo ","0","0","0","0");
INSERT INTO city VALUES("2193","0","1","22","Sheoganj ","Sheoganj ","0","0","0","0");
INSERT INTO city VALUES("2194","0","1","22","Shergarh ","Shergarh ","0","0","0","0");
INSERT INTO city VALUES("2195","0","1","22","Sikar ","Sikar ","0","0","0","0");
INSERT INTO city VALUES("2196","0","1","22","Sirohi ","Sirohi ","0","0","0","0");
INSERT INTO city VALUES("2197","0","1","22","Siwana ","Siwana ","0","0","0","0");
INSERT INTO city VALUES("2198","0","1","22","Sojat ","Sojat ","0","0","0","0");
INSERT INTO city VALUES("2199","0","1","22","Sri Dungargarh ","Sri Dungargarh ","0","0","0","0");
INSERT INTO city VALUES("2200","0","1","22","Sri Ganganagar ","Sri Ganganagar ","0","0","0","0");
INSERT INTO city VALUES("2201","0","1","22","Sri Karanpur ","Sri Karanpur ","0","0","0","0");
INSERT INTO city VALUES("2202","0","1","22","Sri Madhopur ","Sri Madhopur ","0","0","0","0");
INSERT INTO city VALUES("2203","0","1","22","Sujangarh ","Sujangarh ","0","0","0","0");
INSERT INTO city VALUES("2204","0","1","22","Taranagar ","Taranagar ","0","0","0","0");
INSERT INTO city VALUES("2205","0","1","22","Thanaghazi ","Thanaghazi ","0","0","0","0");
INSERT INTO city VALUES("2206","0","1","22","Tibbi ","Tibbi ","0","0","0","0");
INSERT INTO city VALUES("2207","0","1","22","Tijara ","Tijara ","0","0","0","0");
INSERT INTO city VALUES("2208","0","1","22","Todaraisingh ","Todaraisingh ","0","0","0","0");
INSERT INTO city VALUES("2209","0","1","22","Tonk ","Tonk ","0","0","0","0");
INSERT INTO city VALUES("2210","0","1","22","Udaipur ","Udaipur ","0","0","0","0");
INSERT INTO city VALUES("2211","0","1","22","Udaipurwati ","Udaipurwati ","0","0","0","0");
INSERT INTO city VALUES("2212","0","1","22","Uniayara ","Uniayara ","0","0","0","0");
INSERT INTO city VALUES("2213","0","1","22","Vallabhnagar ","Vallabhnagar ","0","0","0","0");
INSERT INTO city VALUES("2214","0","1","22","Viratnagar","Viratnagar","0","0","0","0");
INSERT INTO city VALUES("2215","0","1","23","Barmiak ","Barmiak ","0","0","0","0");
INSERT INTO city VALUES("2216","0","1","23","Be ","Be ","0","0","0","0");
INSERT INTO city VALUES("2217","0","1","23","Bhurtuk ","Bhurtuk ","0","0","0","0");
INSERT INTO city VALUES("2218","0","1","23","Chhubakha ","Chhubakha ","0","0","0","0");
INSERT INTO city VALUES("2219","0","1","23","Chidam ","Chidam ","0","0","0","0");
INSERT INTO city VALUES("2220","0","1","23","Chubha ","Chubha ","0","0","0","0");
INSERT INTO city VALUES("2221","0","1","23","Chumikteng ","Chumikteng ","0","0","0","0");
INSERT INTO city VALUES("2222","0","1","23","Dentam ","Dentam ","0","0","0","0");
INSERT INTO city VALUES("2223","0","1","23","Dikchu ","Dikchu ","0","0","0","0");
INSERT INTO city VALUES("2224","0","1","23","Dzongri ","Dzongri ","0","0","0","0");
INSERT INTO city VALUES("2225","0","1","23","Gangtok ","Gangtok ","0","0","0","0");
INSERT INTO city VALUES("2226","0","1","23","Gauzing ","Gauzing ","0","0","0","0");
INSERT INTO city VALUES("2227","0","1","23","Gyalshing ","Gyalshing ","0","0","0","0");
INSERT INTO city VALUES("2228","0","1","23","Hema ","Hema ","0","0","0","0");
INSERT INTO city VALUES("2229","0","1","23","Kerung ","Kerung ","0","0","0","0");
INSERT INTO city VALUES("2230","0","1","23","Lachen ","Lachen ","0","0","0","0");
INSERT INTO city VALUES("2231","0","1","23","Lachung ","Lachung ","0","0","0","0");
INSERT INTO city VALUES("2232","0","1","23","Lema ","Lema ","0","0","0","0");
INSERT INTO city VALUES("2233","0","1","23","Lingtam ","Lingtam ","0","0","0","0");
INSERT INTO city VALUES("2234","0","1","23","Lungthu ","Lungthu ","0","0","0","0");
INSERT INTO city VALUES("2235","0","1","23","Mangan ","Mangan ","0","0","0","0");
INSERT INTO city VALUES("2236","0","1","23","Namchi ","Namchi ","0","0","0","0");
INSERT INTO city VALUES("2237","0","1","23","Namthang ","Namthang ","0","0","0","0");
INSERT INTO city VALUES("2238","0","1","23","Nanga ","Nanga ","0","0","0","0");
INSERT INTO city VALUES("2239","0","1","23","Nantang ","Nantang ","0","0","0","0");
INSERT INTO city VALUES("2240","0","1","23","Naya Bazar ","Naya Bazar ","0","0","0","0");
INSERT INTO city VALUES("2241","0","1","23","Padamachen ","Padamachen ","0","0","0","0");
INSERT INTO city VALUES("2242","0","1","23","Pakhyong ","Pakhyong ","0","0","0","0");
INSERT INTO city VALUES("2243","0","1","23","Pemayangtse ","Pemayangtse ","0","0","0","0");
INSERT INTO city VALUES("2244","0","1","23","Phensang ","Phensang ","0","0","0","0");
INSERT INTO city VALUES("2245","0","1","23","Rangli ","Rangli ","0","0","0","0");
INSERT INTO city VALUES("2246","0","1","23","Rinchingpong ","Rinchingpong ","0","0","0","0");
INSERT INTO city VALUES("2247","0","1","23","Sakyong ","Sakyong ","0","0","0","0");
INSERT INTO city VALUES("2248","0","1","23","Samdong ","Samdong ","0","0","0","0");
INSERT INTO city VALUES("2249","0","1","23","Singtam ","Singtam ","0","0","0","0");
INSERT INTO city VALUES("2250","0","1","23","Siniolchu ","Siniolchu ","0","0","0","0");
INSERT INTO city VALUES("2251","0","1","23","Sombari ","Sombari ","0","0","0","0");
INSERT INTO city VALUES("2252","0","1","23","Soreng ","Soreng ","0","0","0","0");
INSERT INTO city VALUES("2253","0","1","23","Sosing ","Sosing ","0","0","0","0");
INSERT INTO city VALUES("2254","0","1","23","Tekhug ","Tekhug ","0","0","0","0");
INSERT INTO city VALUES("2255","0","1","23","Temi ","Temi ","0","0","0","0");
INSERT INTO city VALUES("2256","0","1","23","Tsetang ","Tsetang ","0","0","0","0");
INSERT INTO city VALUES("2257","0","1","23","Tsomgo ","Tsomgo ","0","0","0","0");
INSERT INTO city VALUES("2258","0","1","23","Tumlong ","Tumlong ","0","0","0","0");
INSERT INTO city VALUES("2259","0","1","23","Yangang ","Yangang ","0","0","0","0");
INSERT INTO city VALUES("2260","0","1","23","Yumtang","Yumtang","0","0","0","0");
INSERT INTO city VALUES("2261","0","1","24","Ambasamudram ","Ambasamudram ","0","0","0","0");
INSERT INTO city VALUES("2262","0","1","24","Anamali ","Anamali ","0","0","0","0");
INSERT INTO city VALUES("2263","0","1","24","Arakandanallur ","Arakandanallur ","0","0","0","0");
INSERT INTO city VALUES("2264","0","1","24","Arantangi ","Arantangi ","0","0","0","0");
INSERT INTO city VALUES("2265","0","1","24","Aravakurichi ","Aravakurichi ","0","0","0","0");
INSERT INTO city VALUES("2266","0","1","24","Ariyalur ","Ariyalur ","0","0","0","0");
INSERT INTO city VALUES("2267","0","1","24","Arkonam ","Arkonam ","0","0","0","0");
INSERT INTO city VALUES("2268","0","1","24","Arni ","Arni ","0","0","0","0");
INSERT INTO city VALUES("2269","0","1","24","Aruppukottai ","Aruppukottai ","0","0","0","0");
INSERT INTO city VALUES("2270","0","1","24","Attur ","Attur ","0","0","0","0");
INSERT INTO city VALUES("2271","0","1","24","Avanashi ","Avanashi ","0","0","0","0");
INSERT INTO city VALUES("2272","0","1","24","Batlagundu ","Batlagundu ","0","0","0","0");
INSERT INTO city VALUES("2273","0","1","24","Bhavani ","Bhavani ","0","0","0","0");
INSERT INTO city VALUES("2274","0","1","24","Chengalpattu ","Chengalpattu ","0","0","0","0");
INSERT INTO city VALUES("2275","0","1","24","Chengam ","Chengam ","0","0","0","0");
INSERT INTO city VALUES("2276","0","1","24","Chennai ","Chennai ","0","0","0","0");
INSERT INTO city VALUES("2277","0","1","24","Chidambaram ","Chidambaram ","0","0","0","0");
INSERT INTO city VALUES("2278","0","1","24","Chingleput ","Chingleput ","0","0","0","0");
INSERT INTO city VALUES("2279","0","1","24","Coimbatore ","Coimbatore ","0","0","0","0");
INSERT INTO city VALUES("2280","0","1","24","Courtallam ","Courtallam ","0","0","0","0");
INSERT INTO city VALUES("2281","0","1","24","Cuddalore ","Cuddalore ","0","0","0","0");
INSERT INTO city VALUES("2282","0","1","24","Cumbum ","Cumbum ","0","0","0","0");
INSERT INTO city VALUES("2283","0","1","24","Denkanikoitah ","Denkanikoitah ","0","0","0","0");
INSERT INTO city VALUES("2284","0","1","24","Devakottai ","Devakottai ","0","0","0","0");
INSERT INTO city VALUES("2285","0","1","24","Dharampuram ","Dharampuram ","0","0","0","0");
INSERT INTO city VALUES("2286","0","1","24","Dharmapuri ","Dharmapuri ","0","0","0","0");
INSERT INTO city VALUES("2287","0","1","24","Dindigul ","Dindigul ","0","0","0","0");
INSERT INTO city VALUES("2288","0","1","24","Erode ","Erode ","0","0","0","0");
INSERT INTO city VALUES("2289","0","1","24","Gingee ","Gingee ","0","0","0","0");
INSERT INTO city VALUES("2290","0","1","24","Gobichettipalayam ","Gobichettipalayam ","0","0","0","0");
INSERT INTO city VALUES("2291","0","1","24","Gudalur ","Gudalur ","0","0","0","0");
INSERT INTO city VALUES("2292","0","1","24","Gudiyatham ","Gudiyatham ","0","0","0","0");
INSERT INTO city VALUES("2293","0","1","24","Harur ","Harur ","0","0","0","0");
INSERT INTO city VALUES("2294","0","1","24","Hosur ","Hosur ","0","0","0","0");
INSERT INTO city VALUES("2295","0","1","24","Jayamkondan ","Jayamkondan ","0","0","0","0");
INSERT INTO city VALUES("2296","0","1","24","Kallkurichi ","Kallkurichi ","0","0","0","0");
INSERT INTO city VALUES("2297","0","1","24","Kanchipuram ","Kanchipuram ","0","0","0","0");
INSERT INTO city VALUES("2298","0","1","24","Kangayam ","Kangayam ","0","0","0","0");
INSERT INTO city VALUES("2299","0","1","24","Kanyakumari ","Kanyakumari ","0","0","0","0");
INSERT INTO city VALUES("2300","0","1","24","Karaikal ","Karaikal ","0","0","0","0");
INSERT INTO city VALUES("2301","0","1","24","Karaikudi ","Karaikudi ","0","0","0","0");
INSERT INTO city VALUES("2302","0","1","24","Karur ","Karur ","0","0","0","0");
INSERT INTO city VALUES("2303","0","1","24","Keeranur ","Keeranur ","0","0","0","0");
INSERT INTO city VALUES("2304","0","1","24","Kodaikanal ","Kodaikanal ","0","0","0","0");
INSERT INTO city VALUES("2305","0","1","24","Kodumudi ","Kodumudi ","0","0","0","0");
INSERT INTO city VALUES("2306","0","1","24","Kotagiri ","Kotagiri ","0","0","0","0");
INSERT INTO city VALUES("2307","0","1","24","Kovilpatti ","Kovilpatti ","0","0","0","0");
INSERT INTO city VALUES("2308","0","1","24","Krishnagiri ","Krishnagiri ","0","0","0","0");
INSERT INTO city VALUES("2309","0","1","24","Kulithalai ","Kulithalai ","0","0","0","0");
INSERT INTO city VALUES("2310","0","1","24","Kumbakonam ","Kumbakonam ","0","0","0","0");
INSERT INTO city VALUES("2311","0","1","24","Kuzhithurai ","Kuzhithurai ","0","0","0","0");
INSERT INTO city VALUES("2312","0","1","24","Madurai ","Madurai ","0","0","0","0");
INSERT INTO city VALUES("2313","0","1","24","Madurantgam ","Madurantgam ","0","0","0","0");
INSERT INTO city VALUES("2314","0","1","24","Manamadurai ","Manamadurai ","0","0","0","0");
INSERT INTO city VALUES("2315","0","1","24","Manaparai ","Manaparai ","0","0","0","0");
INSERT INTO city VALUES("2316","0","1","24","Mannargudi ","Mannargudi ","0","0","0","0");
INSERT INTO city VALUES("2317","0","1","24","Mayiladuthurai ","Mayiladuthurai ","0","0","0","0");
INSERT INTO city VALUES("2318","0","1","24","Mayiladutjurai ","Mayiladutjurai ","0","0","0","0");
INSERT INTO city VALUES("2319","0","1","24","Mettupalayam ","Mettupalayam ","0","0","0","0");
INSERT INTO city VALUES("2320","0","1","24","Metturdam ","Metturdam ","0","0","0","0");
INSERT INTO city VALUES("2321","0","1","24","Mudukulathur ","Mudukulathur ","0","0","0","0");
INSERT INTO city VALUES("2322","0","1","24","Mulanur ","Mulanur ","0","0","0","0");
INSERT INTO city VALUES("2323","0","1","24","Musiri ","Musiri ","0","0","0","0");
INSERT INTO city VALUES("2324","0","1","24","Nagapattinam ","Nagapattinam ","0","0","0","0");
INSERT INTO city VALUES("2325","0","1","24","Nagarcoil ","Nagarcoil ","0","0","0","0");
INSERT INTO city VALUES("2326","0","1","24","Namakkal ","Namakkal ","0","0","0","0");
INSERT INTO city VALUES("2327","0","1","24","Nanguneri ","Nanguneri ","0","0","0","0");
INSERT INTO city VALUES("2328","0","1","24","Natham ","Natham ","0","0","0","0");
INSERT INTO city VALUES("2329","0","1","24","Neyveli ","Neyveli ","0","0","0","0");
INSERT INTO city VALUES("2330","0","1","24","Nilgiris ","Nilgiris ","0","0","0","0");
INSERT INTO city VALUES("2331","0","1","24","Oddanchatram ","Oddanchatram ","0","0","0","0");
INSERT INTO city VALUES("2332","0","1","24","Omalpur ","Omalpur ","0","0","0","0");
INSERT INTO city VALUES("2333","0","1","24","Ootacamund ","Ootacamund ","0","0","0","0");
INSERT INTO city VALUES("2334","0","1","24","Ooty ","Ooty ","0","0","0","0");
INSERT INTO city VALUES("2335","0","1","24","Orathanad ","Orathanad ","0","0","0","0");
INSERT INTO city VALUES("2336","0","1","24","Palacode ","Palacode ","0","0","0","0");
INSERT INTO city VALUES("2337","0","1","24","Palani ","Palani ","0","0","0","0");
INSERT INTO city VALUES("2338","0","1","24","Palladum ","Palladum ","0","0","0","0");
INSERT INTO city VALUES("2339","0","1","24","Papanasam ","Papanasam ","0","0","0","0");
INSERT INTO city VALUES("2340","0","1","24","Paramakudi ","Paramakudi ","0","0","0","0");
INSERT INTO city VALUES("2341","0","1","24","Pattukottai ","Pattukottai ","0","0","0","0");
INSERT INTO city VALUES("2342","0","1","24","Perambalur ","Perambalur ","0","0","0","0");
INSERT INTO city VALUES("2343","0","1","24","Perundurai ","Perundurai ","0","0","0","0");
INSERT INTO city VALUES("2344","0","1","24","Pollachi ","Pollachi ","0","0","0","0");
INSERT INTO city VALUES("2345","0","1","24","Polur ","Polur ","0","0","0","0");
INSERT INTO city VALUES("2346","0","1","24","Pondicherry ","Pondicherry ","0","0","0","0");
INSERT INTO city VALUES("2347","0","1","24","Ponnamaravathi ","Ponnamaravathi ","0","0","0","0");
INSERT INTO city VALUES("2348","0","1","24","Ponneri ","Ponneri ","0","0","0","0");
INSERT INTO city VALUES("2349","0","1","24","Pudukkottai ","Pudukkottai ","0","0","0","0");
INSERT INTO city VALUES("2350","0","1","24","Rajapalayam ","Rajapalayam ","0","0","0","0");
INSERT INTO city VALUES("2351","0","1","24","Ramanathapuram ","Ramanathapuram ","0","0","0","0");
INSERT INTO city VALUES("2352","0","1","24","Rameshwaram ","Rameshwaram ","0","0","0","0");
INSERT INTO city VALUES("2353","0","1","24","Ranipet ","Ranipet ","0","0","0","0");
INSERT INTO city VALUES("2354","0","1","24","Rasipuram ","Rasipuram ","0","0","0","0");
INSERT INTO city VALUES("2355","0","1","24","Salem ","Salem ","0","0","0","0");
INSERT INTO city VALUES("2356","0","1","24","Sankagiri ","Sankagiri ","0","0","0","0");
INSERT INTO city VALUES("2357","0","1","24","Sankaran ","Sankaran ","0","0","0","0");
INSERT INTO city VALUES("2358","0","1","24","Sathiyamangalam ","Sathiyamangalam ","0","0","0","0");
INSERT INTO city VALUES("2359","0","1","24","Sivaganga ","Sivaganga ","0","0","0","0");
INSERT INTO city VALUES("2360","0","1","24","Sivakasi ","Sivakasi ","0","0","0","0");
INSERT INTO city VALUES("2361","0","1","24","Sriperumpudur ","Sriperumpudur ","0","0","0","0");
INSERT INTO city VALUES("2362","0","1","24","Srivaikundam ","Srivaikundam ","0","0","0","0");
INSERT INTO city VALUES("2363","0","1","24","Tenkasi ","Tenkasi ","0","0","0","0");
INSERT INTO city VALUES("2364","0","1","24","Thanjavur ","Thanjavur ","0","0","0","0");
INSERT INTO city VALUES("2365","0","1","24","Theni ","Theni ","0","0","0","0");
INSERT INTO city VALUES("2366","0","1","24","Thirumanglam ","Thirumanglam ","0","0","0","0");
INSERT INTO city VALUES("2367","0","1","24","Thiruraipoondi ","Thiruraipoondi ","0","0","0","0");
INSERT INTO city VALUES("2368","0","1","24","Thoothukudi ","Thoothukudi ","0","0","0","0");
INSERT INTO city VALUES("2369","0","1","24","Thuraiyure ","Thuraiyure ","0","0","0","0");
INSERT INTO city VALUES("2370","0","1","24","Tindivanam ","Tindivanam ","0","0","0","0");
INSERT INTO city VALUES("2371","0","1","24","Tiruchendur ","Tiruchendur ","0","0","0","0");
INSERT INTO city VALUES("2372","0","1","24","Tiruchengode ","Tiruchengode ","0","0","0","0");
INSERT INTO city VALUES("2373","0","1","24","Tiruchirappalli ","Tiruchirappalli ","0","0","0","0");
INSERT INTO city VALUES("2374","0","1","24","Tirunelvelli ","Tirunelvelli ","0","0","0","0");
INSERT INTO city VALUES("2375","0","1","24","Tirupathur ","Tirupathur ","0","0","0","0");
INSERT INTO city VALUES("2376","0","1","24","Tirupur ","Tirupur ","0","0","0","0");
INSERT INTO city VALUES("2377","0","1","24","Tiruttani ","Tiruttani ","0","0","0","0");
INSERT INTO city VALUES("2378","0","1","24","Tiruvallur ","Tiruvallur ","0","0","0","0");
INSERT INTO city VALUES("2379","0","1","24","Tiruvannamalai ","Tiruvannamalai ","0","0","0","0");
INSERT INTO city VALUES("2380","0","1","24","Tiruvarur ","Tiruvarur ","0","0","0","0");
INSERT INTO city VALUES("2381","0","1","24","Tiruvellore ","Tiruvellore ","0","0","0","0");
INSERT INTO city VALUES("2382","0","1","24","Tiruvettipuram ","Tiruvettipuram ","0","0","0","0");
INSERT INTO city VALUES("2383","0","1","24","Trichy ","Trichy ","0","0","0","0");
INSERT INTO city VALUES("2384","0","1","24","Tuticorin ","Tuticorin ","0","0","0","0");
INSERT INTO city VALUES("2385","0","1","24","Udumalpet ","Udumalpet ","0","0","0","0");
INSERT INTO city VALUES("2386","0","1","24","Ulundurpet ","Ulundurpet ","0","0","0","0");
INSERT INTO city VALUES("2387","0","1","24","Usiliampatti ","Usiliampatti ","0","0","0","0");
INSERT INTO city VALUES("2388","0","1","24","Uthangarai ","Uthangarai ","0","0","0","0");
INSERT INTO city VALUES("2389","0","1","24","Valapady ","Valapady ","0","0","0","0");
INSERT INTO city VALUES("2390","0","1","24","Valliyoor ","Valliyoor ","0","0","0","0");
INSERT INTO city VALUES("2391","0","1","24","Vaniyambadi ","Vaniyambadi ","0","0","0","0");
INSERT INTO city VALUES("2392","0","1","24","Vedasandur ","Vedasandur ","0","0","0","0");
INSERT INTO city VALUES("2393","0","1","24","Vellore ","Vellore ","0","0","0","0");
INSERT INTO city VALUES("2394","0","1","24","Velur ","Velur ","0","0","0","0");
INSERT INTO city VALUES("2395","0","1","24","Vilathikulam ","Vilathikulam ","0","0","0","0");
INSERT INTO city VALUES("2396","0","1","24","Villupuram ","Villupuram ","0","0","0","0");
INSERT INTO city VALUES("2397","0","1","24","Virudhachalam ","Virudhachalam ","0","0","0","0");
INSERT INTO city VALUES("2398","0","1","24","Virudhunagar ","Virudhunagar ","0","0","0","0");
INSERT INTO city VALUES("2399","0","1","24","Wandiwash ","Wandiwash ","0","0","0","0");
INSERT INTO city VALUES("2400","0","1","24","Yercaud","Yercaud","0","0","0","0");
INSERT INTO city VALUES("2401","0","1","25","Agartala ","Agartala ","0","0","0","0");
INSERT INTO city VALUES("2402","0","1","25","Ambasa ","Ambasa ","0","0","0","0");
INSERT INTO city VALUES("2403","0","1","25","Bampurbari ","Bampurbari ","0","0","0","0");
INSERT INTO city VALUES("2404","0","1","25","Belonia ","Belonia ","0","0","0","0");
INSERT INTO city VALUES("2405","0","1","25","Dhalai ","Dhalai ","0","0","0","0");
INSERT INTO city VALUES("2406","0","1","25","Dharam Nagar ","Dharam Nagar ","0","0","0","0");
INSERT INTO city VALUES("2407","0","1","25","Kailashahar ","Kailashahar ","0","0","0","0");
INSERT INTO city VALUES("2408","0","1","25","Kamal Krishnabari ","Kamal Krishnabari ","0","0","0","0");
INSERT INTO city VALUES("2409","0","1","25","Khopaiyapara ","Khopaiyapara ","0","0","0","0");
INSERT INTO city VALUES("2410","0","1","25","Khowai ","Khowai ","0","0","0","0");
INSERT INTO city VALUES("2411","0","1","25","Phuldungsei ","Phuldungsei ","0","0","0","0");
INSERT INTO city VALUES("2412","0","1","25","Radha Kishore Pur ","Radha Kishore Pur ","0","0","0","0");
INSERT INTO city VALUES("2413","0","1","25","Tripura","Tripura","0","0","0","0");
INSERT INTO city VALUES("2414","0","1","26","Achhnera ","Achhnera ","0","0","0","0");
INSERT INTO city VALUES("2415","0","1","26","Agra ","Agra ","0","0","0","0");
INSERT INTO city VALUES("2416","0","1","26","Akbarpur ","Akbarpur ","0","0","0","0");
INSERT INTO city VALUES("2417","0","1","26","Aliganj ","Aliganj ","0","0","0","0");
INSERT INTO city VALUES("2418","0","1","26","Aligarh ","Aligarh ","0","0","0","0");
INSERT INTO city VALUES("2419","0","1","26","Allahabad ","Allahabad ","0","0","0","0");
INSERT INTO city VALUES("2420","0","1","26","Ambedkar Nagar ","Ambedkar Nagar ","0","0","0","0");
INSERT INTO city VALUES("2421","0","1","26","Amethi ","Amethi ","0","0","0","0");
INSERT INTO city VALUES("2422","0","1","26","Amiliya ","Amiliya ","0","0","0","0");
INSERT INTO city VALUES("2423","0","1","26","Amroha ","Amroha ","0","0","0","0");
INSERT INTO city VALUES("2424","0","1","26","Anola ","Anola ","0","0","0","0");
INSERT INTO city VALUES("2425","0","1","26","Atrauli ","Atrauli ","0","0","0","0");
INSERT INTO city VALUES("2426","0","1","26","Auraiya ","Auraiya ","0","0","0","0");
INSERT INTO city VALUES("2427","0","1","26","Azamgarh ","Azamgarh ","0","0","0","0");
INSERT INTO city VALUES("2428","0","1","26","Baberu ","Baberu ","0","0","0","0");
INSERT INTO city VALUES("2429","0","1","26","Badaun ","Badaun ","0","0","0","0");
INSERT INTO city VALUES("2430","0","1","26","Baghpat ","Baghpat ","0","0","0","0");
INSERT INTO city VALUES("2431","0","1","26","Bagpat ","Bagpat ","0","0","0","0");
INSERT INTO city VALUES("2432","0","1","26","Baheri ","Baheri ","0","0","0","0");
INSERT INTO city VALUES("2433","0","1","26","Bahraich ","Bahraich ","0","0","0","0");
INSERT INTO city VALUES("2434","0","1","26","Ballia ","Ballia ","0","0","0","0");
INSERT INTO city VALUES("2435","0","1","26","Balrampur ","Balrampur ","0","0","0","0");
INSERT INTO city VALUES("2436","0","1","26","Banda ","Banda ","0","0","0","0");
INSERT INTO city VALUES("2437","0","1","26","Bansdeeh ","Bansdeeh ","0","0","0","0");
INSERT INTO city VALUES("2438","0","1","26","Bansgaon ","Bansgaon ","0","0","0","0");
INSERT INTO city VALUES("2439","0","1","26","Bansi ","Bansi ","0","0","0","0");
INSERT INTO city VALUES("2440","0","1","26","Barabanki ","Barabanki ","0","0","0","0");
INSERT INTO city VALUES("2441","0","1","26","Bareilly ","Bareilly ","0","0","0","0");
INSERT INTO city VALUES("2442","0","1","26","Basti ","Basti ","0","0","0","0");
INSERT INTO city VALUES("2443","0","1","26","Bhadohi ","Bhadohi ","0","0","0","0");
INSERT INTO city VALUES("2444","0","1","26","Bharthana ","Bharthana ","0","0","0","0");
INSERT INTO city VALUES("2445","0","1","26","Bharwari ","Bharwari ","0","0","0","0");
INSERT INTO city VALUES("2446","0","1","26","Bhogaon ","Bhogaon ","0","0","0","0");
INSERT INTO city VALUES("2447","0","1","26","Bhognipur ","Bhognipur ","0","0","0","0");
INSERT INTO city VALUES("2448","0","1","26","Bidhuna ","Bidhuna ","0","0","0","0");
INSERT INTO city VALUES("2449","0","1","26","Bijnore ","Bijnore ","0","0","0","0");
INSERT INTO city VALUES("2450","0","1","26","Bikapur ","Bikapur ","0","0","0","0");
INSERT INTO city VALUES("2451","0","1","26","Bilari ","Bilari ","0","0","0","0");
INSERT INTO city VALUES("2452","0","1","26","Bilgram ","Bilgram ","0","0","0","0");
INSERT INTO city VALUES("2453","0","1","26","Bilhaur ","Bilhaur ","0","0","0","0");
INSERT INTO city VALUES("2454","0","1","26","Bindki ","Bindki ","0","0","0","0");
INSERT INTO city VALUES("2455","0","1","26","Bisalpur ","Bisalpur ","0","0","0","0");
INSERT INTO city VALUES("2456","0","1","26","Bisauli ","Bisauli ","0","0","0","0");
INSERT INTO city VALUES("2457","0","1","26","Biswan ","Biswan ","0","0","0","0");
INSERT INTO city VALUES("2458","0","1","26","Budaun ","Budaun ","0","0","0","0");
INSERT INTO city VALUES("2459","0","1","26","Budhana ","Budhana ","0","0","0","0");
INSERT INTO city VALUES("2460","0","1","26","Bulandshahar ","Bulandshahar ","0","0","0","0");
INSERT INTO city VALUES("2461","0","1","26","Bulandshahr ","Bulandshahr ","0","0","0","0");
INSERT INTO city VALUES("2462","0","1","26","Capianganj ","Capianganj ","0","0","0","0");
INSERT INTO city VALUES("2463","0","1","26","Chakia ","Chakia ","0","0","0","0");
INSERT INTO city VALUES("2464","0","1","26","Chandauli ","Chandauli ","0","0","0","0");
INSERT INTO city VALUES("2465","0","1","26","Charkhari ","Charkhari ","0","0","0","0");
INSERT INTO city VALUES("2466","0","1","26","Chhata ","Chhata ","0","0","0","0");
INSERT INTO city VALUES("2467","0","1","26","Chhibramau ","Chhibramau ","0","0","0","0");
INSERT INTO city VALUES("2468","0","1","26","Chirgaon ","Chirgaon ","0","0","0","0");
INSERT INTO city VALUES("2469","0","1","26","Chitrakoot ","Chitrakoot ","0","0","0","0");
INSERT INTO city VALUES("2470","0","1","26","Chunur ","Chunur ","0","0","0","0");
INSERT INTO city VALUES("2471","0","1","26","Dadri ","Dadri ","0","0","0","0");
INSERT INTO city VALUES("2472","0","1","26","Dalmau ","Dalmau ","0","0","0","0");
INSERT INTO city VALUES("2473","0","1","26","Dataganj ","Dataganj ","0","0","0","0");
INSERT INTO city VALUES("2474","0","1","26","Debai ","Debai ","0","0","0","0");
INSERT INTO city VALUES("2475","0","1","26","Deoband ","Deoband ","0","0","0","0");
INSERT INTO city VALUES("2476","0","1","26","Deoria ","Deoria ","0","0","0","0");
INSERT INTO city VALUES("2477","0","1","26","Derapur ","Derapur ","0","0","0","0");
INSERT INTO city VALUES("2478","0","1","26","Dhampur ","Dhampur ","0","0","0","0");
INSERT INTO city VALUES("2479","0","1","26","Domariyaganj ","Domariyaganj ","0","0","0","0");
INSERT INTO city VALUES("2480","0","1","26","Dudhi ","Dudhi ","0","0","0","0");
INSERT INTO city VALUES("2481","0","1","26","Etah ","Etah ","0","0","0","0");
INSERT INTO city VALUES("2482","0","1","26","Etawah ","Etawah ","0","0","0","0");
INSERT INTO city VALUES("2483","0","1","26","Faizabad ","Faizabad ","0","0","0","0");
INSERT INTO city VALUES("2484","0","1","26","Farrukhabad ","Farrukhabad ","0","0","0","0");
INSERT INTO city VALUES("2485","0","1","26","Fatehpur ","Fatehpur ","0","0","0","0");
INSERT INTO city VALUES("2486","0","1","26","Firozabad ","Firozabad ","0","0","0","0");
INSERT INTO city VALUES("2487","0","1","26","Garauth ","Garauth ","0","0","0","0");
INSERT INTO city VALUES("2488","0","1","26","Garhmukteshwar ","Garhmukteshwar ","0","0","0","0");
INSERT INTO city VALUES("2489","0","1","26","Gautam Buddha Nagar ","Gautam Buddha Nagar ","0","0","0","0");
INSERT INTO city VALUES("2490","0","1","26","Ghatampur ","Ghatampur ","0","0","0","0");
INSERT INTO city VALUES("2491","0","1","26","Ghaziabad ","Ghaziabad ","0","0","0","0");
INSERT INTO city VALUES("2492","0","1","26","Ghazipur ","Ghazipur ","0","0","0","0");
INSERT INTO city VALUES("2493","0","1","26","Ghosi ","Ghosi ","0","0","0","0");
INSERT INTO city VALUES("2494","0","1","26","Gonda ","Gonda ","0","0","0","0");
INSERT INTO city VALUES("2495","0","1","26","Gorakhpur ","Gorakhpur ","0","0","0","0");
INSERT INTO city VALUES("2496","0","1","26","Gunnaur ","Gunnaur ","0","0","0","0");
INSERT INTO city VALUES("2497","0","1","26","Haidergarh ","Haidergarh ","0","0","0","0");
INSERT INTO city VALUES("2498","0","1","26","Hamirpur ","Hamirpur ","0","0","0","0");
INSERT INTO city VALUES("2499","0","1","26","Hapur ","Hapur ","0","0","0","0");
INSERT INTO city VALUES("2500","0","1","26","Hardoi ","Hardoi ","0","0","0","0");
INSERT INTO city VALUES("2501","0","1","26","Harraiya ","Harraiya ","0","0","0","0");
INSERT INTO city VALUES("2502","0","1","26","Hasanganj ","Hasanganj ","0","0","0","0");
INSERT INTO city VALUES("2503","0","1","26","Hasanpur ","Hasanpur ","0","0","0","0");
INSERT INTO city VALUES("2504","0","1","26","Hathras ","Hathras ","0","0","0","0");
INSERT INTO city VALUES("2505","0","1","26","Jalalabad ","Jalalabad ","0","0","0","0");
INSERT INTO city VALUES("2506","0","1","26","Jalaun ","Jalaun ","0","0","0","0");
INSERT INTO city VALUES("2507","0","1","26","Jalesar ","Jalesar ","0","0","0","0");
INSERT INTO city VALUES("2508","0","1","26","Jansath ","Jansath ","0","0","0","0");
INSERT INTO city VALUES("2509","0","1","26","Jarar ","Jarar ","0","0","0","0");
INSERT INTO city VALUES("2510","0","1","26","Jasrana ","Jasrana ","0","0","0","0");
INSERT INTO city VALUES("2511","0","1","26","Jaunpur ","Jaunpur ","0","0","0","0");
INSERT INTO city VALUES("2512","0","1","26","Jhansi ","Jhansi ","0","0","0","0");
INSERT INTO city VALUES("2513","0","1","26","Jyotiba Phule Nagar ","Jyotiba Phule Nagar ","0","0","0","0");
INSERT INTO city VALUES("2514","0","1","26","Kadipur ","Kadipur ","0","0","0","0");
INSERT INTO city VALUES("2515","0","1","26","Kaimganj ","Kaimganj ","0","0","0","0");
INSERT INTO city VALUES("2516","0","1","26","Kairana ","Kairana ","0","0","0","0");
INSERT INTO city VALUES("2517","0","1","26","Kaisarganj ","Kaisarganj ","0","0","0","0");
INSERT INTO city VALUES("2518","0","1","26","Kalpi ","Kalpi ","0","0","0","0");
INSERT INTO city VALUES("2519","0","1","26","Kannauj ","Kannauj ","0","0","0","0");
INSERT INTO city VALUES("2520","0","1","26","Kanpur ","Kanpur ","0","0","0","0");
INSERT INTO city VALUES("2521","0","1","26","Karchhana ","Karchhana ","0","0","0","0");
INSERT INTO city VALUES("2522","0","1","26","Karhal ","Karhal ","0","0","0","0");
INSERT INTO city VALUES("2523","0","1","26","Karvi ","Karvi ","0","0","0","0");
INSERT INTO city VALUES("2524","0","1","26","Kasganj ","Kasganj ","0","0","0","0");
INSERT INTO city VALUES("2525","0","1","26","Kaushambi ","Kaushambi ","0","0","0","0");
INSERT INTO city VALUES("2526","0","1","26","Kerakat ","Kerakat ","0","0","0","0");
INSERT INTO city VALUES("2527","0","1","26","Khaga ","Khaga ","0","0","0","0");
INSERT INTO city VALUES("2528","0","1","26","Khair ","Khair ","0","0","0","0");
INSERT INTO city VALUES("2529","0","1","26","Khalilabad ","Khalilabad ","0","0","0","0");
INSERT INTO city VALUES("2530","0","1","26","Kheri ","Kheri ","0","0","0","0");
INSERT INTO city VALUES("2531","0","1","26","Konch ","Konch ","0","0","0","0");
INSERT INTO city VALUES("2532","0","1","26","Kumaon ","Kumaon ","0","0","0","0");
INSERT INTO city VALUES("2533","0","1","26","Kunda ","Kunda ","0","0","0","0");
INSERT INTO city VALUES("2534","0","1","26","Kushinagar ","Kushinagar ","0","0","0","0");
INSERT INTO city VALUES("2535","0","1","26","Lalganj ","Lalganj ","0","0","0","0");
INSERT INTO city VALUES("2536","0","1","26","Lalitpur ","Lalitpur ","0","0","0","0");
INSERT INTO city VALUES("2537","0","1","26","Lucknow ","Lucknow ","0","0","0","0");
INSERT INTO city VALUES("2538","0","1","26","Machlishahar ","Machlishahar ","0","0","0","0");
INSERT INTO city VALUES("2539","0","1","26","Maharajganj ","Maharajganj ","0","0","0","0");
INSERT INTO city VALUES("2540","0","1","26","Mahoba ","Mahoba ","0","0","0","0");
INSERT INTO city VALUES("2541","0","1","26","Mainpuri ","Mainpuri ","0","0","0","0");
INSERT INTO city VALUES("2542","0","1","26","Malihabad ","Malihabad ","0","0","0","0");
INSERT INTO city VALUES("2543","0","1","26","Mariyahu ","Mariyahu ","0","0","0","0");
INSERT INTO city VALUES("2544","0","1","26","Math ","Math ","0","0","0","0");
INSERT INTO city VALUES("2545","0","1","26","Mathura ","Mathura ","0","0","0","0");
INSERT INTO city VALUES("2546","0","1","26","Mau ","Mau ","0","0","0","0");
INSERT INTO city VALUES("2547","0","1","26","Maudaha ","Maudaha ","0","0","0","0");
INSERT INTO city VALUES("2548","0","1","26","Maunathbhanjan ","Maunathbhanjan ","0","0","0","0");
INSERT INTO city VALUES("2549","0","1","26","Mauranipur ","Mauranipur ","0","0","0","0");
INSERT INTO city VALUES("2550","0","1","26","Mawana ","Mawana ","0","0","0","0");
INSERT INTO city VALUES("2551","0","1","26","Meerut ","Meerut ","0","0","0","0");
INSERT INTO city VALUES("2552","0","1","26","Mehraun ","Mehraun ","0","0","0","0");
INSERT INTO city VALUES("2553","0","1","26","Meja ","Meja ","0","0","0","0");
INSERT INTO city VALUES("2554","0","1","26","Mirzapur ","Mirzapur ","0","0","0","0");
INSERT INTO city VALUES("2555","0","1","26","Misrikh ","Misrikh ","0","0","0","0");
INSERT INTO city VALUES("2556","0","1","26","Modinagar ","Modinagar ","0","0","0","0");
INSERT INTO city VALUES("2557","0","1","26","Mohamdabad ","Mohamdabad ","0","0","0","0");
INSERT INTO city VALUES("2558","0","1","26","Mohamdi ","Mohamdi ","0","0","0","0");
INSERT INTO city VALUES("2559","0","1","26","Moradabad ","Moradabad ","0","0","0","0");
INSERT INTO city VALUES("2560","0","1","26","Musafirkhana ","Musafirkhana ","0","0","0","0");
INSERT INTO city VALUES("2561","0","1","26","Muzaffarnagar ","Muzaffarnagar ","0","0","0","0");
INSERT INTO city VALUES("2562","0","1","26","Nagina ","Nagina ","0","0","0","0");
INSERT INTO city VALUES("2563","0","1","26","Najibabad ","Najibabad ","0","0","0","0");
INSERT INTO city VALUES("2564","0","1","26","Nakur ","Nakur ","0","0","0","0");
INSERT INTO city VALUES("2565","0","1","26","Nanpara ","Nanpara ","0","0","0","0");
INSERT INTO city VALUES("2566","0","1","26","Naraini ","Naraini ","0","0","0","0");
INSERT INTO city VALUES("2567","0","1","26","Naugarh ","Naugarh ","0","0","0","0");
INSERT INTO city VALUES("2568","0","1","26","Nawabganj ","Nawabganj ","0","0","0","0");
INSERT INTO city VALUES("2569","0","1","26","Nighasan ","Nighasan ","0","0","0","0");
INSERT INTO city VALUES("2570","0","1","26","Noida ","Noida ","0","0","0","0");
INSERT INTO city VALUES("2571","0","1","26","Orai ","Orai ","0","0","0","0");
INSERT INTO city VALUES("2572","0","1","26","Padrauna ","Padrauna ","0","0","0","0");
INSERT INTO city VALUES("2573","0","1","26","Pahasu ","Pahasu ","0","0","0","0");
INSERT INTO city VALUES("2574","0","1","26","Patti ","Patti ","0","0","0","0");
INSERT INTO city VALUES("2575","0","1","26","Pharenda ","Pharenda ","0","0","0","0");
INSERT INTO city VALUES("2576","0","1","26","Phoolpur ","Phoolpur ","0","0","0","0");
INSERT INTO city VALUES("2577","0","1","26","Phulpur ","Phulpur ","0","0","0","0");
INSERT INTO city VALUES("2578","0","1","26","Pilibhit ","Pilibhit ","0","0","0","0");
INSERT INTO city VALUES("2579","0","1","26","Pitamberpur ","Pitamberpur ","0","0","0","0");
INSERT INTO city VALUES("2580","0","1","26","Powayan ","Powayan ","0","0","0","0");
INSERT INTO city VALUES("2581","0","1","26","Pratapgarh ","Pratapgarh ","0","0","0","0");
INSERT INTO city VALUES("2582","0","1","26","Puranpur ","Puranpur ","0","0","0","0");
INSERT INTO city VALUES("2583","0","1","26","Purwa ","Purwa ","0","0","0","0");
INSERT INTO city VALUES("2584","0","1","26","Raibareli ","Raibareli ","0","0","0","0");
INSERT INTO city VALUES("2585","0","1","26","Rampur ","Rampur ","0","0","0","0");
INSERT INTO city VALUES("2586","0","1","26","Ramsanehi Ghat ","Ramsanehi Ghat ","0","0","0","0");
INSERT INTO city VALUES("2587","0","1","26","Rasara ","Rasara ","0","0","0","0");
INSERT INTO city VALUES("2588","0","1","26","Rath ","Rath ","0","0","0","0");
INSERT INTO city VALUES("2589","0","1","26","Robertsganj ","Robertsganj ","0","0","0","0");
INSERT INTO city VALUES("2590","0","1","26","Sadabad ","Sadabad ","0","0","0","0");
INSERT INTO city VALUES("2591","0","1","26","Safipur ","Safipur ","0","0","0","0");
INSERT INTO city VALUES("2592","0","1","26","Sagri ","Sagri ","0","0","0","0");
INSERT INTO city VALUES("2593","0","1","26","Saharanpur ","Saharanpur ","0","0","0","0");
INSERT INTO city VALUES("2594","0","1","26","Sahaswan ","Sahaswan ","0","0","0","0");
INSERT INTO city VALUES("2595","0","1","26","Sahjahanpur ","Sahjahanpur ","0","0","0","0");
INSERT INTO city VALUES("2596","0","1","26","Saidpur ","Saidpur ","0","0","0","0");
INSERT INTO city VALUES("2597","0","1","26","Salempur ","Salempur ","0","0","0","0");
INSERT INTO city VALUES("2598","0","1","26","Salon ","Salon ","0","0","0","0");
INSERT INTO city VALUES("2599","0","1","26","Sambhal ","Sambhal ","0","0","0","0");
INSERT INTO city VALUES("2600","0","1","26","Sandila ","Sandila ","0","0","0","0");
INSERT INTO city VALUES("2601","0","1","26","Sant Kabir Nagar ","Sant Kabir Nagar ","0","0","0","0");
INSERT INTO city VALUES("2602","0","1","26","Sant Ravidas Nagar ","Sant Ravidas Nagar ","0","0","0","0");
INSERT INTO city VALUES("2603","0","1","26","Sardhana ","Sardhana ","0","0","0","0");
INSERT INTO city VALUES("2604","0","1","26","Shahabad ","Shahabad ","0","0","0","0");
INSERT INTO city VALUES("2605","0","1","26","Shahganj ","Shahganj ","0","0","0","0");
INSERT INTO city VALUES("2606","0","1","26","Shahjahanpur ","Shahjahanpur ","0","0","0","0");
INSERT INTO city VALUES("2607","0","1","26","Shikohabad ","Shikohabad ","0","0","0","0");
INSERT INTO city VALUES("2608","0","1","26","Shravasti ","Shravasti ","0","0","0","0");
INSERT INTO city VALUES("2609","0","1","26","Siddharthnagar ","Siddharthnagar ","0","0","0","0");
INSERT INTO city VALUES("2610","0","1","26","Sidhauli ","Sidhauli ","0","0","0","0");
INSERT INTO city VALUES("2611","0","1","26","Sikandra Rao ","Sikandra Rao ","0","0","0","0");
INSERT INTO city VALUES("2612","0","1","26","Sikandrabad ","Sikandrabad ","0","0","0","0");
INSERT INTO city VALUES("2613","0","1","26","Sitapur ","Sitapur ","0","0","0","0");
INSERT INTO city VALUES("2614","0","1","26","Siyana ","Siyana ","0","0","0","0");
INSERT INTO city VALUES("2615","0","1","26","Sonbhadra ","Sonbhadra ","0","0","0","0");
INSERT INTO city VALUES("2616","0","1","26","Soraon ","Soraon ","0","0","0","0");
INSERT INTO city VALUES("2617","0","1","26","Sultanpur ","Sultanpur ","0","0","0","0");
INSERT INTO city VALUES("2618","0","1","26","Tanda ","Tanda ","0","0","0","0");
INSERT INTO city VALUES("2619","0","1","26","Tarabganj ","Tarabganj ","0","0","0","0");
INSERT INTO city VALUES("2620","0","1","26","Tilhar ","Tilhar ","0","0","0","0");
INSERT INTO city VALUES("2621","0","1","26","Unnao ","Unnao ","0","0","0","0");
INSERT INTO city VALUES("2622","0","1","26","Utraula ","Utraula ","0","0","0","0");
INSERT INTO city VALUES("2623","0","1","26","Varanasi ","Varanasi ","0","0","0","0");
INSERT INTO city VALUES("2624","0","1","26","Zamania ","Zamania ","0","0","0","0");
INSERT INTO city VALUES("2625","0","1","27","Almora ","Almora ","0","0","0","0");
INSERT INTO city VALUES("2626","0","1","27","Bageshwar ","Bageshwar ","0","0","0","0");
INSERT INTO city VALUES("2627","0","1","27","Bhatwari ","Bhatwari ","0","0","0","0");
INSERT INTO city VALUES("2628","0","1","27","Chakrata ","Chakrata ","0","0","0","0");
INSERT INTO city VALUES("2629","0","1","27","Chamoli ","Chamoli ","0","0","0","0");
INSERT INTO city VALUES("2630","0","1","27","Champawat ","Champawat ","0","0","0","0");
INSERT INTO city VALUES("2631","0","1","27","Dehradun ","Dehradun ","0","0","0","0");
INSERT INTO city VALUES("2632","0","1","27","Deoprayag ","Deoprayag ","0","0","0","0");
INSERT INTO city VALUES("2633","0","1","27","Dharchula ","Dharchula ","0","0","0","0");
INSERT INTO city VALUES("2634","0","1","27","Dunda ","Dunda ","0","0","0","0");
INSERT INTO city VALUES("2635","0","1","27","Haldwani ","Haldwani ","0","0","0","0");
INSERT INTO city VALUES("2636","0","1","27","Haridwar ","Haridwar ","0","0","0","0");
INSERT INTO city VALUES("2637","0","1","27","Joshimath ","Joshimath ","0","0","0","0");
INSERT INTO city VALUES("2638","0","1","27","Karan Prayag ","Karan Prayag ","0","0","0","0");
INSERT INTO city VALUES("2639","0","1","27","Kashipur ","Kashipur ","0","0","0","0");
INSERT INTO city VALUES("2640","0","1","27","Khatima ","Khatima ","0","0","0","0");
INSERT INTO city VALUES("2641","0","1","27","Kichha ","Kichha ","0","0","0","0");
INSERT INTO city VALUES("2642","0","1","27","Lansdown ","Lansdown ","0","0","0","0");
INSERT INTO city VALUES("2643","0","1","27","Munsiari ","Munsiari ","0","0","0","0");
INSERT INTO city VALUES("2644","0","1","27","Mussoorie ","Mussoorie ","0","0","0","0");
INSERT INTO city VALUES("2645","0","1","27","Nainital ","Nainital ","0","0","0","0");
INSERT INTO city VALUES("2646","0","1","27","Pantnagar ","Pantnagar ","0","0","0","0");
INSERT INTO city VALUES("2647","0","1","27","Partapnagar ","Partapnagar ","0","0","0","0");
INSERT INTO city VALUES("2648","0","1","27","Pauri Garhwal ","Pauri Garhwal ","0","0","0","0");
INSERT INTO city VALUES("2649","0","1","27","Pithoragarh ","Pithoragarh ","0","0","0","0");
INSERT INTO city VALUES("2650","0","1","27","Purola ","Purola ","0","0","0","0");
INSERT INTO city VALUES("2651","0","1","27","Rajgarh ","Rajgarh ","0","0","0","0");
INSERT INTO city VALUES("2652","0","1","27","Ranikhet ","Ranikhet ","0","0","0","0");
INSERT INTO city VALUES("2653","0","1","27","Roorkee ","Roorkee ","0","0","0","0");
INSERT INTO city VALUES("2654","0","1","27","Rudraprayag ","Rudraprayag ","0","0","0","0");
INSERT INTO city VALUES("2655","0","1","27","Tehri Garhwal ","Tehri Garhwal ","0","0","0","0");
INSERT INTO city VALUES("2656","0","1","27","Udham Singh Nagar ","Udham Singh Nagar ","0","0","0","0");
INSERT INTO city VALUES("2657","0","1","27","Ukhimath ","Ukhimath ","0","0","0","0");
INSERT INTO city VALUES("2658","0","1","27","Uttarkashi ","Uttarkashi ","0","0","0","0");
INSERT INTO city VALUES("2659","0","1","28","Adra ","Adra ","0","0","0","0");
INSERT INTO city VALUES("2660","0","1","28","Alipurduar ","Alipurduar ","0","0","0","0");
INSERT INTO city VALUES("2661","0","1","28","Amlagora ","Amlagora ","0","0","0","0");
INSERT INTO city VALUES("2662","0","1","28","Arambagh ","Arambagh ","0","0","0","0");
INSERT INTO city VALUES("2663","0","1","28","Asansol ","Asansol ","0","0","0","0");
INSERT INTO city VALUES("2664","0","1","28","Balurghat ","Balurghat ","0","0","0","0");
INSERT INTO city VALUES("2665","0","1","28","Bankura ","Bankura ","0","0","0","0");
INSERT INTO city VALUES("2666","0","1","28","Bardhaman ","Bardhaman ","0","0","0","0");
INSERT INTO city VALUES("2667","0","1","28","Basirhat ","Basirhat ","0","0","0","0");
INSERT INTO city VALUES("2668","0","1","28","Berhampur ","Berhampur ","0","0","0","0");
INSERT INTO city VALUES("2669","0","1","28","Bethuadahari ","Bethuadahari ","0","0","0","0");
INSERT INTO city VALUES("2670","0","1","28","Birbhum ","Birbhum ","0","0","0","0");
INSERT INTO city VALUES("2671","0","1","28","Birpara ","Birpara ","0","0","0","0");
INSERT INTO city VALUES("2672","0","1","28","Bishanpur ","Bishanpur ","0","0","0","0");
INSERT INTO city VALUES("2673","0","1","28","Bolpur ","Bolpur ","0","0","0","0");
INSERT INTO city VALUES("2674","0","1","28","Bongoan ","Bongoan ","0","0","0","0");
INSERT INTO city VALUES("2675","0","1","28","Bulbulchandi ","Bulbulchandi ","0","0","0","0");
INSERT INTO city VALUES("2676","0","1","28","Burdwan ","Burdwan ","0","0","0","0");
INSERT INTO city VALUES("2677","0","1","28","Calcutta ","Calcutta ","0","0","0","0");
INSERT INTO city VALUES("2678","0","1","28","Canning ","Canning ","0","0","0","0");
INSERT INTO city VALUES("2679","0","1","28","Champadanga ","Champadanga ","0","0","0","0");
INSERT INTO city VALUES("2680","0","1","28","Contai ","Contai ","0","0","0","0");
INSERT INTO city VALUES("2681","0","1","28","Cooch Behar ","Cooch Behar ","0","0","0","0");
INSERT INTO city VALUES("2682","0","1","28","Daimond Harbour ","Daimond Harbour ","0","0","0","0");
INSERT INTO city VALUES("2683","0","1","28","Dalkhola ","Dalkhola ","0","0","0","0");
INSERT INTO city VALUES("2684","0","1","28","Dantan ","Dantan ","0","0","0","0");
INSERT INTO city VALUES("2685","0","1","28","Darjeeling ","Darjeeling ","0","0","0","0");
INSERT INTO city VALUES("2686","0","1","28","Dhaniakhali ","Dhaniakhali ","0","0","0","0");
INSERT INTO city VALUES("2687","0","1","28","Dhuliyan ","Dhuliyan ","0","0","0","0");
INSERT INTO city VALUES("2688","0","1","28","Dinajpur ","Dinajpur ","0","0","0","0");
INSERT INTO city VALUES("2689","0","1","28","Dinhata ","Dinhata ","0","0","0","0");
INSERT INTO city VALUES("2690","0","1","28","Durgapur ","Durgapur ","0","0","0","0");
INSERT INTO city VALUES("2691","0","1","28","Gangajalghati ","Gangajalghati ","0","0","0","0");
INSERT INTO city VALUES("2692","0","1","28","Gangarampur ","Gangarampur ","0","0","0","0");
INSERT INTO city VALUES("2693","0","1","28","Ghatal ","Ghatal ","0","0","0","0");
INSERT INTO city VALUES("2694","0","1","28","Guskara ","Guskara ","0","0","0","0");
INSERT INTO city VALUES("2695","0","1","28","Habra ","Habra ","0","0","0","0");
INSERT INTO city VALUES("2696","0","1","28","Haldia ","Haldia ","0","0","0","0");
INSERT INTO city VALUES("2697","0","1","28","Harirampur ","Harirampur ","0","0","0","0");
INSERT INTO city VALUES("2698","0","1","28","Harishchandrapur ","Harishchandrapur ","0","0","0","0");
INSERT INTO city VALUES("2699","0","1","28","Hooghly ","Hooghly ","0","0","0","0");
INSERT INTO city VALUES("2700","0","1","28","Howrah ","Howrah ","0","0","0","0");
INSERT INTO city VALUES("2701","0","1","28","Islampur ","Islampur ","0","0","0","0");
INSERT INTO city VALUES("2702","0","1","28","Jagatballavpur ","Jagatballavpur ","0","0","0","0");
INSERT INTO city VALUES("2703","0","1","28","Jalpaiguri ","Jalpaiguri ","0","0","0","0");
INSERT INTO city VALUES("2704","0","1","28","Jhalda ","Jhalda ","0","0","0","0");
INSERT INTO city VALUES("2705","0","1","28","Jhargram ","Jhargram ","0","0","0","0");
INSERT INTO city VALUES("2706","0","1","28","Kakdwip ","Kakdwip ","0","0","0","0");
INSERT INTO city VALUES("2707","0","1","28","Kalchini ","Kalchini ","0","0","0","0");
INSERT INTO city VALUES("2708","0","1","28","Kalimpong ","Kalimpong ","0","0","0","0");
INSERT INTO city VALUES("2709","0","1","28","Kalna ","Kalna ","0","0","0","0");
INSERT INTO city VALUES("2710","0","1","28","Kandi ","Kandi ","0","0","0","0");
INSERT INTO city VALUES("2711","0","1","28","Karimpur ","Karimpur ","0","0","0","0");
INSERT INTO city VALUES("2712","0","1","28","Katwa ","Katwa ","0","0","0","0");
INSERT INTO city VALUES("2713","0","1","28","Kharagpur ","Kharagpur ","0","0","0","0");
INSERT INTO city VALUES("2714","0","1","28","Khatra ","Khatra ","0","0","0","0");
INSERT INTO city VALUES("2715","0","1","28","Krishnanagar ","Krishnanagar ","0","0","0","0");
INSERT INTO city VALUES("2716","0","1","28","Mal Bazar ","Mal Bazar ","0","0","0","0");
INSERT INTO city VALUES("2717","0","1","28","Malda ","Malda ","0","0","0","0");
INSERT INTO city VALUES("2718","0","1","28","Manbazar ","Manbazar ","0","0","0","0");
INSERT INTO city VALUES("2719","0","1","28","Mathabhanga ","Mathabhanga ","0","0","0","0");
INSERT INTO city VALUES("2720","0","1","28","Medinipur ","Medinipur ","0","0","0","0");
INSERT INTO city VALUES("2721","0","1","28","Mekhliganj ","Mekhliganj ","0","0","0","0");
INSERT INTO city VALUES("2722","0","1","28","Mirzapur ","Mirzapur ","0","0","0","0");
INSERT INTO city VALUES("2723","0","1","28","Murshidabad ","Murshidabad ","0","0","0","0");
INSERT INTO city VALUES("2724","0","1","28","Nadia ","Nadia ","0","0","0","0");
INSERT INTO city VALUES("2725","0","1","28","Nagarakata ","Nagarakata ","0","0","0","0");
INSERT INTO city VALUES("2726","0","1","28","Nalhati ","Nalhati ","0","0","0","0");
INSERT INTO city VALUES("2727","0","1","28","Nayagarh ","Nayagarh ","0","0","0","0");
INSERT INTO city VALUES("2728","0","1","28","Parganas ","Parganas ","0","0","0","0");
INSERT INTO city VALUES("2729","0","1","28","Purulia ","Purulia ","0","0","0","0");
INSERT INTO city VALUES("2730","0","1","28","Raiganj ","Raiganj ","0","0","0","0");
INSERT INTO city VALUES("2731","0","1","28","Rampur Hat ","Rampur Hat ","0","0","0","0");
INSERT INTO city VALUES("2732","0","1","28","Ranaghat ","Ranaghat ","0","0","0","0");
INSERT INTO city VALUES("2733","0","1","28","Seharabazar ","Seharabazar ","0","0","0","0");
INSERT INTO city VALUES("2734","0","1","28","Siliguri ","Siliguri ","0","0","0","0");
INSERT INTO city VALUES("2735","0","1","28","Suri ","Suri ","0","0","0","0");
INSERT INTO city VALUES("2736","0","1","28","Takipur ","Takipur ","0","0","0","0");
INSERT INTO city VALUES("2737","0","1","28","Tamluk ","Tamluk ","0","0","0","0");
INSERT INTO city VALUES("2738","0","1","29","Alipur ","Alipur ","0","0","0","0");
INSERT INTO city VALUES("2739","0","1","29","Andaman Island ","Andaman Island ","0","0","0","0");
INSERT INTO city VALUES("2740","0","1","29","Anderson Island ","Anderson Island ","0","0","0","0");
INSERT INTO city VALUES("2741","0","1","29","Arainj-Laka-Punga ","Arainj-Laka-Punga ","0","0","0","0");
INSERT INTO city VALUES("2742","0","1","29","Austinabad ","Austinabad ","0","0","0","0");
INSERT INTO city VALUES("2743","0","1","29","Bamboo Flat ","Bamboo Flat ","0","0","0","0");
INSERT INTO city VALUES("2744","0","1","29","Barren Island ","Barren Island ","0","0","0","0");
INSERT INTO city VALUES("2745","0","1","29","Beadonabad ","Beadonabad ","0","0","0","0");
INSERT INTO city VALUES("2746","0","1","29","Betapur ","Betapur ","0","0","0","0");
INSERT INTO city VALUES("2747","0","1","29","Bindraban ","Bindraban ","0","0","0","0");
INSERT INTO city VALUES("2748","0","1","29","Bonington ","Bonington ","0","0","0","0");
INSERT INTO city VALUES("2749","0","1","29","Brookesabad ","Brookesabad ","0","0","0","0");
INSERT INTO city VALUES("2750","0","1","29","Cadell Point ","Cadell Point ","0","0","0","0");
INSERT INTO city VALUES("2751","0","1","29","Calicut ","Calicut ","0","0","0","0");
INSERT INTO city VALUES("2752","0","1","29","Chetamale ","Chetamale ","0","0","0","0");
INSERT INTO city VALUES("2753","0","1","29","Cinque Islands ","Cinque Islands ","0","0","0","0");
INSERT INTO city VALUES("2754","0","1","29","Defence Island ","Defence Island ","0","0","0","0");
INSERT INTO city VALUES("2755","0","1","29","Digilpur ","Digilpur ","0","0","0","0");
INSERT INTO city VALUES("2756","0","1","29","Dolyganj ","Dolyganj ","0","0","0","0");
INSERT INTO city VALUES("2757","0","1","29","Flat Island ","Flat Island ","0","0","0","0");
INSERT INTO city VALUES("2758","0","1","29","Geinyale ","Geinyale ","0","0","0","0");
INSERT INTO city VALUES("2759","0","1","29","Great Coco Island ","Great Coco Island ","0","0","0","0");
INSERT INTO city VALUES("2760","0","1","29","Haddo ","Haddo ","0","0","0","0");
INSERT INTO city VALUES("2761","0","1","29","Havelock Island ","Havelock Island ","0","0","0","0");
INSERT INTO city VALUES("2762","0","1","29","Henry Lawrence Island ","Henry Lawrence Island ","0","0","0","0");
INSERT INTO city VALUES("2763","0","1","29","Herbertabad ","Herbertabad ","0","0","0","0");
INSERT INTO city VALUES("2764","0","1","29","Hobdaypur ","Hobdaypur ","0","0","0","0");
INSERT INTO city VALUES("2765","0","1","29","Ilichar ","Ilichar ","0","0","0","0");
INSERT INTO city VALUES("2766","0","1","29","Ingoie ","Ingoie ","0","0","0","0");
INSERT INTO city VALUES("2767","0","1","29","Inteview Island ","Inteview Island ","0","0","0","0");
INSERT INTO city VALUES("2768","0","1","29","Jangli Ghat ","Jangli Ghat ","0","0","0","0");
INSERT INTO city VALUES("2769","0","1","29","Jhon Lawrence Island ","Jhon Lawrence Island ","0","0","0","0");
INSERT INTO city VALUES("2770","0","1","29","Karen ","Karen ","0","0","0","0");
INSERT INTO city VALUES("2771","0","1","29","Kartara ","Kartara ","0","0","0","0");
INSERT INTO city VALUES("2772","0","1","29","KYD Islannd ","KYD Islannd ","0","0","0","0");
INSERT INTO city VALUES("2773","0","1","29","Landfall Island ","Landfall Island ","0","0","0","0");
INSERT INTO city VALUES("2774","0","1","29","Little Andmand ","Little Andmand ","0","0","0","0");
INSERT INTO city VALUES("2775","0","1","29","Little Coco Island ","Little Coco Island ","0","0","0","0");
INSERT INTO city VALUES("2776","0","1","29","Long Island ","Long Island ","0","0","0","0");
INSERT INTO city VALUES("2777","0","1","29","Maimyo ","Maimyo ","0","0","0","0");
INSERT INTO city VALUES("2778","0","1","29","Malappuram ","Malappuram ","0","0","0","0");
INSERT INTO city VALUES("2779","0","1","29","Manglutan ","Manglutan ","0","0","0","0");
INSERT INTO city VALUES("2780","0","1","29","Manpur ","Manpur ","0","0","0","0");
INSERT INTO city VALUES("2781","0","1","29","Mitha Khari ","Mitha Khari ","0","0","0","0");
INSERT INTO city VALUES("2782","0","1","29","Neill Island ","Neill Island ","0","0","0","0");
INSERT INTO city VALUES("2783","0","1","29","Nicobar Island ","Nicobar Island ","0","0","0","0");
INSERT INTO city VALUES("2784","0","1","29","North Brother Island ","North Brother Island ","0","0","0","0");
INSERT INTO city VALUES("2785","0","1","29","North Passage Island ","North Passage Island ","0","0","0","0");
INSERT INTO city VALUES("2786","0","1","29","North Sentinel Island ","North Sentinel Island ","0","0","0","0");
INSERT INTO city VALUES("2787","0","1","29","Nothen Reef Island ","Nothen Reef Island ","0","0","0","0");
INSERT INTO city VALUES("2788","0","1","29","Outram Island ","Outram Island ","0","0","0","0");
INSERT INTO city VALUES("2789","0","1","29","Pahlagaon ","Pahlagaon ","0","0","0","0");
INSERT INTO city VALUES("2790","0","1","29","Palalankwe ","Palalankwe ","0","0","0","0");
INSERT INTO city VALUES("2791","0","1","29","Passage Island ","Passage Island ","0","0","0","0");
INSERT INTO city VALUES("2792","0","1","29","Phaiapong ","Phaiapong ","0","0","0","0");
INSERT INTO city VALUES("2793","0","1","29","Phoenix Island ","Phoenix Island ","0","0","0","0");
INSERT INTO city VALUES("2794","0","1","29","Port Blair ","Port Blair ","0","0","0","0");
INSERT INTO city VALUES("2795","0","1","29","Preparis Island ","Preparis Island ","0","0","0","0");
INSERT INTO city VALUES("2796","0","1","29","Protheroepur ","Protheroepur ","0","0","0","0");
INSERT INTO city VALUES("2797","0","1","29","Rangachang ","Rangachang ","0","0","0","0");
INSERT INTO city VALUES("2798","0","1","29","Rongat ","Rongat ","0","0","0","0");
INSERT INTO city VALUES("2799","0","1","29","Rutland Island ","Rutland Island ","0","0","0","0");
INSERT INTO city VALUES("2800","0","1","29","Sabari ","Sabari ","0","0","0","0");
INSERT INTO city VALUES("2801","0","1","29","Saddle Peak ","Saddle Peak ","0","0","0","0");
INSERT INTO city VALUES("2802","0","1","29","Shadipur ","Shadipur ","0","0","0","0");
INSERT INTO city VALUES("2803","0","1","29","Smith Island ","Smith Island ","0","0","0","0");
INSERT INTO city VALUES("2804","0","1","29","Sound Island ","Sound Island ","0","0","0","0");
INSERT INTO city VALUES("2805","0","1","29","South Sentinel Island ","South Sentinel Island ","0","0","0","0");
INSERT INTO city VALUES("2806","0","1","29","Spike Island ","Spike Island ","0","0","0","0");
INSERT INTO city VALUES("2807","0","1","29","Tarmugli Island ","Tarmugli Island ","0","0","0","0");
INSERT INTO city VALUES("2808","0","1","29","Taylerabad ","Taylerabad ","0","0","0","0");
INSERT INTO city VALUES("2809","0","1","29","Titaije ","Titaije ","0","0","0","0");
INSERT INTO city VALUES("2810","0","1","29","Toibalawe ","Toibalawe ","0","0","0","0");
INSERT INTO city VALUES("2811","0","1","29","Tusonabad ","Tusonabad ","0","0","0","0");
INSERT INTO city VALUES("2812","0","1","29","West Island ","West Island ","0","0","0","0");
INSERT INTO city VALUES("2813","0","1","29","Wimberleyganj ","Wimberleyganj ","0","0","0","0");
INSERT INTO city VALUES("2814","0","1","29","Yadita","Yadita","0","0","0","0");
INSERT INTO city VALUES("2815","0","1","30","Chandigarh ","Chandigarh ","0","0","0","0");
INSERT INTO city VALUES("2816","0","1","30","Mani Marja","Mani Marja","0","0","0","0");
INSERT INTO city VALUES("2817","0","1","31","Amal ","Amal ","0","0","0","0");
INSERT INTO city VALUES("2818","0","1","31","Amli ","Amli ","0","0","0","0");
INSERT INTO city VALUES("2819","0","1","31","Bedpa ","Bedpa ","0","0","0","0");
INSERT INTO city VALUES("2820","0","1","31","Chikhli ","Chikhli ","0","0","0","0");
INSERT INTO city VALUES("2821","0","1","31","Dadra & Nagar Haveli ","Dadra & Nagar Haveli ","0","0","0","0");
INSERT INTO city VALUES("2822","0","1","31","Dahikhed ","Dahikhed ","0","0","0","0");
INSERT INTO city VALUES("2823","0","1","31","Dolara ","Dolara ","0","0","0","0");
INSERT INTO city VALUES("2824","0","1","31","Galonda ","Galonda ","0","0","0","0");
INSERT INTO city VALUES("2825","0","1","31","Kanadi ","Kanadi ","0","0","0","0");
INSERT INTO city VALUES("2826","0","1","31","Karchond ","Karchond ","0","0","0","0");
INSERT INTO city VALUES("2827","0","1","31","Khadoli ","Khadoli ","0","0","0","0");
INSERT INTO city VALUES("2828","0","1","31","Kharadpada ","Kharadpada ","0","0","0","0");
INSERT INTO city VALUES("2829","0","1","31","Kherabari ","Kherabari ","0","0","0","0");
INSERT INTO city VALUES("2830","0","1","31","Kherdi ","Kherdi ","0","0","0","0");
INSERT INTO city VALUES("2831","0","1","31","Kothar ","Kothar ","0","0","0","0");
INSERT INTO city VALUES("2832","0","1","31","Luari ","Luari ","0","0","0","0");
INSERT INTO city VALUES("2833","0","1","31","Mashat ","Mashat ","0","0","0","0");
INSERT INTO city VALUES("2834","0","1","31","Rakholi ","Rakholi ","0","0","0","0");
INSERT INTO city VALUES("2835","0","1","31","Rudana ","Rudana ","0","0","0","0");
INSERT INTO city VALUES("2836","0","1","31","Saili ","Saili ","0","0","0","0");
INSERT INTO city VALUES("2837","0","1","31","Sili ","Sili ","0","0","0","0");
INSERT INTO city VALUES("2838","0","1","31","Silvassa ","Silvassa ","0","0","0","0");
INSERT INTO city VALUES("2839","0","1","31","Sindavni ","Sindavni ","0","0","0","0");
INSERT INTO city VALUES("2840","0","1","31","Udva ","Udva ","0","0","0","0");
INSERT INTO city VALUES("2841","0","1","31","Umbarkoi ","Umbarkoi ","0","0","0","0");
INSERT INTO city VALUES("2842","0","1","31","Vansda ","Vansda ","0","0","0","0");
INSERT INTO city VALUES("2843","0","1","31","Vasona ","Vasona ","0","0","0","0");
INSERT INTO city VALUES("2844","0","1","31","Velugam","Velugam","0","0","0","0");
INSERT INTO city VALUES("2845","0","1","32","Brancavare ","Brancavare ","0","0","0","0");
INSERT INTO city VALUES("2846","0","1","32","Dagasi ","Dagasi ","0","0","0","0");
INSERT INTO city VALUES("2847","0","1","32","Daman ","Daman ","0","0","0","0");
INSERT INTO city VALUES("2848","0","1","32","Diu ","Diu ","0","0","0","0");
INSERT INTO city VALUES("2849","0","1","32","Magarvara ","Magarvara ","0","0","0","0");
INSERT INTO city VALUES("2850","0","1","32","Nagwa ","Nagwa ","0","0","0","0");
INSERT INTO city VALUES("2851","0","1","32","Pariali ","Pariali ","0","0","0","0");
INSERT INTO city VALUES("2852","0","1","32","Passo Covo","Passo Covo","0","0","0","0");
INSERT INTO city VALUES("2853","0","1","33","Central Delhi ","Central Delhi ","0","0","0","0");
INSERT INTO city VALUES("2854","0","1","33","East Delhi ","East Delhi ","0","0","0","0");
INSERT INTO city VALUES("2855","0","1","33","New Delhi ","New Delhi ","0","0","0","0");
INSERT INTO city VALUES("2856","0","1","33","North Delhi ","North Delhi ","0","0","0","0");
INSERT INTO city VALUES("2857","0","1","33","North East Delhi ","North East Delhi ","0","0","0","0");
INSERT INTO city VALUES("2858","0","1","33","North West Delhi ","North West Delhi ","0","0","0","0");
INSERT INTO city VALUES("2859","0","1","33","South Delhi ","South Delhi ","0","0","0","0");
INSERT INTO city VALUES("2860","0","1","33","South West Delhi ","South West Delhi ","0","0","0","0");
INSERT INTO city VALUES("2861","0","1","33","West Delhi","West Delhi","0","0","0","0");
INSERT INTO city VALUES("2862","0","1","34","Agatti Island ","Agatti Island ","0","0","0","0");
INSERT INTO city VALUES("2863","0","1","34","Bingaram Island ","Bingaram Island ","0","0","0","0");
INSERT INTO city VALUES("2864","0","1","34","Bitra Island ","Bitra Island ","0","0","0","0");
INSERT INTO city VALUES("2865","0","1","34","Chetlat Island ","Chetlat Island ","0","0","0","0");
INSERT INTO city VALUES("2866","0","1","34","Kadmat Island ","Kadmat Island ","0","0","0","0");
INSERT INTO city VALUES("2867","0","1","34","Kalpeni Island ","Kalpeni Island ","0","0","0","0");
INSERT INTO city VALUES("2868","0","1","34","Kavaratti Island ","Kavaratti Island ","0","0","0","0");
INSERT INTO city VALUES("2869","0","1","34","Kiltan Island ","Kiltan Island ","0","0","0","0");
INSERT INTO city VALUES("2870","0","1","34","Lakshadweep Sea ","Lakshadweep Sea ","0","0","0","0");
INSERT INTO city VALUES("2871","0","1","34","Minicoy Island ","Minicoy Island ","0","0","0","0");
INSERT INTO city VALUES("2872","0","1","34","North Island ","North Island ","0","0","0","0");
INSERT INTO city VALUES("2873","0","1","34","South Island","South Island","0","0","0","0");
INSERT INTO city VALUES("2874","0","1","35","Bahur ","Bahur ","0","0","0","0");
INSERT INTO city VALUES("2875","0","1","35","Karaikal ","Karaikal ","0","0","0","0");
INSERT INTO city VALUES("2876","0","1","35","Mahe ","Mahe ","0","0","0","0");
INSERT INTO city VALUES("2877","0","1","35","Pondicherry ","Pondicherry ","0","0","0","0");
INSERT INTO city VALUES("2878","0","1","35","Purnankuppam ","Purnankuppam ","0","0","0","0");
INSERT INTO city VALUES("2879","0","1","35","Valudavur ","Valudavur ","0","0","0","0");
INSERT INTO city VALUES("2880","0","1","35","Villianur ","Villianur ","0","0","0","0");
INSERT INTO city VALUES("2881","0","1","35","Yanam","Yanam","0","0","0","0");





CREATE TABLE `class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `slug` varchar(100) DEFAULT NULL,
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO class VALUES("1","Gujarat","","0","1","1","0","","","2017-09-25 14:34:59","");





CREATE TABLE `company_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO company_type VALUES("1","Pvt.Ltd","0","1","1","0","","","0000-00-00 00:00:00","");
INSERT INTO company_type VALUES("2","Government","0","1","1","0","","","0000-00-00 00:00:00","");
INSERT INTO company_type VALUES("3","Properitiery","0","1","1","0","","","0000-00-00 00:00:00","");





CREATE TABLE `country` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `code` varchar(3) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=243 DEFAULT CHARSET=latin1;

INSERT INTO country VALUES("1","IN","India");
INSERT INTO country VALUES("2","CA","Canada");
INSERT INTO country VALUES("3","AF","Afghanistan");
INSERT INTO country VALUES("4","AL","Albania");
INSERT INTO country VALUES("5","DZ","Algeria");
INSERT INTO country VALUES("6","DS","American Samoa");
INSERT INTO country VALUES("7","AD","Andorra");
INSERT INTO country VALUES("8","AO","Angola");
INSERT INTO country VALUES("9","AI","Anguilla");
INSERT INTO country VALUES("10","AQ","Antarctica");
INSERT INTO country VALUES("11","AG","Antigua and Barbuda");
INSERT INTO country VALUES("12","AR","Argentina");
INSERT INTO country VALUES("13","AM","Armenia");
INSERT INTO country VALUES("14","AW","Aruba");
INSERT INTO country VALUES("15","AU","Australia");
INSERT INTO country VALUES("16","AT","Austria");
INSERT INTO country VALUES("17","AZ","Azerbaijan");
INSERT INTO country VALUES("18","BS","Bahamas");
INSERT INTO country VALUES("19","BH","Bahrain");
INSERT INTO country VALUES("20","BD","Bangladesh");
INSERT INTO country VALUES("21","BB","Barbados");
INSERT INTO country VALUES("22","BY","Belarus");
INSERT INTO country VALUES("23","BE","Belgium");
INSERT INTO country VALUES("24","BZ","Belize");
INSERT INTO country VALUES("25","BJ","Benin");
INSERT INTO country VALUES("26","BM","Bermuda");
INSERT INTO country VALUES("27","BT","Bhutan");
INSERT INTO country VALUES("28","BO","Bolivia");
INSERT INTO country VALUES("29","BA","Bosnia and Herzegovina");
INSERT INTO country VALUES("30","BW","Botswana");
INSERT INTO country VALUES("31","BV","Bouvet Island");
INSERT INTO country VALUES("32","BR","Brazil");
INSERT INTO country VALUES("33","IO","British lndian Ocean Territory");
INSERT INTO country VALUES("34","BN","Brunei Darussalam");
INSERT INTO country VALUES("35","BG","Bulgaria");
INSERT INTO country VALUES("36","BF","Burkina Faso");
INSERT INTO country VALUES("37","BI","Burundi");
INSERT INTO country VALUES("38","KH","Cambodia");
INSERT INTO country VALUES("39","CM","Cameroon");
INSERT INTO country VALUES("40","CV","Cape Verde");
INSERT INTO country VALUES("41","KY","Cayman Islands");
INSERT INTO country VALUES("42","CF","Central African Republic");
INSERT INTO country VALUES("43","TD","Chad");
INSERT INTO country VALUES("44","CL","Chile");
INSERT INTO country VALUES("45","CN","China");
INSERT INTO country VALUES("46","CX","Christmas Island");
INSERT INTO country VALUES("47","CC","Cocos Islands");
INSERT INTO country VALUES("48","CO","Colombia");
INSERT INTO country VALUES("49","KM","Comoros");
INSERT INTO country VALUES("50","CG","Congo");
INSERT INTO country VALUES("51","CK","Cook Islands");
INSERT INTO country VALUES("52","CR","Costa Rica");
INSERT INTO country VALUES("53","HR","Croatia (Hrvatska)");
INSERT INTO country VALUES("54","CU","Cuba");
INSERT INTO country VALUES("55","CY","Cyprus");
INSERT INTO country VALUES("56","CZ","Czech Republic");
INSERT INTO country VALUES("57","DK","Denmark");
INSERT INTO country VALUES("58","DJ","Djibouti");
INSERT INTO country VALUES("59","DM","Dominica");
INSERT INTO country VALUES("60","DO","Dominican Republic");
INSERT INTO country VALUES("61","TP","East Timor");
INSERT INTO country VALUES("62","EC","Ecuador");
INSERT INTO country VALUES("63","EG","Egypt");
INSERT INTO country VALUES("64","SV","El Salvador");
INSERT INTO country VALUES("65","GQ","Equatorial Guinea");
INSERT INTO country VALUES("66","ER","Eritrea");
INSERT INTO country VALUES("67","EE","Estonia");
INSERT INTO country VALUES("68","ET","Ethiopia");
INSERT INTO country VALUES("69","FK","Falkland Islands (Malvinas)");
INSERT INTO country VALUES("70","FO","Faroe Islands");
INSERT INTO country VALUES("71","FJ","Fiji");
INSERT INTO country VALUES("72","FI","Finland");
INSERT INTO country VALUES("73","FR","France");
INSERT INTO country VALUES("74","FX","France, Metropolitan");
INSERT INTO country VALUES("75","GF","French Guiana");
INSERT INTO country VALUES("76","PF","French Polynesia");
INSERT INTO country VALUES("77","TF","French Southern Territories");
INSERT INTO country VALUES("78","GA","Gabon");
INSERT INTO country VALUES("79","GM","Gambia");
INSERT INTO country VALUES("80","GE","Georgia");
INSERT INTO country VALUES("81","DE","Germany");
INSERT INTO country VALUES("82","GH","Ghana");
INSERT INTO country VALUES("83","GI","Gibraltar");
INSERT INTO country VALUES("84","GR","Greece");
INSERT INTO country VALUES("85","GL","Greenland");
INSERT INTO country VALUES("86","GD","Grenada");
INSERT INTO country VALUES("87","GP","Guadeloupe");
INSERT INTO country VALUES("88","GU","Guam");
INSERT INTO country VALUES("89","GT","Guatemala");
INSERT INTO country VALUES("90","GN","Guinea");
INSERT INTO country VALUES("91","GW","Guinea-Bissau");
INSERT INTO country VALUES("92","GY","Guyana");
INSERT INTO country VALUES("93","HT","Haiti");
INSERT INTO country VALUES("94","HM","Heard and Mc Donald Islands");
INSERT INTO country VALUES("95","HN","Honduras");
INSERT INTO country VALUES("96","HK","Hong Kong");
INSERT INTO country VALUES("97","HU","Hungary");
INSERT INTO country VALUES("98","IS","Iceland");
INSERT INTO country VALUES("100","ID","Indonesia");
INSERT INTO country VALUES("101","IR","Iran");
INSERT INTO country VALUES("102","IQ","Iraq");
INSERT INTO country VALUES("103","IE","Ireland");
INSERT INTO country VALUES("104","IL","Israel");
INSERT INTO country VALUES("105","IT","Italy");
INSERT INTO country VALUES("106","CI","Ivory Coast");
INSERT INTO country VALUES("107","JM","Jamaica");
INSERT INTO country VALUES("108","JP","Japan");
INSERT INTO country VALUES("109","JO","Jordan");
INSERT INTO country VALUES("110","KZ","Kazakhstan");
INSERT INTO country VALUES("111","KE","Kenya");
INSERT INTO country VALUES("112","KI","Kiribati");
INSERT INTO country VALUES("113","KP","Korea, Democratic People\'s Republic of");
INSERT INTO country VALUES("114","KR","Korea, Republic of");
INSERT INTO country VALUES("115","XK","Kosovo");
INSERT INTO country VALUES("116","KW","Kuwait");
INSERT INTO country VALUES("117","KG","Kyrgyzstan");
INSERT INTO country VALUES("118","LA","Lao People\'s Democratic Republic");
INSERT INTO country VALUES("119","LV","Latvia");
INSERT INTO country VALUES("120","LB","Lebanon");
INSERT INTO country VALUES("121","LS","Lesotho");
INSERT INTO country VALUES("122","LR","Liberia");
INSERT INTO country VALUES("123","LY","Libyan Arab Jamahiriya");
INSERT INTO country VALUES("124","LI","Liechtenstein");
INSERT INTO country VALUES("125","LT","Lithuania");
INSERT INTO country VALUES("126","LU","Luxembourg");
INSERT INTO country VALUES("127","MO","Macau");
INSERT INTO country VALUES("128","MK","Macedonia");
INSERT INTO country VALUES("129","MG","Madagascar");
INSERT INTO country VALUES("130","MW","Malawi");
INSERT INTO country VALUES("131","MY","Malaysia");
INSERT INTO country VALUES("132","MV","Maldives");
INSERT INTO country VALUES("133","ML","Mali");
INSERT INTO country VALUES("134","MT","Malta");
INSERT INTO country VALUES("135","MH","Marshall Islands");
INSERT INTO country VALUES("136","MQ","Martinique");
INSERT INTO country VALUES("137","MR","Mauritania");
INSERT INTO country VALUES("138","MU","Mauritius");
INSERT INTO country VALUES("139","TY","Mayotte");
INSERT INTO country VALUES("140","MX","Mexico");
INSERT INTO country VALUES("141","FM","Micronesia, Federated States of");
INSERT INTO country VALUES("142","MD","Moldova, Republic of");
INSERT INTO country VALUES("143","MC","Monaco");
INSERT INTO country VALUES("144","MN","Mongolia");
INSERT INTO country VALUES("145","ME","Montenegro");
INSERT INTO country VALUES("146","MS","Montserrat");
INSERT INTO country VALUES("147","MA","Morocco");
INSERT INTO country VALUES("148","MZ","Mozambique");
INSERT INTO country VALUES("149","MM","Myanmar");
INSERT INTO country VALUES("150","NA","Namibia");
INSERT INTO country VALUES("151","NR","Nauru");
INSERT INTO country VALUES("152","NP","Nepal");
INSERT INTO country VALUES("153","NL","Netherlands");
INSERT INTO country VALUES("154","AN","Netherlands Antilles");
INSERT INTO country VALUES("155","NC","New Caledonia");
INSERT INTO country VALUES("156","NZ","New Zealand");
INSERT INTO country VALUES("157","NI","Nicaragua");
INSERT INTO country VALUES("158","NE","Niger");
INSERT INTO country VALUES("159","NG","Nigeria");
INSERT INTO country VALUES("160","NU","Niue");
INSERT INTO country VALUES("161","NF","Norfork Island");
INSERT INTO country VALUES("162","MP","Northern Mariana Islands");
INSERT INTO country VALUES("163","NO","Norway");
INSERT INTO country VALUES("164","OM","Oman");
INSERT INTO country VALUES("165","PK","Pakistan");
INSERT INTO country VALUES("166","PW","Palau");
INSERT INTO country VALUES("167","PA","Panama");
INSERT INTO country VALUES("168","PG","Papua New Guinea");
INSERT INTO country VALUES("169","PY","Paraguay");
INSERT INTO country VALUES("170","PE","Peru");
INSERT INTO country VALUES("171","PH","Philippines");
INSERT INTO country VALUES("172","PN","Pitcairn");
INSERT INTO country VALUES("173","PL","Poland");
INSERT INTO country VALUES("174","PT","Portugal");
INSERT INTO country VALUES("175","PR","Puerto Rico");
INSERT INTO country VALUES("176","QA","Qatar");
INSERT INTO country VALUES("177","RE","Reunion");
INSERT INTO country VALUES("178","RO","Romania");
INSERT INTO country VALUES("179","RU","Russian Federation");
INSERT INTO country VALUES("180","RW","Rwanda");
INSERT INTO country VALUES("181","KN","Saint Kitts and Nevis");
INSERT INTO country VALUES("182","LC","Saint Lucia");
INSERT INTO country VALUES("183","VC","Saint Vincent and the Grenadines");
INSERT INTO country VALUES("184","WS","Samoa");
INSERT INTO country VALUES("185","SM","San Marino");
INSERT INTO country VALUES("186","ST","Sao Tome and Principe");
INSERT INTO country VALUES("187","SA","Saudi Arabia");
INSERT INTO country VALUES("188","SN","Senegal");
INSERT INTO country VALUES("189","RS","Serbia");
INSERT INTO country VALUES("190","SC","Seychelles");
INSERT INTO country VALUES("191","SL","Sierra Leone");
INSERT INTO country VALUES("192","SG","Singapore");
INSERT INTO country VALUES("193","SK","Slovakia");
INSERT INTO country VALUES("194","SI","Slovenia");
INSERT INTO country VALUES("195","SB","Solomon Islands");
INSERT INTO country VALUES("196","SO","Somalia");
INSERT INTO country VALUES("197","ZA","South Africa");
INSERT INTO country VALUES("198","GS","South Georgia South Sandwich Islands");
INSERT INTO country VALUES("199","ES","Spain");
INSERT INTO country VALUES("200","LK","Sri Lanka");
INSERT INTO country VALUES("201","SH","St. Helena");
INSERT INTO country VALUES("202","PM","St. Pierre and Miquelon");
INSERT INTO country VALUES("203","SD","Sudan");
INSERT INTO country VALUES("204","SR","Suriname");
INSERT INTO country VALUES("205","SJ","Svalbarn and Jan Mayen Islands");
INSERT INTO country VALUES("206","SZ","Swaziland");
INSERT INTO country VALUES("207","SE","Sweden");
INSERT INTO country VALUES("208","CH","Switzerland");
INSERT INTO country VALUES("209","SY","Syrian Arab Republic");
INSERT INTO country VALUES("210","TW","Taiwan");
INSERT INTO country VALUES("211","TJ","Tajikistan");
INSERT INTO country VALUES("212","TZ","Tanzania, United Republic of");
INSERT INTO country VALUES("213","TH","Thailand");
INSERT INTO country VALUES("214","TG","Togo");
INSERT INTO country VALUES("215","TK","Tokelau");
INSERT INTO country VALUES("216","TO","Tonga");
INSERT INTO country VALUES("217","TT","Trinidad and Tobago");
INSERT INTO country VALUES("218","TN","Tunisia");
INSERT INTO country VALUES("219","TR","Turkey");
INSERT INTO country VALUES("220","TM","Turkmenistan");
INSERT INTO country VALUES("221","TC","Turks and Caicos Islands");
INSERT INTO country VALUES("222","TV","Tuvalu");
INSERT INTO country VALUES("223","UG","Uganda");
INSERT INTO country VALUES("224","UA","Ukraine");
INSERT INTO country VALUES("225","AE","United Arab Emirates");
INSERT INTO country VALUES("226","GB","United Kingdom");
INSERT INTO country VALUES("227","UM","United States");
INSERT INTO country VALUES("228","UY","Uruguay");
INSERT INTO country VALUES("229","UZ","Uzbekistan");
INSERT INTO country VALUES("230","VU","Vanuatu");
INSERT INTO country VALUES("231","VA","Vatican City State");
INSERT INTO country VALUES("232","VE","Venezuela");
INSERT INTO country VALUES("233","VN","Vietnam");
INSERT INTO country VALUES("234","VG","Virgin Islands (British)");
INSERT INTO country VALUES("235","VI","Virgin Islands (U.S.)");
INSERT INTO country VALUES("236","WF","Wallis and Futuna Islands");
INSERT INTO country VALUES("237","EH","Western Sahara");
INSERT INTO country VALUES("238","YE","Yemen");
INSERT INTO country VALUES("239","YU","Yugoslavia");
INSERT INTO country VALUES("240","ZR","Zaire");
INSERT INTO country VALUES("241","ZM","Zambia");
INSERT INTO country VALUES("242","ZW","Zimbabwe");





CREATE TABLE `customer` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `email` varchar(200) CHARACTER SET latin1 NOT NULL,
  `company_name` varchar(150) NOT NULL,
  `password` varchar(100) CHARACTER SET latin1 NOT NULL,
  `name` varchar(100) CHARACTER SET latin1 NOT NULL,
  `person_name` varchar(150) NOT NULL,
  `phone` varchar(25) CHARACTER SET latin1 NOT NULL,
  `address1` varchar(250) CHARACTER SET latin1 NOT NULL,
  `locality` varchar(250) CHARACTER SET latin1 NOT NULL,
  `zip` varchar(20) CHARACTER SET latin1 NOT NULL,
  `country` varchar(5) NOT NULL,
  `state` varchar(20) CHARACTER SET latin1 NOT NULL,
  `city` varchar(50) CHARACTER SET latin1 NOT NULL,
  `image_path` varchar(200) CHARACTER SET latin1 NOT NULL,
  `regDate` datetime NOT NULL,
  `reg_ip` varchar(250) CHARACTER SET latin1 NOT NULL,
  `otp` varchar(250) NOT NULL,
  `last_login` datetime NOT NULL,
  `isDelete` tinyint(1) NOT NULL,
  `isActive` int(11) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text NOT NULL,
  `modified_by_type` text NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` text NOT NULL,
  `isCompanyUser` int(11) NOT NULL DEFAULT '0',
  `price_list` int(11) NOT NULL,
  `facebook_id` varchar(250) CHARACTER SET latin1 NOT NULL,
  `google_id` varchar(250) CHARACTER SET latin1 NOT NULL,
  `fpu_code` varchar(250) CHARACTER SET latin1 NOT NULL,
  `gcmid` text NOT NULL,
  `imei` text NOT NULL,
  `isAff` int(1) NOT NULL COMMENT '1=Affliate',
  PRIMARY KEY (`id`),
  KEY `username` (`email`),
  KEY `isActive` (`isDelete`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO customer VALUES("1","tejas@gmail.com","","21232f297a57a5a743894a0e4a801fc3","Tejas","","8000280311","301/401, Royal Uniform, Opp. Satya Sai Hospital, Kalawad Road.","Rajkot","360005","India","Gujarat","Rajkot","","2017-12-28 12:39:38","","","0000-00-00 00:00:00","0","1","5895","712","5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895","458,458,458,458,458,458,458,458,458,458,458,458,458,458,458,458,458,458,458,458,458,458,458,458,458,458,458,458,458,458,458","2017-12-28 12:39:38","2017-12-28 12:39:48,2017-12-28 12:40:49,2017-12-28 12:50:24,2017-12-28 14:34:26,2017-12-28 14:35:32,2017-12-28 14:35:32,2017-12-28 14:50:45,2017-12-28 14:54:51,2017-12-28 17:54:30,2017-12-28 19:29:32,2017-12-28 20:07:33,2017-12-29 10:12:25,2017-12-29 10:17:42,2017-12-29 10:19:54,2017-12-29 10:27:30,2017-12-29 14:16:01,2017-12-30 14:42:11,2017-12-30 14:42:52,2018-01-01 14:14:11,2018-01-01 14:24:47,2018-01-01 14:25:59,2018-01-01 16:27:42,2018-01-01 16:39:03,2018-01-01 17:20:00,2018-01-05 10:50:45,2018-01-05 18:22:20,2018-01-05 19:36:44,2018-01-06 17:22:18,2018-01-09 10:45:29,2018-01-09 15:40:11,2018-01-13 15:16:29","0","0","","","","c_EvJoIVZC0:APA91bEdnjgJ_WgHBNcKy3M81pskS8QPzgPgX0FP-WH5uYKGx1al9-xRvK6mVtuRCRSdvDCe9xu7RwMDnQZw3BodW7Osd5fUitUeKdBYhY5ux7yBTkAiMW95bPmtKQWkuV1RnzJI5lcf","","0");
INSERT INTO customer VALUES("2","vivek@gmail.com","","21232f297a57a5a743894a0e4a801fc3","vivek","","8866189644","Rajkot","Rajkot","360005","India","Gujarat","Rajkot","","2018-01-13 15:17:56","","","0000-00-00 00:00:00","0","1","5895","712","5895,5895,5895,1,5895","458,458,458,0,458","2018-01-13 15:17:56","2018-01-13 15:18:10,2018-01-13 15:18:16,2018-01-13 15:18:34,2018-01-13 15:20:06,2018-01-13 15:25:43","0","0","","","","c_EvJoIVZC0:APA91bEdnjgJ_WgHBNcKy3M81pskS8QPzgPgX0FP-WH5uYKGx1al9-xRvK6mVtuRCRSdvDCe9xu7RwMDnQZw3BodW7Osd5fUitUeKdBYhY5ux7yBTkAiMW95bPmtKQWkuV1RnzJI5lcf","","0");
INSERT INTO customer VALUES("3","jay@gmail.com","Prashant","21232f297a57a5a743894a0e4a801fc3","jay","","9824518363","Rajkot","Rajkot","360005","India","Gujarat","Rajkot","","2018-01-13 15:27:23","","","0000-00-00 00:00:00","0","1","5895","712","5895,5895,5895","458,458,458","2018-01-13 15:27:23","2018-01-13 15:27:33,2018-01-13 15:49:42,2018-01-16 15:53:38","0","0","","","","cmqiuD4Egts:APA91bG0fUuOHjYzZfuNbsW4lGKuxngHGZeqZZA1igVUcqMT6V2SvjHEqf1G1sRcJu3SPvzEcLQkm7RpL_ZnWm7sceJipfmuDIN1Cq4PZG9K0wskWjYxJ_9JwT58APlmR_Cz2fz0izBW","","0");
INSERT INTO customer VALUES("4","h@gmail.com","h","e10adc3949ba59abbe56e057f20f883e","hardip","","9979055113","fg","tt","566668","India","chv","ydy","","2018-01-18 15:30:44","","","0000-00-00 00:00:00","0","1","5895","712","5895,5895","458,458","2018-01-18 15:30:44","2018-01-18 15:30:56,2018-02-07 12:42:07","0","0","","","","dWVxE7SVIFQ:APA91bEhSoFK3-n_WCuyCl9p-D6ijs9PS1XXBkK49HX-B8npq5TqOs-NhN-oEz7aIzZH_Lq5lPCYEWs8GTI3YuSZinvFfU0mLy_f7HhoKVlIbnsVKFE8QttU0Y3zmV36dEYrm_8jmQVc","","0");





CREATE TABLE `customer_order_request_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `request_no` varchar(150) NOT NULL,
  `customer_id` int(11) NOT NULL DEFAULT '0',
  `customer_name` varchar(150) NOT NULL,
  `company_name` varchar(150) NOT NULL,
  `type_of_customer` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `address` text NOT NULL,
  `country` varchar(150) NOT NULL,
  `state` varchar(150) NOT NULL,
  `city` varchar(150) NOT NULL,
  `phone` varchar(150) NOT NULL,
  `total_qty` double NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `created_date` datetime NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `modified_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO customer_order_request_info VALUES("1","RE1","3","jay","Prashant","normal_user","jay@gmail.com","Rajkot","India","Gujarat","Rajkot","9824518363","550","2","0","1","2018-01-16 15:54:08","5895","712","0","0","0000-00-00 00:00:00");
INSERT INTO customer_order_request_info VALUES("2","RE2","3","jay","Prashant","normal_user","jay@gmail.com","Rajkot","India","Gujarat","Rajkot","9824518363","150","0","0","1","2018-01-16 16:29:59","5895","712","0","0","0000-00-00 00:00:00");
INSERT INTO customer_order_request_info VALUES("3","RE3","4","hardip","h","normal_user","h@gmail.com","fg","India","chv","ydy","9979055113","250","2","0","1","2018-02-07 12:44:25","5895","712","0","0","0000-00-00 00:00:00");
INSERT INTO customer_order_request_info VALUES("4","RE4","4","hardip","h","normal_user","h@gmail.com","fg","India","chv","ydy","9979055113","400","0","0","1","2018-02-07 13:10:33","5895","712","0","0","0000-00-00 00:00:00");





CREATE TABLE `customer_order_request_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `request_id` int(11) NOT NULL DEFAULT '0',
  `item_id` int(11) NOT NULL DEFAULT '0',
  `weight_id` int(11) NOT NULL DEFAULT '0',
  `item_name` varchar(150) NOT NULL,
  `request_qty` double NOT NULL DEFAULT '0',
  `pending_qty` double NOT NULL DEFAULT '0',
  `inner_size` double NOT NULL,
  `box_qty` double NOT NULL,
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `created_date` datetime NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `modified_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO customer_order_request_item VALUES("1","1","1","1","Elbow (1/2\")","250","0","50","5","0","1","2018-01-16 15:54:08","5895","712","0","0","0000-00-00 00:00:00");
INSERT INTO customer_order_request_item VALUES("2","1","1","2","Elbow (3/4\")","300","0","50","6","0","1","2018-01-16 15:54:08","5895","712","0","0","0000-00-00 00:00:00");
INSERT INTO customer_order_request_item VALUES("3","2","1","1","Elbow (1/2\")","150","150","50","3","0","1","2018-01-16 16:29:59","5895","712","0","0","0000-00-00 00:00:00");
INSERT INTO customer_order_request_item VALUES("4","3","1","1","Elbow (1/2\")","250","0","50","5","0","1","2018-02-07 12:44:25","5895","712","0","0","0000-00-00 00:00:00");
INSERT INTO customer_order_request_item VALUES("5","4","1","1","Elbow (1/2\")","400","400","50","8","0","1","2018-02-07 13:10:33","5895","712","0","0","0000-00-00 00:00:00");





CREATE TABLE `customer_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL DEFAULT '0',
  `dispatch_id` int(11) NOT NULL DEFAULT '0',
  `receipt_no` varchar(50) DEFAULT NULL,
  `order_id` int(11) NOT NULL DEFAULT '0',
  `paid_amount` double NOT NULL DEFAULT '0',
  `amount_remaining_that_time` double NOT NULL DEFAULT '0',
  `amount_paid_that_time` double DEFAULT '0',
  `payment_type` varchar(50) DEFAULT NULL,
  `remark` varchar(250) DEFAULT NULL,
  `payment_status` int(11) NOT NULL DEFAULT '0',
  `payment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO customer_payment VALUES("1","1","4","K/RNo/001","9","3000","44515","3000","cheque","","0","2018-01-04 00:00:00","0","1","1","0","1","0","2018-01-05 18:18:52","2018-01-05 18:18:52");
INSERT INTO customer_payment VALUES("2","3","1","K/RNo/002","1","10","7141","10","case","fgdfg","0","2018-01-11 00:00:00","0","1","1","0","1","0","2018-01-16 17:08:55","2018-01-16 17:08:55");





CREATE TABLE `dbbackup` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `createDate` datetime NOT NULL,
  `fileUrl` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_by_type` int(11) NOT NULL,
  `modified_by` text NOT NULL,
  `modified_by_type` text NOT NULL,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO dbbackup VALUES("1","2018-01-29 17:15:41","1517226341.zip","1","0","","","2018-01-29 17:15:41","");
INSERT INTO dbbackup VALUES("2","2018-06-01 15:29:10","1527847149.zip","1","0","","","2018-06-01 15:29:10","");





CREATE TABLE `dealer_distributor_network` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT '0' COMMENT '0=Super Admin,1=Major Admin',
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `forgot_pass_string` text,
  `last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_ip` varchar(250) DEFAULT NULL,
  `isDelete` int(11) DEFAULT '0',
  `adate` datetime NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO dealer_distributor_network VALUES("1","ravi patel","7383220934","0","admin","21232f297a57a5a743894a0e4a801fc3","sejal.craftbox@gmail.com","132cf17c8ba6116927","2018-12-15 15:53:53","24.24.25.107","0","0000-00-00 00:00:00","1","0","2,1,1,1,1,3,1,1,4,3,5,4,6,4,4,6,1,1,1,1,7,7,1,1,8,8,8,1,1,8,1,1,1,1,9,10,11,1,1,12,13,1,1,5,14,14,14,14,1,1,14,5,1,1,14,3,5,3,5,14,5,14,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,7,7,7,1,1,11,11,7,1,1,7,1,1,7,11,1,1,13,11,1,1,13,8,13,1,1,13,1,1,13,1,1,2,1,1,1,1,5,14,4,7,7,1,1,1,1,1,1,1,1,1,1,7,1,1,13,12,11,10,9,8,1,1,13,8,10,1,1,1,1,4,1,1,1,1,5,1,1,1,1,1,1,1,1,7,1,1,4,1,1,7,12,1,1,1,1,1,1,1,1,1,1,1,1,1,1,7,1,1,5,7,13,1,1,1,1,12,7,11,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,4,6,16,4,15,5,3,15,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,3,4,4,16,1,1,16,7,1,1,8,9,10,11,12,13,14,1,1,1,1,8,1,1,1,1,4,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,8,11,11,1,1,11,1,1,8,1,1,1,1,11,8,13,7,16,1,1,1,1,8,1,1,8,1,1,1,1,1,1,8,6,7,8,1,1,9,1,1,6,8,9,6,8,8,11,1,1,9,4,7,8,11,9,13,10,8,6,7,13,9,8,11,13,8,10,13,8,11,1,1,11,6,7,7,11,9,1,1,1,1,1,1,1,1,6,1,1,1,1,1,1,4,6,7,8,11,9,11,13,8,11,10,9,9,1,1,1,1,1,1,8,13,9,12,1,1,6,6,1,1,8,1,1,11,1,1,1,1,1,1,8,4,7,1,1,14,14,5,14,1,1,1,1,17,8,17,18,8,17,18,4,6,7,8,17,18,1,1,8,18,17,6,8,7,8,11,8,1,1,1,1,6,8,4,6,7,8,6,17,18,8,1,1,17,18,8,17,8,17,8,17,18,8,1,1,1,1,1,1,1,1,17,1,1,1,1,1,1,1,1,1,1,4,2,5,14,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,2,2,2,3,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,5895,5895,1,5895,5895,5895,5895,1,1,1,5895,5895,5895,1,1,5895,5895,5895,5895,5895,5895,5895,5895,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,5895,5895,1,1,5895,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1","2,0,0,0,0,19,0,0,20,19,21,25,31,25,25,31,0,0,0,0,9,9,0,0,34,34,34,0,0,34,0,0,0,0,35,36,37,0,0,38,39,0,0,22,6,28,28,28,0,0,28,22,0,0,28,19,22,19,22,28,22,28,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,9,9,0,0,37,37,9,0,0,9,0,0,9,37,0,0,39,37,0,0,39,34,39,0,0,39,0,0,39,0,0,2,0,0,0,0,22,28,25,9,9,0,0,0,0,0,0,0,0,0,0,9,0,0,39,38,37,36,35,34,0,0,39,34,36,0,0,0,0,25,0,0,0,0,22,0,0,0,0,0,0,0,0,9,0,0,25,0,0,9,38,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,0,0,22,9,39,0,0,0,0,38,9,37,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,25,31,31,25,27,22,19,27,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,19,25,25,31,0,0,31,9,0,0,34,35,36,37,38,39,28,0,0,0,0,34,0,0,0,0,25,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,34,37,37,0,0,37,0,0,34,0,0,0,0,37,34,39,9,31,0,0,0,0,34,0,0,34,0,0,0,0,0,0,34,31,9,34,0,0,35,0,0,31,34,35,31,34,34,37,0,0,35,25,9,34,37,35,39,36,34,31,9,39,35,34,37,39,34,36,39,34,37,0,0,37,31,9,9,37,35,0,0,0,0,0,0,0,0,31,0,0,0,0,0,0,25,31,9,34,37,35,37,39,34,37,36,35,35,0,0,0,0,0,0,34,39,35,38,0,0,31,31,0,0,34,0,0,37,0,0,0,0,0,0,34,25,9,0,0,28,28,22,28,0,0,0,0,12,34,12,15,34,12,15,25,31,9,34,12,15,0,0,34,15,12,31,34,9,34,37,34,0,0,0,0,31,34,25,31,9,34,31,12,15,34,0,0,12,15,34,12,34,12,34,12,15,34,0,0,0,0,0,0,0,0,12,0,0,0,0,0,0,0,0,0,0,25,2,22,28,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,458,458,0,458,458,458,458,0,0,0,458,458,458,0,0,458,458,458,458,458,458,458,458,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,458,458,0,0,458,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0","0000-00-00 00:00:00","2017-02-15 15:45:33,2017-02-15 15:45:37,2017-02-15 15:45:37,2017-02-15 15:53:52,2017-02-15 15:53:52,2017-02-15 15:59:44,2017-02-15 16:04:53,2017-02-15 16:04:53,2017-02-15 16:05:38,2017-02-15 16:08:01,2017-02-15 16:10:54,2017-02-15 17:05:05,2017-02-15 17:07:27,2017-02-15 17:12:16,2017-02-15 17:19:53,2017-02-15 17:20:05,2017-02-15 17:23:48,2017-02-15 17:23:48,2017-02-15 17:46:11,2017-02-15 17:46:11,2017-02-15 17:56:19,2017-02-15 18:03:25,2017-02-15 18:27:27,2017-02-15 18:27:27,2017-02-15 18:29:56,2017-02-15 18:33:13,2017-02-15 18:47:47,2017-02-15 18:57:52,2017-02-15 18:57:52,2017-02-15 19:03:13,2017-02-15 19:08:13,2017-02-15 19:08:13,2017-02-15 19:20:29,2017-02-15 19:20:29,2017-02-15 19:23:23,2017-02-15 19:31:04,2017-02-15 19:33:22,2017-02-15 19:34:17,2017-02-15 19:34:17,2017-02-15 19:37:49,2017-02-15 19:45:54,2017-02-15 19:50:16,2017-02-15 19:50:16,2017-02-15 19:50:38,2017-02-15 19:53:55,2017-02-15 19:56:30,2017-02-15 20:04:23,2017-02-15 20:07:06,2017-02-15 21:47:22,2017-02-15 21:47:22,2017-02-15 21:47:54,2017-02-15 21:52:44,2017-02-15 22:00:17,2017-02-15 22:00:17,2017-02-15 22:00:52,2017-02-15 22:06:50,2017-02-15 22:12:02,2017-02-15 22:14:54,2017-02-15 22:24:14,2017-02-15 22:28:06,2017-02-15 22:29:20,2017-02-15 22:41:53,2017-02-16 09:41:15,2017-02-16 09:41:15,2017-02-16 09:47:33,2017-02-16 09:47:33,2017-02-16 09:47:35,2017-02-16 09:47:35,2017-02-16 09:48:08,2017-02-16 09:48:08,2017-02-16 09:50:21,2017-02-16 09:50:21,2017-02-16 09:51:52,2017-02-16 09:51:52,2017-02-16 10:13:53,2017-02-16 10:13:53,2017-02-16 10:20:23,2017-02-16 10:20:23,2017-02-16 10:36:59,2017-02-16 10:37:07,2017-02-16 10:43:04,2017-02-16 10:48:47,2017-02-16 10:48:47,2017-02-16 11:08:12,2017-02-16 11:11:07,2017-02-16 11:13:19,2017-02-16 11:18:58,2017-02-16 11:18:58,2017-02-16 11:49:34,2017-02-16 11:49:58,2017-02-16 11:49:58,2017-02-16 12:13:18,2017-02-16 12:14:48,2017-02-16 12:18:17,2017-02-16 12:18:17,2017-02-16 12:20:05,2017-02-16 12:22:25,2017-02-16 14:01:59,2017-02-16 14:01:59,2017-02-16 14:27:05,2017-02-16 14:28:28,2017-02-16 14:28:47,2017-02-16 14:31:29,2017-02-16 14:31:29,2017-02-16 14:59:08,2017-02-16 15:09:52,2017-02-16 15:09:52,2017-02-16 15:14:14,2017-02-16 15:21:29,2017-02-16 15:21:29,2017-02-16 15:22:35,2017-02-16 16:16:42,2017-02-16 16:16:42,2017-02-16 16:22:50,2017-02-16 16:22:50,2017-02-16 16:23:58,2017-02-16 16:29:01,2017-02-16 16:30:09,2017-02-16 16:55:44,2017-02-16 17:12:49,2017-02-16 17:17:03,2017-02-16 17:17:03,2017-02-16 17:17:48,2017-02-16 17:17:48,2017-02-17 09:39:29,2017-02-17 09:39:29,2017-02-17 09:44:54,2017-02-17 09:44:54,2017-02-17 09:47:12,2017-02-17 09:47:12,2017-02-17 10:13:51,2017-02-17 10:21:02,2017-02-17 10:21:03,2017-02-17 10:22:39,2017-02-17 10:29:50,2017-02-17 10:37:31,2017-02-17 10:38:43,2017-02-17 10:41:14,2017-02-17 10:42:53,2017-02-17 10:50:51,2017-02-17 10:50:51,2017-02-17 11:04:26,2017-02-17 11:08:01,2017-02-17 11:08:37,2017-02-17 11:09:44,2017-02-17 11:09:44,2017-02-17 11:09:52,2017-02-17 11:09:52,2017-02-17 11:10:11,2017-02-17 11:25:28,2017-02-17 11:25:28,2017-02-17 12:09:13,2017-02-17 12:09:13,2017-02-17 14:18:10,2017-02-17 14:19:10,2017-02-17 14:19:10,2017-02-17 15:07:36,2017-02-17 15:07:36,2017-02-17 15:07:45,2017-02-17 15:07:45,2017-02-17 15:28:10,2017-02-17 15:28:10,2017-02-17 15:37:54,2017-02-17 15:38:01,2017-02-17 15:38:01,2017-02-17 15:44:19,2017-02-17 15:55:34,2017-02-17 15:55:34,2017-02-17 16:00:08,2017-02-17 16:05:37,2017-02-17 16:25:35,2017-02-17 16:25:35,2017-02-17 17:06:11,2017-02-17 17:06:11,2017-02-17 17:06:16,2017-02-17 17:06:16,2017-02-17 17:20:01,2017-02-17 17:20:01,2017-02-18 09:50:39,2017-02-18 09:50:39,2017-02-18 09:54:11,2017-02-18 09:54:11,2017-02-18 10:08:16,2017-02-18 10:08:16,2017-02-18 10:27:11,2017-02-18 10:27:13,2017-02-18 10:27:13,2017-02-18 10:33:12,2017-02-18 10:35:42,2017-02-18 10:37:56,2017-02-18 10:38:44,2017-02-18 10:38:44,2017-02-18 10:40:21,2017-02-18 10:40:21,2017-02-18 10:56:07,2017-02-18 11:00:24,2017-02-18 11:05:06,2017-02-18 15:41:57,2017-02-18 15:41:57,2017-02-18 18:18:14,2017-02-18 18:18:14,2017-02-20 12:10:15,2017-02-20 12:10:15,2017-02-21 10:18:36,2017-02-21 10:18:36,2017-02-21 10:22:05,2017-02-21 10:22:05,2017-02-21 10:23:35,2017-02-21 10:23:35,2017-02-21 10:27:33,2017-02-21 10:27:33,2017-02-21 13:28:40,2017-02-21 13:28:40,2017-02-21 15:48:32,2017-02-21 15:48:32,2017-02-21 15:55:33,2017-02-21 15:55:33,2017-02-21 16:19:25,2017-02-21 16:19:25,2017-02-21 16:36:39,2017-02-21 16:36:39,2017-02-21 18:17:47,2017-02-21 18:17:47,2017-02-23 11:10:42,2017-02-23 11:10:42,2017-02-23 11:57:21,2017-02-23 11:57:21,2017-02-23 14:51:52,2017-02-23 14:51:52,2017-02-24 09:57:44,2017-02-24 09:57:44,2017-02-24 11:58:14,2017-02-24 11:58:14,2017-02-24 14:24:32,2017-02-24 14:24:32,2017-02-24 14:25:15,2017-02-24 14:32:40,2017-02-24 14:35:14,2017-02-24 14:36:24,2017-02-24 14:37:57,2017-02-24 14:41:30,2017-02-24 14:42:30,2017-02-24 14:44:18,2017-02-24 18:59:05,2017-02-24 18:59:05,2017-02-25 12:39:19,2017-02-25 12:39:19,2017-02-25 12:39:29,2017-02-25 12:39:29,2017-02-27 09:44:49,2017-02-27 09:44:49,2017-02-27 09:48:14,2017-02-27 09:48:14,2017-02-27 10:31:12,2017-02-27 10:31:12,2017-02-27 10:43:00,2017-02-27 10:43:01,2017-02-27 11:28:59,2017-02-27 11:28:59,2017-02-27 14:58:36,2017-02-27 14:58:36,2017-02-27 14:59:33,2017-02-27 14:59:33,2017-02-27 15:01:13,2017-02-27 15:01:13,2017-02-28 09:47:10,2017-02-28 09:47:10,2017-02-28 16:23:55,2017-02-28 16:23:56,2017-02-28 17:07:10,2017-02-28 17:07:10,2017-03-01 09:46:41,2017-03-01 09:46:41,2017-03-01 09:58:18,2017-03-01 09:58:18,2017-03-01 10:07:53,2017-03-01 10:19:22,2017-03-01 10:21:07,2017-03-01 10:57:39,2017-03-01 11:13:16,2017-03-01 11:22:39,2017-03-01 11:22:39,2017-03-01 11:23:25,2017-03-01 11:33:05,2017-03-01 11:37:15,2017-03-01 11:37:15,2017-03-01 11:47:11,2017-03-01 11:51:30,2017-03-01 11:53:10,2017-03-01 11:56:04,2017-03-01 12:04:08,2017-03-01 12:10:05,2017-03-01 12:35:44,2017-03-01 12:44:38,2017-03-01 12:44:38,2017-03-01 12:57:19,2017-03-01 12:57:19,2017-03-01 13:01:09,2017-03-01 13:02:20,2017-03-01 13:02:20,2017-03-02 09:39:30,2017-03-02 09:39:30,2017-03-02 09:42:03,2017-03-02 11:10:57,2017-03-02 11:10:57,2017-03-02 18:35:12,2017-03-02 18:35:12,2017-03-03 18:12:05,2017-03-03 18:12:05,2017-03-03 18:16:41,2017-03-03 18:16:41,2017-03-04 09:43:13,2017-03-04 09:43:14,2017-03-04 10:21:40,2017-03-04 10:21:40,2017-03-06 10:00:22,2017-03-06 10:00:22,2017-03-07 14:29:13,2017-03-07 14:29:13,2017-03-07 15:25:15,2017-03-07 15:25:15,2017-03-07 18:08:27,2017-03-07 18:08:27,2017-03-07 18:12:29,2017-03-07 18:12:29,2017-03-08 09:52:59,2017-03-08 09:52:59,2017-03-08 11:38:15,2017-03-08 11:38:15,2017-03-08 17:08:34,2017-03-08 17:08:35,2017-03-09 09:42:18,2017-03-09 09:42:18,2017-03-09 12:43:52,2017-03-09 12:43:52,2017-03-10 09:42:48,2017-03-10 09:42:48,2017-03-10 10:53:12,2017-03-10 10:53:12,2017-03-11 09:42:49,2017-03-11 09:42:49,2017-03-11 11:32:48,2017-03-11 12:52:35,2017-03-11 13:19:06,2017-03-11 14:04:34,2017-03-11 14:04:34,2017-03-11 14:11:40,2017-03-11 14:20:08,2017-03-11 14:20:08,2017-03-11 14:23:10,2017-03-11 14:30:47,2017-03-11 14:30:47,2017-03-15 09:46:21,2017-03-15 09:46:21,2017-03-15 09:49:40,2017-03-15 12:35:11,2017-03-15 12:38:51,2017-03-15 18:30:05,2017-03-15 18:31:02,2017-03-15 18:32:33,2017-03-15 18:32:33,2017-03-15 18:50:12,2017-03-15 18:50:12,2017-03-15 18:50:59,2017-03-16 09:43:01,2017-03-16 09:43:02,2017-03-16 10:08:06,2017-03-17 09:42:42,2017-03-17 09:42:42,2017-03-17 10:03:39,2017-03-17 10:03:39,2017-03-17 11:28:08,2017-03-17 11:28:09,2017-03-17 11:28:21,2017-03-17 12:08:13,2017-03-17 12:10:44,2017-03-17 12:22:04,2017-03-17 12:22:23,2017-03-17 12:22:23,2017-03-17 12:55:00,2017-03-17 14:14:53,2017-03-17 14:14:53,2017-03-17 14:19:25,2017-03-17 14:38:44,2017-03-17 14:40:11,2017-03-17 17:02:08,2017-03-17 17:06:44,2017-03-17 17:13:09,2017-03-17 17:21:47,2017-03-17 17:22:02,2017-03-17 17:22:02,2017-03-17 17:23:22,2017-03-17 17:26:46,2017-03-17 17:43:12,2017-03-17 17:53:28,2017-03-17 18:07:59,2017-03-17 18:09:24,2017-03-17 18:11:19,2017-03-17 18:12:28,2017-03-17 18:17:28,2017-03-17 18:25:39,2017-03-17 18:26:58,2017-03-17 18:29:17,2017-03-17 18:30:05,2017-03-17 18:30:41,2017-03-17 18:31:14,2017-03-17 18:39:27,2017-03-17 18:39:49,2017-03-17 18:40:10,2017-03-17 18:44:50,2017-03-17 18:45:02,2017-03-17 18:45:08,2017-03-17 18:52:34,2017-03-17 18:52:34,2017-03-17 18:52:57,2017-03-17 18:57:23,2017-03-17 18:58:24,2017-03-17 19:07:44,2017-03-17 19:16:43,2017-03-17 19:17:28,2017-03-18 09:46:35,2017-03-18 09:46:35,2017-03-18 09:48:16,2017-03-18 09:48:16,2017-03-18 10:26:34,2017-03-18 10:26:34,2017-03-18 10:27:34,2017-03-18 10:27:34,2017-03-18 10:28:05,2017-03-18 10:28:26,2017-03-18 10:28:26,2017-03-18 11:08:25,2017-03-18 11:08:25,2017-03-18 12:21:33,2017-03-18 12:21:33,2017-03-18 12:29:57,2017-03-18 12:35:46,2017-03-18 12:36:55,2017-03-18 12:45:08,2017-03-18 12:45:54,2017-03-18 12:46:15,2017-03-18 12:47:39,2017-03-18 12:48:01,2017-03-18 12:50:28,2017-03-18 12:51:08,2017-03-18 12:51:36,2017-03-18 12:52:56,2017-03-18 12:56:16,2017-03-18 12:58:30,2017-03-18 12:58:30,2017-03-18 12:59:09,2017-03-18 12:59:09,2017-03-18 13:01:34,2017-03-18 13:01:34,2017-03-18 13:06:00,2017-03-18 13:15:37,2017-03-18 13:17:18,2017-03-18 13:18:45,2017-03-18 13:21:57,2017-03-18 13:21:57,2017-03-18 13:22:55,2017-03-18 14:21:30,2017-03-18 14:27:49,2017-03-18 14:27:49,2017-03-18 14:28:22,2017-03-18 14:29:52,2017-03-18 14:29:52,2017-03-18 14:40:06,2017-03-18 14:45:38,2017-03-18 14:45:38,2017-03-18 14:51:08,2017-03-18 14:51:08,2017-03-18 14:52:52,2017-03-18 14:52:52,2017-03-18 14:53:09,2017-03-18 15:50:53,2017-03-18 16:04:35,2017-03-18 16:34:20,2017-03-18 16:34:20,2017-03-18 16:34:46,2017-03-18 17:19:14,2017-03-18 17:19:55,2017-03-18 17:34:12,2017-03-20 09:47:00,2017-03-20 09:47:00,2017-03-20 09:47:59,2017-03-20 09:47:59,2017-03-20 10:12:53,2017-03-20 10:24:57,2017-03-20 10:29:18,2017-03-20 11:03:03,2017-03-20 11:09:10,2017-03-20 11:09:54,2017-03-20 11:16:30,2017-03-20 11:35:43,2017-03-20 11:36:19,2017-03-20 11:38:51,2017-03-20 11:39:15,2017-03-20 11:42:07,2017-03-20 11:42:10,2017-03-20 11:50:16,2017-03-20 11:50:16,2017-03-20 11:54:04,2017-03-20 11:57:34,2017-03-20 12:05:12,2017-03-20 17:04:48,2017-03-20 17:05:31,2017-03-20 17:08:47,2017-03-20 17:10:05,2017-03-20 17:10:56,2017-03-20 17:17:34,2017-03-21 09:44:26,2017-03-21 09:44:26,2017-03-21 09:44:54,2017-03-21 09:44:54,2017-03-21 09:54:38,2017-03-21 10:10:21,2017-03-21 11:34:21,2017-03-21 11:35:30,2017-03-21 11:37:22,2017-03-21 11:37:57,2017-03-21 11:38:32,2017-03-21 11:39:35,2017-03-21 11:41:21,2017-03-21 11:54:11,2017-03-21 11:55:08,2017-03-21 11:55:08,2017-03-21 11:56:03,2017-03-21 11:57:45,2017-03-21 12:06:12,2017-03-21 12:07:23,2017-03-21 12:18:28,2017-03-21 12:19:29,2017-03-21 12:23:57,2017-03-21 12:24:52,2017-03-21 12:25:57,2017-03-21 12:56:49,2017-03-21 14:16:11,2017-03-21 14:16:11,2017-03-21 15:41:22,2017-03-21 15:41:22,2017-03-21 15:47:09,2017-03-21 15:47:09,2017-03-21 15:58:23,2017-03-21 15:58:23,2017-03-21 17:06:27,2017-03-21 17:26:14,2017-03-21 17:26:14,2017-03-21 17:27:52,2017-03-21 17:27:52,2017-03-22 10:34:34,2017-03-22 10:34:34,2017-03-22 10:51:10,2017-03-22 10:51:10,2017-03-22 10:52:46,2017-03-22 10:52:46,2017-03-22 11:43:51,2017-03-22 12:03:05,2017-03-22 12:08:31,2017-03-22 12:18:22,2017-03-22 18:23:35,2017-03-22 18:23:35,2017-03-22 19:23:28,2017-03-22 19:23:28,2017-03-23 09:52:42,2017-03-23 09:52:42,2017-03-23 09:52:45,2017-03-23 09:52:45,2017-03-23 10:56:06,2017-03-23 10:56:06,2017-03-23 11:00:09,2017-03-23 11:00:09,2017-03-23 11:39:24,2017-03-23 11:39:24,2017-03-23 12:19:51,2017-03-23 12:19:51,2017-03-23 14:34:24,2017-03-23 14:34:24,2017-03-23 14:45:39,2017-03-23 14:45:39,2017-03-24 09:47:24,2017-03-24 09:47:24,2017-03-24 09:47:26,2017-03-24 09:47:26,2017-03-24 09:48:45,2017-03-24 09:48:45,2017-03-24 09:50:08,2017-03-24 09:50:08,2017-03-24 09:50:28,2017-03-24 09:50:28,2017-03-24 10:12:30,2017-03-24 10:12:30,2017-03-24 14:38:17,2017-03-24 14:38:17,2017-03-24 18:41:14,2017-03-24 18:41:14,2017-03-25 09:46:16,2017-03-25 09:46:16,2017-03-25 09:46:45,2017-03-25 09:46:45,2017-03-25 10:02:05,2017-03-25 10:02:05,2017-03-25 11:55:17,2017-03-25 11:55:17,2017-03-25 13:09:37,2017-03-25 13:09:37,2017-03-27 09:47:47,2017-03-27 09:47:47,2017-03-27 09:49:42,2017-03-27 09:49:42,2017-03-27 09:52:06,2017-03-27 09:52:06,2017-03-27 10:40:30,2017-03-27 10:40:30,2017-03-28 09:48:14,2017-03-28 09:48:14,2017-03-28 09:49:29,2017-03-28 09:49:29,2017-03-29 09:47:10,2017-03-29 09:47:10,2017-03-29 12:55:22,2017-03-29 12:55:23,2017-03-29 15:41:02,2017-03-29 15:41:03,2017-03-29 22:18:40,2017-03-29 22:18:40,2017-03-30 09:44:06,2017-03-30 09:44:06,2017-03-30 09:48:09,2017-03-30 09:48:09,2017-03-30 15:42:44,2017-03-30 15:42:45,2017-03-31 12:35:14,2017-03-31 12:35:14,2017-04-06 11:36:16,2017-04-06 11:36:16,2017-04-06 11:36:17,2017-04-06 11:36:17,2017-04-06 14:42:33,2017-04-06 14:42:33,2017-04-06 14:51:35,2017-04-06 14:51:35,2017-04-06 14:54:08,2017-04-06 14:54:08,2017-04-06 16:19:59,2017-04-06 16:19:59,2017-04-06 16:24:31,2017-04-06 16:24:31,2017-04-06 17:22:43,2017-04-06 17:22:43,2017-04-07 09:44:57,2017-04-07 09:44:57,2017-04-07 09:51:13,2017-04-07 09:51:13,2017-04-07 09:56:46,2017-04-07 09:56:46,2017-04-07 10:04:43,2017-04-07 10:04:43,2017-04-07 10:08:48,2017-04-07 10:08:48,2017-04-07 11:07:18,2017-04-07 11:07:18,2017-04-07 11:19:55,2017-04-07 11:19:55,2017-04-07 13:18:03,2017-04-07 13:18:03,2017-04-07 18:07:07,2017-04-07 18:07:07,2017-04-08 09:51:18,2017-04-08 09:51:18,2017-04-08 09:53:36,2017-04-08 09:53:36,2017-04-08 09:58:40,2017-04-08 09:58:40,2017-04-08 10:25:26,2017-04-08 10:25:26,2017-04-08 10:27:04,2017-04-08 10:27:04,2017-04-08 10:43:23,2017-04-08 10:43:23,2017-04-08 10:49:43,2017-04-08 10:49:43,2017-04-08 11:43:15,2017-04-08 11:43:15,2017-04-08 12:02:42,2017-04-08 12:02:42,2017-04-10 10:57:49,2017-04-10 10:57:49,2017-04-10 11:19:13,2017-04-10 11:19:13,2017-04-10 11:45:57,2017-04-10 11:45:58,2017-04-10 11:47:09,2017-04-10 11:47:10,2017-04-10 12:25:42,2017-04-10 12:25:42,2017-04-10 12:27:37,2017-04-10 12:27:37,2017-04-10 12:55:55,2017-04-10 12:55:55,2017-04-10 13:08:31,2017-04-10 13:08:31,2017-04-10 14:52:08,2017-04-10 14:52:08,2017-04-10 14:54:22,2017-04-10 14:54:22,2017-04-10 20:07:55,2017-04-10 20:07:55,2017-04-12 10:26:26,2017-04-12 10:26:26,2017-04-12 10:52:43,2017-04-12 10:52:43,2017-04-12 10:57:58,2017-04-12 10:57:58,2017-04-12 12:16:29,2017-04-12 12:16:29,2017-04-19 12:00:06,2017-04-19 12:00:06,2017-04-19 12:08:52,2017-04-19 12:08:52,2017-04-19 14:33:24,2017-04-19 14:33:24,2017-04-19 15:10:28,2017-04-19 15:10:28,2017-04-19 17:44:30,2017-04-19 17:44:30,2017-04-20 09:45:50,2017-04-20 09:45:50,2017-04-20 09:49:39,2017-04-20 09:49:39,2017-04-21 09:46:54,2017-04-21 09:46:54,2017-04-21 09:48:27,2017-04-21 09:48:27,2017-04-21 10:45:46,2017-04-21 10:45:46,2017-04-21 11:43:57,2017-04-21 11:43:57,2017-04-21 16:11:01,2017-04-21 16:11:01,2017-04-21 16:28:21,2017-04-21 16:28:21,2017-04-21 16:41:21,2017-04-21 16:41:21,2017-04-22 09:58:41,2017-04-22 09:58:41,2017-04-22 10:14:26,2017-04-22 10:14:26,2017-04-24 09:49:25,2017-04-24 09:49:25,2017-04-24 12:36:10,2017-04-24 12:36:10,2017-04-25 10:54:23,2017-04-25 10:54:23,2017-04-25 18:53:29,2017-04-25 18:53:30,2017-04-26 09:46:10,2017-04-26 09:46:10,2017-04-26 10:23:18,2017-04-26 10:23:18,2017-04-26 10:43:59,2017-04-26 10:43:59,2017-04-26 11:08:00,2017-04-26 11:08:00,2017-04-26 11:09:46,2017-04-26 11:09:46,2017-04-26 11:32:47,2017-04-26 11:32:47,2017-04-26 11:36:47,2017-04-26 11:36:47,2017-04-26 11:44:15,2017-04-26 11:44:15,2017-04-26 12:22:46,2017-04-26 12:22:46,2017-04-26 12:47:45,2017-04-26 12:55:14,2017-04-26 12:56:15,2017-04-26 12:59:05,2017-04-26 13:00:05,2017-04-26 13:18:10,2017-04-26 13:26:41,2017-04-26 13:26:41,2017-04-26 14:51:35,2017-04-26 14:51:35,2017-04-26 15:06:55,2017-04-26 15:06:55,2017-04-26 16:24:18,2017-04-26 16:24:19,2017-04-26 16:37:57,2017-04-26 16:37:57,2017-04-26 16:47:34,2017-04-26 16:47:34,2017-04-26 18:15:58,2017-04-26 18:15:58,2017-04-26 18:34:13,2017-04-26 18:34:13,2017-04-26 18:34:41,2017-04-26 18:34:41,2017-04-26 19:09:53,2017-04-26 19:09:53,2017-04-27 09:51:08,2017-04-27 09:51:08,2017-04-27 09:54:25,2017-04-27 09:54:25,2017-04-27 10:01:17,2017-04-27 10:01:17,2017-04-27 10:42:59,2017-04-27 10:42:59,2017-04-27 12:03:06,2017-04-27 12:03:06,2017-04-28 09:40:44,2017-04-28 09:40:45,2017-04-28 10:11:11,2017-04-28 10:11:11,2017-04-28 13:27:19,2017-04-28 13:27:19,2017-04-29 09:42:57,2017-04-29 09:42:57,2017-04-29 10:27:13,2017-04-29 10:27:13,2017-04-29 11:46:27,2017-04-29 12:05:53,2017-04-29 12:05:54,2017-04-29 12:05:59,2017-04-29 12:49:19,2017-04-29 12:49:20,2017-04-29 12:55:51,2017-04-29 12:55:51,2017-04-29 13:52:31,2017-04-29 13:52:31,2017-04-29 14:41:49,2017-04-29 14:43:21,2017-04-29 14:43:21,2017-04-29 15:40:42,2017-04-29 15:40:42,2017-04-29 15:48:34,2017-04-29 15:48:34,2017-04-29 15:50:05,2017-04-29 15:50:05,2017-04-29 15:56:03,2017-04-29 15:56:03,2017-04-29 16:04:31,2017-04-29 16:04:31,2017-04-29 16:08:42,2017-04-29 16:08:42,2017-04-29 16:39:49,2017-04-29 17:02:38,2017-04-29 17:02:38,2017-04-29 17:11:44,2017-04-29 18:04:46,2017-04-29 18:04:46,2017-04-29 18:32:43,2017-05-01 09:42:49,2017-05-01 09:42:49,2017-05-01 12:19:55,2017-05-01 12:19:56,2017-05-01 12:25:24,2017-05-01 12:25:24,2017-05-01 13:07:19,2017-05-01 13:07:19,2017-05-01 15:30:43,2017-05-01 15:37:15,2017-05-01 15:37:15,2017-05-01 19:23:38,2017-05-01 19:23:38,2017-05-02 09:46:18,2017-05-02 09:46:18,2017-05-02 09:47:16,2017-05-02 09:47:16,2017-05-02 09:47:42,2017-05-02 09:47:42,2017-05-02 09:48:58,2017-05-02 09:48:58,2017-05-02 09:50:14,2017-05-02 09:50:14,2017-05-02 09:51:06,2017-05-02 09:51:06,2017-05-02 09:51:25,2017-05-02 09:51:25,2017-05-02 10:53:04,2017-05-02 10:53:04,2017-05-02 11:19:24,2017-05-02 11:19:24,2017-05-02 11:55:20,2017-05-02 11:55:20,2017-05-02 15:11:50,2017-05-02 15:11:50,2017-05-02 15:24:56,2017-05-02 15:24:56,2017-05-02 18:16:51,2017-05-02 18:16:51,2017-05-02 18:32:37,2017-05-02 18:32:37,2017-05-03 09:40:47,2017-05-03 09:40:47,2017-05-03 09:41:41,2017-05-03 09:41:41,2017-05-03 11:40:27,2017-05-03 11:40:27,2017-05-03 12:23:21,2017-05-03 12:23:21,2017-05-03 13:06:01,2017-05-03 13:06:01,2017-05-03 14:21:14,2017-05-03 14:21:14,2017-05-03 17:15:54,2017-05-03 17:15:54,2017-05-03 17:30:22,2017-05-03 17:30:22,2017-05-03 17:46:00,2017-05-03 17:46:00,2017-05-03 18:14:28,2017-05-03 18:14:28,2017-05-03 19:02:09,2017-05-03 19:02:09,2017-05-03 19:03:27,2017-05-03 19:03:27,2017-05-03 19:04:46,2017-05-03 19:04:47,2017-05-03 19:13:40,2017-05-03 19:13:40,2017-05-03 19:47:09,2017-05-03 19:47:09,2017-05-03 20:04:51,2017-05-03 20:04:51,2017-05-04 09:46:36,2017-05-04 09:46:36,2017-05-04 09:47:14,2017-05-04 09:47:14,2017-05-04 12:38:10,2017-05-04 12:38:10,2017-05-04 15:19:56,2017-05-04 15:19:56,2017-05-04 15:56:06,2017-05-04 15:56:06,2017-05-04 16:58:45,2017-05-04 16:58:45,2017-05-04 17:32:46,2017-05-04 17:32:46,2017-05-04 17:58:05,2017-05-04 17:58:05,2017-05-04 18:53:53,2017-05-04 18:53:53,2017-05-04 19:01:01,2017-05-04 19:01:01,2017-05-04 19:01:26,2017-05-04 19:01:48,2017-05-04 19:01:48,2017-05-04 19:01:56,2017-05-04 19:02:14,2017-05-04 19:02:52,2017-05-04 19:02:52,2017-05-04 19:03:04,2017-05-04 19:03:34,2017-05-04 19:03:34,2017-05-04 19:03:48,2017-05-04 19:03:48,2017-05-04 19:04:18,2017-05-04 19:04:37,2017-05-04 19:04:37,2017-05-05 09:42:52,2017-05-05 09:42:52,2017-05-05 10:04:29,2017-05-05 10:04:29,2017-05-05 10:05:24,2017-05-05 10:05:24,2017-05-05 06:43:00,2017-05-05 06:44:30,2017-05-05 10:16:23,2017-05-05 06:47:55,2017-05-05 06:51:18,2017-05-05 10:22:03,2017-05-05 06:52:54,2017-05-05 10:37:50,2017-05-05 10:47:49,2017-05-05 10:47:49,2017-05-05 07:49:54,2017-05-05 07:56:50,2017-05-05 11:32:33,2017-05-05 11:32:48,2017-05-05 11:32:48,2017-05-05 08:05:59,2017-05-05 11:36:53,2017-05-05 08:09:25,2017-05-05 11:40:06,2017-05-05 08:11:22,2017-05-05 11:42:33,2017-05-05 08:36:27,2017-05-05 12:07:18,2017-05-05 12:29:51,2017-05-05 12:29:51,2017-05-05 14:44:40,2017-05-05 14:44:40,2017-05-05 15:21:15,2017-05-05 15:21:15,2017-05-05 15:44:01,2017-05-05 15:44:01,2017-05-06 09:45:18,2017-05-06 09:45:18,2017-05-06 10:31:58,2017-05-06 10:32:26,2017-05-06 10:32:37,2017-05-06 10:32:37,2017-05-06 11:28:31,2017-05-06 11:28:31,2017-05-06 12:11:11,2017-05-06 12:11:11,2017-05-06 12:24:14,2017-05-06 12:24:14,2017-05-06 12:49:24,2017-05-06 12:49:25,2017-05-06 12:52:25,2017-05-06 12:52:25,2017-05-06 13:18:55,2017-05-06 13:18:55,2017-05-06 13:26:22,2017-05-06 13:26:22,2017-05-06 15:09:12,2017-05-06 15:09:12,2017-05-06 15:20:28,2017-05-06 15:20:29,2017-05-08 09:48:25,2017-05-08 09:48:25,2017-05-08 09:51:03,2017-05-08 09:51:03,2017-05-08 10:52:33,2017-05-08 10:52:33,2017-05-08 11:59:53,2017-05-08 11:59:53,2017-05-08 17:26:35,2017-05-08 17:26:35,2017-05-09 09:47:23,2017-05-09 09:47:23,2017-05-09 10:09:32,2017-05-09 10:09:32,2017-05-09 10:44:23,2017-05-09 10:44:23,2017-05-09 10:45:59,2017-05-09 10:45:59,2017-05-09 11:46:08,2017-05-09 11:46:08,2017-05-10 09:49:16,2017-05-10 09:49:16,2017-05-10 10:10:19,2017-05-10 10:10:19,2017-05-11 10:13:35,2017-05-11 10:13:35,2017-05-11 11:19:29,2017-05-11 11:19:29,2017-05-11 11:27:57,2017-05-11 11:27:57,2017-05-11 12:37:28,2017-05-11 12:37:28,2017-05-11 14:25:08,2017-05-11 14:25:08,2017-05-11 14:43:32,2017-05-11 14:43:32,2017-05-11 14:44:21,2017-05-11 14:44:21,2017-05-11 15:11:55,2017-05-11 15:11:55,2017-05-12 11:31:55,2017-05-12 11:31:55,2017-05-12 17:50:27,2017-05-12 17:50:27,2017-05-12 18:22:53,2017-05-12 18:22:53,2017-05-13 10:01:26,2017-05-13 10:01:27,2017-05-13 10:09:07,2017-05-13 10:09:07,2017-05-13 10:33:14,2017-05-13 10:33:14,2017-05-13 10:38:51,2017-05-13 10:38:51,2017-05-13 13:02:02,2017-05-13 13:02:03,2017-05-15 09:51:41,2017-05-15 09:51:41,2017-05-15 09:52:53,2017-05-15 09:52:53,2017-05-15 10:04:01,2017-05-15 10:04:01,2017-05-15 10:21:00,2017-05-15 10:21:00,2017-05-15 11:58:20,2017-05-15 11:58:20,2017-05-15 14:22:54,2017-05-15 14:22:55,2017-05-15 15:47:34,2017-05-15 15:47:47,2017-05-15 15:47:48,2017-05-15 15:48:05,2017-05-15 15:48:12,2017-05-15 15:48:12,2017-05-15 16:40:46,2017-05-15 16:40:46,2017-05-15 19:17:57,2017-05-15 19:17:57,2017-05-16 09:49:42,2017-05-16 09:49:42,2017-05-16 09:56:12,2017-05-16 09:56:12,2017-05-16 10:33:29,2017-05-16 10:33:29,2017-05-16 11:51:11,2017-05-16 11:51:11,2017-05-16 11:55:24,2017-05-16 11:55:24,2017-05-16 11:56:33,2017-05-16 11:56:33,2017-05-16 11:56:37,2017-05-16 11:56:37,2017-05-16 12:00:08,2017-05-16 12:00:08,2017-05-16 12:02:08,2017-05-16 12:02:08,2017-05-16 12:08:08,2017-05-16 12:08:08,2017-05-16 12:50:37,2017-05-16 12:50:37,2017-05-16 14:14:28,2017-05-16 14:14:28,2017-05-16 14:20:36,2017-05-16 14:20:36,2017-05-16 14:31:36,2017-05-16 14:31:36,2017-05-16 14:37:27,2017-05-16 14:37:53,2017-05-16 14:38:03,2017-05-16 14:48:15,2017-05-16 14:48:15,2017-05-16 15:44:08,2017-05-16 15:44:08,2017-05-16 15:55:53,2017-05-16 15:55:53,2017-05-16 15:58:35,2017-05-16 15:58:35,2017-05-16 16:05:42,2017-05-16 16:05:42,2017-05-16 16:20:05,2017-05-16 16:20:05,2017-05-16 17:55:25,2017-05-16 17:55:25,2017-05-16 19:05:20,2017-05-16 19:05:20,2017-05-17 09:44:45,2017-05-17 09:44:45,2017-05-17 09:51:37,2017-05-17 09:51:37,2017-05-17 10:03:01,2017-05-17 10:03:01,2017-05-17 10:58:29,2017-05-17 10:58:29,2017-05-17 12:28:31,2017-05-17 12:28:31,2017-05-17 12:47:50,2017-05-17 12:47:50,2017-05-17 14:28:29,2017-05-17 14:28:29,2017-05-17 14:28:33,2017-05-17 14:28:34,2017-05-17 14:30:35,2017-05-17 14:30:35,2017-05-17 14:58:38,2017-05-17 14:58:38,2017-05-17 17:27:52,2017-05-17 17:27:52,2017-05-17 18:56:47,2017-05-17 18:56:47,2017-05-18 14:12:46,2017-05-18 14:12:46,2017-05-18 14:42:03,2017-05-18 14:42:04,2017-05-18 17:12:33,2017-05-18 17:12:33,2017-05-19 09:58:12,2017-05-19 09:58:12,2017-05-19 09:58:47,2017-05-19 09:58:47,2017-05-19 19:04:25,2017-05-19 19:04:25,2017-05-20 09:55:20,2017-05-20 09:55:20,2017-05-22 10:06:28,2017-05-22 10:06:28,2017-05-22 18:42:53,2017-05-22 18:42:53,2017-05-24 11:13:28,2017-05-24 11:13:28,2017-05-24 11:32:53,2017-05-24 11:32:53,2017-05-24 12:27:11,2017-05-24 12:27:11,2017-05-24 12:27:16,2017-05-24 12:27:16,2017-05-24 14:39:14,2017-05-24 14:39:14,2017-05-24 14:50:51,2017-05-24 14:50:51,2017-05-24 15:27:47,2017-05-24 15:27:47,2017-05-24 16:17:56,2017-05-24 16:17:56,2017-05-25 12:47:35,2017-05-25 12:47:35,2017-05-25 18:45:19,2017-05-25 18:45:19,2017-05-25 18:52:58,2017-05-25 18:52:58,2017-05-25 18:57:21,2017-05-25 18:57:21,2017-05-26 09:53:38,2017-05-26 09:53:39,2017-05-26 09:58:57,2017-05-26 09:58:57,2017-05-26 09:59:02,2017-05-26 09:59:03,2017-05-26 10:48:47,2017-05-26 10:48:48,2017-05-26 11:52:42,2017-05-26 11:52:42,2017-05-26 12:20:16,2017-05-26 12:20:16,2017-05-26 12:57:02,2017-05-26 12:57:02,2017-05-26 14:17:07,2017-05-26 14:17:08,2017-05-26 14:27:02,2017-05-26 14:27:02,2017-05-26 16:47:30,2017-05-26 16:47:30,2017-05-26 19:10:36,2017-05-26 19:10:36,2017-05-27 09:49:47,2017-05-27 09:49:47,2017-05-29 09:49:54,2017-05-29 09:49:54,2017-05-29 10:39:54,2017-05-29 10:39:54,2017-05-29 11:07:33,2017-05-29 11:07:33,2017-05-29 11:15:16,2017-05-29 11:15:16,2017-05-29 12:16:40,2017-05-29 12:16:40,2017-05-29 12:17:39,2017-05-29 12:17:39,2017-05-29 12:23:34,2017-05-29 12:23:34,2017-05-29 12:34:31,2017-05-29 12:34:31,2017-05-29 12:46:58,2017-05-29 12:46:58,2017-05-29 12:48:57,2017-05-29 12:48:57,2017-05-29 12:52:56,2017-05-29 12:52:56,2017-05-29 13:03:12,2017-05-29 13:03:12,2017-05-29 13:05:10,2017-05-29 13:05:10,2017-05-29 13:07:47,2017-05-29 13:07:47,2017-05-29 14:24:48,2017-05-29 14:24:48,2017-05-29 14:29:01,2017-05-29 14:29:02,2017-05-29 14:41:29,2017-05-29 14:41:29,2017-05-29 14:42:04,2017-05-29 14:42:04,2017-05-29 14:52:04,2017-05-29 14:52:04,2017-05-29 15:17:54,2017-05-29 15:17:54,2017-05-29 15:24:33,2017-05-29 15:24:33,2017-05-29 15:30:10,2017-05-29 15:30:10,2017-05-29 15:45:17,2017-05-29 15:45:17,2017-05-29 16:22:17,2017-05-29 16:22:17,2017-05-29 16:48:27,2017-05-29 16:48:27,2017-05-29 17:31:41,2017-05-29 17:31:41,2017-05-29 17:36:24,2017-05-29 17:36:24,2017-05-29 18:28:42,2017-05-29 18:28:42,2017-05-29 18:48:12,2017-05-29 18:48:12,2017-05-29 19:03:48,2017-05-29 19:03:48,2017-05-30 09:49:14,2017-05-30 09:49:14,2017-05-30 10:16:06,2017-05-30 10:16:06,2017-05-30 10:24:46,2017-05-30 10:24:46,2017-05-30 10:26:54,2017-05-30 10:26:54,2017-05-30 14:30:06,2017-05-30 14:30:06,2017-05-30 15:25:42,2017-05-30 15:25:42,2017-05-30 15:43:08,2017-05-30 15:43:08,2017-05-30 16:16:15,2017-05-30 16:16:15,2017-05-30 16:58:47,2017-05-30 16:58:47,2017-05-30 19:12:13,2017-05-30 19:12:13,2017-05-31 09:48:58,2017-05-31 09:48:58,2017-05-31 09:51:12,2017-05-31 09:51:12,2017-05-31 14:33:01,2017-05-31 14:33:01,2017-05-31 14:45:09,2017-05-31 14:45:10,2017-06-01 09:48:03,2017-06-01 09:48:04,2017-06-01 09:55:18,2017-06-01 09:55:18,2017-06-01 10:59:58,2017-06-01 10:59:58,2017-06-01 14:12:06,2017-06-01 14:12:06,2017-06-01 16:25:34,2017-06-01 16:25:34,2017-06-01 16:43:59,2017-06-01 16:43:59,2017-06-01 16:55:19,2017-06-01 16:55:19,2017-06-01 17:36:22,2017-06-01 17:36:22,2017-06-01 18:00:08,2017-06-01 18:00:08,2017-06-01 18:03:28,2017-06-01 18:03:28,2017-06-02 14:17:16,2017-06-02 14:17:16,2017-06-02 14:18:58,2017-06-02 14:18:58,2017-06-05 12:20:54,2017-06-05 12:20:54,2017-06-05 12:38:18,2017-06-05 12:38:18,2017-06-05 12:52:01,2017-06-05 12:52:01,2017-06-06 09:56:26,2017-06-06 09:56:26,2017-06-06 10:59:33,2017-06-06 10:59:33,2017-06-06 11:19:05,2017-06-06 11:19:05,2017-06-06 11:29:33,2017-06-06 11:29:33,2017-06-06 11:53:52,2017-06-06 11:53:52,2017-06-06 12:41:46,2017-06-06 12:41:46,2017-06-06 15:11:40,2017-06-06 15:11:40,2017-06-06 15:32:03,2017-06-06 15:32:03,2017-06-06 17:23:19,2017-06-06 17:23:19,2017-06-06 18:51:52,2017-06-06 18:51:52,2017-06-07 09:54:01,2017-06-07 09:54:01,2017-06-07 11:31:57,2017-06-07 11:31:57,2017-06-07 12:04:45,2017-06-07 12:04:45,2017-06-07 12:22:41,2017-06-07 12:22:41,2017-06-07 12:39:05,2017-06-07 12:39:05,2017-06-07 12:56:01,2017-06-07 12:56:01,2017-06-07 12:57:42,2017-06-07 12:57:42,2017-06-07 13:00:46,2017-06-07 13:00:46,2017-06-07 13:06:28,2017-06-07 13:06:28,2017-06-07 13:13:13,2017-06-07 13:13:13,2017-06-07 14:40:33,2017-06-07 14:40:33,2017-06-07 15:00:34,2017-06-07 15:00:34,2017-06-07 15:27:19,2017-06-07 15:27:19,2017-06-08 09:51:14,2017-06-08 09:51:14,2017-06-08 10:44:16,2017-06-08 10:44:16,2017-06-08 11:19:16,2017-06-08 11:19:17,2017-06-08 11:24:25,2017-06-08 11:24:25,2017-06-08 11:28:20,2017-06-08 11:28:20,2017-06-08 11:33:09,2017-06-08 11:33:10,2017-06-08 11:53:01,2017-06-08 11:53:01,2017-06-08 12:01:37,2017-06-08 12:01:37,2017-06-08 12:59:27,2017-06-08 12:59:27,2017-06-08 14:02:27,2017-06-08 14:02:27,2017-06-09 10:26:32,2017-06-09 10:26:32,2017-06-09 16:31:53,2017-06-09 16:31:53,2017-06-12 17:52:01,2017-06-12 17:52:01,2017-06-13 10:10:16,2017-06-13 10:10:16,2017-06-13 10:15:10,2017-06-13 10:15:10,2017-06-13 10:19:57,2017-06-13 10:19:57,2017-06-13 10:21:54,2017-06-13 10:21:54,2017-06-13 10:23:36,2017-06-13 10:23:36,2017-06-13 10:24:36,2017-06-13 10:24:36,2017-06-13 10:44:25,2017-06-13 10:44:25,2017-06-13 11:22:48,2017-06-13 11:22:48,2017-06-13 11:48:02,2017-06-13 11:48:02,2017-06-13 14:53:01,2017-06-13 14:53:01,2017-06-13 15:15:52,2017-06-13 15:15:53,2017-06-13 16:13:50,2017-06-13 16:13:50,2017-06-13 16:20:04,2017-06-13 16:20:05,2017-06-13 18:00:03,2017-06-13 18:00:03,2017-06-13 18:23:26,2017-06-13 18:23:26,2017-06-14 10:01:39,2017-06-14 10:01:39,2017-06-14 10:01:43,2017-06-14 10:01:43,2017-06-14 11:54:36,2017-06-14 11:54:36,2017-06-14 12:43:20,2017-06-14 12:43:20,2017-06-14 12:48:28,2017-06-14 12:48:28,2017-06-14 12:50:27,2017-06-14 12:50:27,2017-06-14 13:07:07,2017-06-14 13:07:07,2017-06-14 16:31:31,2017-06-14 16:31:31,2017-06-14 16:34:33,2017-06-14 16:34:33,2017-06-14 17:14:37,2017-06-14 17:14:37,2017-06-14 18:13:02,2017-06-14 18:13:02,2017-06-15 09:48:40,2017-06-15 09:48:40,2017-06-15 15:03:38,2017-06-15 15:03:38,2017-06-15 17:41:42,2017-06-15 17:41:42,2017-06-16 09:48:38,2017-06-16 09:48:39,2017-06-16 10:25:29,2017-06-16 10:25:29,2017-06-16 10:34:33,2017-06-16 10:34:33,2017-06-16 10:38:04,2017-06-16 10:38:04,2017-06-16 10:40:02,2017-06-16 10:40:02,2017-06-16 11:07:12,2017-06-16 11:07:12,2017-06-16 12:22:36,2017-06-16 12:22:36,2017-06-16 17:32:54,2017-06-16 17:32:54,2017-06-17 09:55:47,2017-06-17 09:55:47,2017-06-17 10:19:53,2017-06-17 10:19:53,2017-06-17 14:17:28,2017-06-17 14:17:28,2017-06-19 09:49:32,2017-06-19 09:49:32,2017-06-19 11:15:03,2017-06-19 11:15:03,2017-06-19 12:13:43,2017-06-19 12:13:43,2017-06-19 13:02:55,2017-06-19 13:02:55,2017-06-19 13:20:44,2017-06-19 13:20:44,2017-06-19 14:35:02,2017-06-19 14:35:02,2017-06-19 18:33:59,2017-06-19 18:33:59,2017-06-19 18:47:39,2017-06-19 18:47:39,2017-06-20 09:48:48,2017-06-20 09:48:48,2017-06-20 09:51:27,2017-06-20 09:51:27,2017-06-20 11:02:32,2017-06-20 11:02:32,2017-06-20 11:18:23,2017-06-20 11:18:23,2017-06-21 09:46:20,2017-06-21 09:46:20,2017-06-21 12:39:14,2017-06-21 12:39:14,2017-06-21 12:40:17,2017-06-21 12:40:17,2017-06-21 15:03:12,2017-06-21 15:03:12,2017-06-21 15:32:18,2017-06-21 15:32:18,2017-06-21 16:44:49,2017-06-21 16:44:49,2017-06-21 17:59:15,2017-06-21 17:59:15,2017-06-22 09:48:13,2017-06-22 09:48:13,2017-06-22 12:59:45,2017-06-22 12:59:45,2017-06-22 14:46:23,2017-06-22 14:46:23,2017-06-23 10:41:30,2017-06-23 10:41:30,2017-06-23 11:11:58,2017-06-23 11:11:58,2017-06-23 11:20:50,2017-06-23 11:20:50,2017-06-23 12:19:44,2017-06-23 12:19:44,2017-06-23 14:54:51,2017-06-23 14:54:52,2017-06-23 16:56:58,2017-06-23 16:56:58,2017-06-23 17:11:35,2017-06-23 17:11:35,2017-06-23 19:42:58,2017-06-23 19:42:58,2017-06-23 19:53:57,2017-06-23 19:53:57,2017-06-23 20:07:12,2017-06-23 20:07:12,2017-06-24 10:23:04,2017-06-24 10:23:04,2017-06-24 11:11:39,2017-06-24 11:11:39,2017-06-24 11:13:17,2017-06-24 11:13:17,2017-06-24 14:22:55,2017-06-24 14:22:55,2017-06-24 14:58:31,2017-06-24 14:58:32,2017-06-24 17:33:07,2017-06-24 17:33:07,2017-06-26 09:54:25,2017-06-26 09:54:25,2017-06-26 09:59:41,2017-06-26 09:59:41,2017-06-26 12:44:52,2017-06-26 12:44:52,2017-06-26 14:23:37,2017-06-26 14:23:37,2017-06-26 16:02:29,2017-06-26 16:02:29,2017-06-28 12:16:28,2017-06-28 12:16:29,2017-06-28 17:00:26,2017-06-28 17:00:26,2017-06-28 17:49:54,2017-06-28 17:49:54,2017-06-29 15:05:51,2017-06-29 15:05:51,2017-06-30 11:14:10,2017-06-30 11:14:10,2017-06-30 16:12:51,2017-06-30 16:12:51,2017-06-30 16:46:13,2017-06-30 16:46:13,2017-06-30 16:46:30,2017-06-30 16:46:30,2017-06-30 16:56:25,2017-06-30 16:56:25,2017-06-30 16:59:29,2017-06-30 16:59:29,2017-06-30 17:10:13,2017-06-30 17:10:13,2017-06-30 17:18:44,2017-06-30 17:18:44,2017-06-30 17:23:11,2017-06-30 17:23:11,2017-06-30 17:34:22,2017-06-30 17:34:22,2017-06-30 17:39:49,2017-06-30 17:39:49,2017-06-30 17:40:15,2017-06-30 17:40:15,2017-06-30 17:42:26,2017-06-30 17:42:26,2017-07-04 11:19:20,2017-07-04 11:19:20,2017-07-04 12:34:29,2017-07-04 12:34:29,2017-07-04 14:15:39,2017-07-04 14:15:39,2017-07-04 14:27:02,2017-07-04 14:27:02,2017-07-05 09:46:58,2017-07-05 09:46:58,2017-07-05 10:12:45,2017-07-05 10:12:45,2017-07-05 18:27:44,2017-07-05 18:27:44,2017-07-05 18:31:36,2017-07-05 18:31:36,2017-07-05 18:53:19,2017-07-05 18:53:19,2017-07-06 14:01:46,2017-07-06 14:01:46,2017-07-06 10:59:49,2017-07-06 11:04:07,2017-07-06 14:34:33,2017-07-06 14:34:33,2017-07-07 06:19:08,2017-07-07 10:47:12,2017-07-07 10:47:12,2017-07-07 11:50:05,2017-07-07 11:50:05,2017-07-07 13:45:55,2017-07-07 13:45:55,2017-07-07 17:41:11,2017-07-07 17:41:11,2017-07-07 17:41:34,2017-07-07 17:41:34,2017-07-08 09:50:44,2017-07-08 10:04:34,2017-07-08 10:04:34,2017-07-08 15:49:30,2017-07-08 15:49:30,2017-07-10 09:51:16,2017-07-10 09:51:16,2017-07-10 10:57:25,2017-07-10 10:57:25,2017-07-10 11:48:45,2017-07-10 11:48:45,2017-07-10 13:03:10,2017-07-10 13:03:10,2017-07-10 14:28:10,2017-07-10 14:28:11,2017-07-10 14:50:12,2017-07-10 14:50:12,2017-07-10 19:32:10,2017-07-10 19:32:10,2017-07-11 09:46:12,2017-07-11 09:46:12,2017-07-11 09:46:59,2017-07-11 09:46:59,2017-07-11 10:00:32,2017-07-11 10:00:32,2017-07-11 10:07:49,2017-07-11 10:08:05,2017-07-11 10:08:05,2017-07-11 10:08:24,2017-07-11 11:02:50,2017-07-11 11:02:50,2017-07-11 16:02:42,2017-07-11 16:02:42,2017-07-11 16:59:23,2017-07-11 16:59:23,2017-07-12 09:50:35,2017-07-12 09:50:35,2017-07-12 16:00:14,2017-07-12 16:00:14,2017-07-12 18:35:56,2017-07-12 18:35:56,2017-07-13 09:50:16,2017-07-13 09:50:16,2017-07-13 14:17:19,2017-07-13 14:17:19,2017-07-14 09:50:08,2017-07-14 09:50:08,2017-07-14 12:05:08,2017-07-14 12:05:08,2017-07-17 11:10:13,2017-07-17 11:10:13,2017-07-17 20:55:55,2017-07-17 20:55:55,2017-07-18 10:46:57,2017-07-18 10:46:58,2017-07-18 14:25:23,2017-07-18 14:25:23,2017-07-18 15:53:34,2017-07-18 15:53:34,2017-07-18 16:44:56,2017-07-18 16:44:56,2017-07-18 16:56:15,2017-07-18 16:56:15,2017-07-18 18:01:11,2017-07-18 18:01:11,2017-07-18 18:14:54,2017-07-18 18:14:55,2017-07-19 09:47:56,2017-07-19 09:47:56,2017-07-19 11:30:11,2017-07-19 11:30:11,2017-07-19 11:33:58,2017-07-19 11:33:58,2017-07-19 15:57:40,2017-07-19 15:57:40,2017-07-19 19:09:31,2017-07-19 19:09:31,2017-07-19 19:09:53,2017-07-19 19:09:53,2017-07-19 19:11:01,2017-07-19 19:11:01,2017-07-20 10:04:39,2017-07-20 10:04:40,2017-07-20 11:37:49,2017-07-20 11:37:49,2017-07-21 09:48:24,2017-07-21 09:48:24,2017-07-21 16:02:33,2017-07-21 16:02:33,2017-07-21 17:32:06,2017-07-21 17:32:06,2017-07-22 10:28:06,2017-07-22 10:28:06,2017-07-22 11:11:58,2017-07-22 11:11:58,2017-07-25 10:10:53,2017-07-25 10:10:53,2017-07-25 10:20:34,2017-07-25 10:20:34,2017-07-25 10:22:33,2017-07-25 10:22:33,2017-07-25 10:26:17,2017-07-25 10:26:17,2017-07-31 10:39:24,2017-07-31 10:39:24,2017-07-31 14:51:14,2017-07-31 14:51:14,2017-07-31 15:02:02,2017-07-31 15:02:02,2017-07-31 15:03:53,2017-07-31 15:03:53,2017-07-31 15:05:33,2017-07-31 15:05:33,2017-07-31 15:39:09,2017-07-31 15:39:09,2017-08-01 09:43:56,2017-08-01 09:43:56,2017-08-01 12:07:12,2017-08-01 12:07:12,2017-08-01 14:28:29,2017-08-01 14:28:29,2017-08-01 17:11:50,2017-08-01 17:11:50,2017-08-02 14:54:37,2017-08-02 14:54:37,2017-08-02 15:29:21,2017-08-02 15:29:21,2017-08-02 18:30:35,2017-08-02 18:30:35,2017-08-03 17:44:25,2017-08-03 17:44:25,2017-08-04 12:37:17,2017-08-04 12:37:17,2017-08-04 13:07:31,2017-08-04 13:07:32,2017-08-04 13:49:33,2017-08-04 13:49:33,2017-08-04 15:35:16,2017-08-04 15:35:16,2017-08-04 15:39:50,2017-08-04 15:39:50,2017-08-04 17:45:15,2017-08-04 17:45:15,2017-08-04 17:49:01,2017-08-04 17:49:01,2017-08-04 18:17:42,2017-08-04 18:17:42,2017-08-04 19:35:02,2017-08-04 19:35:02,2017-08-04 19:49:28,2017-08-04 19:49:28,2017-08-04 21:39:07,2017-08-04 21:39:07,2017-08-05 08:19:38,2017-08-05 08:19:39,2017-08-05 11:24:12,2017-08-05 11:24:12,2017-08-05 14:13:20,2017-08-05 14:13:20,2017-08-05 15:09:31,2017-08-05 15:09:31,2017-08-05 15:54:05,2017-08-05 15:54:05,2017-08-05 16:36:53,2017-08-05 16:36:53,2017-08-05 18:05:48,2017-08-05 18:05:48,2017-08-05 18:16:16,2017-08-05 18:16:16,2017-08-05 21:53:43,2017-08-05 21:53:43,2017-08-08 09:51:45,2017-08-08 09:51:45,2017-08-08 11:29:49,2017-08-08 11:29:49,2017-08-08 15:14:46,2017-08-08 15:14:46,2017-08-08 15:53:57,2017-08-08 15:53:57,2017-08-08 16:16:48,2017-08-08 16:16:48,2017-08-08 16:25:32,2017-08-08 16:25:32,2017-08-08 16:57:29,2017-08-08 16:57:29,2017-08-08 17:17:34,2017-08-08 17:17:34,2017-08-08 19:29:13,2017-08-08 19:29:13,2017-08-08 19:56:29,2017-08-08 19:56:30,2017-08-08 19:57:54,2017-08-08 19:57:54,2017-08-08 21:38:34,2017-08-08 21:38:34,2017-08-09 09:44:16,2017-08-09 09:44:16,2017-08-09 10:40:51,2017-08-09 10:40:51,2017-08-09 10:48:56,2017-08-09 10:48:56,2017-08-09 16:09:31,2017-08-09 16:09:31,2017-08-09 16:46:03,2017-08-09 16:46:03,2017-08-09 17:10:41,2017-08-09 17:10:41,2017-08-09 17:37:44,2017-08-09 17:37:44,2017-08-09 17:59:06,2017-08-09 17:59:06,2017-08-09 18:51:50,2017-08-09 18:51:50,2017-08-09 19:04:49,2017-08-09 19:04:49,2017-08-09 19:24:53,2017-08-09 19:24:53,2017-08-10 11:16:07,2017-08-10 11:16:07,2017-08-10 11:16:42,2017-08-10 11:16:42,2017-08-10 19:28:31,2017-08-10 19:28:31,2017-08-10 19:31:26,2017-08-10 19:31:26,2017-08-11 10:04:46,2017-08-11 10:04:46,2017-08-11 10:22:29,2017-08-11 10:22:29,2017-08-11 13:08:36,2017-08-11 13:08:36,2017-08-11 14:55:26,2017-08-11 14:55:26,2017-08-11 15:13:49,2017-08-11 15:13:49,2017-08-11 17:38:22,2017-08-11 17:38:22,2017-08-12 09:44:36,2017-08-12 09:44:37,2017-08-12 12:37:24,2017-08-12 12:37:24,2017-08-12 16:03:01,2017-08-12 16:03:01,2017-08-17 10:27:18,2017-08-17 10:27:19,2017-08-17 11:24:26,2017-08-17 11:24:26,2017-08-17 11:24:45,2017-08-17 11:24:45,2017-08-17 14:10:34,2017-08-17 14:10:34,2017-08-17 14:44:53,2017-08-17 14:44:53,2017-08-17 14:51:56,2017-08-17 14:51:56,2017-08-17 14:52:02,2017-08-17 14:52:02,2017-08-17 14:52:12,2017-08-17 14:52:12,2017-08-17 16:10:05,2017-08-17 16:10:05,2017-08-17 16:35:45,2017-08-17 16:35:45,2017-08-17 17:28:52,2017-08-17 17:28:52,2017-08-17 18:34:39,2017-08-17 18:34:39,2017-08-17 19:15:55,2017-08-17 19:15:55,2017-08-18 09:34:54,2017-08-18 09:34:54,2017-08-18 09:50:15,2017-08-18 09:50:15,2017-08-18 10:01:10,2017-08-18 10:01:10,2017-08-18 10:02:12,2017-08-18 10:02:12,2017-08-18 10:11:59,2017-08-18 10:11:59,2017-08-18 10:37:41,2017-08-18 10:37:41,2017-08-18 10:54:56,2017-08-18 10:54:56,2017-08-18 11:12:57,2017-08-18 11:12:57,2017-08-18 12:15:05,2017-08-18 12:15:05,2017-08-18 13:16:44,2017-08-18 13:16:44,2017-08-19 09:45:28,2017-08-19 09:45:28,2017-08-19 10:09:15,2017-08-19 10:09:15,2017-08-19 11:07:08,2017-08-19 11:07:08,2017-08-19 12:12:14,2017-08-19 12:12:14,2017-08-19 14:26:24,2017-08-19 14:26:24,2017-08-19 14:46:49,2017-08-19 14:46:49,2017-08-21 16:38:14,2017-08-21 16:38:14,2017-08-21 16:41:40,2017-08-21 16:41:41,2017-08-25 11:19:17,2017-08-25 11:19:17,2017-08-25 15:36:12,2017-08-25 15:36:12,2017-08-25 17:39:38,2017-08-25 17:39:38,2017-08-26 10:23:03,2017-08-26 10:23:03,2017-08-26 10:38:05,2017-08-26 10:38:05,2017-08-26 11:36:37,2017-08-26 11:36:37,2017-08-26 11:45:24,2017-08-26 11:45:24,2017-08-26 14:38:59,2017-08-26 14:38:59,2017-08-26 14:40:49,2017-08-26 14:40:50,2017-08-26 14:53:57,2017-08-26 14:53:57,2017-08-26 15:17:59,2017-08-26 15:17:59,2017-08-28 12:53:08,2017-08-28 12:53:08,2017-08-30 10:17:40,2017-08-30 10:17:41,2017-08-30 12:22:08,2017-08-30 12:22:08,2017-08-30 16:22:28,2017-08-30 16:22:28,2017-08-30 16:31:30,2017-08-30 16:31:30,2017-08-30 17:46:18,2017-08-30 17:46:18,2017-09-01 18:34:23,2017-09-01 18:34:23,2017-09-04 15:03:32,2017-09-04 15:03:32,2017-09-05 10:08:41,2017-09-05 10:08:41,2017-09-05 11:41:01,2017-09-05 11:41:01,2017-09-05 14:02:42,2017-09-05 14:02:43,2017-09-05 15:21:44,2017-09-05 15:21:45,2017-09-05 19:35:55,2017-09-05 19:35:56,2017-09-06 09:57:13,2017-09-06 09:57:13,2017-09-06 11:18:27,2017-09-06 11:18:27,2017-09-06 11:31:40,2017-09-06 11:31:40,2017-09-06 13:03:05,2017-09-06 13:03:05,2017-09-06 15:51:49,2017-09-06 15:51:49,2017-09-08 18:42:39,2017-09-08 18:42:39,2017-09-11 15:50:26,2017-09-11 15:50:27,2017-09-11 16:26:35,2017-09-11 16:26:35,2017-09-11 16:27:24,2017-09-11 16:27:24,2017-09-11 16:33:22,2017-09-11 16:33:22,2017-09-11 16:50:39,2017-09-11 16:50:39,2017-09-11 17:00:23,2017-09-11 17:00:23,2017-09-11 17:08:41,2017-09-11 17:08:41,2017-09-12 15:06:44,2017-09-12 15:06:45,2017-09-13 09:43:12,2017-09-13 09:43:12,2017-09-13 10:04:16,2017-09-13 10:04:16,2017-09-14 12:54:29,2017-09-14 12:54:29,2017-09-15 11:24:55,2017-09-15 11:24:55,2017-09-15 12:36:48,2017-09-15 12:36:48,2017-09-16 10:07:41,2017-09-16 10:07:41,2017-09-16 12:55:40,2017-09-16 12:55:40,2017-09-18 13:12:30,2017-09-18 13:12:30,2017-09-19 10:57:57,2017-09-19 10:57:57,2017-09-19 14:19:06,2017-09-19 14:19:06,2017-09-19 16:29:20,2017-09-19 16:29:21,2017-09-19 17:52:47,2017-09-19 17:52:47,2017-09-20 10:01:25,2017-09-20 10:01:25,2017-09-20 11:57:12,2017-09-20 11:57:12,2017-09-21 17:13:51,2017-09-21 17:13:51,2017-09-21 17:44:47,2017-09-21 17:44:47,2017-09-22 16:15:33,2017-09-22 16:15:33,2017-09-23 12:27:29,2017-09-23 12:27:29,2017-09-23 16:15:00,2017-09-23 16:15:00,2017-09-23 16:18:57,2017-09-23 16:18:57,2017-09-23 18:43:12,2017-09-23 18:43:12,2017-09-25 10:21:57,2017-09-25 10:21:57,2017-09-25 10:26:18,2017-09-25 10:26:18,2017-09-26 10:52:42,2017-09-26 10:52:42,2017-09-26 11:14:48,2017-09-26 11:14:48,2017-09-26 11:51:51,2017-09-26 11:51:51,2017-09-26 15:42:02,2017-09-26 15:42:02,2017-09-26 16:32:11,2017-09-26 16:32:11,2017-09-26 18:35:59,2017-09-26 18:35:59,2017-09-27 14:32:48,2017-09-27 14:32:49,2017-09-29 18:54:46,2017-09-29 18:54:46,2017-09-30 14:29:07,2017-09-30 14:29:08,2017-09-30 16:23:00,2017-09-30 16:23:00,2017-10-02 10:12:30,2017-10-02 10:12:30,2017-10-05 11:08:48,2017-10-05 11:08:48,2017-10-05 12:43:52,2017-10-05 12:43:52,2017-10-05 15:02:18,2017-10-05 15:02:18,2017-10-05 17:59:09,2017-10-05 17:59:09,2017-10-06 10:25:50,2017-10-06 10:25:50,2017-10-06 15:47:29,2017-10-06 15:47:29,2017-10-07 10:33:33,2017-10-07 10:33:33,2017-10-09 16:04:53,2017-10-09 16:04:53,2017-10-09 16:06:28,2017-10-09 16:06:28,2017-10-09 17:24:43,2017-10-09 17:24:44,2017-10-09 18:04:25,2017-10-09 18:04:25,2017-10-09 22:10:02,2017-10-09 22:10:02,2017-10-10 11:11:01,2017-10-10 11:11:01,2017-10-10 15:21:47,2017-10-10 15:21:47,2017-10-10 16:51:24,2017-10-10 16:51:24,2017-10-10 17:20:51,2017-10-10 17:20:51,2017-10-10 17:53:13,2017-10-10 17:53:13,2017-10-10 18:12:45,2017-10-10 18:12:45,2017-10-11 09:52:32,2017-10-11 09:52:32,2017-10-11 10:05:58,2017-10-11 10:05:58,2017-10-11 10:20:12,2017-10-11 10:20:12,2017-10-11 10:34:19,2017-10-11 10:34:19,2017-10-11 11:21:56,2017-10-11 11:21:56,2017-10-11 14:27:47,2017-10-11 14:27:47,2017-10-11 15:48:37,2017-10-11 15:48:37,2017-10-11 17:42:15,2017-10-11 17:42:15,2017-10-11 18:35:21,2017-10-11 18:35:21,2017-10-12 10:55:37,2017-10-12 10:55:38,2017-10-12 11:21:04,2017-10-12 11:21:04,2017-10-12 11:27:30,2017-10-12 11:27:30,2017-10-12 11:30:12,2017-10-12 11:30:12,2017-10-12 11:49:48,2017-10-12 11:49:48,2017-10-12 12:44:05,2017-10-12 12:44:05,2017-10-12 12:49:27,2017-10-12 12:49:27,2017-10-12 14:13:49,2017-10-12 14:13:49,2017-10-12 15:12:15,2017-10-12 15:12:15,2017-10-12 16:29:26,2017-10-12 16:29:27,2017-10-12 17:33:27,2017-10-12 17:33:27,2017-10-12 19:28:28,2017-10-12 19:28:28,2017-10-13 10:03:06,2017-10-13 10:03:06,2017-10-13 10:09:23,2017-10-13 10:09:23,2017-10-13 10:16:01,2017-10-13 10:16:01,2017-10-13 10:35:03,2017-10-13 10:35:03,2017-10-13 11:14:32,2017-10-13 11:14:32,2017-10-13 11:21:12,2017-10-13 11:21:12,2017-10-13 11:24:33,2017-10-13 11:24:33,2017-10-13 11:31:31,2017-10-13 11:31:31,2017-10-13 11:58:14,2017-10-13 11:58:14,2017-10-13 12:15:41,2017-10-13 12:15:41,2017-10-13 14:07:57,2017-10-13 14:07:57,2017-10-13 14:20:08,2017-10-13 14:20:09,2017-10-13 15:47:11,2017-10-13 15:47:11,2017-10-13 16:30:17,2017-10-13 16:30:17,2017-10-28 10:23:49,2017-10-28 10:23:49,2017-11-01 11:08:57,2017-11-01 11:08:57,2017-11-07 14:43:36,2017-11-07 14:43:37,2017-11-08 10:26:11,2017-11-08 10:26:11,2017-11-08 10:28:48,2017-11-08 10:28:48,2017-11-08 10:40:39,2017-11-08 10:40:39,2017-11-08 10:43:09,2017-11-08 10:43:09,2017-11-08 12:47:23,2017-11-08 12:47:23,2017-11-08 14:43:48,2017-11-08 14:43:48,2017-11-08 16:48:48,2017-11-08 16:48:48,2017-11-08 18:35:00,2017-11-08 18:35:00,2017-11-09 10:35:53,2017-11-09 10:35:53,2017-11-09 11:18:50,2017-11-09 11:18:51,2017-11-11 16:47:06,2017-11-11 16:47:06,2017-11-13 10:10:49,2017-11-13 10:10:49,2017-11-15 10:44:31,2017-11-15 10:44:31,2017-11-15 10:53:55,2017-11-15 10:53:56,2017-11-15 14:39:50,2017-11-15 14:39:50,2017-11-15 14:43:25,2017-11-15 14:43:25,2017-11-15 14:44:19,2017-11-15 14:44:19,2017-11-15 14:44:25,2017-11-15 14:44:25,2017-11-16 10:16:57,2017-11-16 10:16:57,2017-11-17 17:15:11,2017-11-17 17:15:11,2017-11-18 10:18:32,2017-11-18 10:18:33,2017-11-22 09:58:42,2017-11-22 09:58:42,2017-11-22 11:14:52,2017-11-22 11:14:52,2017-11-22 12:04:59,2017-11-22 12:04:59,2017-11-23 14:35:26,2017-11-23 14:35:26,2017-11-30 12:29:52,2017-11-30 12:29:52,2017-11-30 14:43:59,2017-11-30 14:43:59,2017-11-30 17:12:45,2017-11-30 17:12:45,2017-11-30 19:01:44,2017-11-30 19:01:44,2017-12-01 09:59:34,2017-12-01 09:59:34,2017-12-01 10:00:25,2017-12-01 10:00:26,2017-12-01 11:16:03,2017-12-01 11:16:03,2017-12-01 18:37:01,2017-12-01 18:37:01,2017-12-01 19:01:30,2017-12-01 19:01:30,2017-12-02 09:56:41,2017-12-02 09:56:41,2017-12-04 11:29:20,2017-12-04 11:29:20,2017-12-04 11:56:39,2017-12-04 11:56:39,2017-12-05 11:29:06,2017-12-05 11:29:06,2017-12-06 09:58:45,2017-12-06 09:58:45,2017-12-07 08:43:25,2017-12-07 08:43:25,2017-12-07 10:08:57,2017-12-07 10:08:57,2017-12-07 12:43:34,2017-12-07 12:43:34,2017-12-07 12:47:12,2017-12-07 12:47:12,2017-12-07 12:52:34,2017-12-07 12:52:34,2017-12-07 12:53:20,2017-12-07 12:53:20,2017-12-07 13:08:21,2017-12-07 13:08:22,2017-12-08 09:59:19,2017-12-08 09:59:19,2017-12-08 10:03:15,2017-12-08 10:03:15,2017-12-08 16:12:04,2017-12-08 16:12:04,2017-12-11 16:01:28,2017-12-11 16:01:28,2017-12-12 11:40:58,2017-12-12 11:40:58,2017-12-14 17:03:14,2017-12-14 17:03:14,2017-12-14 17:14:56,2017-12-14 17:14:56,2017-12-14 18:39:41,2017-12-14 18:39:41,2017-12-15 09:54:55,2017-12-15 09:54:55,2017-12-15 10:15:32,2017-12-15 10:15:32,2017-12-16 15:33:18,2017-12-16 15:33:19,2017-12-18 13:03:38,2017-12-18 13:03:38,2017-12-18 15:56:27,2017-12-18 15:56:27,2017-12-18 17:17:37,2017-12-18 17:17:37,2017-12-18 17:51:13,2017-12-18 17:51:13,2017-12-19 09:50:46,2017-12-19 09:50:46,2017-12-19 09:57:03,2017-12-19 09:57:03,2017-12-19 12:24:30,2017-12-19 12:24:30,2017-12-19 16:40:22,2017-12-19 16:40:22,2017-12-20 13:10:50,2017-12-20 13:10:50,2017-12-22 10:34:26,2017-12-22 10:34:26,2017-12-22 15:39:41,2017-12-22 15:39:42,2017-12-22 16:51:20,2017-12-22 16:51:20,2017-12-23 10:00:49,2017-12-23 10:00:49,2017-12-23 11:14:23,2017-12-23 11:14:23,2017-12-23 13:20:57,2017-12-23 13:20:57,2017-12-23 16:09:14,2017-12-23 16:09:14,2017-12-23 17:14:19,2017-12-23 17:14:19,2017-12-23 19:46:09,2017-12-23 19:46:09,2017-12-26 09:48:11,2017-12-26 09:48:12,2017-12-26 09:55:03,2017-12-26 09:55:03,2017-12-26 10:00:21,2017-12-26 10:00:21,2017-12-26 10:13:35,2017-12-26 10:13:35,2017-12-26 11:32:40,2017-12-26 11:32:40,2017-12-26 14:39:37,2017-12-26 14:39:37,2017-12-26 15:10:54,2017-12-26 15:10:54,2017-12-26 16:41:37,2017-12-26 16:41:37,2017-12-26 16:44:49,2017-12-26 16:44:49,2017-12-26 18:40:51,2017-12-26 18:40:51,2017-12-27 09:56:09,2017-12-27 09:56:09,2017-12-27 11:16:33,2017-12-27 11:16:33,2017-12-27 14:30:29,2017-12-27 14:30:29,2017-12-27 17:02:58,2017-12-27 17:02:59,2017-12-28 10:27:57,2017-12-28 10:27:57,2017-12-28 10:34:23,2017-12-28 10:34:23,2017-12-28 12:34:34,2017-12-28 12:34:34,2017-12-28 12:46:00,2017-12-28 12:46:00,2017-12-28 14:39:52,2017-12-28 14:39:52,2017-12-28 14:52:07,2017-12-28 14:52:07,2017-12-28 15:20:05,2017-12-28 15:20:05,2017-12-28 17:57:57,2017-12-28 17:57:57,2017-12-29 10:10:57,2017-12-29 10:10:57,2017-12-29 10:11:06,2017-12-29 10:11:06,2017-12-29 11:20:48,2017-12-29 11:20:48,2018-01-01 14:16:09,2018-01-01 14:16:09,2018-01-01 14:19:11,2018-01-01 14:19:11,2018-01-01 16:18:31,2018-01-01 16:18:31,2018-01-05 18:03:59,2018-01-05 18:03:59,2018-01-08 14:53:21,2018-01-08 14:53:21,2018-01-09 15:13:16,2018-01-09 15:13:16,2018-01-09 15:25:45,2018-01-09 15:25:45,2018-01-12 16:20:07,2018-01-12 16:20:07,2018-01-13 14:56:08,2018-01-13 14:56:08,2018-01-13 15:15:39,2018-01-13 15:15:39,2018-01-13 15:16:22,2018-01-13 15:16:22,2018-01-15 10:07:32,2018-01-15 10:07:32,2018-01-15 10:19:51,2018-01-15 10:19:51,2018-01-16 11:33:19,2018-01-16 11:33:19,2018-01-16 15:49:17,2018-01-16 15:49:17,2018-01-16 15:53:13,2018-01-16 15:53:13,2018-01-16 17:10:22,2018-01-16 17:10:22,2018-01-18 10:32:49,2018-01-18 10:32:49,2018-02-07 12:35:11,2018-02-07 12:35:11,2018-02-07 12:41:16,2018-04-05 18:20:22,2018-04-05 18:20:22,2018-05-22 11:21:55,2018-05-22 11:21:55,2018-05-22 11:23:39,2018-05-22 11:23:39,2018-06-01 14:24:36,2018-06-01 14:24:36,2018-06-23 16:12:29,2018-06-23 16:12:29,2018-06-30 15:57:20,2018-06-30 15:57:20,2018-07-06 14:58:58,2018-07-06 14:58:58,2018-12-07 10:58:02,2018-12-07 10:58:02,2018-12-08 10:04:26,2018-12-08 10:04:26,2018-12-08 11:00:30,2018-12-08 11:11:24,2018-12-08 11:11:24,2018-12-15 15:53:53,2018-12-15 15:53:53");





CREATE TABLE `delivery_pincode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pincode` int(10) unsigned NOT NULL DEFAULT '0',
  `country` int(11) NOT NULL DEFAULT '1',
  `state` int(100) DEFAULT '0',
  `city` int(100) DEFAULT '0',
  `area` varchar(100) DEFAULT NULL,
  `area_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=Local, 1=Zonal, 2=National',
  `isDelivery` tinyint(1) NOT NULL DEFAULT '0',
  `isCOD` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=Available, 1=Not Available',
  `isDelete` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3167 DEFAULT CHARSET=latin1;

INSERT INTO delivery_pincode VALUES("1","110001","1","31","3","Sansad Marg","2","1","1","0");
INSERT INTO delivery_pincode VALUES("2","110002","1","31","3","Indraprastha","2","1","1","0");
INSERT INTO delivery_pincode VALUES("3","110003","1","31","3","Lodi Road","2","1","1","0");
INSERT INTO delivery_pincode VALUES("4","110004","1","31","3","Rashtrapati Bhawan","2","1","1","0");
INSERT INTO delivery_pincode VALUES("5","110005","1","31","3","Karol Bagh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("6","110006","1","31","3","Delhi G.P.O. ","2","1","1","0");
INSERT INTO delivery_pincode VALUES("7","110007","1","31","3","Roop Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("8","110008","1","31","3","Patel Nagar West","2","1","1","0");
INSERT INTO delivery_pincode VALUES("9","110009","1","31","3","Nirankari Colony","2","1","1","0");
INSERT INTO delivery_pincode VALUES("10","110010","1","31","3","R R Hospital","2","1","1","0");
INSERT INTO delivery_pincode VALUES("11","110011","1","31","3","Nirman Bhawan","2","1","1","0");
INSERT INTO delivery_pincode VALUES("12","110012","1","31","3","Inderpuri","2","1","1","0");
INSERT INTO delivery_pincode VALUES("13","110013","1","31","3","Hazrat Nizamuddin","2","1","1","0");
INSERT INTO delivery_pincode VALUES("14","110014","1","31","3","Jungpura","2","1","1","0");
INSERT INTO delivery_pincode VALUES("15","110015","1","31","3","Ramesh Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("16","110016","1","31","3","Green Park Market","2","1","1","0");
INSERT INTO delivery_pincode VALUES("17","110017","1","31","3","Malviya Nagar (South Delhi)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("18","110018","1","31","3","Ashok Nagar (West Delhi)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("19","110019","1","31","3","Kalkaji","2","1","1","0");
INSERT INTO delivery_pincode VALUES("20","110020","1","31","3","Okhla Industrial Estate","2","1","1","0");
INSERT INTO delivery_pincode VALUES("21","110021","1","31","3","Moti Bagh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("22","110022","1","31","3","R K Puram Sector - 6 Postal SB","2","1","1","0");
INSERT INTO delivery_pincode VALUES("23","110023","1","31","3","Sarojini Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("24","110024","1","31","3","Defence Colony (South Delhi)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("25","110025","1","31","3","New Friends Colony","2","1","1","0");
INSERT INTO delivery_pincode VALUES("26","110026","1","31","3","Punjabi Bagh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("27","110027","1","31","3","Janta Market","2","1","1","0");
INSERT INTO delivery_pincode VALUES("28","110028","1","31","3","Naraina Industrial Estate","2","1","1","0");
INSERT INTO delivery_pincode VALUES("29","110029","1","31","3","Nauroji Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("30","110030","1","31","3","Gadaipur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("31","110031","1","31","3","Gandhi Nagar Bazar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("32","110032","1","31","3","Shahdara","2","1","1","0");
INSERT INTO delivery_pincode VALUES("33","110033","1","31","3","Adrash Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("34","110034","1","31","3","Rani Bagh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("35","110035","1","31","3","Ganeshpura","2","1","1","0");
INSERT INTO delivery_pincode VALUES("36","110036","1","31","3","Alipur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("37","110037","1","31","3","Gurgaon Road","2","1","1","0");
INSERT INTO delivery_pincode VALUES("38","110038","1","31","3","A F Rajokari","2","1","1","0");
INSERT INTO delivery_pincode VALUES("39","110039","1","31","3","Bawana","2","1","1","0");
INSERT INTO delivery_pincode VALUES("40","110040","1","31","3","Narela","2","1","1","0");
INSERT INTO delivery_pincode VALUES("41","110041","1","31","3","Nangloi","2","1","1","0");
INSERT INTO delivery_pincode VALUES("42","110042","1","31","3","Badli (North West Delhi)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("43","110043","1","31","3","Najafgarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("44","110044","1","31","3","Badarpur (South Delhi)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("45","110045","1","31","3","Palam Village","2","1","1","0");
INSERT INTO delivery_pincode VALUES("46","110046","1","31","3","Sagarpur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("47","110047","1","31","3","Arjungarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("48","110048","1","31","3","Masjid Moth","2","1","1","0");
INSERT INTO delivery_pincode VALUES("49","110049","1","31","3","Gautam Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("50","110050","1","31","3","UPSC","2","1","1","0");
INSERT INTO delivery_pincode VALUES("51","110051","1","31","3","Krishna Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("52","110052","1","31","3","Ashok Vihar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("53","110053","1","31","3","Brahampuri","2","1","1","0");
INSERT INTO delivery_pincode VALUES("54","110054","1","31","3","District Courts (North Delhi)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("55","110055","1","31","3","Multani Dhanda","2","1","1","0");
INSERT INTO delivery_pincode VALUES("56","110056","1","31","3","Shakur Basti Depot","2","1","1","0");
INSERT INTO delivery_pincode VALUES("57","110057","1","31","3","Vasant Vihar-1","2","1","1","0");
INSERT INTO delivery_pincode VALUES("58","110058","1","31","3","Jail Road (West Delhi)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("59","110059","1","31","3","Uttam Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("60","110060","1","31","3","Rajender Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("61","110061","1","31","3","Bijwasan","2","1","1","0");
INSERT INTO delivery_pincode VALUES("62","110062","1","31","3","Khanpur (South Delhi)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("63","110063","1","31","3","Paschim Vihar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("64","110064","1","31","3","Maya Puri","2","1","1","0");
INSERT INTO delivery_pincode VALUES("65","110065","1","31","3","Sant Nagar (South Delhi)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("66","110066","1","31","3","R K Puram (Main)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("67","110067","1","31","3","JNU New Campus","2","1","1","0");
INSERT INTO delivery_pincode VALUES("68","110068","1","31","3","Ignou","2","1","1","0");
INSERT INTO delivery_pincode VALUES("69","110069","1","31","3","Union Public Service Commission","2","1","1","0");
INSERT INTO delivery_pincode VALUES("70","110070","1","31","3","Vasant Kunj","2","1","1","0");
INSERT INTO delivery_pincode VALUES("71","110071","1","31","3","Chhawla","2","1","1","0");
INSERT INTO delivery_pincode VALUES("72","110072","1","31","3","CRPF Jharoda Kalan","2","1","1","0");
INSERT INTO delivery_pincode VALUES("73","110073","1","31","3","Ujwa","2","1","1","0");
INSERT INTO delivery_pincode VALUES("74","110074","1","31","3","Chattarpur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("75","110075","1","31","3","Dwarka Sec-6","2","1","1","0");
INSERT INTO delivery_pincode VALUES("76","110076","1","31","3","Sarita Vihar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("77","110077","1","31","3","Bagdola","2","1","1","0");
INSERT INTO delivery_pincode VALUES("78","110078","1","31","3","N.S.I.T. Dwarka","2","1","1","0");
INSERT INTO delivery_pincode VALUES("79","110080","1","31","0","Delhi","2","1","1","0");
INSERT INTO delivery_pincode VALUES("80","110081","1","31","3","Kanjhawla","2","1","1","0");
INSERT INTO delivery_pincode VALUES("81","110082","1","31","3","Khera Kalan","2","1","1","0");
INSERT INTO delivery_pincode VALUES("82","110083","1","31","3","Mangolpuri S Block","2","1","1","0");
INSERT INTO delivery_pincode VALUES("83","110084","1","31","3","Burari","2","1","1","0");
INSERT INTO delivery_pincode VALUES("84","110085","1","31","3","Rithala","2","1","1","0");
INSERT INTO delivery_pincode VALUES("85","110086","1","31","3","Begumpur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("86","110087","1","31","3","Jwala Puri","2","1","1","0");
INSERT INTO delivery_pincode VALUES("87","110088","1","31","3","Haiderpur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("88","110089","1","31","3","Rohini Sector 15","2","1","1","0");
INSERT INTO delivery_pincode VALUES("89","110090","1","31","0","Delhi","2","1","1","0");
INSERT INTO delivery_pincode VALUES("90","110091","1","31","3","Patparganj","2","1","1","0");
INSERT INTO delivery_pincode VALUES("91","110092","1","31","3","Yozna Vihar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("92","110093","1","31","3","Loni Road Housing Complex","2","1","1","0");
INSERT INTO delivery_pincode VALUES("93","110094","1","31","3","Sonia Vihar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("94","110095","1","31","3","Jhilmil","2","1","1","0");
INSERT INTO delivery_pincode VALUES("95","110096","1","31","3","Ghazipur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("96","110097","1","31","0","kapashera","2","1","1","0");
INSERT INTO delivery_pincode VALUES("97","110101","1","31","3","PMO OFFICE","2","1","1","0");
INSERT INTO delivery_pincode VALUES("98","110103","1","31","3","TIMES OF INDIA","2","1","1","0");
INSERT INTO delivery_pincode VALUES("99","110104","1","31","3","ICAI","2","1","1","0");
INSERT INTO delivery_pincode VALUES("100","110105","1","31","3","SENA BHAWAN","2","1","1","0");
INSERT INTO delivery_pincode VALUES("101","110106","1","31","3","VAYU BHAWAN ","2","1","1","0");
INSERT INTO delivery_pincode VALUES("102","110107","1","31","3","UDYOG BHAWAN","2","1","1","0");
INSERT INTO delivery_pincode VALUES("103","110108","1","31","3","NIRMAN BHAWAN ","2","1","1","0");
INSERT INTO delivery_pincode VALUES("104","110109","1","31","3","CENTRE REVENUE BLDG","2","1","1","0");
INSERT INTO delivery_pincode VALUES("105","110110","1","31","3","VIKAS BHAWAN ","2","1","1","0");
INSERT INTO delivery_pincode VALUES("106","110112","1","31","3","POLICE HQ ","2","1","1","0");
INSERT INTO delivery_pincode VALUES("107","110113","1","31","3","DELHI SECTRIAT","2","1","1","0");
INSERT INTO delivery_pincode VALUES("108","110114","1","31","3","KRISH VHAWAN","2","1","1","0");
INSERT INTO delivery_pincode VALUES("109","110115","1","31","3","SHASHTRI BHAWAN","2","1","1","0");
INSERT INTO delivery_pincode VALUES("110","110116","1","31","3","DAK BHAWAN","2","1","1","0");
INSERT INTO delivery_pincode VALUES("111","110117","1","31","3","SANCHAR BHAWAN","2","1","1","0");
INSERT INTO delivery_pincode VALUES("112","110118","1","31","3","RAIL BHAWAN","2","1","1","0");
INSERT INTO delivery_pincode VALUES("113","110119","1","31","3","SHRAM SHAKTI BHAWAN","2","1","1","0");
INSERT INTO delivery_pincode VALUES("114","110120","1","31","3","INS BHAWAN","2","1","1","0");
INSERT INTO delivery_pincode VALUES("115","110122","1","31","3","HT HOUSE","2","1","1","0");
INSERT INTO delivery_pincode VALUES("116","110124","1","31","3","CAG","2","1","1","0");
INSERT INTO delivery_pincode VALUES("117","110125","1","31","3","RAJENDERA PLACE","2","1","1","0");
INSERT INTO delivery_pincode VALUES("118","110301","1","31","3","CBSE","2","1","1","0");
INSERT INTO delivery_pincode VALUES("119","110302","1","31","3","DSSSB","2","1","1","0");
INSERT INTO delivery_pincode VALUES("120","110501","1","31","3","AGRI INDIA","2","1","1","0");
INSERT INTO delivery_pincode VALUES("121","110502","1","31","3","AIMA","2","1","1","0");
INSERT INTO delivery_pincode VALUES("122","110503","1","31","3","DELHI HIGH COURT","2","1","1","0");
INSERT INTO delivery_pincode VALUES("123","110504","1","31","3","SSC","2","1","1","0");
INSERT INTO delivery_pincode VALUES("124","110510","1","31","3","MINISTRY OF ENVIORMENT","2","1","1","0");
INSERT INTO delivery_pincode VALUES("125","110511","1","31","3","LOK NAYAK BHAWAN","2","1","1","0");
INSERT INTO delivery_pincode VALUES("126","110512","1","31","3","PRAGATI VIHAR HOSTEL","2","1","1","0");
INSERT INTO delivery_pincode VALUES("127","110601","1","31","3","IIT DELHI","2","1","1","0");
INSERT INTO delivery_pincode VALUES("128","110602","1","31","3","KENDRI VIDALYA SJE","2","1","1","0");
INSERT INTO delivery_pincode VALUES("129","110603","1","31","3","CENTRAL SOCIAL WELFARE","2","1","1","0");
INSERT INTO delivery_pincode VALUES("130","110604","1","31","3","EAST BLOCK","2","1","1","0");
INSERT INTO delivery_pincode VALUES("131","110605","1","31","3","WEST BLOCK","2","1","1","0");
INSERT INTO delivery_pincode VALUES("132","110606","1","31","3","SEWA BHAWAN","2","1","1","0");
INSERT INTO delivery_pincode VALUES("133","110607","1","31","3","BHIKAJI CAMA PLACE","2","1","1","0");
INSERT INTO delivery_pincode VALUES("134","110608","1","31","3","AIIMS","2","1","1","0");
INSERT INTO delivery_pincode VALUES("135","110609","1","31","3","HELPAGE INDIA","2","1","1","0");
INSERT INTO delivery_pincode VALUES("136","120002","1","31","0","Gurgaon","2","1","1","0");
INSERT INTO delivery_pincode VALUES("137","121001","1","0","0","Faridabad NIT","2","1","1","0");
INSERT INTO delivery_pincode VALUES("138","121002","1","0","0","Faridabad City","2","1","1","0");
INSERT INTO delivery_pincode VALUES("139","121003","1","0","0","Mathura Road Faridabad","2","1","1","0");
INSERT INTO delivery_pincode VALUES("140","121004","1","0","0","N.T.P.C./sector-10 Faridabad","2","1","1","0");
INSERT INTO delivery_pincode VALUES("141","121005","1","0","0","Jawahar Colony Faridabad","2","1","1","0");
INSERT INTO delivery_pincode VALUES("142","121006","1","0","0","G.T. Road Faridabad","2","1","1","0");
INSERT INTO delivery_pincode VALUES("143","121007","1","0","0","Escortsnagar Faridabad","2","1","1","0");
INSERT INTO delivery_pincode VALUES("144","121008","1","0","0","Faridabad Sector 29","2","1","1","0");
INSERT INTO delivery_pincode VALUES("145","121009","1","0","0","Surajkund Faridabad","2","1","1","0");
INSERT INTO delivery_pincode VALUES("146","121010","1","0","0","Nhpc Colony Faridabad","2","1","1","0");
INSERT INTO delivery_pincode VALUES("147","121011","1","31","0","Faridabad","2","1","1","0");
INSERT INTO delivery_pincode VALUES("148","121012","1","0","0","Sector-21D ","2","1","1","0");
INSERT INTO delivery_pincode VALUES("149","121102","1","0","0","Palwal","2","1","1","0");
INSERT INTO delivery_pincode VALUES("150","122001","1","0","0","Gurgaon","2","1","1","0");
INSERT INTO delivery_pincode VALUES("151","122002","1","0","0","DLF QE","2","1","1","0");
INSERT INTO delivery_pincode VALUES("152","122003","1","0","0","Gurgaon Sector 45","2","1","1","0");
INSERT INTO delivery_pincode VALUES("153","122004","1","0","0","Narsinghpur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("154","122005","1","0","0","Air Force","2","1","1","0");
INSERT INTO delivery_pincode VALUES("155","122006","1","0","0","Railwary Road","2","1","1","0");
INSERT INTO delivery_pincode VALUES("156","122007","1","0","0","Industrial Estate (Gurgaon)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("157","122008","1","0","0","DLF Ph-II","2","1","1","0");
INSERT INTO delivery_pincode VALUES("158","122009","1","0","0","Galleria DLF-IV","2","1","1","0");
INSERT INTO delivery_pincode VALUES("159","122010","1","0","0","DLF Ph-III","2","1","1","0");
INSERT INTO delivery_pincode VALUES("160","122011","1","0","0","Gurgaon Sector 56","2","1","1","0");
INSERT INTO delivery_pincode VALUES("161","122012","1","0","0","Gurgaon Sector 56","2","1","1","0");
INSERT INTO delivery_pincode VALUES("162","122014","1","31","0","Gurgaon SARHAUL","2","1","1","0");
INSERT INTO delivery_pincode VALUES("163","122015","1","0","0","Palam Road","2","1","1","0");
INSERT INTO delivery_pincode VALUES("164","122016","1","0","0","Industrial Complex Dundahera","2","1","1","0");
INSERT INTO delivery_pincode VALUES("165","122017","1","0","0","Palam Vihar (Gurgaon)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("166","122018","1","0","0","Gurgaon South City II","2","1","1","0");
INSERT INTO delivery_pincode VALUES("167","122022","1","31","0","Gurgaon Sec-27, Gurgaon","2","1","1","0");
INSERT INTO delivery_pincode VALUES("168","122050","1","0","0","Gurgaon South City II","2","1","1","0");
INSERT INTO delivery_pincode VALUES("169","122051","1","0","0","Nsg Camp Manesar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("170","124001","1","0","0","Rohtak","2","1","1","0");
INSERT INTO delivery_pincode VALUES("171","124103","1","0","0","Jhajjar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("172","124507","1","0","0","Bahadurgarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("173","125001","1","0","0","Hisar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("174","125002","1","0","0","Hisar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("175","125003","1","0","0","Hisar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("176","125004","1","0","0","Ha U Hisar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("177","125005","1","0","0","Vidut Nagar Hisar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("178","125050","1","0","0","Nai Mandi Fatehabad","2","1","1","0");
INSERT INTO delivery_pincode VALUES("179","125055","1","0","0","Sirsa","2","1","1","0");
INSERT INTO delivery_pincode VALUES("180","125120","1","0","0","Tohana","2","1","1","0");
INSERT INTO delivery_pincode VALUES("181","125133","1","0","0","Jakhal Mandi","2","1","1","0");
INSERT INTO delivery_pincode VALUES("182","126102","1","0","0","Jind","2","1","1","0");
INSERT INTO delivery_pincode VALUES("183","126112","1","0","0","Jind","2","1","1","0");
INSERT INTO delivery_pincode VALUES("184","126113","1","0","0","Jind","2","1","1","0");
INSERT INTO delivery_pincode VALUES("185","126115","1","0","0","Jind","2","1","1","0");
INSERT INTO delivery_pincode VALUES("186","126116","1","0","0","Jind","2","1","1","0");
INSERT INTO delivery_pincode VALUES("187","127021","1","0","0","Bhiwani","2","1","1","0");
INSERT INTO delivery_pincode VALUES("188","127306","1","0","0","Charkhi Dadri City","2","1","1","0");
INSERT INTO delivery_pincode VALUES("189","131001","1","0","0","SONIPAT","2","1","1","0");
INSERT INTO delivery_pincode VALUES("190","131021","1","0","0","BAHALGARH","2","1","1","0");
INSERT INTO delivery_pincode VALUES("191","131027","1","0","0","MURTHAL","2","1","1","0");
INSERT INTO delivery_pincode VALUES("192","131028","1","0","0","KUNDLI","2","1","1","0");
INSERT INTO delivery_pincode VALUES("193","131029","1","0","0","RAI","2","1","1","0");
INSERT INTO delivery_pincode VALUES("194","131101","1","0","0","Ganaur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("195","132001","1","0","0","Karnal","2","1","1","0");
INSERT INTO delivery_pincode VALUES("196","132103","1","0","0","Panipat","2","1","1","0");
INSERT INTO delivery_pincode VALUES("197","132106","1","0","0","Panipat NFL","2","1","1","0");
INSERT INTO delivery_pincode VALUES("198","133001","1","0","0","Ambala G.P.O.","2","1","1","0");
INSERT INTO delivery_pincode VALUES("199","133004","1","0","0","Kuldeep Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("200","133005","1","0","0","Babyal","2","1","1","0");
INSERT INTO delivery_pincode VALUES("201","133006","1","0","0","Ind-estate","2","1","1","0");
INSERT INTO delivery_pincode VALUES("202","134002","1","0","0","Ambala City","2","1","1","0");
INSERT INTO delivery_pincode VALUES("203","134003","1","0","0","Ambala City","2","1","1","0");
INSERT INTO delivery_pincode VALUES("204","134007","1","0","0","Baldev Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("205","134102","1","0","0","Pinjore","2","1","1","0");
INSERT INTO delivery_pincode VALUES("206","134104","1","0","0","C.R.P.F. Pinjore","2","1","1","0");
INSERT INTO delivery_pincode VALUES("207","134107","1","0","0","Chandi Mandir","2","1","1","0");
INSERT INTO delivery_pincode VALUES("208","134108","1","0","0","G.K. Panchkula","2","1","1","0");
INSERT INTO delivery_pincode VALUES("209","134109","1","0","0","Panchkula Sector 8","2","1","1","0");
INSERT INTO delivery_pincode VALUES("210","134112","1","0","0","Panchkula Sector 4","2","1","1","0");
INSERT INTO delivery_pincode VALUES("211","134113","1","0","0","Sector 15 Panchkula","2","1","1","0");
INSERT INTO delivery_pincode VALUES("212","134114","1","0","0","Mansa  Devi Sec-5","2","1","1","0");
INSERT INTO delivery_pincode VALUES("213","134115","1","0","0","Panchkula Sector 12","2","1","1","0");
INSERT INTO delivery_pincode VALUES("214","134116","1","0","0","Sector 20 Panchkula","2","1","1","0");
INSERT INTO delivery_pincode VALUES("215","134117","1","0","0","Panchkula","2","1","1","0");
INSERT INTO delivery_pincode VALUES("216","135001","1","0","0","Yamunanagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("217","135002","1","0","0","Jagdhari Work Shop","2","1","1","0");
INSERT INTO delivery_pincode VALUES("218","135003","1","0","0","Jagadhri","2","1","1","0");
INSERT INTO delivery_pincode VALUES("219","136027","1","0","0","Kaithal","2","1","1","0");
INSERT INTO delivery_pincode VALUES("220","136118","1","0","0","Kurukshetra","2","1","1","0");
INSERT INTO delivery_pincode VALUES("221","136132","1","0","0","Ladwa","2","1","1","0");
INSERT INTO delivery_pincode VALUES("222","136135","1","0","0","Shahabad(M)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("223","140001","1","0","0","Ropar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("224","140113","1","0","0","Ghanauli","2","1","1","0");
INSERT INTO delivery_pincode VALUES("225","140301","1","0","0","Kharar (Rupnagar)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("226","140306","1","0","0","Manauli","2","1","1","0");
INSERT INTO delivery_pincode VALUES("227","140307","1","0","0","Landran","2","1","1","0");
INSERT INTO delivery_pincode VALUES("228","140308","1","0","0","Sohana","2","1","1","0");
INSERT INTO delivery_pincode VALUES("229","140401","1","0","0","Rajpura","2","1","1","0");
INSERT INTO delivery_pincode VALUES("230","140501","1","0","0","Lalru","2","1","1","0");
INSERT INTO delivery_pincode VALUES("231","140506","1","0","0","Derabassi","2","1","1","0");
INSERT INTO delivery_pincode VALUES("232","140507","1","0","0","Derabassi","2","1","1","0");
INSERT INTO delivery_pincode VALUES("233","140601","1","0","0","Banur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("234","140603","1","0","0","Zirakpur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("235","140604","1","0","0","Baltana","2","1","1","0");
INSERT INTO delivery_pincode VALUES("236","141001","1","0","0","Ludhiana","2","1","1","0");
INSERT INTO delivery_pincode VALUES("237","141002","1","0","0","Model Town (Ludhiana)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("238","141003","1","0","0","Shimlapuri","2","1","1","0");
INSERT INTO delivery_pincode VALUES("239","141004","1","0","0","P.A.U.","2","1","1","0");
INSERT INTO delivery_pincode VALUES("240","141005","1","0","0","Gne College","2","1","1","0");
INSERT INTO delivery_pincode VALUES("241","141006","1","0","0","Gne College","2","1","1","0");
INSERT INTO delivery_pincode VALUES("242","141007","1","0","0","Basti Jodhewal","2","1","1","0");
INSERT INTO delivery_pincode VALUES("243","141008","1","0","0","Madhopuri","2","1","1","0");
INSERT INTO delivery_pincode VALUES("244","141009","1","0","0","Moti Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("245","141010","1","0","0","Moti Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("246","141011","1","0","0","Rajguru Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("247","141012","1","0","0","Rajguru Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("248","141013","1","0","0","Basant Avenue","2","1","1","0");
INSERT INTO delivery_pincode VALUES("249","141014","1","0","0","Daba Road","2","1","1","0");
INSERT INTO delivery_pincode VALUES("250","141015","1","0","0","Mundian Kalan","2","1","1","0");
INSERT INTO delivery_pincode VALUES("251","141016","1","0","0","Lohora","2","1","1","0");
INSERT INTO delivery_pincode VALUES("252","141017","1","0","0","Jugiana","2","1","1","0");
INSERT INTO delivery_pincode VALUES("253","141304","1","0","0","Khanna","2","1","1","0");
INSERT INTO delivery_pincode VALUES("254","141309","1","0","0","Khanna","2","1","1","0");
INSERT INTO delivery_pincode VALUES("255","141310","1","0","0","Khanna","2","1","1","0");
INSERT INTO delivery_pincode VALUES("256","142001","1","0","0","Moga","2","1","1","0");
INSERT INTO delivery_pincode VALUES("257","142021","1","0","0","Baddowal","2","1","1","0");
INSERT INTO delivery_pincode VALUES("258","142027","1","0","0","Ayali Kalan","2","1","1","0");
INSERT INTO delivery_pincode VALUES("259","143001","1","0","0","Amritsar G.P.O. ","2","1","1","0");
INSERT INTO delivery_pincode VALUES("260","143002","1","0","0","Khalsa College","2","1","1","0");
INSERT INTO delivery_pincode VALUES("261","143003","1","0","0","J.F.Mill","2","1","1","0");
INSERT INTO delivery_pincode VALUES("262","143004","1","0","0","J.F.Mill","2","1","1","0");
INSERT INTO delivery_pincode VALUES("263","143005","1","0","0","Guru Nanak Dev University","2","1","1","0");
INSERT INTO delivery_pincode VALUES("264","143006","1","0","0","New Amritsar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("265","143007","1","0","0","Amritsar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("266","143008","1","0","0","Sjs Avenue","2","1","1","0");
INSERT INTO delivery_pincode VALUES("267","143009","1","0","0","Fatahpur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("268","143010","1","0","0","Pratapnagar (Amritsar)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("269","143021","1","0","0","Pratapnagar (Amritsar)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("270","143022","1","0","0","Kot Mit Singh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("271","143101","1","0","0","Raja Sansi","2","1","1","0");
INSERT INTO delivery_pincode VALUES("272","143102","1","0","0","Ajnala","2","1","1","0");
INSERT INTO delivery_pincode VALUES("273","143104","1","0","0","Rayon & Silk Mill","2","1","1","0");
INSERT INTO delivery_pincode VALUES("274","143105","1","0","0","Chheharta","2","1","1","0");
INSERT INTO delivery_pincode VALUES("275","143106","1","0","0","Amritsar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("276","143109","1","0","0","Chogawan","2","1","1","0");
INSERT INTO delivery_pincode VALUES("277","143501","1","0","0","Verka","2","1","1","0");
INSERT INTO delivery_pincode VALUES("278","143505","1","0","0","Batala","2","1","1","0");
INSERT INTO delivery_pincode VALUES("279","143521","1","0","0","Gurdaspur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("280","143531","1","0","0","Gurdaspur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("281","144001","1","0","0","Jalandhar City","2","1","1","0");
INSERT INTO delivery_pincode VALUES("282","144002","1","0","0","Athola","2","1","1","0");
INSERT INTO delivery_pincode VALUES("283","144003","1","0","0","Model Town (Jalandhar)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("284","144004","1","0","0","Hoshiarpur Road","2","1","1","0");
INSERT INTO delivery_pincode VALUES("285","144005","1","0","0","Jalandhar Cantt","2","1","1","0");
INSERT INTO delivery_pincode VALUES("286","144006","1","0","0","BSF Campus","2","1","1","0");
INSERT INTO delivery_pincode VALUES("287","144007","1","0","0","Ladhewali","2","1","1","0");
INSERT INTO delivery_pincode VALUES("288","144008","1","0","0","Adarsh Nagar (Jalandhar)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("289","144009","1","0","0","Chogitti","2","1","1","0");
INSERT INTO delivery_pincode VALUES("290","144010","1","0","0","Dhanowali","2","1","1","0");
INSERT INTO delivery_pincode VALUES("291","144011","1","0","0","R.E.C. Jalandhar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("292","144012","1","0","0","Reru","2","1","1","0");
INSERT INTO delivery_pincode VALUES("293","144013","1","0","0","Nagra (Jalandhar)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("294","144014","1","0","0","Tower Town Colony","2","1","1","0");
INSERT INTO delivery_pincode VALUES("295","144021","1","0","0","Basti Bawa Khel","2","1","1","0");
INSERT INTO delivery_pincode VALUES("296","144022","1","0","0","Garha (Jalandhar)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("297","144023","1","0","0","Dakoha","2","1","1","0");
INSERT INTO delivery_pincode VALUES("298","144027","1","0","0","Suranussi","2","1","1","0");
INSERT INTO delivery_pincode VALUES("299","144031","1","0","0","Rurka Kalan","2","1","1","0");
INSERT INTO delivery_pincode VALUES("300","144032","1","0","0","Samrai","2","1","1","0");
INSERT INTO delivery_pincode VALUES("301","144033","1","0","0","Jandiala","2","1","1","0");
INSERT INTO delivery_pincode VALUES("302","144034","1","0","0","Bundala (Jalandhar)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("303","144035","1","0","0","Partappura","2","1","1","0");
INSERT INTO delivery_pincode VALUES("304","144036","1","0","0","Bilga","2","1","1","0");
INSERT INTO delivery_pincode VALUES("305","144037","1","0","0","Pasla","2","1","1","0");
INSERT INTO delivery_pincode VALUES("306","144038","1","0","0","Pasla","2","1","1","0");
INSERT INTO delivery_pincode VALUES("307","144039","1","0","0","Nurmahal","2","1","1","0");
INSERT INTO delivery_pincode VALUES("308","144040","1","0","0","Nakoder","2","1","1","0");
INSERT INTO delivery_pincode VALUES("309","144041","1","0","0","Mehatpur (Jalandhar)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("310","144042","1","0","0","Shankar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("311","144043","1","0","0","Sarih","2","1","1","0");
INSERT INTO delivery_pincode VALUES("312","144044","1","0","0","Sidhwan R.S.","2","1","1","0");
INSERT INTO delivery_pincode VALUES("313","144203","1","0","0","Tanda (Gurdaspur)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("314","144211","1","0","0","Mukerian","2","1","1","0");
INSERT INTO delivery_pincode VALUES("315","144311","1","0","0","Dhesian Kahna","2","1","1","0");
INSERT INTO delivery_pincode VALUES("316","144401","1","0","0","Phagwara","2","1","1","0");
INSERT INTO delivery_pincode VALUES("317","144402","1","0","0","Satnampura","2","1","1","0");
INSERT INTO delivery_pincode VALUES("318","144403","1","0","0","Ranipur (Kapurthala)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("319","144405","1","0","0","Narur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("320","144407","1","0","0","Domeli","2","1","1","0");
INSERT INTO delivery_pincode VALUES("321","144408","1","0","0","Panchhat","2","1","1","0");
INSERT INTO delivery_pincode VALUES("322","144410","1","0","0","Phillaur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("323","144416","1","0","0","Apra","2","1","1","0");
INSERT INTO delivery_pincode VALUES("324","144505","1","0","0","Baharwal","2","1","1","0");
INSERT INTO delivery_pincode VALUES("325","144506","1","0","0","Mahil Gailan","2","1","1","0");
INSERT INTO delivery_pincode VALUES("326","144507","1","0","0","Mokandpur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("327","144508","1","0","0","Naura","2","1","1","0");
INSERT INTO delivery_pincode VALUES("328","144514","1","0","0","Nawanshahar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("329","144515","1","0","0","Jadla","2","1","1","0");
INSERT INTO delivery_pincode VALUES("330","144517","1","0","0","Rahon","2","1","1","0");
INSERT INTO delivery_pincode VALUES("331","144524","1","0","0","Saroa","2","1","1","0");
INSERT INTO delivery_pincode VALUES("332","144526","1","0","0","Mehandpur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("333","144527","1","0","0","Garhshanker","2","1","1","0");
INSERT INTO delivery_pincode VALUES("334","144528","1","0","0","Rampur Bilron","2","1","1","0");
INSERT INTO delivery_pincode VALUES("335","144601","1","0","0","Kapurthala","2","1","1","0");
INSERT INTO delivery_pincode VALUES("336","144602","1","0","0","Rail Coach Factory","2","1","1","0");
INSERT INTO delivery_pincode VALUES("337","144620","1","0","0","Sheikhupur (Kapurthala)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("338","144621","1","0","0","Begowal","2","1","1","0");
INSERT INTO delivery_pincode VALUES("339","144622","1","0","0","Bholath","2","1","1","0");
INSERT INTO delivery_pincode VALUES("340","144623","1","0","0","Kala Sanghian","2","1","1","0");
INSERT INTO delivery_pincode VALUES("341","144624","1","0","0","Nadala","2","1","1","0");
INSERT INTO delivery_pincode VALUES("342","144625","1","0","0","Sidhwan Dona","2","1","1","0");
INSERT INTO delivery_pincode VALUES("343","144626","1","0","0","Dalla","2","1","1","0");
INSERT INTO delivery_pincode VALUES("344","144628","1","0","0","Thatha Jadid","2","1","1","0");
INSERT INTO delivery_pincode VALUES("345","144629","1","0","0","Lohian","2","1","1","0");
INSERT INTO delivery_pincode VALUES("346","144630","1","0","0","Bopa Rai Kalan (Jalandhar)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("347","144632","1","0","0","Chachoki","2","1","1","0");
INSERT INTO delivery_pincode VALUES("348","144702","1","0","0","Shahkot","2","1","1","0");
INSERT INTO delivery_pincode VALUES("349","144802","1","0","0","Jagatjit Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("350","144803","1","0","0","Dialpur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("351","144804","1","0","0","Dhilwan","2","1","1","0");
INSERT INTO delivery_pincode VALUES("352","144806","1","0","0","Pattar Kalan","2","1","1","0");
INSERT INTO delivery_pincode VALUES("353","144819","1","0","0","Raipur Pir Bux Wala","2","1","1","0");
INSERT INTO delivery_pincode VALUES("354","145001","1","0","0","Pathankot","2","1","1","0");
INSERT INTO delivery_pincode VALUES("355","145023","1","0","0","Sujanpur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("356","147001","1","0","0","Patiala","2","1","1","0");
INSERT INTO delivery_pincode VALUES("357","147002","1","0","0","University(Patiala)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("358","147003","1","0","0","Gurbax Colony","2","1","1","0");
INSERT INTO delivery_pincode VALUES("359","147004","1","0","0","Tripri","2","1","1","0");
INSERT INTO delivery_pincode VALUES("360","147005","1","0","0","Majithia Enclave","2","1","1","0");
INSERT INTO delivery_pincode VALUES("361","147103","1","0","0","Sanaur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("362","147201","1","0","0","Nabha","2","1","1","0");
INSERT INTO delivery_pincode VALUES("363","147301","1","0","0","Mandigobindgarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("364","148023","1","0","0","Malerkotla","2","1","1","0");
INSERT INTO delivery_pincode VALUES("365","148026","1","0","0","Alloarakh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("366","148033","1","0","0","Moonak","2","1","1","0");
INSERT INTO delivery_pincode VALUES("367","148101","1","0","0","Barnala","2","1","1","0");
INSERT INTO delivery_pincode VALUES("368","151001","1","0","0","Bathinda","2","1","1","0");
INSERT INTO delivery_pincode VALUES("369","151002","1","0","0","Gndtp Bathinda","2","1","1","0");
INSERT INTO delivery_pincode VALUES("370","151003","1","0","0","Nfl Bathinda","2","1","1","0");
INSERT INTO delivery_pincode VALUES("371","151004","1","0","0","Bathinda Cantt","2","1","1","0");
INSERT INTO delivery_pincode VALUES("372","151005","1","0","0","Railway Colony (Bathinda)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("373","151101","1","0","0","Bhucho Mandi","2","1","1","0");
INSERT INTO delivery_pincode VALUES("374","151103","1","0","0","Ballian Wali","2","1","1","0");
INSERT INTO delivery_pincode VALUES("375","151201","1","0","0","Goniana Mandi","2","1","1","0");
INSERT INTO delivery_pincode VALUES("376","151202","1","0","0","Jaitu","2","1","1","0");
INSERT INTO delivery_pincode VALUES("377","151203","1","0","0","Faridkot","2","1","1","0");
INSERT INTO delivery_pincode VALUES("378","151204","1","0","0","Kotkapura","2","1","1","0");
INSERT INTO delivery_pincode VALUES("379","151301","1","0","0","Raman","2","1","1","0");
INSERT INTO delivery_pincode VALUES("380","151505","1","0","0","Mansa (Mansa)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("381","152001","1","0","0","Ferozepur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("382","152002","1","0","0","Ferozepur City","2","1","1","0");
INSERT INTO delivery_pincode VALUES("383","152024","1","0","0","Jalalabad (W)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("384","152026","1","0","0","Muktsar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("385","152101","1","0","0","Gidderbaha","2","1","1","0");
INSERT INTO delivery_pincode VALUES("386","152107","1","0","0","Malout","2","1","1","0");
INSERT INTO delivery_pincode VALUES("387","152116","1","0","0","Abohar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("388","160001","1","0","0","Vidhansadan","2","1","1","0");
INSERT INTO delivery_pincode VALUES("389","160002","1","0","0","Hallomajra","2","1","1","0");
INSERT INTO delivery_pincode VALUES("390","160003","1","0","0","Aerodrome","2","1","1","0");
INSERT INTO delivery_pincode VALUES("391","160004","1","0","0","Airforce Highground","2","1","1","0");
INSERT INTO delivery_pincode VALUES("392","160005","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("393","160006","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("394","160007","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("395","160008","1","0","0","Airforce Highground","2","1","1","0");
INSERT INTO delivery_pincode VALUES("396","160009","1","0","0","Sector 8(Chandgarh)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("397","160010","1","0","0","Sector 8(Chandgarh)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("398","160011","1","0","0","Sector 10 (Chandigarh)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("399","160012","1","0","0","Sector 12 (Chandigarh)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("400","160013","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("401","160014","1","0","0","Sector 14 (Chandigarh)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("402","160015","1","0","0","Sector 15 Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("403","160016","1","0","0","Sector 15 Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("404","160017","1","0","0","Chandigarh G.P.O. ","2","1","1","0");
INSERT INTO delivery_pincode VALUES("405","160018","1","0","0","Sector 18 (Chandigarh)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("406","160019","1","0","0","Sector 19 (Chandigarh)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("407","160020","1","0","0","Sector 20 (Chandigarh)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("408","160021","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("409","160022","1","0","0","Sector 21 (Chandigarh)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("410","160023","1","0","0","Sector 23 ( Chandigarh)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("411","160024","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("412","160025","1","0","0","Maloya Colony","2","1","1","0");
INSERT INTO delivery_pincode VALUES("413","160026","1","0","0","Maloya Colony","2","1","1","0");
INSERT INTO delivery_pincode VALUES("414","160027","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("415","160028","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("416","160029","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("417","160030","1","0","0","Sector 29 (Chandigarh)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("418","160031","1","0","0","Sector 29 (Chandigarh)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("419","160032","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("420","160033","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("421","160034","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("422","160035","1","0","0","Sector 29 (Chandigarh)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("423","160036","1","0","0","Sector 36 (Chandigarh)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("424","160037","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("425","160038","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("426","160039","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("427","160040","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("428","160041","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("429","160042","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("430","160043","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("431","160044","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("432","160045","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("433","160046","1","0","0","Sector 36 (Chandigarh)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("434","160047","1","0","0","Sector 44 (Chandigarh)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("435","160048","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("436","160049","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("437","160050","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("438","160051","1","0","0","Sector 44 (Chandigarh)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("439","160052","1","0","0","Mohali","2","1","1","0");
INSERT INTO delivery_pincode VALUES("440","160053","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("441","160054","1","0","0","Mohali","2","1","1","0");
INSERT INTO delivery_pincode VALUES("442","160055","1","0","0","Chandigarh Sector 55","2","1","1","0");
INSERT INTO delivery_pincode VALUES("443","160058","1","0","0","Chandigarh Sector 55","2","1","1","0");
INSERT INTO delivery_pincode VALUES("444","160059","1","0","0","Chandigarh Sector 59","2","1","1","0");
INSERT INTO delivery_pincode VALUES("445","160060","1","0","0","Mohali","2","1","1","0");
INSERT INTO delivery_pincode VALUES("446","160062","1","0","0","Chandigarh Sector 61","2","1","1","0");
INSERT INTO delivery_pincode VALUES("447","160064","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("448","160065","1","0","0","Mohali","2","1","1","0");
INSERT INTO delivery_pincode VALUES("449","160067","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("450","160069","1","0","0","Mohali","2","1","1","0");
INSERT INTO delivery_pincode VALUES("451","160070","1","0","0","Mohali","2","1","1","0");
INSERT INTO delivery_pincode VALUES("452","160071","1","0","0","Chandigarh Sector 71","2","1","1","0");
INSERT INTO delivery_pincode VALUES("453","160101","1","0","0","Manimajra","2","1","1","0");
INSERT INTO delivery_pincode VALUES("454","160102","1","0","0","Mauli Jagran","2","1","1","0");
INSERT INTO delivery_pincode VALUES("455","160103","1","0","0","Naya Gaon (Mohali)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("456","160106","1","0","0","Chandigarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("457","166031","1","0","0","Dhakaoli","2","1","1","0");
INSERT INTO delivery_pincode VALUES("458","173205","1","0","0","BADDI","2","1","1","0");
INSERT INTO delivery_pincode VALUES("459","173211","1","0","0","Rabon Solan","2","1","1","0");
INSERT INTO delivery_pincode VALUES("460","173212","1","0","0","Main Market ","2","1","1","0");
INSERT INTO delivery_pincode VALUES("461","173213","1","0","0","Chamba Ghat","2","1","1","0");
INSERT INTO delivery_pincode VALUES("462","174103","1","0","0","JHARMAJRI","2","1","1","0");
INSERT INTO delivery_pincode VALUES("463","180001","1","0","0","Jammu","2","1","1","0");
INSERT INTO delivery_pincode VALUES("464","180002","1","0","0","Talab Tillo","2","1","1","0");
INSERT INTO delivery_pincode VALUES("465","180003","1","0","0","Jammu Cantt","2","1","1","0");
INSERT INTO delivery_pincode VALUES("466","180004","1","0","0","Gandhinagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("467","180005","1","0","0","Karan Nagar (Jammu)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("468","180006","1","0","0","Bain Bajalta","2","1","1","0");
INSERT INTO delivery_pincode VALUES("469","180007","1","0","0","Janipur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("470","180010","1","0","0","Gangyal","2","1","1","0");
INSERT INTO delivery_pincode VALUES("471","180011","1","0","0","Sainik Colony","2","1","1","0");
INSERT INTO delivery_pincode VALUES("472","180012","1","0","0","New Fruit Market","2","1","1","0");
INSERT INTO delivery_pincode VALUES("473","180013","1","0","0","Roopnagar Jammu Tawi","2","1","1","0");
INSERT INTO delivery_pincode VALUES("474","180015","1","0","0","Chani Himat","2","1","1","0");
INSERT INTO delivery_pincode VALUES("475","180016","1","0","0","General Bus Stand (Jammu)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("476","181124","1","0","0","Bsf Camp Paloura","2","1","1","0");
INSERT INTO delivery_pincode VALUES("477","181133","1","0","0","Bari Brahmna","2","1","1","0");
INSERT INTO delivery_pincode VALUES("478","181205","1","0","0","Muthi","2","1","1","0");
INSERT INTO delivery_pincode VALUES("479","181206","1","0","0","Dumana","2","1","1","0");
INSERT INTO delivery_pincode VALUES("480","201001","1","0","0","Ghaziabad","2","1","1","0");
INSERT INTO delivery_pincode VALUES("481","201002","1","0","0","Vivekanand Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("482","201003","1","0","0","Meerut Road","2","1","1","0");
INSERT INTO delivery_pincode VALUES("483","201004","1","0","0","Hindon Air Field","2","1","1","0");
INSERT INTO delivery_pincode VALUES("484","201005","1","0","0","Sahibabad","2","1","1","0");
INSERT INTO delivery_pincode VALUES("485","201006","1","0","0","Chikamberpur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("486","201007","1","0","0","Mohan Nagar (Ghaziabad)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("487","201008","1","0","0","Vidyut Nagar (Gautam Buddha Nagar)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("488","201009","1","0","0","Ghaziabad City","2","1","1","0");
INSERT INTO delivery_pincode VALUES("489","201010","1","0","0","Bharat Nagar (Ghaziabad)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("490","201011","1","0","0","Chander Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("491","201012","1","0","0","Kaushambi","2","1","1","0");
INSERT INTO delivery_pincode VALUES("492","201013","1","0","0","Govindpuram","2","1","1","0");
INSERT INTO delivery_pincode VALUES("493","201014","1","0","0","Shipra Sun City","2","1","1","0");
INSERT INTO delivery_pincode VALUES("494","201204","1","0","0","Modi Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("495","201301","1","0","0","Noida","2","1","1","0");
INSERT INTO delivery_pincode VALUES("496","201302","1","0","0","Hindan Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("497","201303","1","0","0","Noida Sector 30","2","1","1","0");
INSERT INTO delivery_pincode VALUES("498","201304","1","0","0","Maharishi Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("499","201305","1","0","0","Nepz Post Office","2","1","1","0");
INSERT INTO delivery_pincode VALUES("500","201306","1","0","0","I.A. Surajpur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("501","201307","1","0","0","Noida Sector 34","2","1","1","0");
INSERT INTO delivery_pincode VALUES("502","201308","1","0","0","Noida Sector 34","2","1","1","0");
INSERT INTO delivery_pincode VALUES("503","201309","1","0","0","Noida Sector 62","2","1","1","0");
INSERT INTO delivery_pincode VALUES("504","201310","1","0","0","Alpha Greater Noida","2","1","1","0");
INSERT INTO delivery_pincode VALUES("505","202001","1","0","0","ALIGARH","2","1","1","0");
INSERT INTO delivery_pincode VALUES("506","202002","1","0","0","ALIGARH","2","1","1","0");
INSERT INTO delivery_pincode VALUES("507","208001","1","0","0","Kanpur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("508","208002","1","0","0","Nawabganj","2","1","1","0");
INSERT INTO delivery_pincode VALUES("509","208003","1","0","0","Anwarganj","2","1","1","0");
INSERT INTO delivery_pincode VALUES("510","208004","1","0","0","Kanpur Cantt.","2","1","1","0");
INSERT INTO delivery_pincode VALUES("511","208005","1","0","0","Hns Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("512","208006","1","0","0","Govind Nagar (Kanpur Nagar)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("513","208007","1","0","0","Harjinder Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("514","208008","1","0","0","Chakeri Aerodrum","2","1","1","0");
INSERT INTO delivery_pincode VALUES("515","208009","1","0","0","Armapore","2","1","1","0");
INSERT INTO delivery_pincode VALUES("516","208010","1","0","0","Shiwans Tanney","2","1","1","0");
INSERT INTO delivery_pincode VALUES("517","208011","1","0","0","Yashoda Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("518","208012","1","0","0","Kaushalpuri","2","1","1","0");
INSERT INTO delivery_pincode VALUES("519","208013","1","0","0","Dmsrde","2","1","1","0");
INSERT INTO delivery_pincode VALUES("520","208014","1","0","0","Juhi Colony","2","1","1","0");
INSERT INTO delivery_pincode VALUES("521","208015","1","0","0","New Pac Lines","2","1","1","0");
INSERT INTO delivery_pincode VALUES("522","208016","1","0","0","Iit","2","1","1","0");
INSERT INTO delivery_pincode VALUES("523","208017","1","0","0","Nsi","2","1","1","0");
INSERT INTO delivery_pincode VALUES("524","208018","1","0","0","Nsi","2","1","1","0");
INSERT INTO delivery_pincode VALUES("525","208019","1","0","0","Rawatpur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("526","208020","1","0","0","Panki (Kanpur Nagar)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("527","208021","1","0","0","N H Road","2","1","1","0");
INSERT INTO delivery_pincode VALUES("528","208022","1","0","0","Ratan Lal Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("529","208023","1","0","0","Munshipurwa","2","1","1","0");
INSERT INTO delivery_pincode VALUES("530","208024","1","0","0","Bima Vihar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("531","208025","1","0","0","Naveen Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("532","208026","1","0","0","Indira Nagar (Kanpur Nagar)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("533","208027","1","0","0","Barra","2","1","1","0");
INSERT INTO delivery_pincode VALUES("534","209801","1","0","0","Magarwara","2","1","1","0");
INSERT INTO delivery_pincode VALUES("535","209861","1","0","0","Unnao","2","1","1","0");
INSERT INTO delivery_pincode VALUES("536","209862","1","0","0","UNNAO","2","1","1","0");
INSERT INTO delivery_pincode VALUES("537","211001","1","0","0","Allahabad","2","1","1","0");
INSERT INTO delivery_pincode VALUES("538","211002","1","0","0","Allahabad Kty.","2","1","1","0");
INSERT INTO delivery_pincode VALUES("539","211003","1","0","0","Allahabad City","2","1","1","0");
INSERT INTO delivery_pincode VALUES("540","211004","1","0","0","Cavellary Lines","2","1","1","0");
INSERT INTO delivery_pincode VALUES("541","211005","1","0","0","Allahabad Fort","2","1","1","0");
INSERT INTO delivery_pincode VALUES("542","211006","1","0","0","Allahpur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("543","211007","1","0","0","Agriculture Institute","2","1","1","0");
INSERT INTO delivery_pincode VALUES("544","211008","1","0","0","Arail","2","1","1","0");
INSERT INTO delivery_pincode VALUES("545","211009","1","0","0","Udyog Nagar (Allahabad)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("546","211010","1","0","0","I T I, Naini","2","1","1","0");
INSERT INTO delivery_pincode VALUES("547","211011","1","0","0","Rajrooppur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("548","211012","1","0","0","Bamrauli","2","1","1","0");
INSERT INTO delivery_pincode VALUES("549","211014","1","0","0","C D A (P)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("550","211015","1","0","0","C D A (P)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("551","211016","1","0","0","Karela Bagh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("552","211017","1","0","0","Allahabad High Court","2","1","1","0");
INSERT INTO delivery_pincode VALUES("553","211018","1","0","0","Public Service Commission","2","1","1","0");
INSERT INTO delivery_pincode VALUES("554","221001","1","0","0","Varanasi","2","1","1","0");
INSERT INTO delivery_pincode VALUES("555","221002","1","0","0","Varanasi Cantt","2","1","1","0");
INSERT INTO delivery_pincode VALUES("556","221003","1","0","0","Vsi Shivpur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("557","221004","1","0","0","West Colony","2","1","1","0");
INSERT INTO delivery_pincode VALUES("558","221005","1","0","0","Malviya Nagar (Varanasi)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("559","221006","1","0","0","Babatpur Ad","2","1","1","0");
INSERT INTO delivery_pincode VALUES("560","221007","1","0","0","Sarnath","2","1","1","0");
INSERT INTO delivery_pincode VALUES("561","221010","1","0","0","Aurangabad (Varanasi)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("562","221103","1","0","0","Manduadih","2","1","1","0");
INSERT INTO delivery_pincode VALUES("563","221105","1","0","0","Harhua","2","1","1","0");
INSERT INTO delivery_pincode VALUES("564","221106","1","0","0","Industrial Estate (Varanasi)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("565","221109","1","0","0","Bazardiha","2","1","1","0");
INSERT INTO delivery_pincode VALUES("566","222001","1","0","0","Jaunpur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("567","222002","1","0","0","Civil Court (Jaunpur)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("568","224001","1","0","0","Faizabad","2","1","1","0");
INSERT INTO delivery_pincode VALUES("569","224123","1","0","0","Ayodhya RS","2","1","1","0");
INSERT INTO delivery_pincode VALUES("570","225001","1","0","0","Barabanki","2","1","1","0");
INSERT INTO delivery_pincode VALUES("571","225002","1","0","0","Barabanki Sugar Mill","2","1","1","0");
INSERT INTO delivery_pincode VALUES("572","225003","1","0","0","Gandhi Aashram","2","1","1","0");
INSERT INTO delivery_pincode VALUES("573","225301","1","0","0","Dewa Sharif","2","1","1","0");
INSERT INTO delivery_pincode VALUES("574","225414","1","0","0","Zaidpur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("575","226001","1","0","0","Lucknow G.P.O. ","2","1","1","0");
INSERT INTO delivery_pincode VALUES("576","226002","1","0","0","Arjunganj","2","1","1","0");
INSERT INTO delivery_pincode VALUES("577","226003","1","0","0","Lucknow Chowk","2","1","1","0");
INSERT INTO delivery_pincode VALUES("578","226004","1","0","0","Charbagh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("579","226005","1","0","0","Sujanpura","2","1","1","0");
INSERT INTO delivery_pincode VALUES("580","226006","1","0","0","Sant Market","2","1","1","0");
INSERT INTO delivery_pincode VALUES("581","226007","1","0","0","Nadwa","2","1","1","0");
INSERT INTO delivery_pincode VALUES("582","226008","1","0","0","Sarojini Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("583","226009","1","0","0","Amausi Ad","2","1","1","0");
INSERT INTO delivery_pincode VALUES("584","226010","1","0","0","Gomtinagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("585","226011","1","0","0","Manaknagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("586","226012","1","0","0","32 Bn PAC ","2","1","1","0");
INSERT INTO delivery_pincode VALUES("587","226013","1","0","0","Iim Mubarakpur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("588","226014","1","0","0","Sgpgi","2","1","1","0");
INSERT INTO delivery_pincode VALUES("589","226015","1","0","0","Cimap","2","1","1","0");
INSERT INTO delivery_pincode VALUES("590","226016","1","0","0","Ghazipur (Lucknow)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("591","226017","1","0","0","Alamnagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("592","226018","1","0","0","Aminabad Park","2","1","1","0");
INSERT INTO delivery_pincode VALUES("593","226019","1","0","0","Industria Area Chinhat","2","1","1","0");
INSERT INTO delivery_pincode VALUES("594","226020","1","0","0","D M Road","2","1","1","0");
INSERT INTO delivery_pincode VALUES("595","226021","1","0","0","Batha Sabauli","2","1","1","0");
INSERT INTO delivery_pincode VALUES("596","226022","1","0","0","Kalyanpur (Lucknow)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("597","226023","1","0","0","Manasnagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("598","226024","1","0","0","Aliganj Extension","2","1","1","0");
INSERT INTO delivery_pincode VALUES("599","226025","1","0","0","B R A University","2","1","1","0");
INSERT INTO delivery_pincode VALUES("600","229001","1","0","0","Raebarely","2","1","1","0");
INSERT INTO delivery_pincode VALUES("601","229010","1","0","0","ITI (Raebareli)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("602","229302","1","0","0","Fursatganj","2","1","1","0");
INSERT INTO delivery_pincode VALUES("603","229316","1","0","0","Ratapur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("604","231001","1","0","0","Mirzapur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("605","231307","1","0","0","Mirzapur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("606","243001","1","0","0","Bareilly","2","1","1","0");
INSERT INTO delivery_pincode VALUES("607","243002","1","0","0","Air Force Station Bareilly","2","1","1","0");
INSERT INTO delivery_pincode VALUES("608","243003","1","0","0","Baljati","2","1","1","0");
INSERT INTO delivery_pincode VALUES("609","243005","1","0","0","Marwari Ganj","2","1","1","0");
INSERT INTO delivery_pincode VALUES("610","243006","1","0","0","R.K.University","2","1","1","0");
INSERT INTO delivery_pincode VALUES("611","243122","1","0","0","Bhandsar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("612","243123","1","0","0","P.A.C.Dso","2","1","1","0");
INSERT INTO delivery_pincode VALUES("613","243202","1","0","0","Bhojipura","2","1","1","0");
INSERT INTO delivery_pincode VALUES("614","243501","1","0","0","B R Factory","2","1","1","0");
INSERT INTO delivery_pincode VALUES("615","243502","1","0","0","C.B. Ganj","2","1","1","0");
INSERT INTO delivery_pincode VALUES("616","244001","1","0","0","Moradabad","2","1","1","0");
INSERT INTO delivery_pincode VALUES("617","246149","1","0","0","Kotdwara","2","1","1","0");
INSERT INTO delivery_pincode VALUES("618","247661","1","0","0","Bhagwanpur (Haridwar)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("619","247667","1","0","0","Roorkee","2","1","1","0");
INSERT INTO delivery_pincode VALUES("620","248001","1","0","0","Dehradun G.P.O. ","2","1","1","0");
INSERT INTO delivery_pincode VALUES("621","248002","1","0","0","Clementtown","2","1","1","0");
INSERT INTO delivery_pincode VALUES("622","248003","1","0","0","Dehradun Cantt","2","1","1","0");
INSERT INTO delivery_pincode VALUES("623","248005","1","0","0","I.I.P.","2","1","1","0");
INSERT INTO delivery_pincode VALUES("624","248006","1","0","0","Newforest","2","1","1","0");
INSERT INTO delivery_pincode VALUES("625","248007","1","0","0","Ambiwala","2","1","1","0");
INSERT INTO delivery_pincode VALUES("626","248008","1","0","0","Raipur(O.F)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("627","248009","1","0","0","Rajpur (Dehradun)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("628","248110","1","0","0","Defence Colony","2","1","1","0");
INSERT INTO delivery_pincode VALUES("629","248115","1","0","0","Dehradun","2","1","1","0");
INSERT INTO delivery_pincode VALUES("630","248121","1","0","0","Ajabpur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("631","248146","1","0","0","Seemadwar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("632","248161","1","0","0","Dehradun","2","1","1","0");
INSERT INTO delivery_pincode VALUES("633","248195","1","0","0","I.P.E.","2","1","1","0");
INSERT INTO delivery_pincode VALUES("634","248201","1","0","0","Dehradun","2","1","1","0");
INSERT INTO delivery_pincode VALUES("635","249401","1","0","0","Haridwar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("636","249402","1","0","0","Bahadrabad(industrial Area)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("637","249403","1","0","0","BHEL (Haridwar)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("638","249404","1","0","0","Kankhal","2","1","1","0");
INSERT INTO delivery_pincode VALUES("639","249407","1","0","0","Arya Nagar (Haridwar)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("640","250001","1","0","0","Meerut Cantt","2","1","1","0");
INSERT INTO delivery_pincode VALUES("641","250002","1","0","0","Meerut City","2","1","1","0");
INSERT INTO delivery_pincode VALUES("642","250102","1","0","0","I. E. Partapur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("643","250103","1","0","0","I. E. Partapur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("644","251001","1","0","0","Muzaffarnagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("645","251002","1","0","0","Khala Par","2","1","1","0");
INSERT INTO delivery_pincode VALUES("646","251003","1","0","0","Industrial Estate (Muzaffarnagar)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("647","251301","1","0","0","Alipur Kheri","2","1","1","0");
INSERT INTO delivery_pincode VALUES("648","251306","1","0","0","Baghra (Muzaffarnagar)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("649","261001","1","0","0","Sitapur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("650","263153","1","0","0","RUDRAPUR CITY","2","1","1","0");
INSERT INTO delivery_pincode VALUES("651","273001","1","0","0","Gorakhpur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("652","273003","1","0","0","Arogyamandir","2","1","1","0");
INSERT INTO delivery_pincode VALUES("653","273004","1","0","0","Ashok Nagar (Gorakhpur)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("654","273005","1","0","0","Gita Press","2","1","1","0");
INSERT INTO delivery_pincode VALUES("655","273006","1","0","0","Gita Vatika","2","1","1","0");
INSERT INTO delivery_pincode VALUES("656","273008","1","0","0","Kunraghat","2","1","1","0");
INSERT INTO delivery_pincode VALUES("657","273009","1","0","0","Gorakhpur University","2","1","1","0");
INSERT INTO delivery_pincode VALUES("658","273010","1","0","0","M.M.M.E.College","2","1","1","0");
INSERT INTO delivery_pincode VALUES("659","273012","1","0","0","GR Railway Station","2","1","1","0");
INSERT INTO delivery_pincode VALUES("660","273013","1","0","0","B.R.D Medical College","2","1","1","0");
INSERT INTO delivery_pincode VALUES("661","273014","1","0","0","Pac Camp","2","1","1","0");
INSERT INTO delivery_pincode VALUES("662","273015","1","0","0","Gorakhnath Mandir","2","1","1","0");
INSERT INTO delivery_pincode VALUES("663","274001","1","0","0","Deoria","2","1","1","0");
INSERT INTO delivery_pincode VALUES("664","274509","1","0","0","Salaempur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("665","274702","1","0","0","Bhatpar Rani","2","1","1","0");
INSERT INTO delivery_pincode VALUES("666","276001","1","0","0","AZAMGARH","2","1","1","0");
INSERT INTO delivery_pincode VALUES("667","277001","1","0","0","Ballia","2","1","1","0");
INSERT INTO delivery_pincode VALUES("668","281001","1","0","0","Mathura","2","1","1","0");
INSERT INTO delivery_pincode VALUES("669","281002","1","0","0","Uttar Pradesh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("670","281003","1","0","0","Gayatri Tapo Bhoomi","2","1","1","0");
INSERT INTO delivery_pincode VALUES("671","281004","1","0","0","Krishna Nagar (Mathura)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("672","281005","1","0","0","Mathura Refinery","2","1","1","0");
INSERT INTO delivery_pincode VALUES("673","281006","1","0","0","Refinery Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("674","281121","1","0","0","G.N. Bazar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("675","282001","1","0","0","Agra","2","1","1","0");
INSERT INTO delivery_pincode VALUES("676","282002","1","0","0","Gokulpura","2","1","1","0");
INSERT INTO delivery_pincode VALUES("677","282003","1","0","0","Agra Fort","2","1","1","0");
INSERT INTO delivery_pincode VALUES("678","282004","1","0","0","Agra University","2","1","1","0");
INSERT INTO delivery_pincode VALUES("679","282005","1","0","0","New Agra","2","1","1","0");
INSERT INTO delivery_pincode VALUES("680","282006","1","0","0","Bamrauli Katara","2","1","1","0");
INSERT INTO delivery_pincode VALUES("681","282007","1","0","0","Sikandra (Agra)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("682","282008","1","0","0","Kheria Airport","2","1","1","0");
INSERT INTO delivery_pincode VALUES("683","282009","1","0","0","C.O.D.","2","1","1","0");
INSERT INTO delivery_pincode VALUES("684","282010","1","0","0","Shahaganj (Agra)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("685","283203","1","0","0","Firozabad","2","1","1","0");
INSERT INTO delivery_pincode VALUES("686","283204","1","0","0","Tundla","2","1","1","0");
INSERT INTO delivery_pincode VALUES("687","301001","1","0","0","ALWAR","2","1","1","0");
INSERT INTO delivery_pincode VALUES("688","301002","1","0","0","MOTI DOONGRI","2","1","1","0");
INSERT INTO delivery_pincode VALUES("689","301019","1","0","0","Bhiwadi","2","1","1","0");
INSERT INTO delivery_pincode VALUES("690","301701","1","0","0","BAHROR","2","1","1","0");
INSERT INTO delivery_pincode VALUES("691","301705","1","0","0","NEEMRANA","2","1","1","0");
INSERT INTO delivery_pincode VALUES("692","301706","1","0","0","SHAHJAHANPUR","2","1","1","0");
INSERT INTO delivery_pincode VALUES("693","301707","1","0","0","Tapukara","2","1","1","0");
INSERT INTO delivery_pincode VALUES("694","302001","1","0","0","Jaipur G.P.O. ","2","1","1","0");
INSERT INTO delivery_pincode VALUES("695","302002","1","0","0","Amer Road","2","1","1","0");
INSERT INTO delivery_pincode VALUES("696","302003","1","0","0","Jaipur City","2","1","1","0");
INSERT INTO delivery_pincode VALUES("697","302004","1","0","0","Jawahar Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("698","302005","1","0","0","High Court (Jaipur)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("699","302006","1","0","0","Jaipur R.S.","2","1","1","0");
INSERT INTO delivery_pincode VALUES("700","302007","1","0","0","Jaipur R.S.","2","1","1","0");
INSERT INTO delivery_pincode VALUES("701","302008","1","0","0","Jaipur R.S.","2","1","1","0");
INSERT INTO delivery_pincode VALUES("702","302009","1","0","0","Jaipur R.S.","2","1","1","0");
INSERT INTO delivery_pincode VALUES("703","302010","1","0","0","Jaipur R.S.","2","1","1","0");
INSERT INTO delivery_pincode VALUES("704","302011","1","0","0","Jaipur R.S.","2","1","1","0");
INSERT INTO delivery_pincode VALUES("705","302012","1","0","0","Jhotwara","2","1","1","0");
INSERT INTO delivery_pincode VALUES("706","302013","1","0","0","Akhepura","2","1","1","0");
INSERT INTO delivery_pincode VALUES("707","302015","1","0","0","Gandhi Nagar (Jaipur)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("708","302016","1","0","0","Shastri Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("709","302017","1","0","0","Malviya Nagar (Jaipur)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("710","302018","1","0","0","Durgapura","2","1","1","0");
INSERT INTO delivery_pincode VALUES("711","302019","1","0","0","Shyam Nagar (Jaipur)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("712","302020","1","0","0","Mansarovar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("713","302021","1","0","0","Vaishali Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("714","302022","1","0","0","Sitapura Industrial Area","2","1","1","0");
INSERT INTO delivery_pincode VALUES("715","302023","1","0","0","Sitapura Industrial Area","2","1","1","0");
INSERT INTO delivery_pincode VALUES("716","302024","1","0","0","Heerapura","2","1","1","0");
INSERT INTO delivery_pincode VALUES("717","302025","1","0","0","Jagatpura","2","1","1","0");
INSERT INTO delivery_pincode VALUES("718","302026","1","0","0","Bhankrota","2","1","1","0");
INSERT INTO delivery_pincode VALUES("719","302027","1","0","0","Crpf Campus  Lalwas","2","1","1","0");
INSERT INTO delivery_pincode VALUES("720","302028","1","0","0","Amer","2","1","1","0");
INSERT INTO delivery_pincode VALUES("721","302029","1","0","0","Airport Sanganer","2","1","1","0");
INSERT INTO delivery_pincode VALUES("722","302032","1","0","0","Harmada","2","1","1","0");
INSERT INTO delivery_pincode VALUES("723","302033","1","0","0","Pratap Nagar Housing Board","2","1","1","0");
INSERT INTO delivery_pincode VALUES("724","302034","1","0","0","Panchyawala","2","1","1","0");
INSERT INTO delivery_pincode VALUES("725","302039","1","0","0","Amba Bari","2","1","1","0");
INSERT INTO delivery_pincode VALUES("726","303001","1","0","0","Andhi","2","1","1","0");
INSERT INTO delivery_pincode VALUES("727","303002","1","0","0","Achrol","2","1","1","0");
INSERT INTO delivery_pincode VALUES("728","303003","1","0","0","Med","2","1","1","0");
INSERT INTO delivery_pincode VALUES("729","303005","1","0","0","Phagi","2","1","1","0");
INSERT INTO delivery_pincode VALUES("730","303006","1","0","0","Madhorajpura","2","1","1","0");
INSERT INTO delivery_pincode VALUES("731","303007","1","0","0","Bagru","2","1","1","0");
INSERT INTO delivery_pincode VALUES("732","303008","1","0","0","Dudu","2","1","1","0");
INSERT INTO delivery_pincode VALUES("733","303009","1","0","0","Mozmabad","2","1","1","0");
INSERT INTO delivery_pincode VALUES("734","303010","1","0","0","Bichoon","2","1","1","0");
INSERT INTO delivery_pincode VALUES("735","303012","1","0","0","Kanota","2","1","1","0");
INSERT INTO delivery_pincode VALUES("736","303101","1","0","0","Kanota","2","1","1","0");
INSERT INTO delivery_pincode VALUES("737","303102","1","0","0","Virat Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("738","303103","1","0","0","Shahpura","2","1","1","0");
INSERT INTO delivery_pincode VALUES("739","303104","1","0","0","Manoharpur (Jaipur)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("740","303105","1","0","0","Nareda","2","1","1","0");
INSERT INTO delivery_pincode VALUES("741","303106","1","0","0","Paota(Jaipur)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("742","303107","1","0","0","Pragpura","2","1","1","0");
INSERT INTO delivery_pincode VALUES("743","303108","1","0","0","Kotputli","2","1","1","0");
INSERT INTO delivery_pincode VALUES("744","303109","1","0","0","Jamwaramgarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("745","303110","1","0","0","Rajnauta","2","1","1","0");
INSERT INTO delivery_pincode VALUES("746","303119","1","0","0","Bhabroo","2","1","1","0");
INSERT INTO delivery_pincode VALUES("747","303120","1","0","0","Gathwadi","2","1","1","0");
INSERT INTO delivery_pincode VALUES("748","303301","1","0","0","Bassi (Jaipur)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("749","303305","1","0","0","Banskho","2","1","1","0");
INSERT INTO delivery_pincode VALUES("750","303328","1","0","0","Jobner","2","1","1","0");
INSERT INTO delivery_pincode VALUES("751","303329","1","0","0","A C Jobner","2","1","1","0");
INSERT INTO delivery_pincode VALUES("752","303331","1","0","0","Asalpur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("753","303338","1","0","0","Akoda","2","1","1","0");
INSERT INTO delivery_pincode VALUES("754","303339","1","0","0","Manda Bhim Singh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("755","303348","1","0","0","Naraina","2","1","1","0");
INSERT INTO delivery_pincode VALUES("756","303601","1","0","0","Amarsar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("757","303602","1","0","0","Badhal","2","1","1","0");
INSERT INTO delivery_pincode VALUES("758","303603","1","0","0","Renwal","2","1","1","0");
INSERT INTO delivery_pincode VALUES("759","303604","1","0","0","Sambhar Lake","2","1","1","0");
INSERT INTO delivery_pincode VALUES("760","303701","1","0","0","Jahota","2","1","1","0");
INSERT INTO delivery_pincode VALUES("761","303702","1","0","0","Chomu","2","1","1","0");
INSERT INTO delivery_pincode VALUES("762","303704","1","0","0","Jaitpura I A","2","1","1","0");
INSERT INTO delivery_pincode VALUES("763","303706","1","0","0","Kalwad","2","1","1","0");
INSERT INTO delivery_pincode VALUES("764","303712","1","0","0","Govindgarh (Jaipur)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("765","303801","1","0","0","Kaladera","2","1","1","0");
INSERT INTO delivery_pincode VALUES("766","303802","1","0","0","Tripolia Chomu","2","1","1","0");
INSERT INTO delivery_pincode VALUES("767","303803","1","0","0","Khejroli","2","1","1","0");
INSERT INTO delivery_pincode VALUES("768","303804","1","0","0","Etwa Bhopji","2","1","1","0");
INSERT INTO delivery_pincode VALUES("769","303805","1","0","0","Morija","2","1","1","0");
INSERT INTO delivery_pincode VALUES("770","303806","1","0","0","Samod","2","1","1","0");
INSERT INTO delivery_pincode VALUES("771","303807","1","0","0","Udaipuria","2","1","1","0");
INSERT INTO delivery_pincode VALUES("772","303901","1","0","0","Chaksu","2","1","1","0");
INSERT INTO delivery_pincode VALUES("773","303903","1","0","0","Shivdaspura","2","1","1","0");
INSERT INTO delivery_pincode VALUES("774","303904","1","0","0","Chittora Renwal","2","1","1","0");
INSERT INTO delivery_pincode VALUES("775","303905","1","0","0","Watika","2","1","1","0");
INSERT INTO delivery_pincode VALUES("776","303908","1","0","0","Kotkhawada","2","1","1","0");
INSERT INTO delivery_pincode VALUES("777","304021","1","0","0","Baroni","2","1","1","0");
INSERT INTO delivery_pincode VALUES("778","304022","1","0","0","Banasthali Vidya Peeth","2","1","1","0");
INSERT INTO delivery_pincode VALUES("779","304804","1","0","0","Ambapura Colony Daulta","2","1","1","0");
INSERT INTO delivery_pincode VALUES("780","305001","1","0","0","Ajmer","2","1","1","0");
INSERT INTO delivery_pincode VALUES("781","305002","1","0","0","Adarsh Nagar (Ajmer)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("782","305003","1","0","0","Ajai Nagra","2","1","1","0");
INSERT INTO delivery_pincode VALUES("783","305004","1","0","0","Chorsiawas","2","1","1","0");
INSERT INTO delivery_pincode VALUES("784","305005","1","0","0","Crpf Ajmer","2","1","1","0");
INSERT INTO delivery_pincode VALUES("785","305006","1","0","0","Crpf Ajmer","2","1","1","0");
INSERT INTO delivery_pincode VALUES("786","305007","1","0","0","Gc Road Ajmer","2","1","1","0");
INSERT INTO delivery_pincode VALUES("787","305801","1","0","0","Madanganj Kishangarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("788","305802","1","0","0","Dhan Mandi - Kishan Garh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("789","305901","1","0","0","BEAWER","2","1","1","0");
INSERT INTO delivery_pincode VALUES("790","306401","1","0","0","Pali Marwar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("791","311001","1","0","0","Bhilwara","2","1","1","0");
INSERT INTO delivery_pincode VALUES("792","312001","1","0","0","Chittorgarh","2","1","1","0");
INSERT INTO delivery_pincode VALUES("793","313001","1","0","0","Udaipur Station Road","2","1","1","0");
INSERT INTO delivery_pincode VALUES("794","313002","1","0","0","Udaipur H Magri","2","1","1","0");
INSERT INTO delivery_pincode VALUES("795","313003","1","0","0","Udaipur Industrial Area","2","1","1","0");
INSERT INTO delivery_pincode VALUES("796","313004","1","0","0","Udaipur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("797","322001","1","0","0","Sawaimadhopur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("798","322021","1","0","0","Alanpur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("799","323001","1","0","0","Bundi","2","1","1","0");
INSERT INTO delivery_pincode VALUES("800","324001","1","0","0","Kota","2","1","1","0");
INSERT INTO delivery_pincode VALUES("801","324002","1","0","0","Kota Jn.","2","1","1","0");
INSERT INTO delivery_pincode VALUES("802","324003","1","0","0","Industerial Estate Kota","2","1","1","0");
INSERT INTO delivery_pincode VALUES("803","324004","1","0","0","Udyog Puri Kota","2","1","1","0");
INSERT INTO delivery_pincode VALUES("804","324005","1","0","0","Mahaveer Nagar Kota","2","1","1","0");
INSERT INTO delivery_pincode VALUES("805","324006","1","0","0","Kota City","2","1","1","0");
INSERT INTO delivery_pincode VALUES("806","324007","1","0","0","New Grain Mandi Kota","2","1","1","0");
INSERT INTO delivery_pincode VALUES("807","324008","1","0","0","Thermal Colony Kota","2","1","1","0");
INSERT INTO delivery_pincode VALUES("808","324009","1","0","0","Dadabari Kota","2","1","1","0");
INSERT INTO delivery_pincode VALUES("809","327001","1","0","0","Banswara","2","1","1","0");
INSERT INTO delivery_pincode VALUES("810","332001","1","0","0","Sikar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("811","332402","1","0","0","Palsana (Sikar)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("812","332403","1","0","0","Ranoli (Sikar)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("813","332404","1","0","0","Bhopatpura","2","1","1","0");
INSERT INTO delivery_pincode VALUES("814","332405","1","0","0","Shishu","2","1","1","0");
INSERT INTO delivery_pincode VALUES("815","333001","1","0","0","Jhunjhunu","2","1","1","0");
INSERT INTO delivery_pincode VALUES("816","334001","1","0","0","Bikaner","2","1","1","0");
INSERT INTO delivery_pincode VALUES("817","334002","1","0","0","Bikaner","2","1","1","0");
INSERT INTO delivery_pincode VALUES("818","334003","1","0","0","Pawanpuri (Bikaner)","2","1","1","0");
INSERT INTO delivery_pincode VALUES("819","334004","1","0","0","Bangalanagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("820","334005","1","0","0","Bangalanagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("821","334006","1","0","0","Bichhwal Ind.Area","2","1","1","0");
INSERT INTO delivery_pincode VALUES("822","335001","1","0","0","Sriganganagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("823","335512","1","0","0","Hanumangarh Jn.","2","1","1","0");
INSERT INTO delivery_pincode VALUES("824","335513","1","0","0","Amarpura Theri","2","1","1","0");
INSERT INTO delivery_pincode VALUES("825","341001","1","0","0","Nagaur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("826","342001","1","0","0","Jodhpur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("827","342002","1","0","0","Jodhpur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("828","342003","1","0","0","Gandhi Maidan","2","1","1","0");
INSERT INTO delivery_pincode VALUES("829","342004","1","0","0","Jodhpur","2","1","1","0");
INSERT INTO delivery_pincode VALUES("830","342005","1","0","0","Jhalamand","2","1","1","0");
INSERT INTO delivery_pincode VALUES("831","342006","1","0","0","Jodhpur Laxmi Nagar","2","1","1","0");
INSERT INTO delivery_pincode VALUES("832","342007","1","0","0","Jodhpur K.U.M. Mandore Road","2","1","1","0");
INSERT INTO delivery_pincode VALUES("833","342008","1","0","0","Nandanwan","2","1","1","0");
INSERT INTO delivery_pincode VALUES("834","342009","1","0","0","Nandanwan","2","1","1","0");
INSERT INTO delivery_pincode VALUES("835","342010","1","0","0","Nandanwan","2","1","1","0");
INSERT INTO delivery_pincode VALUES("836","342011","1","0","0","Jodhpur Agency","2","1","1","0");
INSERT INTO delivery_pincode VALUES("837","344022","1","0","0","Asada","2","1","1","0");
INSERT INTO delivery_pincode VALUES("838","345001","1","0","0","Jaisalmer","2","1","1","0");
INSERT INTO delivery_pincode VALUES("839","360001","1","0","0","Rajkot","0","1","1","0");
INSERT INTO delivery_pincode VALUES("840","360002","1","0","0","Kherdi","0","1","1","0");
INSERT INTO delivery_pincode VALUES("841","360003","1","0","0","Anandpar Navagam","0","1","1","0");
INSERT INTO delivery_pincode VALUES("842","360004","1","0","0","Mavdi","0","1","1","0");
INSERT INTO delivery_pincode VALUES("843","360005","1","0","0","Rajkot Sau Uni Area","0","1","1","0");
INSERT INTO delivery_pincode VALUES("844","360006","1","0","0","Rajkot Bhomeshwar Plot","0","1","1","0");
INSERT INTO delivery_pincode VALUES("845","360007","1","0","0","Rajkot  Raiya Road","0","1","1","0");
INSERT INTO delivery_pincode VALUES("846","360575","1","0","0","Porbandar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("847","360577","1","0","0","Porbandar G.I.D.C.","1","1","1","0");
INSERT INTO delivery_pincode VALUES("848","360578","1","0","0","Chhaya","1","1","1","0");
INSERT INTO delivery_pincode VALUES("849","360579","1","0","0","Bokhira","1","1","1","0");
INSERT INTO delivery_pincode VALUES("850","361001","1","0","0","Jamnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("851","361002","1","0","0","Jamnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("852","361003","1","0","0","Jamnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("853","361004","1","0","0","Jamnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("854","361005","1","0","0","Jamnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("855","361006","1","0","0","Jamnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("856","363641","1","0","0","Morbi GIDC","1","1","1","0");
INSERT INTO delivery_pincode VALUES("857","364001","1","0","0","Bhavnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("858","364002","1","0","0","Adhewada","1","1","1","0");
INSERT INTO delivery_pincode VALUES("859","364003","1","0","0","Bhavnagar Para","1","1","1","0");
INSERT INTO delivery_pincode VALUES("860","364004","1","0","0","Bhavnagar Chitra","1","1","1","0");
INSERT INTO delivery_pincode VALUES("861","364005","1","0","0","Bhavnagar Anandnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("862","364006","1","0","0","Bhavnagar Kumbharwada","1","1","1","0");
INSERT INTO delivery_pincode VALUES("863","370001","1","0","0","Bhuj","1","1","1","0");
INSERT INTO delivery_pincode VALUES("864","370002","1","0","0","Bhuj Din Dayal Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("865","370015","1","0","0","Bhuj B S F Camp","1","1","1","0");
INSERT INTO delivery_pincode VALUES("866","370201","1","0","0","Gandhidham","1","1","1","0");
INSERT INTO delivery_pincode VALUES("867","370202","1","0","0","Gandhidham","1","1","1","0");
INSERT INTO delivery_pincode VALUES("868","370203","1","0","0","Udaynagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("869","370205","1","0","0","Adipur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("870","370210","1","0","0","Kandla Harbour","1","1","1","0");
INSERT INTO delivery_pincode VALUES("871","370240","1","0","0","Gopalpuri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("872","380001","1","0","0","Ahmedabad G.P.O. ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("873","380002","1","0","0","Revdibazar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("874","380003","1","0","0","Revdibazar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("875","380004","1","0","0","Shahpur (Ahmedabad)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("876","380005","1","0","0","Sabarmati","1","1","1","0");
INSERT INTO delivery_pincode VALUES("877","380006","1","0","0","Ambawadi (Ahmedabad)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("878","380007","1","0","0","Anandnagar (Ahmedabad)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("879","380008","1","0","0","Vasisthnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("880","380009","1","0","0","Navrangpura","1","1","1","0");
INSERT INTO delivery_pincode VALUES("881","380010","1","0","0","Navrangpura","1","1","1","0");
INSERT INTO delivery_pincode VALUES("882","380012","1","0","0","Navrangpura","1","1","1","0");
INSERT INTO delivery_pincode VALUES("883","380013","1","0","0","Shastrinagar (Ahmedabad)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("884","380014","1","0","0","Navjivan","1","1","1","0");
INSERT INTO delivery_pincode VALUES("885","380015","1","0","0","Ambawadi Vistar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("886","380016","1","0","0","Meghaningar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("887","380017","1","0","0","Meghaningar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("888","380018","1","0","0","Saraspur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("889","380019","1","0","0","Railway Colony (Ahmedabad)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("890","380021","1","0","0","Gomtipur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("891","380022","1","0","0","Behrampura","1","1","1","0");
INSERT INTO delivery_pincode VALUES("892","380023","1","0","0","Rakhial","1","1","1","0");
INSERT INTO delivery_pincode VALUES("893","380024","1","0","0","Asarwa Ext South","1","1","1","0");
INSERT INTO delivery_pincode VALUES("894","380025","1","0","0","Naroda Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("895","380026","1","0","0","Amraiwadi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("896","380027","1","0","0","Gandhi Ashram (Ahmedabad)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("897","380028","1","0","0","Bhairavnath Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("898","380050","1","0","0","Ghodasar (Ahmedabad)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("899","380051","1","0","0","Jivraj Park","1","1","1","0");
INSERT INTO delivery_pincode VALUES("900","380052","1","0","0","Memnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("901","380053","1","0","0","Memnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("902","380054","1","0","0","Bodakdev","1","1","1","0");
INSERT INTO delivery_pincode VALUES("903","380055","1","0","0","Juhapura","1","1","1","0");
INSERT INTO delivery_pincode VALUES("904","380058","1","0","0","Bopal","1","1","1","0");
INSERT INTO delivery_pincode VALUES("905","380059","1","0","0","Thaltej","1","1","1","0");
INSERT INTO delivery_pincode VALUES("906","380060","1","0","0","Gujrat High Court","1","1","1","0");
INSERT INTO delivery_pincode VALUES("907","380061","1","0","0","Ghatlodia","1","1","1","0");
INSERT INTO delivery_pincode VALUES("908","380063","1","0","0","Sola H B C","1","1","1","0");
INSERT INTO delivery_pincode VALUES("909","382001","1","0","0","(Gandhinagar) Sector 6","1","1","1","0");
INSERT INTO delivery_pincode VALUES("910","382002","1","0","0","(Gandhinagar) Sector 6","1","1","1","0");
INSERT INTO delivery_pincode VALUES("911","382003","1","0","0","(Gandhinagar) Sector 6","1","1","1","0");
INSERT INTO delivery_pincode VALUES("912","382004","1","0","0","(Gandhinagar) Sector 6","1","1","1","0");
INSERT INTO delivery_pincode VALUES("913","382005","1","0","0","(Gandhinagar) Sector 6","1","1","1","0");
INSERT INTO delivery_pincode VALUES("914","382006","1","0","0","(Gandhinagar) Sector 6","1","1","1","0");
INSERT INTO delivery_pincode VALUES("915","382008","1","0","0","(Gandhinagar) Sector 7","1","1","1","0");
INSERT INTO delivery_pincode VALUES("916","382009","1","0","0","(Gandhinagar) Sector 7","1","1","1","0");
INSERT INTO delivery_pincode VALUES("917","382325","1","0","0","Naroda","1","1","1","0");
INSERT INTO delivery_pincode VALUES("918","382330","1","0","0","Naroda","1","1","1","0");
INSERT INTO delivery_pincode VALUES("919","382340","1","0","0","Kubernagar B A","1","1","1","0");
INSERT INTO delivery_pincode VALUES("920","382345","1","0","0","Krishnanagar (Ahmedabad)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("921","382346","1","0","0","Khodiyarnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("922","382350","1","0","0","Khodiyarnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("923","382352","1","0","0","Dabhoda","1","1","1","0");
INSERT INTO delivery_pincode VALUES("924","382405","1","0","0","Narol","1","1","1","0");
INSERT INTO delivery_pincode VALUES("925","382410","1","0","0","Odhav","1","1","1","0");
INSERT INTO delivery_pincode VALUES("926","382415","1","0","0","Odhav","1","1","1","0");
INSERT INTO delivery_pincode VALUES("927","382424","1","0","0","Chandkheda Society Area","1","1","1","0");
INSERT INTO delivery_pincode VALUES("928","382427","1","0","0","Aslali","1","1","1","0");
INSERT INTO delivery_pincode VALUES("929","382440","1","0","0","Vatva","1","1","1","0");
INSERT INTO delivery_pincode VALUES("930","382443","1","0","0","Isanpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("931","382470","1","0","0","Digvijaynagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("932","382475","1","0","0","Sardarnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("933","382480","1","0","0","Ranip","1","1","1","0");
INSERT INTO delivery_pincode VALUES("934","382481","1","0","0","Chandlodia","1","1","1","0");
INSERT INTO delivery_pincode VALUES("935","384001","1","0","0","Mehsana 1","1","1","1","0");
INSERT INTO delivery_pincode VALUES("936","384002","1","0","0","Mehsana 2","1","1","1","0");
INSERT INTO delivery_pincode VALUES("937","384160","1","0","0","Unjha","1","1","1","0");
INSERT INTO delivery_pincode VALUES("938","384315","1","0","0","Visnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("939","388001","1","0","0","ANAND","1","1","1","0");
INSERT INTO delivery_pincode VALUES("940","388120","1","0","0","V.V.NAGAR","1","1","1","0");
INSERT INTO delivery_pincode VALUES("941","388121","1","0","0","V.U.NAGAR","1","1","1","0");
INSERT INTO delivery_pincode VALUES("942","390001","1","0","0","Vadodara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("943","390002","1","0","0","Fateganj","1","1","1","0");
INSERT INTO delivery_pincode VALUES("944","390003","1","0","0","Chemical Industries","1","1","1","0");
INSERT INTO delivery_pincode VALUES("945","390004","1","0","0","Pratapnagar (Vadodara)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("946","390005","1","0","0","Fatepura (Vadodara)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("947","390006","1","0","0","Fatepura (Vadodara)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("948","390007","1","0","0","Alkapuri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("949","390008","1","0","0","Eme","1","1","1","0");
INSERT INTO delivery_pincode VALUES("950","390009","1","0","0","Sharadnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("951","390010","1","0","0","M.I. Estate","1","1","1","0");
INSERT INTO delivery_pincode VALUES("952","390011","1","0","0","Manjalpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("953","390012","1","0","0","Atladara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("954","390013","1","0","0","Maneja","1","1","1","0");
INSERT INTO delivery_pincode VALUES("955","390014","1","0","0","Makarpura","1","1","1","0");
INSERT INTO delivery_pincode VALUES("956","390015","1","0","0","Industrial Estate (Vadodara)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("957","390016","1","0","0","Industrial Estate (Vadodara)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("958","390017","1","0","0","Wadi S.N. Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("959","390018","1","0","0","Karelibaug","1","1","1","0");
INSERT INTO delivery_pincode VALUES("960","390019","1","0","0","Ajwa Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("961","390020","1","0","0","Akota","1","1","1","0");
INSERT INTO delivery_pincode VALUES("962","390021","1","0","0","T B Sanatorium","1","1","1","0");
INSERT INTO delivery_pincode VALUES("963","390022","1","0","0","Harni Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("964","390023","1","0","0","Subhanpura","1","1","1","0");
INSERT INTO delivery_pincode VALUES("965","390024","1","0","0","Chhani Rd","1","1","1","0");
INSERT INTO delivery_pincode VALUES("966","391310","1","0","0","Bajwa","1","1","1","0");
INSERT INTO delivery_pincode VALUES("967","391320","1","0","0","Jawahar Nagar (Vadodara)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("968","391345","1","0","0","Petrochemical  T Ship","1","1","1","0");
INSERT INTO delivery_pincode VALUES("969","391346","1","0","0","Petrochemical","1","1","1","0");
INSERT INTO delivery_pincode VALUES("970","391350","1","0","0","Ranoli (Vadodara)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("971","391440","1","0","0","Padra","1","1","1","0");
INSERT INTO delivery_pincode VALUES("972","391750","1","0","0","Fartilizer Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("973","392001","1","0","0","Bharuch city area","1","1","1","0");
INSERT INTO delivery_pincode VALUES("974","392002","1","0","0","Bharuch soc area","1","1","1","0");
INSERT INTO delivery_pincode VALUES("975","392011","1","0","0","Zadeshwar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("976","392015","1","0","0","Kantharia","1","1","1","0");
INSERT INTO delivery_pincode VALUES("977","393001","1","0","0","Ankleshwar IE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("978","393002","1","0","0","Ankleshwar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("979","394101","1","0","0","Mota Varachha","1","1","1","0");
INSERT INTO delivery_pincode VALUES("980","394105","1","0","0","Utran Power House","1","1","1","0");
INSERT INTO delivery_pincode VALUES("981","394107","1","0","0","Amroli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("982","394210","1","0","0","Udhna","1","1","1","0");
INSERT INTO delivery_pincode VALUES("983","394220","1","0","0","Fatehnagar (Surat)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("984","394221","1","0","0","Pandesara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("985","394270","1","0","0","Nandniketan","1","1","1","0");
INSERT INTO delivery_pincode VALUES("986","394315","1","0","0","Palsana (Surat)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("987","394510","1","0","0","Bhatha","1","1","1","0");
INSERT INTO delivery_pincode VALUES("988","394515","1","0","0","Kribhconagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("989","394520","1","0","0","Kosam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("990","394540","1","0","0","Olpad","1","1","1","0");
INSERT INTO delivery_pincode VALUES("991","394550","1","0","0","Dumas","1","1","1","0");
INSERT INTO delivery_pincode VALUES("992","395001","1","0","0","Nanpura","1","1","1","0");
INSERT INTO delivery_pincode VALUES("993","395002","1","0","0","Khatodara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("994","395003","1","0","0","Surat","1","1","1","0");
INSERT INTO delivery_pincode VALUES("995","395004","1","0","0","Dabholi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("996","395005","1","0","0","Rander","1","1","1","0");
INSERT INTO delivery_pincode VALUES("997","395006","1","0","0","Varachha Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("998","395007","1","0","0","Abhva","1","1","1","0");
INSERT INTO delivery_pincode VALUES("999","395008","1","0","0","A. K. Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1000","395009","1","0","0","Adajan Dn","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1001","395010","1","0","0","Bombay Market","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1002","395011","1","0","0","Althan","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1003","395017","1","0","0","Althan","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1004","396191","1","0","0","Vapi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1005","396193","1","0","0","Dadra","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1006","396195","1","0","0","Vapi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1007","396230","1","0","0","Silvassa","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1008","396235","1","0","0","Naroli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1009","396240","1","0","0","Karad Daman Project","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1010","396445","1","0","0","Navsari","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1011","400001","1","0","0","Mumbai G.P.O. ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1012","400002","1","0","0","Kalbadevi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1013","400003","1","0","0","Masjid","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1014","400004","1","0","0","Girgaon","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1015","400005","1","0","0","Colaba","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1016","400006","1","0","0","Malabar Hill","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1017","400007","1","0","0","Tardeo","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1018","400008","1","0","0","Mumbai Central","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1019","400009","1","0","0","Chinchbunder","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1020","400010","1","0","0","Mazgaon","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1021","400011","1","0","0","Chinchpokli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1022","400012","1","0","0","Parel","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1023","400013","1","0","0","Delisle Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1024","400014","1","0","0","Dadar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1025","400015","1","0","0","Sewri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1026","400016","1","0","0","Mahim","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1027","400017","1","0","0","Dharavi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1028","400018","1","0","0","Worli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1029","400019","1","0","0","Matunga","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1030","400020","1","0","0","Churchgate","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1031","400021","1","0","0","Nariman Point","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1032","400022","1","0","0","Sion","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1033","400023","1","0","0","Nariman Point","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1034","400024","1","0","0","Nehru Nagar (Mumbai)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1035","400025","1","0","0","Prabhadevi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1036","400026","1","0","0","Gowalia Tank","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1037","400027","1","0","0","V J B Udyan","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1038","400028","1","0","0","Shivaji Park (Mumbai)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1039","400029","1","0","0","Santacruz P&t Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1040","400030","1","0","0","Worli Sea Face","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1041","400031","1","0","0","Wadala","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1042","400032","1","0","0","Mantralaya (Mumbai)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1043","400033","1","0","0","Reay Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1044","400034","1","0","0","Haji Ali","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1045","400035","1","0","0","Rajbhavan (Mumbai)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1046","400036","1","0","0","Antop Hill","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1047","400037","1","0","0","Antop Hill","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1048","400038","1","0","0","Fort","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1049","400039","1","0","0","Fort","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1050","400042","1","0","0","Bhandup East","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1051","400043","1","0","0","Shivaji Nagar (Mumbai)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1052","400049","1","0","0","Juhu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1053","400050","1","0","0","Bandra West","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1054","400051","1","0","0","Bandra(East)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1055","400052","1","0","0","Khar Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1056","400053","1","0","0","Andheri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1057","400054","1","0","0","Santacruz(West)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1058","400055","1","0","0","Santacruz(East)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1059","400056","1","0","0","Vileparle(West)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1060","400057","1","0","0","Vileeparle (East)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1061","400058","1","0","0","Andheri Railway Station","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1062","400059","1","0","0","J.B. Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1063","400060","1","0","0","Jogeshwari East","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1064","400061","1","0","0","Vesava","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1065","400062","1","0","0","Goregaon East","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1066","400063","1","0","0","Goregaon East","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1067","400064","1","0","0","Malad","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1068","400065","1","0","0","Nagari Niwara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1069","400066","1","0","0","Borivali East","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1070","400067","1","0","0","Charkop","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1071","400068","1","0","0","Dahisar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1072","400069","1","0","0","Nagardas Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1073","400070","1","0","0","Kurla","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1074","400071","1","0","0","Chembur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1075","400072","1","0","0","Sakinaka","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1076","400074","1","0","0","Mahul Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1077","400075","1","0","0","Pant Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1078","400076","1","0","0","Powai Iit","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1079","400077","1","0","0","Rajawadi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1080","400078","1","0","0","Bhandup West","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1081","400079","1","0","0","Vikhroli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1082","400080","1","0","0","Mulund West","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1083","400081","1","0","0","Mulund East","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1084","400082","1","0","0","Mulund Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1085","400083","1","0","0","Kannamwar Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1086","400084","1","0","0","Barve Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1087","400085","1","0","0","BARC","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1088","400086","1","0","0","Ghatkopar West","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1089","400087","1","0","0","Nitie","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1090","400088","1","0","0","Govandi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1091","400089","1","0","0","Tilak Nagar (Mumbai)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1092","400090","1","0","0","Borivali","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1093","400091","1","0","0","Borivali","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1094","400092","1","0","0","Borivali West","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1095","400093","1","0","0","Chakala Midc","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1096","400094","1","0","0","Anushakti Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1097","400095","1","0","0","Kharodi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1098","400096","1","0","0","Seepz","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1099","400097","1","0","0","Malad East","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1100","400098","1","0","0","Vidyanagari","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1101","400099","1","0","0","Airport (Mumbai)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1102","400101","1","0","0","Kandivali East","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1103","400102","1","0","0","Jogeshwari West","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1104","400103","1","0","0","Mandapeshwar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1105","400104","1","0","0","Goregaon (Mumbai)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1106","400601","1","0","0","Thane","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1107","400602","1","0","0","Naupada (Thane)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1108","400603","1","0","0","Kopri Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1109","400604","1","0","0","Wagle I.E.","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1110","400605","1","0","0","Kalwa","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1111","400606","1","0","0","Jekegram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1112","400607","1","0","0","Sandozbaugh","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1113","400608","1","0","0","Balkum","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1114","400609","1","0","0","Apna Bazar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1115","400610","1","0","0","Apna Bazar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1116","400613","1","0","0","Turbe MIDC","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1117","400614","1","0","0","Konkan Bhavan","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1118","400615","1","0","0","Kasarvadavali","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1119","400701","1","0","0","Ghansoli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1120","400703","1","0","0","Turbhe","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1121","400705","1","0","0","Sanpada","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1122","400706","1","0","0","Nerul Sec-48","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1123","400708","1","0","0","Airoli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1124","400709","1","0","0","Kopar Khairne","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1125","400710","1","0","0","Millenium Business Park","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1126","401101","1","0","0","Bhayander West","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1127","401104","1","0","0","Mira road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1128","401105","1","0","0","Bhayander East","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1129","401107","1","0","0","Mira Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1130","401201","1","0","0","Bassein","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1131","401202","1","0","0","Vasai Road E","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1132","401203","1","0","0","Sopara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1133","401205","1","0","0","Thane","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1134","401207","1","0","0","Papdi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1135","401208","1","0","0","Vasai East IE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1136","401209","1","0","0","Nallosapare E","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1137","401210","1","0","0","Nallosapare E","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1138","401302","1","0","0","Arnala","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1139","401303","1","0","0","Virar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1140","401404","1","0","0","Palghar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1141","401501","1","0","0","Boisar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1142","401502","1","0","0","Tarapur (Thane)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1143","401503","1","0","0","Chinchani","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1144","401506","1","0","0","Tarapur Ti","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1145","401602","1","0","0","Dahanu Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1146","402108","1","0","0","Poynad","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1147","402201","1","0","0","Alibag","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1148","402202","1","0","0","Revdanda","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1149","402203","1","0","0","Chaul","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1150","402204","1","0","0","Nagaon","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1151","402207","1","0","0","Thal (Raigarh(MH))","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1152","402209","1","0","0","Kurul RCF Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1153","403001","1","0","0","Panaji","2","1","1","0");
INSERT INTO delivery_pincode VALUES("1154","403002","1","0","0","Caranzalem","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1155","403003","1","0","0","Nio Dona Paula","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1156","403004","1","0","0","Nio Dona Paula","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1157","403005","1","0","0","Santa Cruz","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1158","403006","1","0","0","Ribandar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1159","403101","1","0","0","Betim","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1160","403104","1","0","0","Neura","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1161","403108","1","0","0","Goa -velha","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1162","403109","1","0","0","N B Verem","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1163","403110","1","0","0","Corlim IE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1164","403112","1","0","0","Reis Magos","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1165","403114","1","0","0","Reis Magos","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1166","403115","1","0","0","Cundaim I.E.","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1167","403201","1","0","0","Bambolim Camp","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1168","403202","1","0","0","Bambolim Complex","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1169","403203","1","0","0","Pilar (North Goa)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1170","403204","1","0","0","St. Lourence","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1171","403206","1","0","0","Goa University","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1172","403325","1","0","0","Ponda","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1173","403401","1","0","0","Ponda","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1174","403402","1","0","0","Velha-goa","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1175","403404","1","0","0","Mardol","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1176","403405","1","0","0","Mardol","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1177","403406","1","0","0","Tisca","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1178","403407","1","0","0","Tisca","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1179","403409","1","0","0","Betora I.E.","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1180","403501","1","0","0","Porvorim","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1181","403502","1","0","0","Tivim","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1182","403507","1","0","0","Mapusa","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1183","403509","1","0","0","Anjuna","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1184","403510","1","0","0","Parra","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1185","403511","1","0","0","Saligao","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1186","403513","1","0","0","Colvale","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1187","403514","1","0","0","Colvale","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1188","403515","1","0","0","Sinquerim","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1189","403516","1","0","0","Calangute","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1190","403517","1","0","0","Siolim","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1191","403518","1","0","0","Siolim","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1192","403519","1","0","0","Siolim","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1193","403521","1","0","0","Secretariat (North Goa)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1194","403526","1","0","0","Tivim Ie","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1195","403601","1","0","0","Margao","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1196","403602","1","0","0","Fatorda","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1197","403604","1","0","0","Fatorda","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1198","403703","1","0","0","Cuncolim","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1199","403707","1","0","0","Navelim","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1200","403708","1","0","0","Colva","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1201","403709","1","0","0","St. Jose De Areal","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1202","403711","1","0","0","Chicalim","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1203","403712","1","0","0","Cansaulim","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1204","403713","1","0","0","Majorda","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1205","403716","1","0","0","Benaulim","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1206","403721","1","0","0","Varca","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1207","403722","1","0","0","Verna","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1208","403726","1","0","0","Zuarinagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1209","403729","1","0","0","Navelim Camp","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1210","403731","1","0","0","Cavelossim","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1211","403801","1","0","0","A.P.Terminal","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1212","403802","1","0","0","Vasco-Da-Gama","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1213","403803","1","0","0","Mormugao","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1214","403804","1","0","0","Sada","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1215","403806","1","0","0","Bogmalo","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1216","410206","1","0","0","Panvel (Only City Limits)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1217","410208","1","0","0","Taloja","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1218","410210","1","0","0","Kharghar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1219","410218","1","0","0","Kalamboli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1220","411001","1","0","0","Pune","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1221","411002","1","0","0","Pune City","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1222","411003","1","0","0","Khadki","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1223","411004","1","0","0","Deccan Gymkhana","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1224","411005","1","0","0","Shivajinagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1225","411006","1","0","0","Yerwada","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1226","411007","1","0","0","Aundh","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1227","411008","1","0","0","N.C.L. Pune","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1228","411009","1","0","0","Parvati","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1229","411010","1","0","0","Parvati","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1230","411011","1","0","0","Kasba Peth","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1231","411012","1","0","0","Dapodi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1232","411013","1","0","0","Hadpsar I.E.","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1233","411014","1","0","0","Vadgaon Sheri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1234","411015","1","0","0","Vishrantwadi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1235","411016","1","0","0","Gokhalenagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1236","411017","1","0","0","Pimpri Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1237","411018","1","0","0","Nehrunagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1238","411019","1","0","0","M.Phulenagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1239","411020","1","0","0","Range Hills","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1240","411021","1","0","0","Armament","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1241","411022","1","0","0","Srpf","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1242","411026","1","0","0","Bhosari I.E.","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1243","411027","1","0","0","Aundh Camp","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1244","411028","1","0","0","Hadapsar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1245","411029","1","0","0","Hadapsar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1246","411030","1","0","0","Sadashiv Peth","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1247","411031","1","0","0","C M E","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1248","411032","1","0","0","Airport (Pune)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1249","411033","1","0","0","Chinchwadga0n","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1250","411034","1","0","0","Kasarwadi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1251","411035","1","0","0","Akurdi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1252","411036","1","0","0","Mundhva AV","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1253","411037","1","0","0","Market Yard (Pune)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1254","411038","1","0","0","Kothrud","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1255","411039","1","0","0","Bhosarigoan","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1256","411040","1","0","0","Wanowarie","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1257","411041","1","0","0","Vadgaon Budruk","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1258","411042","1","0","0","Swargate","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1259","411043","1","0","0","Dhankawadi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1260","411044","1","0","0","Yamunanagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1261","411045","1","0","0","N.I.A.","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1262","411046","1","0","0","Katraj","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1263","411047","1","0","0","Lohogaon","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1264","411048","1","0","0","N I B M","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1265","411051","1","0","0","Anandnagar (Pune)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1266","411052","1","0","0","Karvenagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1267","411053","1","0","0","Infotech  Park (Hinjawadi)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1268","411061","1","0","0","Pimple Gurav ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1269","411062","1","0","0","Talwade IT Park ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1270","413001","1","0","0","Solapur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1271","413002","1","0","0","Solapur Mkt","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1272","413003","1","0","0","Zilla Nayalaya Solapur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1273","413004","1","0","0","Jule Solapur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1274","413005","1","0","0","Market Yard Solapur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1275","413006","1","0","0","Midc Solapur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1276","413007","1","0","0","Solapur City","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1277","413102","1","0","0","Baramati","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1278","413104","1","0","0","Bhvaneenagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1279","413110","1","0","0","Pandare","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1280","413115","1","0","0","Malegoan ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1281","413117","1","0","0","Lasurne","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1282","413133","1","0","0","Baramati MIDC","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1283","413255","1","0","0","Midc Chincholi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1284","413512","1","0","0","Latur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1285","414001","1","0","0","Ahmednagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1286","414002","1","0","0","Ahmednagar Camp","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1287","414003","1","0","0","Savedi Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1288","414005","1","0","0","Ahmednagar R.S.","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1289","414111","1","0","0","Ahamednagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1290","415001","1","0","0","Satara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1291","415002","1","0","0","Mangalwar Peth Satara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1292","415003","1","0","0","Sangamnagar Satara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1293","415004","1","0","0","Midc Satara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1294","415605","1","0","0","Chiplun","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1295","415612","1","0","0","Ratnagiri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1296","415639","1","0","0","Bhoke","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1297","415709","1","0","0","Khed City","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1298","415712","1","0","0","Dapoli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1299","416001","1","0","0","Kolhapur RS","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1300","416002","1","0","0","Shaniwar Peth (Kolhapur)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1301","416003","1","0","0","Kolhapur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1302","416004","1","0","0","Shivaji University","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1303","416005","1","0","0","Gur Market Yard","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1304","416006","1","0","0","Kasba Bavada","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1305","416007","1","0","0","Kalamba","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1306","416008","1","0","0","Rajarampuri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1307","416009","1","0","0","Phulewadi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1308","416010","1","0","0","Phulewadi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1309","416012","1","0","0","Kolhapur City","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1310","416013","1","0","0","R K Nagar (Kolhapur)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1311","416101","1","0","0","Jaysingpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1312","416115","1","0","0","Ichalkaranji","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1313","416117","1","0","0","Jawaharnagar Ichalkaranji","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1314","416119","1","0","0","Gandhinagar (Kolhapur)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1315","416121","1","0","0","R K Nagar Ichalkaranji","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1316","416122","1","0","0","Shiroli MIDC","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1317","416234","1","0","0","Gokul Shirgaon MIDC","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1318","416236","1","0","0","KAGAL, 5STAR MIDC","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1319","416306","1","0","0","Sangli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1320","416406","1","0","0","Madhavnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1321","416410","1","0","0","Miraj","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1322","416415","1","0","0","Willingdon College Sangli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1323","416416","1","0","0","Sangli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1324","416436","1","0","0","Kupwad MIDC Area","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1325","421001","1","0","0","Ulhasnagar-1","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1326","421002","1","0","0","Ulhasnagar-2","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1327","421003","1","0","0","Ulhasnagar-4","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1328","421004","1","0","0","Ulhasnagar-4","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1329","421005","1","0","0","Ulhasnagar-5","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1330","421201","1","0","0","Dombivali","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1331","421202","1","0","0","Vishnunagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1332","421203","1","0","0","Dombivali I.A.","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1333","421204","1","0","0","Manpada","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1334","421301","1","0","0","Kalyan City","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1335","421302","1","0","0","Dandekarwadi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1336","421304","1","0","0","Kamba","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1337","421305","1","0","0","Vidyashram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1338","421306","1","0","0","Ganeshwadi (Thane)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1339","421501","1","0","0","Ambernath","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1340","421502","1","0","0","O.E.Ambernath","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1341","422001","1","0","0","Nashik","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1342","422002","1","0","0","Gole Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1343","422003","1","0","0","Panchvati","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1344","422004","1","0","0","Akrale","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1345","422005","1","0","0","H P T College","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1346","422006","1","0","0","Gandhi Nagar (Nashik)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1347","422007","1","0","0","Satpur Township","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1348","422008","1","0","0","Trimurti Chowk","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1349","422009","1","0","0","Indira Nagar (Nashik)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1350","422010","1","0","0","Ambad A.S.","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1351","422011","1","0","0","Dwarka Corner","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1352","422013","1","0","0","Sawarkar Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1353","422101","1","0","0","Nashik Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1354","424001","1","0","0","Dhule","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1355","424002","1","0","0","Dhule Deopur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1356","424003","1","0","0","Dhule Market Yard","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1357","424004","1","0","0","Dhule Market Yard","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1358","424006","1","0","0","Dhule Midc","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1359","424101","1","0","0","Chalisgaon","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1360","424311","1","0","0","Mohadi Laling","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1361","425001","1","0","0","Jalgaon","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1362","425002","1","0","0","M.J.College Jalgaon","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1363","425003","1","0","0","Audyogik Vasahat Jalgaon","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1364","425201","1","0","0","Bhusawal","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1365","425401","1","0","0","Amalner (Jalgaon)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1366","425405","1","0","0","Shirpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1367","431001","1","0","0","Aurangabad (MH)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1368","431002","1","0","0","Aurangabad Cantonment","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1369","431003","1","0","0","Nizamganj","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1370","431004","1","0","0","Begumpura","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1371","431005","1","0","0","Osmanpura","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1372","431006","1","0","0","Chikalthana Industrial Area","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1373","431007","1","0","0","Chikalthana","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1374","431122","1","0","0","Beed","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1375","431133","1","0","0","Waluj","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1376","431136","1","0","0","Bajaj Nagar Midc Waluj","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1377","431201","1","0","0","Jalna","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1378","431203","1","0","0","Jalna","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1379","431210","1","0","0","Aurangabad","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1380","431601","1","0","0","Nanded","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1381","431602","1","0","0","Yeshwantnagar? Nanded","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1382","431603","1","0","0","Cidco Nanded","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1383","431604","1","0","0","Itwara Nanded","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1384","431605","1","0","0","Ashoknagar (Nanded)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1385","440001","1","0","0","Nagpur GPO","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1386","440002","1","0","0","Nagpur City","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1387","440003","1","0","0","Imamwada","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1388","440004","1","0","0","Bezonbagh","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1389","440005","1","0","0","Nagpur Airport","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1390","440006","1","0","0","Seminary Hills","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1391","440007","1","0","0","Vayusena Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1392","440008","1","0","0","Bagadganj","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1393","440009","1","0","0","Dighori Naka","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1394","440010","1","0","0","Gandhi Nagar (Nagpur)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1395","440011","1","0","0","Congress Nagar (Nagpur)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1396","440012","1","0","0","Congress Nagar (Nagpur)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1397","440013","1","0","0","Borgaon Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1398","440014","1","0","0","Jaripatka","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1399","440015","1","0","0","Narendra Nagar (Nagpur)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1400","440016","1","0","0","Indl.Area Nagpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1401","440017","1","0","0","Dr.Ambedkar Marg","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1402","440018","1","0","0","Mominpura","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1403","440019","1","0","0","C.R.P.F. Nagpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1404","440020","1","0","0","Neeri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1405","440021","1","0","0","A.D. Project","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1406","440022","1","0","0","Laxmi Nagar (Nagpur)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1407","440023","1","0","0","Wadi (Nagpur)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1408","440024","1","0","0","Ayodhya Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1409","440025","1","0","0","Ujwal Nagar (Nagpur)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1410","440026","1","0","0","Uppalwadi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1411","440027","1","0","0","Parvati Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1412","440028","1","0","0","MIDC Nagpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1413","440030","1","0","0","Mankapur (Nagpur)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1414","440032","1","0","0","Mahal (Nagpur)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1415","440033","1","0","0","University Campus (Nagpur)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1416","440034","1","0","0","Mhalginagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1417","441002","1","0","0","Kamthi City","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1418","441108","1","0","0","Bori (Nagpur)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1419","441122","1","0","0","Industrial Area Butibori","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1420","442001","1","0","0","Wardha","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1421","442002","1","0","0","Wardha","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1422","442003","1","0","0","Wardha Ganj","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1423","442004","1","0","0","Sawangi meghe, Wardha","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1424","442005","1","0","0","Manas Mandir-Wardha","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1425","442006","1","0","0","Akpo Wardha","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1426","442102","1","0","0","Sewagram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1427","442401","1","0","0","Chandrapur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1428","442402","1","0","0","CITY AREA","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1429","442403","1","0","0","Babupeth","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1430","442404","1","0","0","Chandrapur TPS","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1431","442406","1","0","0","MIDC, PADOLI","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1432","442507","1","0","0","H.L.C.","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1433","444001","1","0","0","Akola","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1434","444002","1","0","0","Akola City","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1435","444003","1","0","0","Shivaji Park Akola","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1436","444004","1","0","0","Gandhinagar (Akola)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1437","444005","1","0","0","Jatherpeth Akola","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1438","444601","1","0","0","Amravati","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1439","444602","1","0","0","Amravati Camp","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1440","444603","1","0","0","Shivaji Nagar (Amravati)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1441","444604","1","0","0","V.M.V. (Amravati)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1442","444605","1","0","0","Rajapeth","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1443","444606","1","0","0","Congress Nagar (Amravati)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1444","444607","1","0","0","Badnera Town","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1445","444709","1","0","0","Dhamangaon","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1446","445001","1","0","0","Yavatmal","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1447","450001","1","0","0","Khandwa","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1448","452001","1","0","0","Indore G.P.O. ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1449","452002","1","0","0","Indore Cloth Market","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1450","452003","1","0","0","Indore Malwa Mill","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1451","452004","1","0","0","Bijasan Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1452","452005","1","0","0","Bijasan Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1453","452006","1","0","0","Army Head Quarter","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1454","452007","1","0","0","Indore Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1455","452008","1","0","0","Lokmanya Nagar Indore","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1456","452009","1","0","0","Lokmanya Nagar Indore","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1457","452010","1","0","0","Indore DDU Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1458","452011","1","0","0","Indore R.S.S.Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1459","452012","1","0","0","Rajendra Nagar (Indore)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1460","452013","1","0","0","Indore Cat","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1461","452014","1","0","0","Khatiwala Tank","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1462","452015","1","0","0","Indore Industrial Area","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1463","452016","1","0","0","Indore Kanadia Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1464","452017","1","0","0","Indore","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1465","452018","1","0","0","Indore Tillaknagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1466","452019","1","0","0","Kasturbagram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1467","452020","1","0","0","Kasturbagram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1468","452056","1","0","0","Kasturbagram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1469","453001","1","0","0","Betma","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1470","453331","1","0","0","Rao","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1471","453441","1","0","0","Mhow Railway Stattion","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1472","453661","1","0","0","Manpur (Indore)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1473","454774","1","0","0","Pithampur III","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1474","454775","1","0","0","Pithampur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1475","455001","1","0","0","Dewas","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1476","456001","1","0","0","Ujjain","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1477","456003","1","0","0","Ujjain  Bherugarh","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1478","456006","1","0","0","Ujjain  City","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1479","456010","1","0","0","Ujjain  Kothi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1480","457001","1","0","0","Ratlam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1481","457002","1","0","0","Ratlam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1482","462001","1","0","0","Bhopal G.P.O. ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1483","462002","1","0","0","Vidya Vihar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1484","462003","1","0","0","C.T.T.Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1485","462004","1","0","0","Satpura","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1486","462005","1","0","0","Satpura","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1487","462006","1","0","0","Satpura","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1488","462007","1","0","0","M.A.C.T.","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1489","462008","1","0","0","Barkhedi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1490","462010","1","0","0","Balampur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1491","462011","1","0","0","Arera Hills","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1492","462012","1","0","0","Arera Hills","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1493","462013","1","0","0","Regional College","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1494","462014","1","0","0","Regional College","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1495","462015","1","0","0","Regional College","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1496","462016","1","0","0","1100 Qrts.","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1497","462017","1","0","0","1100 Qrts.","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1498","462018","1","0","0","1100 Qrts.","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1499","462019","1","0","0","1100 Qrts.","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1500","462021","1","0","0","1100 Qrts.","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1501","462022","1","0","0","Bhel","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1502","462023","1","0","0","Govindpura","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1503","462024","1","0","0","H.E. Hospital","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1504","462025","1","0","0","H.E. Hospital","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1505","462026","1","0","0","University (Bhopal)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1506","462027","1","0","0","Dak Bhawan","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1507","462029","1","0","0","Dak Bhawan","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1508","462030","1","0","0","Air Port","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1509","462031","1","0","0","3 EME Centre","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1510","462032","1","0","0","3 EME Centre","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1511","462034","1","0","0","RGPV","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1512","462035","1","0","0","RGPV","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1513","462036","1","0","0","Gandhi Nagar (Bhopal)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1514","462037","1","0","0","Peoples Campus","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1515","462038","1","0","0","M.L. Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1516","462039","1","0","0","Trilanga","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1517","462041","1","0","0","Ayodhaya Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1518","462042","1","0","0","Kolar Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1519","462046","1","0","0","Mandideep","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1520","473551","1","0","0","shivpuri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1521","473583","1","0","0","khatora","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1522","473638","1","0","0","katta mill","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1523","473660","1","0","0","karera","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1524","473662","1","0","0","T.c.karera","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1525","473770","1","0","0","kolaras","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1526","473880","1","0","0","narwar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1527","473990","1","0","0","khaniyadana","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1528","474001","1","0","0","Lashkar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1529","474002","1","0","0","Defence Colony (Gwalior)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1530","474003","1","0","0","Gwalior City","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1531","474004","1","0","0","Birla Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1532","474005","1","0","0","Gwalior Residency","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1533","474006","1","0","0","Morar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1534","474007","1","0","0","Moti Mahal","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1535","474008","1","0","0","Gwalior Fort","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1536","474009","1","0","0","Phalka Bazar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1537","474010","1","0","0","Moti Jheel","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1538","474011","1","0","0","R.K Puri Gwalior","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1539","474012","1","0","0","S.P. Ashram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1540","474020","1","0","0","Bahadurpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1541","480001","1","0","0","Chhindwara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1542","480002","1","0","0","Chitanvisganj","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1543","482001","1","0","0","Jabalpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1544","482002","1","0","0","Vijay Nagar Colony (Jabalpur)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1545","482003","1","0","0","Medical College (Jabalpur)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1546","482004","1","0","0","Kanchanpur (Jabalpur)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1547","482005","1","0","0","Khamaria (Jabalpur)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1548","482007","1","0","0","High Court (Jabalpur)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1549","482008","1","0","0","Vidyut Nagar (Jabalpur)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1550","482009","1","0","0","Shobhapur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1551","482010","1","0","0","Richhai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1552","482011","1","0","0","Engineering College (Jabalpur)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1553","482020","1","0","0","Bilhari","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1554","490001","1","0","0","Ibsb Bhilai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1555","490006","1","0","0","Civic Centre Bhilai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1556","490009","1","0","0","Bhilai West","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1557","490011","1","0","0","Khursipar Bhilai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1558","490012","1","0","0","Khursipar Bhilai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1559","490020","1","0","0","Motilal Nehru Nagr Bhilai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1560","490021","1","0","0","Bhilai East","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1561","490023","1","0","0","Khoka Bhilai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1562","490024","1","0","0","Jamul Cement Works","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1563","491001","1","0","0","Durg","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1564","492001","1","0","0","Raipur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1565","492002","1","0","0","Mantralaya Raipur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1566","492003","1","0","0","Urla","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1567","492004","1","0","0","Pandri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1568","492005","1","0","0","Vidhan Sabha","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1569","492006","1","0","0","Ravigram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1570","492007","1","0","0","Shanker Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1571","492008","1","0","0","W.R.S.Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1572","492009","1","0","0","Raipur Ganj","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1573","492010","1","0","0","Ravi Shankar University","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1574","492012","1","0","0","Raipur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1575","492013","1","0","0","Sunder Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1576","495001","1","0","0","Bilaspur City","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1577","495004","1","0","0","Bilaspur City","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1578","495006","1","0","0","Seepat Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1579","495223","1","0","0","Sipra Industrial Estate","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1580","500001","1","0","0","Hyderabad G.P.O. ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1581","500002","1","0","0","Hyderabad Jubilee","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1582","500003","1","0","0","Secunderabad","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1583","500004","1","0","0","Khairatabad","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1584","500005","1","0","0","Crp Camp (Hyderabad)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1585","500006","1","0","0","Karwan Sahu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1586","500007","1","0","0","Administrative Buildings","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1587","500008","1","0","0","Appa Himayathsagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1588","500009","1","0","0","Manovikasnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1589","500010","1","0","0","Alwal","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1590","500011","1","0","0","Bowenpally","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1591","500012","1","0","0","Afzalgunj","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1592","500013","1","0","0","Amberpet","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1593","500014","1","0","0","Hakimpet","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1594","500015","1","0","0","Trimulgherry","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1595","500016","1","0","0","Begumpet","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1596","500017","1","0","0","Lallapet","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1597","500018","1","0","0","Bharat Nagar Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1598","500019","1","0","0","Lingampalli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1599","500020","1","0","0","Ashoknagar (Hyderabad)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1600","500021","1","0","0","EME Records","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1601","500022","1","0","0","Central Secretariat","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1602","500023","1","0","0","Yakutpura","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1603","500024","1","0","0","Sahifa","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1604","500025","1","0","0","Padmaraonagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1605","500026","1","0","0","Nehrunagar (Hyderabad)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1606","500027","1","0","0","Stn Kachiguda","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1607","500028","1","0","0","Murad Nagar (Hyderabad)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1608","500029","1","0","0","Old Mla Quarters","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1609","500030","1","0","0","Rajendranagar (K.V.Rangareddy)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1610","500031","1","0","0","Ibrahim Bagh Lines","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1611","500032","1","0","0","Gachibowli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1612","500033","1","0","0","Jubilee Hills","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1613","500034","1","0","0","Banjara Hills","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1614","500035","1","0","0","Huda Residential Complex","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1615","500036","1","0","0","Malakpet Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1616","500037","1","0","0","Balanagar Township","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1617","500038","1","0","0","Sanjeev Reddy Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1618","500039","1","0","0","Peerzadiguda","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1619","500040","1","0","0","Aphb Colony Moulali","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1620","500041","1","0","0","Raj Bhawan (Hyderabad)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1621","500042","1","0","0","Hal (Hyderabad)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1622","500044","1","0","0","Vidyanagar (Hyderabad)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1623","500045","1","0","0","A.Gs. Staff Quarters","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1624","500046","1","0","0","CUC","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1625","500047","1","0","0","Anandbagh","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1626","500048","1","0","0","Attapur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1627","500049","1","0","0","Miyapur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1628","500050","1","0","0","Chandanagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1629","500051","1","0","0","Hindustan Cables Ltd","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1630","500052","1","0","0","Svpnpa","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1631","500053","1","0","0","Falaknuma","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1632","500054","1","0","0","HMT Township","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1633","500055","1","0","0","IDA Jeedimetla","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1634","500056","1","0","0","Neredmet","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1635","500057","1","0","0","Vijay Nagar Colony (Hyderabad)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1636","500058","1","0","0","Kanchanbagh","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1637","500059","1","0","0","Saidabad (Hyderabad)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1638","500060","1","0","0","P & T Colony (K.V.Rangareddy)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1639","500061","1","0","0","Sitaphalmandi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1640","500062","1","0","0","Dr As Rao Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1641","500063","1","0","0","LIC Division","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1642","500064","1","0","0","Bahadurpura","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1643","500065","1","0","0","Fatehdarwaza","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1644","500066","1","0","0","High Court (Hyderabad)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1645","500067","1","0","0","Suchitra Junction","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1646","500068","1","0","0","Gsi(Sr) Bandlaguda","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1647","500069","1","0","0","R.C.Imarat","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1648","500070","1","0","0","Sarada Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1649","500071","1","0","0","Rail Nilayam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1650","500072","1","0","0","KPHB Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1651","500073","1","0","0","Srinagar Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1652","500074","1","0","0","L B Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1653","500075","1","0","0","C.B.I.T","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1654","500076","1","0","0","I.E.Nacharam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1655","500077","1","0","0","Kattedan Ie","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1656","500078","1","0","0","Nisa Hakimpet","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1657","500079","1","0","0","Vaishalinagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1658","500080","1","0","0","Gandhinagar (Hyderabad)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1659","500081","1","0","0","Cyberabad","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1660","500082","1","0","0","I.M.Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1661","500083","1","0","0","Nagaram (K.V.Rangareddy)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1662","500084","1","0","0","Kothaguda (K.V.Rangareddy)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1663","500085","1","0","0","Jntu Kukat Pally","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1664","500087","1","0","0","Allembylines","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1665","500089","1","0","0","Puppalaguda","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1666","500090","1","0","0","Nizampet ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1667","500091","1","0","0","Hydershahkote","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1668","500092","1","0","0","Boduppal","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1669","500093","1","0","0","Vikasnagar (Hyderabad)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1670","500094","1","0","0","Sainikpuri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1671","500095","1","0","0","Putlibowli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1672","500096","1","0","0","Film Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1673","500097","1","0","0","Meerpet","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1674","500098","1","0","0","Medipalli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1675","500123","1","0","0","Medipalli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1676","500195","1","0","0","KOTI ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1677","500409","1","0","0","(shamshabad)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1678","500484","1","0","0","SOMAJIGUDA","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1679","500486","1","0","0","Medipalli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1680","500594","1","0","0","Defence Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1681","500890","1","0","0","Kalyan nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1682","501218","1","0","0","Shamshabad (K.V.Rangareddy)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1683","501401","1","0","0","Medchal","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1684","501507","1","0","0","Raipole","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1685","502032","1","0","0","A.I.E. R.C.puram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1686","502312","1","0","0","Kodakandla","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1687","502313","1","0","0","Narsapur (Medak)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1688","502324","1","0","0","Icrisat","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1689","505001","1","0","0","Karimnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1690","505002","1","0","0","Uppal (Karim Nagar)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1691","505301","1","0","0","Bonala","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1692","505302","1","0","0","Vemulawada","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1693","506001","1","0","0","Hanamkonda","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1694","506002","1","0","0","Warangal","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1695","506003","1","0","0","Khazipet","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1696","506004","1","0","0","Fathima Nagar(NIT)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1697","506007","1","0","0","KMC Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1698","506009","1","0","0","KUC Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1699","506011","1","0","0","Reddy Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1700","506013","1","0","0","Pragati Industrial Estate","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1701","506015","1","0","0","Bheemaram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1702","507001","1","0","0","I Town","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1703","507002","1","0","0","II Town","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1704","507003","1","0","0","III Town","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1705","507101","1","0","0","Kothagudem Colls","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1706","507113","1","0","0","Mothugudem","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1707","507115","1","0","0","Dantalaboru","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1708","517101","1","0","0","Chandragiri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1709","517102","1","0","0","Narasingapuram (Chittoor)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1710","517501","1","0","0","Tirupati","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1711","517520","1","0","0","Renigunta","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1712","518001","1","0","0","Kurnool","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1713","518002","1","0","0","Bukkapuram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1714","518003","1","0","0","SAP Camp-kNL","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1715","518004","1","0","0","Bhagya Nagar-kurnool","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1716","518005","1","0","0","Ashoknagar (Kurnool)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1717","518006","1","0","0","Balaji Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1718","523001","1","0","0","Ongole","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1719","523002","1","0","0","Kurnool Road (O)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1720","524001","1","0","0","Nellore H.O.","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1721","524002","1","0","0","Stonehouse peta","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1722","524003","1","0","0","Dargamitta","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1723","524004","1","0","0","Andrakesarinagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1724","524005","1","0","0","Polytechnic college","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1725","530001","1","0","0","VISAKHAPATNAM HEAD POST OFFICE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1726","530002","1","0","0","MAHARANIPETA","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1727","530003","1","0","0","ANDHARAUNIVERSITY","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1728","530004","1","0","0","WALTAIR RAILWAY STATION","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1729","530005","1","0","0","GANDHIGRAM","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1730","530007","1","0","0","INDUSTRIALESTATE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1731","530008","1","0","0","KANCHARAPALEM","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1732","530009","1","0","0","N.A.D","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1733","530011","1","0","0","MALKAPURAM","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1734","530012","1","0","0","BHPV","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1735","530013","1","0","0","P & T COLONY OR SEETHAMADHARA","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1736","530014","1","0","0","NAVALBASE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1737","530015","1","0","0","ZINC SMELTER","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1738","530016","1","0","0","AKKAYAPALEM","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1739","530017","1","0","0","L.B COLONY &? M.V.P COLONY","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1740","530018","1","0","0","MARRIPALEM","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1741","530020","1","0","0","DABAGARDENS","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1742","530022","1","0","0","H.B COLONY","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1743","530024","1","0","0","SALIGRAMAPURAM","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1744","530026","1","0","0","GAJUWAKA","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1745","530027","1","0","0","GOPALAPATNAM","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1746","530028","1","0","0","SIMHACHALAM","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1747","530035","1","0","0","PORT","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1748","530040","1","0","0","Govt Dairy Farm","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1749","530048","1","0","0","Madhurawada","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1750","530049","1","0","0","Sez","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1751","531001","1","0","0","Anakapalle","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1752","531002","1","0","0","Nidanam Doddi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1753","531011","1","0","0","ACHUTAPURAM","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1754","531021","1","0","0","JNPHARMA CITY","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1755","531162","1","0","0","Chittivalasa","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1756","533001","1","0","0","Kakinada","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1757","533002","1","0","0","Church Square","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1758","533003","1","0","0","Bhaskarnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1759","533004","1","0","0","Gandhinagar(KKD)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1760","533005","1","0","0","Apiic","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1761","533006","1","0","0","Indrapalem","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1762","533101","1","0","0","R.S.Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1763","533103","1","0","0","Danavaipeta","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1764","533104","1","0","0","Aryapuram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1765","533105","1","0","0","Sriram Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1766","533106","1","0","0","Spinning Mill Centre","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1767","533461","1","0","0","Coringa","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1768","533463","1","0","0","Tallarevu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1769","533464","1","0","0","Yanam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1770","534134","1","0","0","Attili","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1771","534201","1","0","0","I Town","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1772","534202","1","0","0","II Town","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1773","534204","1","0","0","Chinnameram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1774","534211","1","0","0","Tanuku","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1775","534215","1","0","0","Venkatrayapuram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1776","534216","1","0","0","Vundrajavaram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1777","534222","1","0","0","Velpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1778","560001","1","0","0","Bangalore G.P.O. ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1779","560002","1","0","0","Bangalore City","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1780","560003","1","0","0","Malleswaram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1781","560004","1","0","0","Basavanagudi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1782","560005","1","0","0","Fraser Town","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1783","560006","1","0","0","J.C.Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1784","560007","1","0","0","Air Force Hospital","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1785","560008","1","0","0","H.A.L II Stage","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1786","560009","1","0","0","Bangalore Dist Offices Bldg","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1787","560010","1","0","0","Rajajinagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1788","560011","1","0","0","Jayangar III Block","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1789","560012","1","0","0","Science Institute","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1790","560013","1","0","0","Jalahalli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1791","560014","1","0","0","Jalahalli East","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1792","560015","1","0","0","Jalahalli West","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1793","560016","1","0","0","Krishnarajapuram R S","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1794","560017","1","0","0","Vimanapura","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1795","560018","1","0","0","Chamrajpet Bazar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1796","560019","1","0","0","Gaviopuram Extension","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1797","560020","1","0","0","Seshadripuram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1798","560021","1","0","0","Gayathrinagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1799","560022","1","0","0","Yeshwanthpur Bazar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1800","560023","1","0","0","Magadi Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1801","560024","1","0","0","Anandnagar (Bangalore)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1802","560025","1","0","0","Museum Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1803","560026","1","0","0","Bapujinagar (Bangalore)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1804","560027","1","0","0","Sampangiramnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1805","560028","1","0","0","Tyagrajnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1806","560029","1","0","0","Dharmaram College","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1807","560030","1","0","0","Adugodi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1808","560031","1","0","0","R T Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1809","560032","1","0","0","R T Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1810","560033","1","0","0","Malkand Lines","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1811","560034","1","0","0","Agara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1812","560035","1","0","0","Carmelaram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1813","560036","1","0","0","Devasandra","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1814","560037","1","0","0","Doddanekkundi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1815","560038","1","0","0","Indiranagar Com. Complex","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1816","560039","1","0","0","Nayandahalli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1817","560040","1","0","0","Vijayanagar (Bangalore)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1818","560041","1","0","0","Jayanagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1819","560042","1","0","0","Sivan Chetty Gardens","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1820","560043","1","0","0","Banaswadi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1821","560044","1","0","0","Arabic College","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1822","560045","1","0","0","Arabic College","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1823","560046","1","0","0","Benson Town","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1824","560047","1","0","0","Viveknagar (Bangalore)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1825","560048","1","0","0","Mahadevapura","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1826","560049","1","0","0","Bhattarahalli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1827","560050","1","0","0","Ashoknagar (Bangalore)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1828","560051","1","0","0","H.K.P. Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1829","560052","1","0","0","H.K.P. Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1830","560053","1","0","0","Chickpet","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1831","560054","1","0","0","Mathikere","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1832","560055","1","0","0","Malleswaram West","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1833","560056","1","0","0","Bnagalore Viswavidalaya","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1834","560057","1","0","0","Peenya Dasarahalli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1835","560058","1","0","0","Laggere","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1836","560059","1","0","0","Rv Niketan","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1837","560060","1","0","0","Kengeri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1838","560061","1","0","0","Chikkalasandra","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1839","560062","1","0","0","Doddakallasandra","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1840","560063","1","0","0","A F Station Yelahanka","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1841","560064","1","0","0","Attur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1842","560065","1","0","0","G.K.V.K.","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1843","560066","1","0","0","Whitefield","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1844","560067","1","0","0","Kadugodi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1845","560068","1","0","0","Begur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1846","560069","1","0","0","B Sk II Stage","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1847","560070","1","0","0","B Sk II Stage","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1848","560071","1","0","0","Domlur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1849","560072","1","0","0","Nagarbhavi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1850","560073","1","0","0","Bagalgunte","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1851","560074","1","0","0","Jeevabhimanagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1852","560075","1","0","0","Jeevabhimanagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1853","560076","1","0","0","Bannerghatta Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1854","560077","1","0","0","Dr. Shivarama Karanth Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1855","560078","1","0","0","J P Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1856","560079","1","0","0","Basaveshwaranagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1857","560080","1","0","0","Sadashivanagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1858","560081","1","0","0","Udaypura","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1859","560082","1","0","0","Udaypura","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1860","560083","1","0","0","Bannerghatta","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1861","560084","1","0","0","Kacharakanahalli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1862","560085","1","0","0","Banashankari III Stage","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1863","560086","1","0","0","Mahalakshmipuram Layout","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1864","560087","1","0","0","Vartur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1865","560088","1","0","0","Hessarghatta","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1866","560089","1","0","0","Hessarghatta Lake","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1867","560090","1","0","0","Chikkabanavara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1868","560091","1","0","0","Bapagrama","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1869","560092","1","0","0","Sahakaranagar P.O","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1870","560093","1","0","0","C.V.Raman Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1871","560094","1","0","0","ISRO Anthariksha Bhavan","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1872","560095","1","0","0","Koramangala VI Bk","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1873","560096","1","0","0","Kanteeravanagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1874","560097","1","0","0","Vidyaranyapura","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1875","560098","1","0","0","Rajarajeshwarinagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1876","560099","1","0","0","Bommasandra Industrial Estate","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1877","560100","1","0","0","Electronics City","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1878","560102","1","0","0","HSR Layout","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1879","560103","1","0","0","Bellandur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1880","560104","1","0","0","Hampinagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1881","560300","1","0","0","Bangalore International Airport","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1882","561203","1","0","0","Antharahalli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1883","562114","1","0","0","Hoskote","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1884","570001","1","0","0","Mysore","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1885","570002","1","0","0","Gokulam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1886","570003","1","0","0","Note Mudran Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1887","570004","1","0","0","Chamundi Extension","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1888","570005","1","0","0","Mysore Law Courts","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1889","570006","1","0","0","Manasagangothri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1890","570007","1","0","0","Narasimha Raja Mohalla","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1891","570008","1","0","0","Asokapuram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1892","570009","1","0","0","Saraswathipuram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1893","570010","1","0","0","Chamundi Betta","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1894","570011","1","0","0","Siddarthanagar Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1895","570012","1","0","0","Jayalakshmipuram (Mysore)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1896","570013","1","0","0","Jayanagar (Mysore)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1897","570014","1","0","0","Jayanagar (Mysore)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1898","570015","1","0","0","Bannimantap","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1899","570016","1","0","0","Hebbal Layout","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1900","570017","1","0","0","Hinkal","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1901","570018","1","0","0","Belavadi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1902","570019","1","0","0","Jyothinagar (Mysore)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1903","570020","1","0","0","Brindavan Extension","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1904","570021","1","0","0","Ramakrishna Nagar (Mysore)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1905","570022","1","0","0","Ramakrishna Nagar (Mysore)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1906","570023","1","0","0","Jt Extension","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1907","570024","1","0","0","Krishna Raja Mohalla","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1908","570025","1","0","0","G S Ashram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1909","570026","1","0","0","Bogadi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1910","570027","1","0","0","Infosys Campus","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1911","572101","1","0","0","Tumkur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1912","572102","1","0","0","Gandinagar Tumkur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1913","572103","1","0","0","Kuvempunagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1914","572104","1","0","0","Belagumba","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1915","572105","1","0","0","Maralur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1916","572106","1","0","0","Northren Extension","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1917","575001","1","0","0","Mangalore","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1918","575002","1","0","0","Balmatta","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1919","575003","1","0","0","District Courts (Dakshina Kannada)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1920","575004","1","0","0","Bijai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1921","575005","1","0","0","Kulshekar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1922","575006","1","0","0","Ashoknagar(MR)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1923","575008","1","0","0","Konchady","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1924","575010","1","0","0","Panambur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1925","575011","1","0","0","Baikampady","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1926","576001","1","0","0","Katipalla","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1927","576101","1","0","0","Udupi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1928","576102","1","0","0","Kunjibettu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1929","576103","1","0","0","Ambalapadi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1930","576104","1","0","0","Manipal","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1931","576124","1","0","0","Perdur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1932","577001","1","0","0","Davangere","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1933","577002","1","0","0","Basavanahal","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1934","577003","1","0","0","Rm Yard- Davanagere","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1935","577004","1","0","0","Cg Hospital","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1936","577005","1","0","0","Bapuji Vidyanagara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1937","577006","1","0","0","Devaraj Urs Layout-Dvg","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1938","577501","1","0","0","Chitradurga","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1939","577502","1","0","0","Chikkagondanahally","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1940","580001","1","0","0","Dharwad","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1941","580002","1","0","0","Dharwad S D M E college","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1942","580003","1","0","0","Dharwad K V V","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1943","580004","1","0","0","Dharwad Vidyagiri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1944","580005","1","0","0","Dharwad U A S","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1945","580007","1","0","0","Aravatagi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1946","580008","1","0","0","Dharwad K.C.Park","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1947","580009","1","0","0","Dharwad Sattur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1948","580011","1","0","0","Dharwad High Court","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1949","580020","1","0","0","Hubli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1950","580021","1","0","0","Hubli KMC","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1951","580022","1","0","0","Byahatti","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1952","580023","1","0","0","Byahatti","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1953","580024","1","0","0","Anchatageri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1954","580025","1","0","0","Amragol","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1955","580026","1","0","0","Hubli Tarihal Indl. Estate","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1956","580027","1","0","0","Hubli Tarihal Indl. Estate","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1957","580028","1","0","0","Adaragunchi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1958","580029","1","0","0","Hubli Bharat Mill","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1959","580030","1","0","0","Gokul","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1960","580031","1","0","0","Hubli Eng College","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1961","580032","1","0","0","Hubli Vijayanagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1962","581110","1","0","0","Haveri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1963","582101","1","0","0","Gadag","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1964","582102","1","0","0","Balaganur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1965","582103","1","0","0","Advisomapur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1966","583101","1","0","0","Bellary","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1967","583102","1","0","0","Bandihatti","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1968","583103","1","0","0","Asundi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1969","583123","1","0","0","Bellary","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1970","583132","1","0","0","Hospet","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1971","583201","1","0","0","Hospet","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1972","583202","1","0","0","Hospet N C C","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1973","583203","1","0","0","Hospet N C C","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1974","583211","1","0","0","Hospet","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1975","583221","1","0","0","Hospet","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1976","583225","1","0","0","Hospet","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1977","583234","1","0","0","Hospet","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1978","583239","1","0","0","Hospet","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1979","583275","1","0","0","Vidyanagar (Bellary)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1980","584101","1","0","0","Raichur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1981","584102","1","0","0","Askihal","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1982","584103","1","0","0","Dinni","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1983","585101","1","0","0","Gulbarga","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1984","585102","1","0","0","Bhopal Tegnoor","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1985","585103","1","0","0","GB Bahamanipura","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1986","585104","1","0","0","Asta","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1987","585105","1","0","0","GB Ggh","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1988","585201","1","0","0","Yadgiri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1989","585202","1","0","0","Yadgiri Station","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1990","585401","1","0","0","Bidar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1991","585402","1","0","0","Bidar G.N.Jhira","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1992","585403","1","0","0","Bidar Gandhi Gunj","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1993","586101","1","0","0","Bijapur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1994","586102","1","0","0","Bijapur Sainik School","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1995","586103","1","0","0","Bijapur Vijaya College","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1996","586104","1","0","0","Ainapur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1997","586108","1","0","0","AMC Yard","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1998","587101","1","0","0","Bagalkot","1","1","1","0");
INSERT INTO delivery_pincode VALUES("1999","587102","1","0","0","Bagalkot Grbc","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2000","587103","1","0","0","Bagalkot Navanagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2001","587104","1","0","0","Bagalkot Taluk ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2002","590001","1","0","0","Belgaum","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2003","590002","1","0","0","Belgaum","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2004","590003","1","0","0","Alarwad","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2005","590004","1","0","0","Alarwad","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2006","590005","1","0","0","Belgaum M. Vadgaon","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2007","590006","1","0","0","Angol","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2008","590007","1","0","0","Udyambag","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2009","590008","1","0","0","Udyambag","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2010","590009","1","0","0","Belgaum Records MLI","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2011","590010","1","0","0","Aluminium Factory","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2012","590011","1","0","0","Hindawadi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2013","590012","1","0","0","Hindawadi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2014","590013","1","0","0","Hindawadi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2015","590014","1","0","0","Peeranwadi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2016","590015","1","0","0","Peeranwadi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2017","590016","1","0","0","Ashte","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2018","590018","1","0","0","VTU Campus Belgaum","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2019","600001","1","0","0","Chennai G.P.O. ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2020","600002","1","0","0","Anna Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2021","600003","1","0","0","Park Town","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2022","600004","1","0","0","Mylapore","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2023","600005","1","0","0","Chepauk","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2024","600006","1","0","0","Greams Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2025","600007","1","0","0","Vepery","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2026","600008","1","0","0","Egmore ND","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2027","600009","1","0","0","Fort St George","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2028","600010","1","0","0","Kilpauk Medical College","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2029","600011","1","0","0","Perambur North","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2030","600012","1","0","0","Decosters Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2031","600013","1","0","0","Rayapuram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2032","600014","1","0","0","Lloyds Estate","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2033","600015","1","0","0","Guindy North","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2034","600016","1","0","0","St.Thomas Mount","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2035","600017","1","0","0","Thygarayanagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2036","600018","1","0","0","Pr. Accountant General","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2037","600019","1","0","0","Kaladipet","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2038","600020","1","0","0","Adyar (Chennai)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2039","600021","1","0","0","Cemetry Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2040","600022","1","0","0","Rajbhavan (Chennai)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2041","600023","1","0","0","Aynavaram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2042","600024","1","0","0","Kodambakkam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2043","600025","1","0","0","Engineering College (Chennai)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2044","600026","1","0","0","Vadapalani","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2045","600027","1","0","0","Vadapalani","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2046","600028","1","0","0","Raja Annamalaipuram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2047","600029","1","0","0","Aminjikarai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2048","600030","1","0","0","Shenoy Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2049","600031","1","0","0","Chetput","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2050","600032","1","0","0","Ekkaduthangal","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2051","600033","1","0","0","Mambalam R.S.","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2052","600034","1","0","0","Loyola College","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2053","600035","1","0","0","Nandanam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2054","600036","1","0","0","Indian Institute Of Technology","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2055","600037","1","0","0","Mogappair","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2056","600038","1","0","0","Icf Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2057","600039","1","0","0","Vyasar Nagar Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2058","600040","1","0","0","Anna Nagar (Chennai)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2059","600041","1","0","0","Neelankarai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2060","600042","1","0","0","Velacheri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2061","600043","1","0","0","Pallavaram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2062","600044","1","0","0","Bharathipuram (Kanchipuram)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2063","600045","1","0","0","Tambaram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2064","600046","1","0","0","Tambaram IAF","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2065","600047","1","0","0","Tambaram Sanatorium","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2066","600048","1","0","0","Kolapakkam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2067","600049","1","0","0","Rajajinagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2068","600050","1","0","0","Jagadambigainagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2069","600051","1","0","0","Madhavaram Milk Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2070","600053","1","0","0","Ambattur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2071","600054","1","0","0","Avadi Camp","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2072","600055","1","0","0","Avadi IAF","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2073","600056","1","0","0","POONAMALLEE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2074","600057","1","0","0","Ennore RS","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2075","600058","1","0","0","Ambattur Indl Estate","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2076","600059","1","0","0","Christian College Tambaram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2077","600060","1","0","0","Madhavaram (Tiruvallur)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2078","600061","1","0","0","Nanganallur Bazaar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2079","600062","1","0","0","Kovilpadagai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2080","600063","1","0","0","Srinivasanagar (Kanchipuram)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2081","600064","1","0","0","Chitlapakkam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2082","600065","1","0","0","CRP camp (Tiruvallur)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2083","600068","1","0","0","Manali (Tiruvallur)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2084","600069","1","0","0","Kunnathur (Kanchipuram)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2085","600070","1","0","0","Anakaputhur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2086","600071","1","0","0","Kamarajnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2087","600072","1","0","0","Arignar Anna Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2088","600073","1","0","0","Gowriwakkam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2089","600074","1","0","0","Polichalur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2090","600075","1","0","0","Pammal East","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2091","600076","1","0","0","Korattur RS","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2092","600077","1","0","0","Thiruverkadu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2093","600078","1","0","0","Kalaignar Karunanidhi Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2094","600079","1","0","0","Kalaignar Karunanidhi Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2095","600080","1","0","0","Korattur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2096","600081","1","0","0","Tondiarpet Bazaar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2097","600082","1","0","0","Agaram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2098","600083","1","0","0","Ashoknagar (Chennai)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2099","600084","1","0","0","Flowers Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2100","600085","1","0","0","Kotturpuram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2101","600086","1","0","0","Gopalapuram (Chennai)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2102","600087","1","0","0","Alwarthirunagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2103","600088","1","0","0","Adambakkam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2104","600089","1","0","0","Nandambakkam Kudiyiruppu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2105","600090","1","0","0","Besantnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2106","600091","1","0","0","Madipakkam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2107","600092","1","0","0","Koyambedu Wholesale Market Com","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2108","600093","1","0","0","Saligramam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2109","600094","1","0","0","Choolaimedu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2110","600095","1","0","0","Maduravoyal","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2111","600096","1","0","0","Perungudi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2112","600097","1","0","0","Karapakkam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2113","600098","1","0","0","Sidco Estate","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2114","600099","1","0","0","Kolathur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2115","600100","1","0","0","Medavakkam ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2116","600101","1","0","0","Anna Nagar Western Extn","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2117","600102","1","0","0","Anna Nagar East","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2118","600103","1","0","0","Manali New Town","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2119","600104","1","0","0","High Court Building (Chennai)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2120","600105","1","0","0","High Court Building (Chennai)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2121","600106","1","0","0","Arumbakkam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2122","600107","1","0","0","Koyambedu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2123","600108","1","0","0","Broadway","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2124","600109","1","0","0","Avadi ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2125","600110","1","0","0","Ponniammanmedu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2126","600111","1","0","0","Ponniammanmedu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2127","600112","1","0","0","Choolai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2128","600113","1","0","0","Tidel Park","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2129","600114","1","0","0","Pazhavanthangal","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2130","600115","1","0","0","Injambakkam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2131","600116","1","0","0","Alapakkam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2132","600117","1","0","0","Bharathinagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2133","600118","1","0","0","Kodungaiyur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2134","600119","1","0","0","Sholinganallur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2135","600120","1","0","0","North Chennai Thermal PP","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2136","600122","1","0","0","Mangadu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2137","600126","1","0","0","Madambakkam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2138","605001","1","0","0","Pondicherry","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2139","605002","1","0","0","Sri Aurobindo Ashram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2140","605003","1","0","0","Muthialpet","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2141","605004","1","0","0","Mudaliarpet","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2142","605005","1","0","0","Nellithoppe","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2143","605006","1","0","0","Dhanvantry Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2144","605008","1","0","0","Lawspet","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2145","605009","1","0","0","Thattanchavady","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2146","605010","1","0","0","Reddiyarpalayam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2147","605011","1","0","0","Venkata Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2148","605012","1","0","0","Padmini  Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2149","605013","1","0","0","Saram(Py)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2150","605014","1","0","0","Kalapet","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2151","605110","1","0","0","Villianur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2152","620001","1","0","0","Tiruchirappalli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2153","620002","1","0","0","Rock Fort","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2154","620003","1","0","0","Woriur Bazaar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2155","620004","1","0","0","Ambikapuram (Tiruchirappalli)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2156","620005","1","0","0","EVR Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2157","620006","1","0","0","Srirangam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2158","620007","1","0","0","Tiruchirappalli Airport","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2159","620008","1","0","0","Clock Tower (Tiruchirappalli)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2160","620009","1","0","0","Ramjeenagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2161","620010","1","0","0","Industrial Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2162","620011","1","0","0","Melakalkandarkottai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2163","620012","1","0","0","Craw Ford Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2164","620013","1","0","0","Thiruverumbur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2165","620014","1","0","0","Administrative Office(BHEL)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2166","620015","1","0","0","Regional Engineering College .","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2167","620016","1","0","0","Ordnance Estate - TR","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2168","620017","1","0","0","Puthur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2169","620018","1","0","0","Thillai Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2170","620019","1","0","0","Pappakurichi Kattur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2171","620020","1","0","0","Jamal Mohamed College","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2172","620021","1","0","0","K.K.Nagar (Tiruchirappalli)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2173","620022","1","0","0","Thuvakudimalai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2174","620023","1","0","0","Khajanagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2175","620024","1","0","0","Bharathidasan University","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2176","620025","1","0","0","Hapf Township","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2177","620026","1","0","0","Annanagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2178","624001","1","0","0","Angunagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2179","624002","1","0","0","Begampur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2180","624003","1","0","0","Adiyanuthu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2181","625001","1","0","0","Madurai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2182","625002","1","0","0","Tallakulam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2183","625003","1","0","0","Alagappa Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2184","625004","1","0","0","Pasumalai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2185","625005","1","0","0","Thiruparankundram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2186","625006","1","0","0","Pandian Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2187","625007","1","0","0","Denobli Press","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2188","625008","1","0","0","Kappalur Indl.Estate","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2189","625009","1","0","0","Anuppanadi Housing Board Colon","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2190","625010","1","0","0","Anuppanadi Housing Board Colon","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2191","625011","1","0","0","Jaihindpuram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2192","625012","1","0","0","Avanivapuram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2193","625014","1","0","0","Chatrapatti","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2194","625015","1","0","0","Thiagarajar Engg College","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2195","625016","1","0","0","Arasaradi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2196","625017","1","0","0","Anaiyur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2197","625018","1","0","0","Kumaram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2198","625019","1","0","0","Nagamalai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2199","625020","1","0","0","Andarkottaram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2200","626102","1","0","0","Chatrapatti (Virudhunagar)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2201","626108","1","0","0","Kumarasamy Raja Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2202","626111","1","0","0","Muhavur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2203","626117","1","0","0","Rajapalayam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2204","626121","1","0","0","Seithur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2205","626122","1","0","0","Settiyarpatti","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2206","626125","1","0","0","Inamkarisalkulam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2207","626139","1","0","0","Cholapuram South","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2208","626188","1","0","0","Dhalavaipuram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2209","628001","1","0","0","Tuticorin","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2210","628002","1","0","0","Alagesapuram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2211","628003","1","0","0","Tuticorin Court","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2212","628004","1","0","0","Tuticorin Harbour Estate","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2213","628005","1","0","0","Athimarapatti","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2214","628006","1","0","0","Thermal Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2215","628007","1","0","0","Heavy Water Project Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2216","628008","1","0","0","Chidambaranagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2217","629001","1","0","0","Nagercoil","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2218","629002","1","0","0","Edalakudy","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2219","629003","1","0","0","Vetturnimadam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2220","629004","1","0","0","Nagercoil Industrial Estate","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2221","636001","1","0","0","Salem","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2222","636016","1","0","0","Fairlands","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2223","638001","1","0","0","Erode","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2224","638002","1","0","0","Erode Railway Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2225","638003","1","0","0","Karungalpalayam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2226","638004","1","0","0","Veerappanchatram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2227","638005","1","0","0","Peria Agraharam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2228","638006","1","0","0","Pallipalayam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2229","638007","1","0","0","Cauvery Railway Station","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2230","638008","1","0","0","Pallipalayamagraharam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2231","638009","1","0","0","Edayankattuvalsu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2232","638010","1","0","0","SPB Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2233","638011","1","0","0","Erode Collectorate","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2234","638012","1","0","0","Thindal","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2235","639001","1","0","0","Ramakrishnapuram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2236","639002","1","0","0","Andankoil","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2237","639003","1","0","0","Sukkaliyur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2238","639004","1","0","0","Gandhi Gramam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2239","639005","1","0","0","Thanthonimalai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2240","639006","1","0","0","Vengamedu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2241","639007","1","0","0","Karur Collectorate","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2242","641001","1","0","0","Coimbatore","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2243","641002","1","0","0","Rathinasabapathy Puram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2244","641003","1","0","0","Lawley Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2245","641004","1","0","0","Gandhimaanagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2246","641005","1","0","0","Singanallur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2247","641006","1","0","0","Ganapathy","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2248","641007","1","0","0","S.B.Institute","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2249","641008","1","0","0","Kuniamuthur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2250","641009","1","0","0","Ramnagar Coimbatore","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2251","641010","1","0","0","Perur (Coimbatore)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2252","641011","1","0","0","Saibaba Mission","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2253","641012","1","0","0","Gandhipuram (Coimbatore)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2254","641013","1","0","0","Govt.College Of Technology","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2255","641014","1","0","0","Coimbatore Aerodrome","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2256","641015","1","0","0","Uppilipalayam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2257","641016","1","0","0","Ondipudur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2258","641017","1","0","0","Vadamadurai Kurudampalayam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2259","641018","1","0","0","Coimbatore Central","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2260","641019","1","0","0","Coimbatore Press Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2261","641020","1","0","0","Naickenpalayam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2262","641021","1","0","0","Coimbatore Industrial Estate","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2263","641022","1","0","0","N.G.G.O Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2264","641023","1","0","0","Konavaikalpalayam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2265","641024","1","0","0","Sundarapuram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2266","641025","1","0","0","Velandipalayam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2267","641026","1","0","0","Komarapalayam Coimbatore","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2268","641027","1","0","0","Rathinapuri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2269","641028","1","0","0","Sowripalayam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2270","641029","1","0","0","Cherannagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2271","641030","1","0","0","Kavundampalayam Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2272","641031","1","0","0","Narasimhanaickenpalayam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2273","641032","1","0","0","Othakkalmandapam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2274","641033","1","0","0","Neelikonampalayam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2275","641034","1","0","0","Tudiyalur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2276","641035","1","0","0","Saravanampatti","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2277","641036","1","0","0","Nanjundapuram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2278","641037","1","0","0","Pappanaickenpalayam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2279","641038","1","0","0","Kuppakonanpudur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2280","641039","1","0","0","Telungupalayam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2281","641040","1","0","0","Telungupalayam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2282","641041","1","0","0","Pappanaickenpudur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2283","641042","1","0","0","Kovaipudur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2284","641043","1","0","0","Sahs College","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2285","641044","1","0","0","Siddhapudur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2286","641045","1","0","0","Krishnaswamy Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2287","641046","1","0","0","Bharathiyar University","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2288","641047","1","0","0","Jothipuram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2289","641048","1","0","0","Kalaptti","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2290","641050","1","0","0","Malumachampatti","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2291","641062","1","0","0","Chinniam Palayam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2292","641111","1","0","0","Vellalore","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2293","641114","1","0","0","Karunya Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2294","641601","1","0","0","Tirupur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2295","641602","1","0","0","Kallampalayam Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2296","641603","1","0","0","Ayyankalipalayam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2297","641604","1","0","0","Arasampalayam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2298","641605","1","0","0","Veerapandi (Coimbatore)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2299","641606","1","0","0","Vijayapuram (Coimbatore)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2300","641607","1","0","0","Tirupur East","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2301","641608","1","0","0","Tirupur East","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2302","641652","1","0","0","Anuppapalayam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2303","641654","1","0","0","Avanash","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2304","641687","1","0","0","Iduvampalayam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2305","673001","1","0","0","Calicut","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2306","673002","1","0","0","Chalapuram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2307","673003","1","0","0","Kallai-kozhikode","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2308","673004","1","0","0","Calicut City","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2309","673005","1","0","0","East Hill","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2310","673006","1","0","0","Eranhipalam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2311","673007","1","0","0","Mankavu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2312","673008","1","0","0","Calicut Medical College","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2313","673009","1","0","0","Malaparamba","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2314","673010","1","0","0","Karaparamba","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2315","673011","1","0","0","Nadakavu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2316","673012","1","0","0","Marikunnu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2317","673013","1","0","0","Marikunnu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2318","673016","1","0","0","Kuthiravattom","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2319","673017","1","0","0","Chevayur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2320","673020","1","0","0","Calicut Civil Station","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2321","673021","1","0","0","Puthiyangadi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2322","673032","1","0","0","Calicut Beach","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2323","676102","1","0","0","Bettath Pudiangadi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2324","676103","1","0","0","Thalakkadathur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2325","676104","1","0","0","Trikkandiyur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2326","676105","1","0","0","Thekkummuri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2327","676106","1","0","0","Ponmundam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2328","676107","1","0","0","Pookayil Bazar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2329","676108","1","0","0","Triprangode","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2330","676109","1","0","0","Niramaruthur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2331","676110","1","0","0","Niramaruthur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2332","676320","1","0","0","Tayyalingal","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2333","676505","1","0","0","Malappuram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2334","676506","1","0","0","Kottilangadi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2335","676510","1","0","0","Randathani","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2336","678001","1","0","0","Palakkad","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2337","678002","1","0","0","Olavakkot","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2338","678003","1","0","0","Kalpathi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2339","678004","1","0","0","Nurani","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2340","678005","1","0","0","Chokkanathapuram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2341","678006","1","0","0","Pallipuram PG","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2342","678007","1","0","0","Chandranagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2343","678008","1","0","0","Palakkad Engineering College","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2344","678011","1","0","0","Ambikapuram (Palakkad)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2345","678012","1","0","0","Vadakanthara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2346","678013","1","0","0","Kunnathurmedu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2347","678014","1","0","0","Palakkad City","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2348","679321","1","0","0","Angadipuram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2349","679338","1","0","0","Kolathur-MLP","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2350","679357","1","0","0","Anamangad","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2351","680001","1","0","0","Thrissur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2352","680002","1","0","0","Punkunnu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2353","680003","1","0","0","Ayyanthole","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2354","680004","1","0","0","Poothole","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2355","680005","1","0","0","Thrissur East","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2356","680020","1","0","0","Thrissur City","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2357","680021","1","0","0","Thrissur R S","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2358","682001","1","0","0","Kochi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2359","682002","1","0","0","Mattancherry Jetty","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2360","682003","1","0","0","Willingdon Island","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2361","682005","1","0","0","Thoppumpady","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2362","682006","1","0","0","Palluruthy","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2363","682007","1","0","0","Kumbalangi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2364","682009","1","0","0","North End","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2365","682011","1","0","0","Ernakulam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2366","682012","1","0","0","Pachalam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2367","682013","1","0","0","Thevara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2368","682014","1","0","0","Thevara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2369","682015","1","0","0","Perumanur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2370","682016","1","0","0","Ernakulam Hindi Prachar Sabha","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2371","682017","1","0","0","Kaloor","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2372","682018","1","0","0","Ernakulam North","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2373","682019","1","0","0","Vyttila","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2374","682020","1","0","0","Kadavanthara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2375","682021","1","0","0","Thrikkakara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2376","682022","1","0","0","Kochi University","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2377","682023","1","0","0","Vaduthala","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2378","682024","1","0","0","Edapally","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2379","682025","1","0","0","Palarivattom","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2380","682026","1","0","0","Elamakkara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2381","682028","1","0","0","Vennala","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2382","682029","1","0","0","Matsyapuri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2383","682030","1","0","0","Kakkanad","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2384","682031","1","0","0","Ernakulam High Court","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2385","682032","1","0","0","Thammanam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2386","682033","1","0","0","Changampuzha Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2387","682035","1","0","0","Ernakulam College","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2388","682036","1","0","0","Panampilly Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2389","682037","1","0","0","Cochin Special Economic Zone","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2390","682301","1","0","0","Kochi Palace","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2391","683101","1","0","0","Aluva","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2392","683104","1","0","0","Kalamassery","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2393","683111","1","0","0","Kochi Airport","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2394","683572","1","0","0","Angamally","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2395","686001","1","0","0","Kottayam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2396","686002","1","0","0","Kottayam Collectorate","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2397","686003","1","0","0","Kottayam West","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2398","686004","1","0","0","Muttambalam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2399","686039","1","0","0","Chengalam South","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2400","688001","1","0","0","Alappuzha","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2401","688002","1","0","0","Thiruvampady Junction","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2402","688003","1","0","0","Sanathanapuram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2403","688006","1","0","0","Avalukkunnu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2404","688007","1","0","0","Alappuzha North","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2405","688008","1","0","0","Thumpoly","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2406","688009","1","0","0","Pazhaveedu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2407","688010","1","0","0","Pazhaveedu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2408","688011","1","0","0","Alappuzha District Hospital","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2409","688012","1","0","0","Alappuzha Bazar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2410","688013","1","0","0","Thathampally","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2411","688521","1","0","0","Pathirappally","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2412","688522","1","0","0","Kalavoor","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2413","688539","1","0","0","Mayithara Market","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2414","690101","1","0","0","Mavelikara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2415","690103","1","0","0","Thattarambalam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2416","690104","1","0","0","Cherukole","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2417","690106","1","0","0","Chettikulangara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2418","690110","1","0","0","Kallumala","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2419","690502","1","0","0","Kayangulam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2420","690503","1","0","0","Pallickal","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2421","690507","1","0","0","Cheppaud","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2422","690527","1","0","0","Puthuppally","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2423","690537","1","0","0","Pullikanakku","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2424","690559","1","0","0","Perungala","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2425","691001","1","0","0","Kollam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2426","691002","1","0","0","Asramom","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2427","691004","1","0","0","Kallumthazham","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2428","691005","1","0","0","T K M College","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2429","691006","1","0","0","Pallithottam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2430","691007","1","0","0","Thangasserry","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2431","691008","1","0","0","Kadappakada","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2432","691009","1","0","0","Thevally","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2433","691010","1","0","0","Vadakkevila","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2434","691011","1","0","0","Eravipuram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2435","691012","1","0","0","Thirumullavaram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2436","691013","1","0","0","Kollam Civil Station","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2437","691016","1","0","0","Thekkevila","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2438","691017","1","0","0","Thekkevila","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2439","691019","1","0","0","Uliyakovil","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2440","691020","1","0","0","Thattamala","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2441","691021","1","0","0","Pattathanam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2442","695001","1","0","0","Thiruvananthapuram G.P.O. ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2443","695002","1","0","0","Karamana","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2444","695003","1","0","0","Kaudiar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2445","695004","1","0","0","Pattom Palace","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2446","695005","1","0","0","Ambalamukku","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2447","695008","1","0","0","Vallakkadavoo","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2448","695009","1","0","0","Manacaud","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2449","695010","1","0","0","Sasthamangalam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2450","695011","1","0","0","Cheruvikkal","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2451","695012","1","0","0","Poojapura Junction","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2452","695014","1","0","0","Thycaud","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2453","695023","1","0","0","Attakulangara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2454","695024","1","0","0","Chakkai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2455","695033","1","0","0","PMG Jn","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2456","695034","1","0","0","Thiruvananthapuram  University","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2457","695035","1","0","0","Vanchiyoor Junction","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2458","695036","1","0","0","Thiruvananthapuram  Chalai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2459","695037","1","0","0","Thiruvananthapuram  Chalai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2460","700001","1","0","0","Kolkatta G.P.O. ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2461","700002","1","0","0","Cossipore","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2462","700003","1","0","0","Amrita Bazar Partika","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2463","700004","1","0","0","R.G.Kar Medical College","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2464","700005","1","0","0","Ahritola","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2465","700006","1","0","0","Beadon Street","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2466","700007","1","0","0","Barabazar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2467","700008","1","0","0","Barisha","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2468","700009","1","0","0","Parsibagan","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2469","700010","1","0","0","Beleghata","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2470","700011","1","0","0","Narkeldanga","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2471","700012","1","0","0","Bowbazar (Kolkata)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2472","700013","1","0","0","Dharmatala","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2473","700014","1","0","0","Asylum Lane","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2474","700015","1","0","0","Sales Tax Building","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2475","700016","1","0","0","Park Street","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2476","700017","1","0","0","Circus Avenue","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2477","700018","1","0","0","Bartala","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2478","700019","1","0","0","Ballygunge RS","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2479","700020","1","0","0","A.J.C.Bose Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2480","700021","1","0","0","Fort William","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2481","700022","1","0","0","Bakery Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2482","700023","1","0","0","Khiddirpore","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2483","700024","1","0","0","Garden Reach","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2484","700025","1","0","0","Bhawanipore","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2485","700026","1","0","0","Kalighat","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2486","700027","1","0","0","Alipore","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2487","700028","1","0","0","Dumdum","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2488","700029","1","0","0","Dover Lane","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2489","700030","1","0","0","Ashokegarh","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2490","700031","1","0","0","Dhakuria","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2491","700032","1","0","0","Bijoygarh","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2492","700033","1","0","0","Tollygunge","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2493","700034","1","0","0","Behala Municipal Market","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2494","700035","1","0","0","Alambazar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2495","700036","1","0","0","Baranagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2496","700037","1","0","0","Belgachia Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2497","700038","1","0","0","Sahapur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2498","700039","1","0","0","Bediadanga","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2499","700040","1","0","0","Netaji Nagar (Kolkata)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2500","700041","1","0","0","Paschim Putiari","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2501","700042","1","0","0","Kasba (Kolkata)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2502","700043","1","0","0","Sonai (Kolkata)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2503","700044","1","0","0","Badartala","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2504","700045","1","0","0","Lake Gardens","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2505","700046","1","0","0","Abinash Chaowdhury Lane","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2506","700047","1","0","0","Ganguly Bagan","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2507","700048","1","0","0","Patipukur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2508","700049","1","0","0","Nimta","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2509","700050","1","0","0","Sinthee","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2510","700051","1","0","0","Birati","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2511","700052","1","0","0","Kendriya Vihar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2512","700053","1","0","0","Kalabagan","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2513","700054","1","0","0","Bengal Chemical","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2514","700055","1","0","0","Bangur Avenue","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2515","700056","1","0","0","Belgharia","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2516","700057","1","0","0","Ariadaha","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2517","700058","1","0","0","Kamarhati","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2518","700059","1","0","0","Desh Bandhu Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2519","700060","1","0","0","Mahendra Banerjee Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2520","700061","1","0","0","Jairampur (Kolkata)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2521","700062","1","0","0","W.B.Governors Camp.","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2522","700063","1","0","0","Kalagachia (Kolkata)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2523","700064","1","0","0","Bidhan Nagar AE Market","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2524","700065","1","0","0","Durganagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2525","700066","1","0","0","Bidhangarh","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2526","700067","1","0","0","Lily Biscuit","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2527","700068","1","0","0","Jodhpur Park","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2528","700069","1","0","0","Esplanade","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2529","700070","1","0","0","Bansdroni","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2530","700071","1","0","0","Little Russel Street","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2531","700072","1","0","0","Hindustan Building","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2532","700073","1","0","0","Chittaranjan Avenue (Kolkata)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2533","700074","1","0","0","Dumdum Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2534","700075","1","0","0","Garfa","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2535","700076","1","0","0","Dakshineswar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2536","700077","1","0","0","Bediapara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2537","700078","1","0","0","Haltu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2538","700079","1","0","0","Italghacha","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2539","700080","1","0","0","Jessore Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2540","700081","1","0","0","Rajbari Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2541","700082","1","0","0","Haridevpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2542","700083","1","0","0","Nandan Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2543","700084","1","0","0","Garia Garden","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2544","700085","1","0","0","K.G Bose Sarani","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2545","700086","1","0","0","Baghajatin","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2546","700087","1","0","0","New Market","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2547","700088","1","0","0","Brace Bridge","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2548","700089","1","0","0","Kalindi Housing Estate","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2549","700090","1","0","0","Netaji Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2550","700091","1","0","0","Bidhan Nagar CK Market","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2551","700092","1","0","0","Regent Estate","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2552","700093","1","0","0","Purba Putiary","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2553","700094","1","0","0","Panchasayar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2554","700095","1","0","0","Golf Green","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2555","700096","1","0","0","Brahmapur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2556","700097","1","0","0","Purbachal","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2557","700098","1","0","0","Bidhan Nagar Sai Complex","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2558","700099","1","0","0","Kalikapur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2559","700100","1","0","0","Vip Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2560","700101","1","0","0","Prafulla Kanan","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2561","700102","1","0","0","Krishnapur (North 24 Parganas)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2562","700103","1","0","0","Narendrapur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2563","700104","1","0","0","Amgachi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2564","700105","1","0","0","Chowbhanga","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2565","700106","1","0","0","Bidhan Nagar IB Market","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2566","700107","1","0","0","E.K.T","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2567","700108","1","0","0","ISI Po","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2568","700109","1","0","0","Agarpara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2569","700110","1","0","0","Jugberia","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2570","700111","1","0","0","Ghola Bazar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2571","700112","1","0","0","Pansila","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2572","700113","1","0","0","Natagarh","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2573","700114","1","0","0","Panihati","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2574","700115","1","0","0","Sukchar (North 24 Parganas)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2575","700116","1","0","0","B.D.Sopan","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2576","700117","1","0","0","Khardah","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2577","700118","1","0","0","Rahara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2578","700119","1","0","0","Bandipur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2579","700121","1","0","0","Nilganj Bazaar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2580","700122","1","0","0","Anandapuri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2581","700123","1","0","0","Barrackpore RS","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2582","700137","1","0","0","Bawali Chandipur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2583","700138","1","0","0","Pujali","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2584","700139","1","0","0","Vivekananda Pally","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2585","700140","1","0","0","Batanagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2586","700141","1","0","0","Mahestala","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2587","700142","1","0","0","Santosh Pur (Maheshtala)so","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2588","700143","1","0","0","Sarkarpool","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2589","711101","1","0","0","Howrah","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2590","711102","1","0","0","Baisnabpara Bazar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2591","711103","1","0","0","Andul Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2592","711104","1","0","0","Chakraberia","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2593","711105","1","0","0","Dasnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2594","711106","1","0","0","Salkia","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2595","711107","1","0","0","Ghusuri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2596","711108","1","0","0","Netajigarh","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2597","711109","1","0","0","Bakultala","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2598","711112","1","0","0","Gip Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2599","711113","1","0","0","Balitikuri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2600","711202","1","0","0","Belur Bazar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2601","711204","1","0","0","A.Guha Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2602","712105","1","0","0","Buroshibtala (Hooghly)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2603","712136","1","0","0","Boraichanditala","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2604","712137","1","0","0","Gondalpara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2605","712139","1","0","0","Mankundu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2606","713201","1","0","0","Durgapur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2607","713202","1","0","0","Durgapur C Zone","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2608","713203","1","0","0","Amrai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2609","713204","1","0","0","Benachity Market","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2610","713205","1","0","0","Durgapur Steel Town East","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2611","713206","1","0","0","Durgapur Abl Township","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2612","713207","1","0","0","Durgapur Thermal Power Station","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2613","713208","1","0","0","Durgapur ASP SB Bureau","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2614","713209","1","0","0","Durgapur Mg Avenue","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2615","713210","1","0","0","Durgapur Heavy Engg Plant","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2616","713211","1","0","0","Durgapur Sagarbhanga Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2617","713212","1","0","0","Bidhannagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2618","713213","1","0","0","Benachity","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2619","713214","1","0","0","Amrabati","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2620","713215","1","0","0","Angadpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2621","713216","1","0","0","City Centre","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2622","713217","1","0","0","Oyaria","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2623","713346","1","0","0","Pandaveshwar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2624","713363","1","0","0","Balijuri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2625","713381","1","0","0","Nutandanga","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2626","713385","1","0","0","Laudoha","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2627","721137","1","0","0","Alinan","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2628","721301","1","0","0","Balarampur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2629","721302","1","0","0","Kharagpur Technology","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2630","721303","1","0","0","Kalaikunda A F","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2631","721304","1","0","0","Dharenda","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2632","721305","1","0","0","Inda","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2633","721306","1","0","0","Hijli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2634","721401","1","0","0","Contai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2635","721429","1","0","0","Baranihary","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2636","721441","1","0","0","Ramnagar (East Midnapore)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2637","721602","1","0","0","Basudevpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2638","721604","1","0","0","Haldia","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2639","721605","1","0","0","Haldia Port","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2640","721606","1","0","0","H.I.T","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2641","721607","1","0","0","Haldia T.S","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2642","721652","1","0","0","Kumarchak","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2643","732101","1","0","0","Malda","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2644","732102","1","0","0","Jhaljhalia Railway Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2645","732103","1","0","0","Mukdumpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2646","732215","1","0","0","Pubarun","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2647","733101","1","0","0","Balurghat","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2648","733102","1","0","0","Chakvrigu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2649","733103","1","0","0","Amrail","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2650","733121","1","0","0","Buniadpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2651","733124","1","0","0","Gangarampur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2652","733126","1","0","0","Hili","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2653","733127","1","0","0","Tapan","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2654","733129","1","0","0","Akhanagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2655","733132","1","0","0","Kushmandi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2656","733133","1","0","0","Patiram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2657","733134","1","0","0","Raiganj","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2658","733140","1","0","0","Rampur (South Dinajpur)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2659","733141","1","0","0","Gopalganj","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2660","733142","1","0","0","Nayabazar (South Dinajpur)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2661","733158","1","0","0","Atrai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2662","734001","1","0","0","Siliguri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2663","734006","1","0","0","Rabindra Sarani","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2664","734007","1","0","0","Bhaktinagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2665","734009","1","0","0","Sukna","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2666","734010","1","0","0","Matigara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2667","734011","1","0","0","Kadamtala (Darjiling)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2668","734012","1","0","0","Sushrut Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2669","734014","1","0","0","Bagdogra","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2670","736101","1","0","0","Cooch Behar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2671","736121","1","0","0","Alipurduar New Town","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2672","741101","1","0","0","Krishnanagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2673","741126","1","0","0","Arpara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2674","741137","1","0","0","Debagram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2675","741138","1","0","0","Dharmada","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2676","741139","1","0","0","Dhubulia","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2677","741154","1","0","0","Muragachha","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2678","741156","1","0","0","Plassey","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2679","741162","1","0","0","Kasiadanga","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2680","741234","1","0","0","Gayeshpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2681","741235","1","0","0","Kalyani","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2682","741245","1","0","0","Madanpur (Nadia)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2683","741313","1","0","0","Sreemayapur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2684","742101","1","0","0","Berhampore (WB)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2685","742102","1","0","0","Banjetia","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2686","742103","1","0","0","Daihatta Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2687","742202","1","0","0","Dhuliyan","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2688","742212","1","0","0","Bagdabra","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2689","742236","1","0","0","Nabarun","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2690","743122","1","0","0","Bengal Enamel","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2691","743123","1","0","0","Bhatpara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2692","743124","1","0","0","ESD (M)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2693","743125","1","0","0","Golghar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2694","743126","1","0","0","Kankinara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2695","743127","1","0","0","Feeder Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2696","743128","1","0","0","Athpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2697","743129","1","0","0","Fingapara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2698","743133","1","0","0","Garulia","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2699","743134","1","0","0","Halishahar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2700","743136","1","0","0","Nabanagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2701","743144","1","0","0","Anandamath","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2702","743145","1","0","0","Bagermore","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2703","743165","1","0","0","Naihati Anandabazar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2704","743194","1","0","0","Kelabagan","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2705","751001","1","0","0","Bhubaneswar G.P.O. ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2706","751002","1","0","0","Bankual","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2707","751003","1","0","0","Andharua","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2708","751004","1","0","0","Utkal University","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2709","751005","1","0","0","Sainik School (Khorda)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2710","751006","1","0","0","Budheswari Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2711","751007","1","0","0","Saheed Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2712","751008","1","0","0","Rajbhawan (Khorda)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2713","751009","1","0","0","Ashok Nagar (Khorda)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2714","751010","1","0","0","Rasulgarh","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2715","751011","1","0","0","C R P Lines","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2716","751012","1","0","0","Nayapalli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2717","751013","1","0","0","Regional Research Laboratory","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2718","751014","1","0","0","Bhubaneswar Court","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2719","751015","1","0","0","I R C Village","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2720","751016","1","0","0","Chandra Sekhar Pur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2721","751017","1","0","0","Mancheswar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2722","751018","1","0","0","Badagarh Brit Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2723","751019","1","0","0","Dumduma Housing Board Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2724","751020","1","0","0","Aerodrome Area","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2725","751021","1","0","0","Sailashree Vihar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2726","751022","1","0","0","Acharya Vihar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2727","751023","1","0","0","S.E Rly.Proj. Complex","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2728","751024","1","0","0","K I I T","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2729","751025","1","0","0","G.G.P.Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2730","751026","1","0","0","G.G.P.Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2731","751027","1","0","0","G.G.P.Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2732","751028","1","0","0","G.G.P.Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2733","751029","1","0","0","G.G.P.Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2734","751030","1","0","0","Khandagiri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2735","751031","1","0","0","Khandagiri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2736","752001","1","0","0","Puri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2737","752002","1","0","0","Badagaon","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2738","753001","1","0","0","Cuttack G.P.O. ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2739","753002","1","0","0","Chandinchowk","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2740","753003","1","0","0","Chandinchowk","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2741","753004","1","0","0","Chauliaganj","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2742","753005","1","0","0","Barabati Stadium","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2743","753006","1","0","0","C R R I (Cuttack)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2744","753007","1","0","0","Medical College (Cuttack)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2745","753008","1","0","0","Kanika Rajbati","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2746","753009","1","0","0","Rajabagicha","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2747","753010","1","0","0","Industrial Estate (Cuttack)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2748","753011","1","0","0","Gopalpur (Cuttack)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2749","753012","1","0","0","A D Market","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2750","753013","1","0","0","Kalyani Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2751","753014","1","0","0","Avinab Bidanasi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2752","753051","1","0","0","Cuttack","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2753","754021","1","0","0","Jagatpur (Cuttack)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2754","754025","1","0","0","Birol","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2755","754028","1","0","0","Charbatia","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2756","754071","1","0","0","Kapaleswar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2757","760001","1","0","0","Berhampur(GM)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2758","760002","1","0","0","Banthapalli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2759","760003","1","0","0","Gosaninuagam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2760","760004","1","0","0","Baidyanathpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2761","760005","1","0","0","Berhampur RS","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2762","760006","1","0","0","Panigrahipentho","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2763","760007","1","0","0","Berhampur University","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2764","760008","1","0","0","Industrial Estates","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2765","760009","1","0","0","Nabeen","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2766","760010","1","0","0","Engineering School","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2767","761001","1","0","0","Nimakhandi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2768","761002","1","0","0","Gopalpur (Ganjam)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2769","761003","1","0","0","Bhatakumarada","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2770","761004","1","0","0","Patrapur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2771","761005","1","0","0","Jaradagada","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2772","761006","1","0","0","Jayantipur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2773","761007","1","0","0","Padmanavapur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2774","761008","1","0","0","Golanthara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2775","761009","1","0","0","Girisola","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2776","761010","1","0","0","Chikiti","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2777","761011","1","0","0","Nuapada","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2778","761012","1","0","0","Ambagaon","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2779","761013","1","0","0","Pattapur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2780","761014","1","0","0","Pudamari","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2781","761020","1","0","0","Chatrapur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2782","761037","1","0","0","Surangi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2783","781001","1","0","0","Guwahati G.P.O. ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2784","781002","1","0","0","Guwahati G.P.O. ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2785","781003","1","0","0","Silpukhuri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2786","781004","1","0","0","Kharguli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2787","781005","1","0","0","Dispur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2788","781006","1","0","0","Assam Sachivalaya","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2789","781007","1","0","0","Ulubari","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2790","781008","1","0","0","Rehabari","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2791","781009","1","0","0","Bharalumukh","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2792","781010","1","0","0","Kamakhya","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2793","781011","1","0","0","Gotanagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2794","781012","1","0","0","Pandu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2795","781013","1","0","0","Jalukbari","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2796","781014","1","0","0","Guwahati University","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2797","781015","1","0","0","Guwahati Airport","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2798","781016","1","0","0","Gopinathnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2799","781017","1","0","0","Azara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2800","781018","1","0","0","Binovanagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2801","781019","1","0","0","Kahilipara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2802","781020","1","0","0","Noonmati","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2803","781021","1","0","0","Bamunimaidan","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2804","781022","1","0","0","Khanapara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2805","781023","1","0","0","Amerigog","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2806","781024","1","0","0","Zoo Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2807","781025","1","0","0","Ambari Fatasil","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2808","781026","1","0","0","Narangi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2809","781027","1","0","0","Satgaon","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2810","781028","1","0","0","Beltola","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2811","781029","1","0","0","Basistha","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2812","781030","1","0","0","North Guwahati","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2813","781031","1","0","0","Amingaon","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2814","781032","1","0","0","Rupnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2815","781034","1","0","0","Odalbakra","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2816","781035","1","0","0","Garchuk","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2817","781036","1","0","0","Hengrabari","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2818","781037","1","0","0","Panjabari","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2819","781038","1","0","0","Hatigaon Chariali","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2820","781039","1","0","0","I I T","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2821","781301","1","0","0","BARPETA","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2822","781313","1","0","0","SIMLAGURI","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2823","781314","1","0","0","BARPALLI","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2824","781315","1","0","0","BARPETA ROAD","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2825","781316","1","0","0","HOWLI","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2826","781317","1","0","0","SORBHOG","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2827","781325","1","0","0","PATSHALA","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2828","781334","1","0","0","ARARA","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2829","781335","1","0","0","NALBARI","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2830","781337","1","0","0","BARKHANAJAN","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2831","781341","1","0","0","BALIKARIA","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2832","781347","1","0","0","AARANGMOW","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2833","781348","1","0","0","BAGALSROAD","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2834","781351","1","0","0","BARBARI","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2835","782001","1","0","0","Nagaon","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2836","782002","1","0","0","Haiborgaon","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2837","782003","1","0","0","Itachali","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2838","782435","1","0","0","HOJAI","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2839","782446","1","0","0","LANKA","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2840","782447","1","0","0","LUMDING","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2841","783380","1","0","0","BONGAIGAON","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2842","783385","1","0","0","DHALIGAON","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2843","784001","1","0","0","TEZPUR","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2844","784010","1","0","0","TEZPUR","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2845","785001","1","0","0","JORHAT","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2846","785002","1","0","0","SATHITYA SABHA BHAWAN","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2847","785006","1","0","0","CHARINGIA","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2848","785007","1","0","0","ENGG COLLEGE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2849","785610","1","0","0","FORCUTTING","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2850","785621","1","0","0","GOLAGHAT TOWN","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2851","785622","1","0","0","DHEKIAL","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2852","785625","1","0","0","KAMARBANDA ALI","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2853","785640","1","0","0","Sivasagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2854","785685","1","0","0","Nazira","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2855","785699","1","0","0","NUMALIGARH","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2856","785702","1","0","0","BENGENAKHOWA","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2857","786001","1","0","0","Dibrugarh","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2858","786002","1","0","0","Assam Medical College","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2859","786003","1","0","0","Central Revenue Building","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2860","786004","1","0","0","Dibrugarh University","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2861","786005","1","0","0","Jalan Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2862","786007","1","0","0","Barbaruah","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2863","786125","1","0","0","Tinsukia","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2864","786126","1","0","0","Borguri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2865","786145","1","0","0","Sripuria","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2866","786146","1","0","0","Sukhanpukhuri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2867","786147","1","0","0","Tinsukia","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2868","786156","1","0","0","Talap (Tinsukia)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2869","786170","1","0","0","Tinsukia","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2870","788001","1","0","0","Silchar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2871","788002","1","0","0","Malugram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2872","788003","1","0","0","Tarapur (Cachar)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2873","788004","1","0","0","G C College","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2874","788005","1","0","0","Rangirkhari","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2875","788006","1","0","0","Link Road (Cachar)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2876","793001","1","0","0","Shillong G.P.O. ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2877","793002","1","0","0","Iewduh","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2878","793003","1","0","0","Laitumkhrah","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2879","793004","1","0","0","Rilbong","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2880","793005","1","0","0","Upper Shillong","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2881","793006","1","0","0","Rynjah","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2882","793007","1","0","0","Happy Valley","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2883","793008","1","0","0","Phudmawri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2884","793010","1","0","0","Laitkor Peak","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2885","793011","1","0","0","Assam Rifles","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2886","793014","1","0","0","Nongthymmai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2887","793017","1","0","0","Upper Shillong","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2888","793022","1","0","0","Nehu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2889","796001","1","0","0","Aizawl","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2890","796002","1","0","0","Aizawl","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2891","796003","1","0","0","Aizawl","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2892","796005","1","0","0","Kulikawn","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2893","796007","1","0","0","Chandmary","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2894","796009","1","0","0","Vaivakawn","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2895","796012","1","0","0","Ramhlun","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2896","796014","1","0","0","Bawngkawn","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2897","796017","1","0","0","Zemabawk","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2898","797103","1","0","0","CHUMUKEDIMA","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2899","797112","1","0","0","DIMAPUR","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2900","797115","1","0","0","AOYIMTI","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2901","797116","1","0","0","DIMAPUR BAZAR","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2902","799001","1","0","0","Agartala","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2903","799002","1","0","0","Ramnagar (West Tripura)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2904","799003","1","0","0","Arundhutinagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2905","799004","1","0","0","Agartala College","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2906","799005","1","0","0","Abhoynagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2907","799006","1","0","0","Kunjaban","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2908","800001","1","0","0","Patna G.P.O. ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2909","800002","1","0","0","Anisabad","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2910","800003","1","0","0","Kadamkuan","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2911","800004","1","0","0","Bankipore","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2912","800005","1","0","0","Patna University","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2913","800006","1","0","0","Mahendru","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2914","800007","1","0","0","Gulzarbagh","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2915","800008","1","0","0","Patna City","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2916","800009","1","0","0","Begampur (Patna)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2917","800010","1","0","0","Sadaquat Ashram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2918","800011","1","0","0","Dighaghat","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2919","800012","1","0","0","Digha (Patna)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2920","800013","1","0","0","Patliputra","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2921","800014","1","0","0","Sheikhpura","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2922","800015","1","0","0","Patna Sectt.","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2923","800016","1","0","0","Rajendra Nagar (Patna)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2924","800017","1","0","0","B.S.E. Board","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2925","800018","1","0","0","Bataganj","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2926","800019","1","0","0","C.D.A","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2927","800020","1","0","0","Ashok Nagar (Patna)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2928","800021","1","0","0","Vidyut Parisad","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2929","800022","1","0","0","B.G. Camp/raj Bhawan","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2930","800023","1","0","0","L.B.S Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2931","800024","1","0","0","Keshari Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2932","800025","1","0","0","Ashiananagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2933","800026","1","0","0","Kumhrar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2934","800027","1","0","0","New Jaganpura","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2935","800028","1","0","0","Patna High Court","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2936","803101","1","0","0","Biharsharif","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2937","803118","1","0","0","Sohsarai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2938","803216","1","0","0","Ramchandrapur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2939","812001","1","0","0","Bhagalpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2940","812002","1","0","0","Bhagalpur City","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2941","812003","1","0","0","Barari","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2942","812004","1","0","0","Champanagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2943","812005","1","0","0","Mirjanhat","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2944","812006","1","0","0","Nathnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2945","813210","1","0","0","Sabour","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2946","823001","1","0","0","Gaya","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2947","823002","1","0","0","Kharkhura","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2948","823003","1","0","0","Durga Asthan","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2949","823004","1","0","0","Civil Aerodram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2950","827001","1","0","0","Bokaro Steel City","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2951","827002","1","0","0","BOKARO","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2952","827003","1","0","0","Sector- III","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2953","827004","1","0","0","Sector- IV","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2954","827005","1","0","0","BOKARO","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2955","827006","1","0","0","Sector-VI","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2956","827008","1","0","0","BOKARO","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2957","827009","1","0","0","Sector- IX","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2958","827010","1","0","0","B.S.City R.S.","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2959","827011","1","0","0","B.S.City Plant","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2960","827012","1","0","0","Marafari Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2961","827013","1","0","0","Garga Check Post","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2962","827014","1","0","0","Balidih","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2963","831001","1","0","0","Jamshedpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2964","831002","1","0","0","Jamshedpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2965","831003","1","0","0","Jamshedpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2966","831004","1","0","0","Jamshedpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2967","831005","1","0","0","Jamshedpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2968","831006","1","0","0","Jamshedpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2969","831007","1","0","0","Jamshedpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2970","831008","1","0","0","Jamshedpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2971","831009","1","0","0","Jamshedpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2972","831010","1","0","0","Jamshedpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2973","831011","1","0","0","Jamshedpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2974","831012","1","0","0","Jamshedpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2975","831013","1","0","0","Jamshedpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2976","831014","1","0","0","R.I.T","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2977","831015","1","0","0","Gobindpur Housing Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2978","831016","1","0","0","Rahargora","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2979","831017","1","0","0","Jamshedpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2980","831018","1","0","0","M.G.M Medical College","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2981","832108","1","0","0","Gamharia","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2982","832109","1","0","0","Adityapur Industrial Area","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2983","832110","1","0","0","Azadnagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2984","834001","1","0","0","Ranchi G.P.O. ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2985","834002","1","0","0","Doranda","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2986","834003","1","0","0","Hatia (Ranchi)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2987","834004","1","0","0","Satellite Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2988","834005","1","0","0","Hehal","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2989","834006","1","0","0","Boreya","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2990","834008","1","0","0","Ranchi University","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2991","834009","1","0","0","Bariatu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2992","834010","1","0","0","Namkum","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2993","834012","1","0","0","Harmu Housing Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2994","842001","1","0","0","Muzaffarpur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2995","842002","1","0","0","Ramna (Muzaffarpur)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2996","842003","1","0","0","M.I.T.","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2997","842004","1","0","0","Umanagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2998","842005","1","0","0","M.I.C.","1","1","1","0");
INSERT INTO delivery_pincode VALUES("2999","851101","1","0","0","Begusarai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3000","851112","1","0","0","Barauni","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3001","851113","1","0","0","B.Deorhi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3002","851116","1","0","0","B.T.P.P","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3003","851117","1","0","0","Refinery Township","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3004","851118","1","0","0","Baro","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3005","851126","1","0","0","Garhara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3006","851133","1","0","0","Teghra","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3007","384170","1","0","0","Aithor","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3008","844101","1","0","0","Hajipur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3009","400040","1","0","0","Linking Road, Bandra (W)/","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3010","400041","1","0","0","Jogeshwari (E)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3011","400044","1","0","0","Santacruz (E)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3012","400045","1","0","0","Vile Parle (W)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3013","400046","1","0","0","Vile Parle (E)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3014","400047","1","0","0","Andheri (E)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3015","400048","1","0","0","Andheri - J.B.Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3016","636002","1","0","0","Shevapet ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3017","636003","1","0","0","Ammapettai","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3018","636004","1","0","0","Alagapuram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3019","636005","1","0","0","Meyyanur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3020","636006","1","0","0","Thangamapuripattinam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3021","636007","1","0","0","Peramanur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3022","636008","1","0","0","Gorimedu","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3023","636009","1","0","0","Swaminathapuram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3024","174302","1","0","0","dhusara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3025","174301","1","0","0","Santokhgarh","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3026","174507","1","0","0","thaliwal","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3027","174315","1","0","0","Mehatpur (Una)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3028","177220","1","0","0","haroli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3029","174307","1","0","0","bagana","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3030","441804","1","0","0","Lakhni","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3031","441805","1","0","0","Dighori","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3032","441905","1","0","0","Bhandara Road","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3033","441906","1","0","0","Bhandara Of","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3034","441909","1","0","0","Mohadi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3035","441924","1","0","0","Pahela","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3036","826001","1","0","0","Dhanbad","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3037","826003","1","0","0","Jagjivan Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3038","826004","1","0","0","Indian School Of Mines","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3039","826005","1","0","0","BCCl Township","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3040","826124","1","0","0","A.C.C. Colony","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3041","828108","1","0","0","Fri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3042","828111","1","0","0","Jharia","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3043","828130","1","0","0","B.Polytechnic","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3044","125033","1","0","0","T C Hansi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3045","110102","1","31","3","Palika Kendra NDMC Bldg ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3046","110121","1","31","3","H.T.Media Hindustan Times House","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3047","110401","1","31","3","Distt. Courts Tis Hazari ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3048","110402","1","31","3","DAP Bldg ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3049","110403","1","31","3","GGSIPU kashmere gate ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3050","110505","1","31","3","Council ICSE Board Pragari House","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3051","110506","1","31","3","MTNL Nehru Place ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3052","110507","1","31","3","B.S.E.S. Nehru Place","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3053","110508","1","31","3","IFCI Tower 61 Nehru Place ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3054","110509","1","31","3","Skylark Bldg 60 Nehru Place","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3055","577227","1","0","0","SHIMOGA","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3056","587116","1","0","0","BAGALKOT","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3057","587118","1","0","0","BAGALKOT","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3058","587125","1","0","0","BAGALKOT","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3059","587203","1","0","0","BAGALKOT","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3060","415722","1","0","0","RATNAGIRI","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3061","415804","1","0","0","RATNAGIRI","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3062","415611","1","0","0","RATNAGIRI","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3063","530032","1","0","0","VISAKHAPATNAM","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3064","530046","1","0","0","VISAKHAPATNAM","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3065","572201","1","0","0","Belagarahali","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3066","573103","1","0","0","Aggunda","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3067","573112","1","0","0","Arakere","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3068","573119","1","0","0","Gandasi","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3069","573125","1","0","0","Appihalli","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3070","470113","1","0","0","SAGAR","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3071","470115","1","0","0","SAGAR","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3072","470117","1","0","0","SAGAR","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3073","470119","1","0","0","SAGAR","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3074","470226","1","0","0","SAGAR","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3075","470229","1","0","0","SAGAR","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3076","470335","1","0","0","SAGAR","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3077","470666","1","0","0","DAMOH","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3078","472001","1","0","0","TIKAMGARH","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3079","461111","1","0","0","BETUL","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3080","412215","1","0","0","PUNE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3081","412219","1","0","0","PUNE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3082","413130","1","0","0","PUNE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3083","413801","1","0","0","PUNE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3084","413802","1","0","0","PUNE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3085","431517","1","0","0","Beed","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3086","431127","1","0","0","Beed","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3087","431131","1","0","0","Beed","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3088","431515","1","0","0","Beed","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3089","414204","1","0","0","Beed","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3090","396001","1","0","0","VALSAD","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3091","396002","1","0","0","VALSAD","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3092","396007","1","0","0","VALSAD","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3093","396020","1","0","0","VALSAD","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3094","396030","1","0","0","VALSAD","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3095","396035","1","0","0","VALSAD","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3096","396321","1","0","0","NAVSARI","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3097","396375","1","0","0","VALSAD","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3098","396385","1","0","0","VALSAD","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3099","605803","1","0","0","VILLUPURAM","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3100","632401","1","0","0","VELLORE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3101","632403","1","0","0","VELLORE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3102","632406","1","0","0","VELLORE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3103","632503","1","0","0","VELLORE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3104","632513","1","0","0","VELLORE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3105","635751","1","0","0","VELLORE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3106","635752","1","0","0","VELLORE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3107","635801","1","0","0","VELLORE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3108","635802","1","0","0","VELLORE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3109","613001","1","0","0","ARISIKARA STREET","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3110","613002","1","0","0","KALIMEDU","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3111","613003","1","0","0","ANNAPPANPETTAI","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3112","613004","1","0","0","MANOJIPATTI","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3113","613005","1","0","0","INAYATHUKKANPATTI","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3114","613006","1","0","0","MARUNGULAM","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3115","613007","1","0","0","GANAPATHI NAGAR","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3116","613008","1","0","0","THANJAVUR NORTH GATE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3117","613009","1","0","0","SRINIVASAPURAM","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3118","613010","1","0","0","TAMIL UNIVERSITY","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3119","722102","1","0","0","Bankura Town2","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3120","722202","1","0","0","BARJORA","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3121","722203","1","0","0","BELIATORE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3122","722122","1","0","0","Bishnupur","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3123","722140","1","0","0","KHATRA","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3124","722138","1","0","0","M.T.PS","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3125","811201","1","0","0","Munger","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3126","712234","1","0","0","Kanaipur ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3127","712235","1","0","0","Konnagar ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3128","712245","1","0","0","Makhla ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3129","712246","1","0","0","Nabagram (Hooghly)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3130","712247","1","0","0","Raghunathpur (Hooghly)","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3131","712248","1","0","0","Rishra ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3132","712258","1","0","0","Rajendra Avenue ","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3133","712232","1","0","0","Bhadrakali","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3134","712233","1","0","0","HindMotor","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3135","123401","1","0","0","Rewari","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3136","123501","1","0","0","Bawal","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3137","140124","1","0","0","Nangal Dam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3138","140126","1","0","0","Bhanam","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3139","174303","1","0","0","una","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3140","721636","1","0","0","Tamluk","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3141","441904","1","0","0","Bhandara","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3142","470001","1","0","0","SAGAR","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3143","470002","1","0","0","SAGAR","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3144","470003","1","0","0","SAGAR","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3145","412103","1","0","0","PUNE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3146","412204","1","0","0","PUNE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3147","412304","1","0","0","PUNE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3148","413114","1","0","0","PUNE","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3149","415523","1","0","0","SATARA","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3150","795001","1","0","0","Imphal","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3151","795002","1","0","0","Mantripukhri","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3152","795003","1","0","0","Manipur University","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3153","795004","1","0","0","Lamphelpat","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3154","795005","1","0","0","Porompat","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3155","795008","1","0","0","Singjamei","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3156","520001","1","0","0","Vijayawada H.O.","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3157","520002","1","0","0","Bankinghompet","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3158","520003","1","0","0","Gandhi Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3159","520004","1","0","0","Machavaram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3160","520006","1","0","0","Benz circle","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3161","520007","1","0","0","Autonagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3162","520008","1","0","0","Polytechnic college","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3163","520010","1","0","0","Venkateswarapuram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3164","520011","1","0","0","Satyanarayanapuram","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3165","520012","1","0","0","Kamakoti Nagar","1","1","1","0");
INSERT INTO delivery_pincode VALUES("3166","520013","1","0","0","Krishnalanka","1","1","1","0");





CREATE TABLE `department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  `isActive` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `department_map_process` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `process_id` int(11) NOT NULL DEFAULT '0',
  `department_id` int(11) NOT NULL DEFAULT '0',
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `designation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `dispatch_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dispatch_no` varchar(50) DEFAULT NULL,
  `order_id` int(11) NOT NULL DEFAULT '0',
  `order_no` varchar(50) DEFAULT NULL,
  `dispatch_qty` int(11) NOT NULL DEFAULT '0',
  `unitprice` double NOT NULL,
  `totalprice` double NOT NULL,
  `discount_amount` double NOT NULL,
  `cash_discount` double NOT NULL DEFAULT '0',
  `cash_discount_amount` double NOT NULL DEFAULT '0',
  `taxable` double NOT NULL,
  `cgst_amount` double NOT NULL,
  `sgst_amount` double NOT NULL,
  `igst_amount` double NOT NULL,
  `subtotal` double NOT NULL,
  `round_off` double NOT NULL DEFAULT '0',
  `grand_total` int(11) NOT NULL DEFAULT '0',
  `grand_total_rounded` double NOT NULL,
  `dispatch_date` date DEFAULT NULL,
  `LR_copy` varchar(250) DEFAULT NULL,
  `remark` varchar(250) DEFAULT NULL,
  `sales_id` int(11) NOT NULL DEFAULT '0',
  `customer_id` int(11) NOT NULL DEFAULT '0',
  `sales_name` varchar(50) DEFAULT NULL,
  `customer_name` varchar(50) DEFAULT NULL,
  `company_name` varchar(150) NOT NULL,
  `contact_number` varchar(150) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(150) NOT NULL,
  `state` varchar(150) NOT NULL,
  `country` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `order_type` varchar(50) DEFAULT NULL,
  `remaining_amount` double DEFAULT '0',
  `paid_amount` double NOT NULL DEFAULT '0',
  `payment_status` int(11) NOT NULL DEFAULT '0',
  `asse_value` double NOT NULL DEFAULT '0',
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO dispatch_detail VALUES("1","K/U/DIS/001","1","K/OUT/001","550","0","0","0","0","0","6060","545.4","545.4","0","6060","0.2","7151","7151","2018-01-16","","","0","3","","jay","Prashant","9824518363","Rajkot","Rajkot","Gujarat","India","jay@gmail.com","normal_user","7151","0","0","0","0","1","1","0","1","0","2018-01-16 17:01:51","2018-01-16 17:01:52");
INSERT INTO dispatch_detail VALUES("2","K/U/DIS/002","2","K/OUT/002","50","0","0","0","0","0","450","40.5","40.5","0","450","0","531","531","2018-02-07","","","0","4","","hardip","h","9979055113","fg","ydy","Gujarat","India","h@gmail.com","normal_user","531","0","0","0","0","1","1","0","1","0","2018-02-07 12:46:00","2018-02-07 12:46:00");
INSERT INTO dispatch_detail VALUES("3","K/SS/DIS/003","3","K/OUT/003","50","0","0","0","0","0","450","40.5","40.5","0","450","0","531","531","2018-02-07","","","1","1","Tejas","Jay","Uma Polymer","8866189644","Panchayat Chowk, Rajkot","Rajkot","Gujarat","India","uma@gmail.com","super_stockist","531","0","0","0","0","1","1","0","1","0","2018-02-07 12:52:58","2018-02-07 12:52:58");
INSERT INTO dispatch_detail VALUES("4","K/U/DIS/004","2","K/OUT/002","50","0","0","0","0","0","450","40.5","40.5","0","450","0","531","531","2018-02-07","","","0","4","","hardip","h","9979055113","fg","ydy","Gujarat","India","h@gmail.com","normal_user","531","0","0","0","0","1","1","0","1","0","2018-02-07 13:05:30","2018-02-07 13:05:30");





CREATE TABLE `dispatch_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL DEFAULT '0',
  `dispatch_id` int(11) NOT NULL DEFAULT '0',
  `pro_id` int(11) NOT NULL DEFAULT '0',
  `weight_id` int(11) NOT NULL DEFAULT '0',
  `pro_name` varchar(250) DEFAULT NULL,
  `qty` int(11) NOT NULL DEFAULT '0',
  `unitprice` float NOT NULL DEFAULT '0',
  `totalprice` double NOT NULL,
  `amount` float NOT NULL DEFAULT '0',
  `discount` double NOT NULL DEFAULT '0',
  `discount_amount` double NOT NULL DEFAULT '0',
  `taxable` double NOT NULL DEFAULT '0',
  `cgst_tax` double NOT NULL DEFAULT '0',
  `cgst_tax_amount` double NOT NULL DEFAULT '0',
  `sgst_tax` double NOT NULL DEFAULT '0',
  `sgst_tax_amount` double NOT NULL DEFAULT '0',
  `igst_tax` double NOT NULL DEFAULT '0',
  `igst_tax_amount` double NOT NULL DEFAULT '0',
  `cash_discount` double NOT NULL DEFAULT '0',
  `cash_discount_amount` double NOT NULL DEFAULT '0',
  `inner_size` double NOT NULL DEFAULT '0',
  `outer_size` double NOT NULL,
  `box_qty` double NOT NULL DEFAULT '0',
  `subtotal` double NOT NULL DEFAULT '0',
  `grand_total` double NOT NULL DEFAULT '0',
  `dispatch_date` date DEFAULT NULL,
  `isActive` int(11) NOT NULL DEFAULT '0',
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO dispatch_item VALUES("1","1","1","1","1","Elbow (1/2\")","250","9","2250","0","0","0","2250","9","202.5","9","202.5","0","0","0","0","50","0","5","2250","2655","2018-01-16","0","0","1","0","","","2018-01-16 17:01:51","");
INSERT INTO dispatch_item VALUES("2","1","1","1","2","Elbow (3/4\")","300","12.7","3810","0","0","0","3810","9","342.9","9","342.9","0","0","0","0","50","0","6","3810","4495.8","2018-01-16","0","0","1","0","","","2018-01-16 17:01:51","");
INSERT INTO dispatch_item VALUES("3","2","2","1","1","Elbow (1/2\")","50","9","450","0","0","0","450","9","40.5","9","40.5","0","0","0","0","50","0","1","450","531","2018-02-07","0","0","1","0","","","2018-02-07 12:46:00","");
INSERT INTO dispatch_item VALUES("4","3","3","1","1","Elbow(1/2\")","50","9","450","0","0","0","450","9","40.5","9","40.5","0","0","0","0","50","0","1","450","531","2018-02-07","0","0","1","0","","","2018-02-07 12:52:58","");
INSERT INTO dispatch_item VALUES("5","2","4","1","1","Elbow (1/2\")","50","9","450","0","0","0","450","9","40.5","9","40.5","0","0","0","0","50","0","1","450","531","2018-02-07","0","0","1","0","","","2018-02-07 13:05:30","");





CREATE TABLE `dispatch_map_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weight_id` int(11) NOT NULL DEFAULT '0',
  `pid` int(11) NOT NULL DEFAULT '0',
  `dispatch_id` int(11) NOT NULL DEFAULT '0',
  `dispatch_item_id` int(11) NOT NULL DEFAULT '0',
  `order_id` int(11) NOT NULL DEFAULT '0',
  `order_item_id` int(11) NOT NULL DEFAULT '0',
  `qty` double NOT NULL DEFAULT '0',
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `emp_company_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` int(11) NOT NULL DEFAULT '0',
  `designation` int(11) NOT NULL DEFAULT '0',
  `department` int(11) NOT NULL DEFAULT '0',
  `joining_date` date DEFAULT NULL,
  `shift` int(11) NOT NULL DEFAULT '0',
  `account_number` varchar(50) DEFAULT NULL,
  `bank_name` varchar(50) DEFAULT NULL,
  `isDelete` tinyint(4) NOT NULL DEFAULT '0',
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `adate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `emp_personal_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_code` varchar(50) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `other_contact` varchar(100) DEFAULT NULL,
  `perment_address` varchar(100) DEFAULT NULL,
  `residential_address` varchar(100) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `blood_group` varchar(100) DEFAULT NULL,
  `remark` varchar(100) DEFAULT NULL,
  `identification_proof` varchar(100) DEFAULT NULL,
  `proof_document` varchar(100) DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL,
  `isDelete` tinyint(4) NOT NULL DEFAULT '0',
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `adate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `emp_salary_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` int(11) NOT NULL,
  `year` year(4) NOT NULL,
  `month` int(11) NOT NULL DEFAULT '0',
  `basic` varchar(50) NOT NULL,
  `hra` varchar(50) NOT NULL,
  `medical` varchar(50) NOT NULL,
  `conv` varchar(50) NOT NULL,
  `wash` varchar(50) NOT NULL,
  `edu` varchar(50) NOT NULL,
  `lt` varchar(50) NOT NULL,
  `spe` varchar(50) NOT NULL,
  `gross` varchar(50) NOT NULL,
  `it` varchar(50) NOT NULL,
  `pt` varchar(50) NOT NULL,
  `pf` varchar(50) NOT NULL,
  `net_payable` varchar(50) NOT NULL,
  `remark` varchar(50) NOT NULL,
  `isDelete` tinyint(4) NOT NULL,
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `adate` datetime NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text NOT NULL,
  `modified_by_type` text NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `executive` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dealer_distributor_id` int(11) NOT NULL DEFAULT '0',
  `super_stockist_id` int(11) NOT NULL DEFAULT '0',
  `type_of_executive` varchar(50) DEFAULT NULL,
  `company_type` varchar(100) DEFAULT NULL,
  `company_name` varchar(50) DEFAULT NULL,
  `cname` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `cst` varchar(50) DEFAULT NULL,
  `pan` varchar(50) DEFAULT NULL,
  `gst` varchar(50) DEFAULT NULL,
  `vat` varchar(50) DEFAULT NULL,
  `excise` varchar(50) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `address` text,
  `zip` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `bank_name` varchar(50) DEFAULT NULL,
  `account_no` varchar(50) DEFAULT NULL,
  `ifsc_code` varchar(50) DEFAULT NULL,
  `mobile_no1` varchar(150) NOT NULL,
  `adate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modify_date` datetime NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  `isDelete` tinyint(11) NOT NULL DEFAULT '0',
  `isActive` tinyint(11) NOT NULL DEFAULT '1',
  `class_id` int(11) NOT NULL DEFAULT '0',
  `discount` double NOT NULL DEFAULT '0',
  `seid` int(11) NOT NULL DEFAULT '0',
  `forgot_pass_string` text,
  `local_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO executive VALUES("1","0","0","super_stockist","1","Uma Polymer","Jay","26c0bea40eaef1eb3ee7852814c0ea6f","uma@gmail.com","","","","","","8866189644","Panchayat Chowk, Rajkot","360005","India","Gujarat","Rajkot","","","","","2017-12-28 13:35:23","2017-12-28 13:35:23","1","0","1","0","2017-12-28 13:35:23","2017-12-28 13:35:25","0","1","1","0","0","","0");
INSERT INTO executive VALUES("2","0","1","dealer","1","Maico Poly Plast","Hardip","d1cd43454cf22f2bfe1d690100e6c2a1","hardip@gmail.com","","","","","","9714292925","301/401, Royal Uniform","360005","India","Gujarat","Rajkot","","","","","2017-12-28 14:41:43","2017-12-28 14:41:43","1","0","1","0","2017-12-28 14:41:43","2017-12-28 14:41:44","0","1","1","0","0","","0");
INSERT INTO executive VALUES("3","0","0","super_stockist","1","Craftbox Super Stockist","Ravi kansagra","6e6f5e0f81e949b0a955f642ab9d3e8e","rvpatel685@gmail.com","","","","","","8866110546","Rajkot","","India","Gujarat","Rajkot","","","","","2018-12-08 10:08:02","2018-12-08 10:08:02","1","0","1","0","2018-12-08 10:08:02","2018-12-08 10:08:03","0","1","1","0","0","","0");
INSERT INTO executive VALUES("4","0","3","dealer","1","Craftbox Distibutor","Janki","4372d0da139be5c4b91eaf159c729474","info@craftbox.in","","","","","","9879931636","Rajkot","","India","Gujarat","Rajkot","","","","","2018-12-08 10:09:03","2018-12-08 10:09:03","1","0","1","0","2018-12-08 10:09:03","2018-12-08 10:09:03","0","1","1","0","0","","0");
INSERT INTO executive VALUES("5","4","3","outlets","1","Ram Industry Customer","Ram Kansagra","8f42c6475608b170cb39bbe70a6530af","rvpatel685@gmail.com","","","","","","8866110545","Rajkot","","India","Gujarat","Rajkot","","","","","2018-12-08 10:09:42","2018-12-08 10:09:42","1","0","1","0","2018-12-08 10:09:42","2018-12-08 10:09:43","0","1","1","0","0","","0");
INSERT INTO executive VALUES("6","4","3","outlets","1","rajesh industry","rajesh bhai","e79a3ab9a7bfd681ac29d3d1d44cb0af","","","","hsjsskdhdsjsvav","","","7777777777","jamnagar","","India","Gujarat","Jamnagar","","","","9999999999","2018-12-08 10:16:43","2018-12-08 10:17:13","5895","712","5895,1","458,0","2018-12-08 10:16:43","2018-12-08 10:16:44,2018-12-08 10:17:13","0","1","1","0","0","","0");





CREATE TABLE `executive_branch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL DEFAULT '0',
  `branch_name` varchar(1000) DEFAULT NULL,
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `adate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`),
  KEY `customer_id_index` (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `executive_contact_person` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL DEFAULT '0',
  `branch` int(11) NOT NULL DEFAULT '0',
  `name` varchar(100) DEFAULT NULL,
  `designation` varchar(100) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `adate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  `isDelete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='// Contact Person for Customer or Comapny, Branch is from customer branch';






CREATE TABLE `executive_map_area` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL DEFAULT '0',
  `area_id` int(11) NOT NULL DEFAULT '0',
  `executive_id` int(11) NOT NULL DEFAULT '0',
  `executive_type` varchar(100) DEFAULT NULL,
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

INSERT INTO executive_map_area VALUES("1","1","1","1","super_stockist","0","0","1","0","","","2017-12-28 13:35:23","");
INSERT INTO executive_map_area VALUES("2","1","2","1","super_stockist","0","0","1","0","","","2017-12-28 13:35:23","");
INSERT INTO executive_map_area VALUES("3","1","3","1","super_stockist","0","0","1","0","","","2017-12-28 13:35:23","");
INSERT INTO executive_map_area VALUES("4","1","1","2","dealer","0","0","1","0","","","2017-12-28 14:41:43","");
INSERT INTO executive_map_area VALUES("5","1","2","2","dealer","0","0","1","0","","","2017-12-28 14:41:43","");
INSERT INTO executive_map_area VALUES("6","1","3","2","dealer","0","0","1","0","","","2017-12-28 14:41:43","");
INSERT INTO executive_map_area VALUES("7","1","3","3","super_stockist","0","0","1","0","","","2018-12-08 10:08:02","");
INSERT INTO executive_map_area VALUES("8","1","3","4","dealer","0","0","1","0","","","2018-12-08 10:09:03","");
INSERT INTO executive_map_area VALUES("9","1","3","4","dealer","0","0","1","0","","","2018-12-08 10:09:43","");
INSERT INTO executive_map_area VALUES("10","1","3","3","super_stockist","0","0","1","0","","","2018-12-08 10:09:43","");
INSERT INTO executive_map_area VALUES("11","1","3","5","outlets","0","0","1","0","","","2018-12-08 10:09:43","");
INSERT INTO executive_map_area VALUES("12","1","3","4","dealer","0","0","5895","712","","","2018-12-08 10:16:44","");
INSERT INTO executive_map_area VALUES("13","1","3","3","super_stockist","0","0","5895","712","","","2018-12-08 10:16:44","");
INSERT INTO executive_map_area VALUES("15","1","3","4","dealer","0","0","1","0","","","2018-12-08 10:17:14","");
INSERT INTO executive_map_area VALUES("16","1","3","3","super_stockist","0","0","1","0","","","2018-12-08 10:17:14","");
INSERT INTO executive_map_area VALUES("17","1","3","6","outlets","0","0","1","0","","","2018-12-08 10:17:14","");





CREATE TABLE `expense` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sales_executive_id` int(11) NOT NULL DEFAULT '0',
  `expense_date` date DEFAULT NULL,
  `DA` double NOT NULL DEFAULT '0',
  `TA` double NOT NULL DEFAULT '0',
  `MOA` double NOT NULL DEFAULT '0',
  `NA` double NOT NULL DEFAULT '0',
  `extra` double NOT NULL DEFAULT '0',
  `total` double NOT NULL DEFAULT '0',
  `remark` text,
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO expense VALUES("1","1","2017-12-28","99","56","0","55","9","219","","0","0","5895","712","1,1","0,0","2017-12-28 15:06:54","2017-12-28 15:07:16,2017-12-28 15:07:51");
INSERT INTO expense VALUES("2","1","2017-12-28","50","50","0","50","50","200","","0","0","5895","712","1,1,1,1,1","0,0,0,0,0","2017-12-28 15:09:27","2017-12-28 15:09:42,2017-12-28 15:10:28,2017-12-28 15:10:41,2017-12-28 15:11:58,2017-12-28 15:13:36");
INSERT INTO expense VALUES("3","1","2017-12-28","3","6","0","6","6","21","tut","0","0","5895","712","1","0","2017-12-28 15:40:43","2017-12-28 15:40:51");
INSERT INTO expense VALUES("4","1","2017-12-28","6","5","0","8","5","24","fyf","0","0","5895","712","1","0","2017-12-28 15:45:53","2017-12-28 15:46:03");
INSERT INTO expense VALUES("5","1","2018-01-01","50","50","0","50","100","250","virpur","0","0","5895","712","1","0","2018-01-01 17:01:10","2018-01-01 17:02:32");
INSERT INTO expense VALUES("6","4","2018-12-08","24545","54545","0","5454","545454","629998","gshajaka","0","0","5895","712","1","0","2018-12-08 10:19:15","2018-12-08 10:21:35");
INSERT INTO expense VALUES("7","4","2018-12-08","226565","32323","0","5656","5653","270197","ggitkt","0","0","5895","712","1","0","2018-12-08 10:22:06","2018-12-08 10:22:13");





CREATE TABLE `identification_proof` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `url` varchar(100) DEFAULT NULL,
  `isDelete` tinyint(4) NOT NULL DEFAULT '0',
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO identification_proof VALUES("1","Aadhar Card","","0","1","1","0","","","0000-00-00 00:00:00","");
INSERT INTO identification_proof VALUES("2","Pan Card","","0","1","1","0","","","0000-00-00 00:00:00","");





CREATE TABLE `inquiry_action` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `status` int(11) NOT NULL,
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `inward_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vendor` int(10) NOT NULL DEFAULT '0',
  `vendor_name` varchar(150) NOT NULL,
  `sales_id` int(11) NOT NULL DEFAULT '0',
  `total_qty` double NOT NULL DEFAULT '0',
  `grand_total` double NOT NULL DEFAULT '0',
  `remark` varchar(100) DEFAULT NULL,
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `adate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `inward_store_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `inward_store_id` int(11) NOT NULL DEFAULT '0',
  `product_id` int(11) NOT NULL DEFAULT '0',
  `weight_id` int(10) NOT NULL DEFAULT '0',
  `product_name` varchar(100) DEFAULT NULL,
  `product_code` varchar(100) DEFAULT NULL,
  `receive_qty` double NOT NULL DEFAULT '0',
  `product_price` double NOT NULL DEFAULT '0',
  `totalprice` double NOT NULL DEFAULT '0',
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `adate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime DEFAULT NULL,
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `item_map_unit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL DEFAULT '0',
  `item_category_id` varchar(150) NOT NULL,
  `primary_unit_id` int(11) NOT NULL DEFAULT '0',
  `primary_unit_value` varchar(150) NOT NULL,
  `alter_unit_id` int(11) NOT NULL DEFAULT '0',
  `alter_unit_value` varchar(150) NOT NULL,
  `alter_unit_slug` varchar(150) NOT NULL,
  `alter_unit_name` varchar(150) NOT NULL,
  `primary_unit_slug` varchar(150) NOT NULL,
  `primary_unit_name` varchar(150) NOT NULL,
  `unit_conversion` double NOT NULL DEFAULT '0',
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `created_date` datetime NOT NULL,
  `modified_date` text NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text NOT NULL,
  `modified_by_type` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `item_rm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rm_item_code` varchar(150) NOT NULL,
  `rm_item_name` varchar(150) NOT NULL,
  `rm_item_name_slug` varchar(150) NOT NULL,
  `rm_item_category` int(11) NOT NULL,
  `rm_packaging_type` int(11) NOT NULL COMMENT '0=> Box,1=> Pouch,2=>Loose',
  `rm_sku` varchar(150) NOT NULL,
  `rm_image` text NOT NULL,
  `rm_opening_qty` double NOT NULL,
  `rm_stock_qty` double NOT NULL,
  `rm_item_reserved_qty` int(11) NOT NULL,
  `rm_min_stock_qty` double NOT NULL,
  `rm_max_stock_qty` double NOT NULL,
  `rm_unit` int(11) NOT NULL,
  `rm_unit_name` varchar(150) NOT NULL,
  `rm_unit_slug` varchar(150) NOT NULL,
  `primary_unit_value` double NOT NULL DEFAULT '0',
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `created_date` datetime NOT NULL,
  `modified_date` text NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text NOT NULL,
  `modified_by_type` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Finish Good Items';






CREATE TABLE `item_rm_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_rm_category_name` varchar(150) NOT NULL,
  `item_rm_category_slug` varchar(150) NOT NULL,
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `created_date` datetime NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `no_order_inquiry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `local_id` int(11) NOT NULL,
  `sales_executive_id` int(11) NOT NULL DEFAULT '0',
  `class_id` int(11) NOT NULL DEFAULT '0',
  `area_id` int(11) NOT NULL DEFAULT '0',
  `customer_name` varchar(150) NOT NULL,
  `mobile_number` varchar(150) NOT NULL,
  `contact_person` varchar(150) NOT NULL,
  `country` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `action` int(11) NOT NULL,
  `datetime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` int(11) NOT NULL,
  `modify_date` datetime NOT NULL,
  `modified_by_type` int(11) NOT NULL,
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modify_track` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO no_order_inquiry VALUES("1","1","1","1","2","Abc","8866189644","","","","","Not require today","1","2018-01-11 00:00:00","0","1","2018-01-01 17:06:16","5895","712","0","2018-12-08 12:33:01","0","0000-00-00 00:00:00","2018-01-01 17:06:16&5895;2018-01-01 17:06:53&5895;2018-01-05 18:32:32&5895;2018-01-05 18:34:06&5895;2018-01-09 10:23:54&5895;2018-01-09 10:28:20&5895;2018-01-09 10:31:32&5895;2018-01-09 10:40:37&5895;2018-01-09 13:49:42&5895;2018-01-09 15:29:46&5895;2018-01-09 15:33:21&5895;2018-01-09 16:19:31&5895;2018-01-12 14:06:53&5895;2018-01-12 15:07:17&5895;2018-01-12 16:18:47&5895;2018-01-18 16:36:07&5895;2018-01-19 17:30:32&5895;2018-01-19 18:30:32&5895;2018-01-20 09:48:22&5895;2018-01-20 10:49:22&5895;2018-01-20 11:49:36&5895;2018-01-20 12:49:52&5895;2018-01-20 14:53:21&5895;2018-01-20 15:53:20&5895;2018-01-20 16:53:39&5895;2018-02-07 12:52:16&5895;2018-02-07 14:52:38&5895;2018-02-07 16:53:26&5895;2018-02-07 17:53:59&5895;2018-02-07 18:57:38&5895;2018-12-07 19:23:41&5895;2018-12-08 10:01:40&5895;2018-12-08 10:13:37&5895;2018-12-08 11:34:23&5895;2018-12-08 12:33:01");
INSERT INTO no_order_inquiry VALUES("2","2","1","1","2","Tejas","8866189644","","","","","Not require","1","2018-01-11 00:00:00","0","1","2018-01-09 13:49:42","5895","712","0","2018-12-08 12:33:01","0","0000-00-00 00:00:00","2018-01-09 13:49:42&5895;2018-01-09 15:29:46&5895;2018-01-09 15:33:21&5895;2018-01-09 16:19:31&5895;2018-01-12 14:06:53&5895;2018-01-12 15:07:17&5895;2018-01-12 16:18:47&5895;2018-01-18 16:36:07&5895;2018-01-19 17:30:32&5895;2018-01-19 18:30:32&5895;2018-01-20 09:48:22&5895;2018-01-20 10:49:23&5895;2018-01-20 11:49:36&5895;2018-01-20 12:49:53&5895;2018-01-20 14:53:22&5895;2018-01-20 15:53:21&5895;2018-01-20 16:53:39&5895;2018-02-07 12:52:16&5895;2018-02-07 14:52:38&5895;2018-02-07 16:53:26&5895;2018-02-07 17:53:59&5895;2018-02-07 18:57:38&5895;2018-12-07 19:23:41&5895;2018-12-08 10:01:40&5895;2018-12-08 10:13:37&5895;2018-12-08 11:34:23&5895;2018-12-08 12:33:01");
INSERT INTO no_order_inquiry VALUES("3","3","4","1","3","ram","8866110546","","","","","rajkot","1","2018-12-08 00:00:00","0","1","2018-12-08 10:17:47","5895","712","0","2018-12-08 11:15:38","0","0000-00-00 00:00:00","2018-12-08 10:17:47&5895;2018-12-08 10:19:24&5895;2018-12-08 11:04:41&5895;2018-12-08 11:15:38");





CREATE TABLE `no_order_inquiry_action` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO no_order_inquiry_action VALUES("1","Next Followup 	","0","1","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO no_order_inquiry_action VALUES("2","In Future","0","1","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO no_order_inquiry_action VALUES("3","Cancel","0","1","0000-00-00 00:00:00","0000-00-00 00:00:00");





CREATE TABLE `notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `user_type` varchar(250) NOT NULL,
  `referance_id` int(11) NOT NULL DEFAULT '0',
  `referance_type` varchar(150) NOT NULL,
  `type_slug` varchar(100) DEFAULT NULL,
  `notification_type` int(11) NOT NULL,
  `notification_title` varchar(250) NOT NULL,
  `notification_description` text NOT NULL,
  `notification_icon` varchar(100) DEFAULT NULL,
  `notification_extra` text,
  `respective_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=latin1;

INSERT INTO notification VALUES("1","1","customer","1","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.53</b> for date <b>28-12-2017</b> added by <b>admin</b> to your account","","","2017-12-28 00:00:00","0","0","1","0","1","0","2017-12-28 14:52:55","0000-00-00 00:00:00");
INSERT INTO notification VALUES("2","1","customer","2","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.2575</b> for date <b>28-12-2017</b> added by <b>admin</b> to your account","","","2017-12-28 00:00:00","0","0","1","0","1","0","2017-12-28 14:55:28","0000-00-00 00:00:00");
INSERT INTO notification VALUES("3","1","customer","3","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.10</b> for date <b>28-12-2017</b> added by <b>admin</b> to your account","","","2017-12-28 00:00:00","0","0","1","0","1","0","2017-12-28 14:57:45","0000-00-00 00:00:00");
INSERT INTO notification VALUES("4","1","customer","4","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.11</b> for date <b>28-12-2017</b> added by <b>admin</b> to your account","","","2017-12-28 00:00:00","0","0","1","0","1","0","2017-12-28 15:02:54","0000-00-00 00:00:00");
INSERT INTO notification VALUES("5","1","customer","5","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.11</b> for date <b>28-12-2017</b> added by <b>admin</b> to your account","","","2017-12-28 00:00:00","0","0","1","0","1","0","2017-12-28 15:04:02","0000-00-00 00:00:00");
INSERT INTO notification VALUES("6","1","customer","6","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.11</b> for date <b>28-12-2017</b> added by <b>admin</b> to your account","","","2017-12-28 00:00:00","0","0","1","0","1","0","2017-12-28 15:04:52","0000-00-00 00:00:00");
INSERT INTO notification VALUES("7","1","customer","7","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.10</b> for date <b>28-12-2017</b> added by <b>admin</b> to your account","","","2017-12-28 00:00:00","0","0","1","0","1","0","2017-12-28 15:06:36","0000-00-00 00:00:00");
INSERT INTO notification VALUES("8","1","sales_manager","1","expense","Expense Message","1","Expense Notification.","Expense of Rs.219 for date 28-12-2017 Rejected by admin","","","2017-12-28 00:00:00","0","0","1","0","1","0","2017-12-28 15:07:16","0000-00-00 00:00:00");
INSERT INTO notification VALUES("9","1","sales_manager","1","expense","Expense Message","1","Expense Notification.","Expense of Rs.219 for date 28-12-2017 Rejected by admin","","","2017-12-28 00:00:00","0","0","1","0","1","0","2017-12-28 15:07:51","0000-00-00 00:00:00");
INSERT INTO notification VALUES("10","1","sales_manager","2","expense","Expense Message","1","Expense Notification.","Expense of Rs.200 for date 28-12-2017 Rejected by admin","","","2017-12-28 00:00:00","0","0","1","0","1","0","2017-12-28 15:09:42","0000-00-00 00:00:00");
INSERT INTO notification VALUES("11","1","sales_manager","2","expense","Expense Message","1","Expense Notification.","Expense of Rs.200 for date 28-12-2017 Rejected by admin","","","2017-12-28 00:00:00","0","0","1","0","1","0","2017-12-28 15:10:28","0000-00-00 00:00:00");
INSERT INTO notification VALUES("12","1","sales_manager","2","expense","Expense Message","1","Expense Notification.","Expense of Rs.200 for date 28-12-2017 Rejected by admin","","","2017-12-28 00:00:00","0","0","1","0","1","0","2017-12-28 15:10:41","0000-00-00 00:00:00");
INSERT INTO notification VALUES("13","1","sales_manager","2","expense","Expense Message","1","Expense Notification.","Expense of Rs.200 for date 28-12-2017 Rejected by admin","","","2017-12-28 00:00:00","0","0","1","0","1","0","2017-12-28 15:11:58","0000-00-00 00:00:00");
INSERT INTO notification VALUES("14","1","sales_manager","2","expense","Expense Message","1","Expense Notification.","Expense of Rs.200 for date 28-12-2017 Rejected by admin","","","2017-12-28 00:00:00","0","0","1","0","1","0","2017-12-28 15:13:36","0000-00-00 00:00:00");
INSERT INTO notification VALUES("15","1","sales_manager","3","expense","Expense Message","1","Expense Notification.","Expense of Rs.21 for date 28-12-2017 Rejected by admin","","","2017-12-28 00:00:00","0","0","1","0","1","0","2017-12-28 15:40:51","0000-00-00 00:00:00");
INSERT INTO notification VALUES("16","1","customer","8","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.11</b> for date <b>28-12-2017</b> added by <b>admin</b> to your account","","","2017-12-28 00:00:00","0","0","1","0","1","0","2017-12-28 15:41:30","0000-00-00 00:00:00");
INSERT INTO notification VALUES("17","1","customer","9","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.11</b> for date <b>28-12-2017</b> added by <b>admin</b> to your account","","","2017-12-28 00:00:00","0","0","1","0","1","0","2017-12-28 15:42:18","0000-00-00 00:00:00");
INSERT INTO notification VALUES("18","1","customer","10","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.11</b> for date <b>28-12-2017</b> added by <b>admin</b> to your account","","","2017-12-28 00:00:00","0","0","1","0","1","0","2017-12-28 15:44:56","0000-00-00 00:00:00");
INSERT INTO notification VALUES("19","1","customer","11","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.11</b> for date <b>28-12-2017</b> added by <b>admin</b> to your account","","","2017-12-28 00:00:00","0","0","1","0","1","0","2017-12-28 15:45:33","0000-00-00 00:00:00");
INSERT INTO notification VALUES("20","1","sales_manager","4","expense","Expense Message","1","Expense Notification.","Expense of Rs.24 for date 28-12-2017 Rejected by admin","","","2017-12-28 00:00:00","0","0","1","0","1","0","2017-12-28 15:46:03","0000-00-00 00:00:00");
INSERT INTO notification VALUES("21","1","normal_user","1","orders","Order Message","5","Order Notification.","Order of <b>Rs.11</b> for date <b>28-12-2017</b> added by <b>Tejas</b>","","","2017-12-28 00:00:00","0","0","5895","712","1","0","2017-12-28 15:46:22","0000-00-00 00:00:00");
INSERT INTO notification VALUES("22","1","normal_user","1","dispatch_detail","Dispatch Message","4","Order <b>K/OUT/001</b> Dispatched","Dispatch No.<b>K/U/DIS/001</b><br/>Items:<br/>Elbow (1/2\\&quot;) X 1","","","2017-12-28 00:00:00","0","0","1","0","1","0","2017-12-28 15:46:53","0000-00-00 00:00:00");
INSERT INTO notification VALUES("23","1","super_stockist","2","orders","Order Message","5","Order Notification.","Order of <b>Rs.2124.0</b> for date <b>28-12-2017</b> added by <b>Jay</b>","","","2017-12-28 00:00:00","0","0","5895","712","1","0","2017-12-28 15:47:30","0000-00-00 00:00:00");
INSERT INTO notification VALUES("24","1","super_stockist","2","dispatch_detail","Dispatch Message","4","Order <b>K/OUT/002</b> Dispatched","Dispatch No.<b>K/SS/DIS/002</b><br/>Items:<br/>Elbow(1/2\\&quot;) X 200","","","2017-12-28 00:00:00","0","0","1","0","1","0","2017-12-28 15:47:44","0000-00-00 00:00:00");
INSERT INTO notification VALUES("25","1","customer","12","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.8555</b> for date <b>28-12-2017</b> added by <b>admin</b> to your account","","","2017-12-28 00:00:00","0","0","1","0","1","0","2017-12-28 17:59:25","0000-00-00 00:00:00");
INSERT INTO notification VALUES("26","1","normal_user","3","orders","Order Message","5","Order Notification.","Order of <b>Rs.8555</b> for date <b>28-12-2017</b> added by <b>Tejas</b>","","","2017-12-28 00:00:00","0","0","5895","712","1","0","2017-12-28 18:00:22","0000-00-00 00:00:00");
INSERT INTO notification VALUES("27","1","customer","13","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.1062</b> for date <b>28-12-2017</b> added by <b>admin</b> to your account","","","2017-12-28 00:00:00","0","0","1","0","1","0","2017-12-28 18:04:46","0000-00-00 00:00:00");
INSERT INTO notification VALUES("28","1","normal_user","4","orders","Order Message","5","Order Notification.","Order of <b>Rs.1062</b> for date <b>28-12-2017</b> added by <b>Tejas</b>","","","2017-12-28 00:00:00","0","0","5895","712","1","0","2017-12-28 18:05:15","0000-00-00 00:00:00");
INSERT INTO notification VALUES("29","1","super_stockist","5","orders","Order Message","5","Order Notification.","Order of <b>Rs.979.0</b> for date <b>28-12-2017</b> added by <b>Jay</b>","","","2017-12-28 00:00:00","0","0","5895","712","1","0","2017-12-28 18:08:48","0000-00-00 00:00:00");
INSERT INTO notification VALUES("30","1","customer","14","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.8655</b> for date <b>01-01-2018</b> added by <b>admin</b> to your account","","","2018-01-01 00:00:00","0","0","1","0","1","0","2018-01-01 14:17:21","0000-00-00 00:00:00");
INSERT INTO notification VALUES("31","1","normal_user","6","orders","Order Message","5","Order Notification.","Order of <b>Rs.8655</b> for date <b>01-01-2018</b> added by <b>Tejas</b>","","","2018-01-01 00:00:00","0","0","5895","712","1","0","2018-01-01 14:18:03","0000-00-00 00:00:00");
INSERT INTO notification VALUES("32","1","customer","15","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.1630</b> for date <b>01-01-2018</b> added by <b>admin</b> to your account","","","2018-01-01 00:00:00","0","0","1","0","1","0","2018-01-01 16:40:46","0000-00-00 00:00:00");
INSERT INTO notification VALUES("33","1","customer","16","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.1540</b> for date <b>01-01-2018</b> added by <b>admin</b> to your account","","","2018-01-01 00:00:00","0","0","1","0","1","0","2018-01-01 16:42:26","0000-00-00 00:00:00");
INSERT INTO notification VALUES("34","1","normal_user","7","orders","Order Message","5","Order Notification.","Order of <b>Rs.1540</b> for date <b>01-01-2018</b> added by <b>Tejas</b>","","","2018-01-01 00:00:00","0","0","5895","712","1","0","2018-01-01 16:42:53","0000-00-00 00:00:00");
INSERT INTO notification VALUES("35","1","normal_user","3","dispatch_detail","Dispatch Message","4","Order <b>K/OUT/007</b> Dispatched","Dispatch No.<b>K/U/DIS/003</b><br/>Items:<br/>Elbow (1/2\\&quot;) X 100<br/>Elbow (3/4\\&quot;) X 50","","","2018-01-01 00:00:00","0","0","1","0","1","0","2018-01-01 16:45:35","0000-00-00 00:00:00");
INSERT INTO notification VALUES("36","1","super_stockist","8","orders","Order Message","5","Order Notification.","Order of <b>Rs.76.0</b> for date <b>01-01-2018</b> added by <b>Jay</b>","","","2018-01-01 00:00:00","0","0","5895","712","1","0","2018-01-01 16:56:42","0000-00-00 00:00:00");
INSERT INTO notification VALUES("37","1","sales_manager","5","expense","Expense Message","1","Expense Notification.","Expense of Rs.250 for date 01-01-2018 Rejected by admin","","","2018-01-01 00:00:00","0","0","1","0","1","0","2018-01-01 17:02:32","0000-00-00 00:00:00");
INSERT INTO notification VALUES("38","1","","0","","Admin Message","2","abc","<p>hiii</p>","","","2018-01-01 17:15:12","0","0","1","0","1","0","2018-01-01 17:15:12","0000-00-00 00:00:00");
INSERT INTO notification VALUES("39","1","customer","17","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.47515</b> for date <b>05-01-2018</b> added by <b>admin</b> to your account","","","2018-01-05 00:00:00","0","0","1","0","1","0","2018-01-05 18:08:35","0000-00-00 00:00:00");
INSERT INTO notification VALUES("40","1","normal_user","9","orders","Order Message","5","Order Notification.","Order of <b>Rs.47515</b> for date <b>05-01-2018</b> added by <b>Tejas</b>","","","2018-01-05 00:00:00","0","0","5895","712","1","0","2018-01-05 18:09:09","0000-00-00 00:00:00");
INSERT INTO notification VALUES("41","1","normal_user","4","dispatch_detail","Dispatch Message","4","Order <b>K/OUT/009</b> Dispatched","Dispatch No.<b>K/U/DIS/004</b><br/>Items:<br/>Elbow (1/2\\&quot;) X 600<br/>Elbow (3/4\\&quot;) X 500<br/>Elbow (1\\&quot;) X 1250","","","2018-01-05 00:00:00","0","0","1","0","1","0","2018-01-05 18:14:49","0000-00-00 00:00:00");
INSERT INTO notification VALUES("42","1","super_stockist","10","orders","Order Message","5","Order Notification.","Order of <b>Rs.13239.0</b> for date <b>05-01-2018</b> added by <b>Jay</b>","","","2018-01-05 00:00:00","0","0","5895","712","1","0","2018-01-05 18:34:07","0000-00-00 00:00:00");
INSERT INTO notification VALUES("43","1","customer","18","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.504</b> for date <b>08-01-2018</b> added by <b>admin</b> to your account","","","2018-01-08 00:00:00","0","0","1","0","1","0","2018-01-08 14:55:27","0000-00-00 00:00:00");
INSERT INTO notification VALUES("44","1","normal_user","11","orders","Order Message","5","Order Notification.","Order of <b>Rs.504</b> for date <b>08-01-2018</b> added by <b>Tejas</b>","","","2018-01-08 00:00:00","0","0","5895","712","1","0","2018-01-08 14:55:43","0000-00-00 00:00:00");
INSERT INTO notification VALUES("45","1","super_stockist","12","orders","Order Message","5","Order Notification.","Order of <b>Rs.50.0</b> for date <b>09-01-2018</b> added by <b>Jay</b>","","","2018-01-09 00:00:00","0","0","5895","712","1","0","2018-01-09 10:28:21","0000-00-00 00:00:00");
INSERT INTO notification VALUES("46","1","super_stockist","13","orders","Order Message","5","Order Notification.","Order of <b>Rs.119.0</b> for date <b>09-01-2018</b> added by <b>Jay</b>","","","2018-01-09 00:00:00","0","0","5895","712","1","0","2018-01-09 10:31:32","0000-00-00 00:00:00");
INSERT INTO notification VALUES("47","1","dealer","14","orders","Order Message","5","Order Notification.","Order of <b>Rs.50.0</b> for date <b>09-01-2018</b> added by <b>Hardip</b>","","","2018-01-09 00:00:00","0","0","5895","712","1","0","2018-01-09 10:40:37","0000-00-00 00:00:00");
INSERT INTO notification VALUES("48","1","super_stockist","15","orders","Order Message","5","Order Notification.","Order of <b>Rs.489.0</b> for date <b>09-01-2018</b> added by <b>Jay</b>","","","2018-01-09 00:00:00","0","0","5895","712","1","0","2018-01-09 15:33:22","0000-00-00 00:00:00");
INSERT INTO notification VALUES("49","1","customer","19","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.504</b> for date <b>09-01-2018</b> added by <b>admin</b> to your account","","","2018-01-09 00:00:00","0","0","1","0","1","0","2018-01-09 15:42:02","0000-00-00 00:00:00");
INSERT INTO notification VALUES("50","1","normal_user","16","orders","Order Message","5","Order Notification.","Order of <b>Rs.504</b> for date <b>09-01-2018</b> added by <b>Tejas</b>","","","2018-01-09 00:00:00","0","0","5895","712","1","0","2018-01-09 15:42:39","0000-00-00 00:00:00");
INSERT INTO notification VALUES("51","1","normal_user","5","dispatch_detail","Dispatch Message","4","Order <b>K/OUT/011</b> Dispatched","Dispatch No.<b>K/U/DIS/005</b><br/>Items:<br/>Elbow (1/2\\&quot;) X 50","","","2018-01-09 00:00:00","0","0","1","0","1","0","2018-01-09 15:44:41","0000-00-00 00:00:00");
INSERT INTO notification VALUES("52","1","dealer","17","orders","Order Message","5","Order Notification.","Order of <b>Rs.649.0</b> for date <b>12-01-2018</b> added by <b>Hardip</b>","","","2018-01-12 00:00:00","0","0","5895","712","1","0","2018-01-12 16:18:47","0000-00-00 00:00:00");
INSERT INTO notification VALUES("53","1","super_stockist","18","orders","Order Message","5","Order Notification.","Order of <b>Rs.2655.0</b> for date <b>12-01-2018</b> added by <b>Jay</b>","","","2018-01-12 00:00:00","0","0","5895","712","1","0","2018-01-12 16:22:19","0000-00-00 00:00:00");
INSERT INTO notification VALUES("54","1","normal_user","14","customer_order_request_info","Order Request Message","6","Order Request Notification.","Order Request of <b>Qty.50</b> for date <b>13-01-2018</b> added by <b>jay</b>","","","2018-01-13 15:28:23","0","0","5895","712","1","0","2018-01-13 15:28:23","0000-00-00 00:00:00");
INSERT INTO notification VALUES("55","3","customer","20","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.478</b> for date <b>13-01-2018</b> added by <b>admin</b> to your account","","","2018-01-13 00:00:00","0","0","1","0","1","0","2018-01-13 15:30:53","0000-00-00 00:00:00");
INSERT INTO notification VALUES("56","1","normal_user","15","customer_order_request_info","Order Request Message","6","Order Request Notification.","Order Request of <b>Qty.50</b> for date <b>13-01-2018</b> added by <b>jay</b>","","","2018-01-13 15:39:56","0","0","5895","712","1","0","2018-01-13 15:39:57","0000-00-00 00:00:00");
INSERT INTO notification VALUES("57","3","customer","21","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.478</b> for date <b>13-01-2018</b> added by <b>admin</b> to your account","","","2018-01-13 00:00:00","0","0","1","0","1","0","2018-01-13 15:42:20","0000-00-00 00:00:00");
INSERT INTO notification VALUES("58","1","normal_user","1","proforma_invoice_info","ProForma Invoice Reject Message","7","ProForma Invoice Reject Notification.","ProForma Invoice Rejected by <b></b> Due to dfgdggdfgfdgdfgdfg","","","2018-01-13 00:00:00","0","0","1","0","1","0","2018-01-13 15:48:52","0000-00-00 00:00:00");
INSERT INTO notification VALUES("59","1","normal_user","1","proforma_invoice_info","ProForma Invoice Reject Message","7","ProForma Invoice Reject Notification.","ProForma Invoice Rejected by <b></b> Due to dfgdggdfgfdgdfgdfg","","","2018-01-13 00:00:00","0","0","1","0","1","0","2018-01-13 15:49:26","0000-00-00 00:00:00");
INSERT INTO notification VALUES("60","3","customer","22","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.478</b> for date <b>13-01-2018</b> added by <b>admin</b> to your account","","","2018-01-13 00:00:00","0","0","1","0","1","0","2018-01-13 15:50:13","0000-00-00 00:00:00");
INSERT INTO notification VALUES("61","1","normal_user","22","proforma_invoice_info","ProForma Invoice Reject Message","7","ProForma Invoice Reject Notification.","ProForma Invoice Rejected by <b></b> Due to ","","","2018-01-13 00:00:00","0","0","5895","712","1","0","2018-01-13 15:50:31","0000-00-00 00:00:00");
INSERT INTO notification VALUES("62","3","customer","23","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.478</b> for date <b>13-01-2018</b> added by <b>admin</b> to your account","","","2018-01-13 00:00:00","0","0","1","0","1","0","2018-01-13 15:51:13","0000-00-00 00:00:00");
INSERT INTO notification VALUES("63","1","normal_user","23","proforma_invoice_info","ProForma Invoice Reject Message","7","ProForma Invoice Reject Notification.","ProForma Invoice Rejected by <b></b> Due to Hello","","","2018-01-13 00:00:00","0","0","5895","712","1","0","2018-01-13 15:51:21","0000-00-00 00:00:00");
INSERT INTO notification VALUES("64","3","customer","24","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.451</b> for date <b>13-01-2018</b> added by <b>admin</b> to your account","","","2018-01-13 00:00:00","0","0","1","0","1","0","2018-01-13 15:52:25","0000-00-00 00:00:00");
INSERT INTO notification VALUES("65","1","normal_user","19","orders","Order Message","5","Order Notification.","Order of <b>Rs.451</b> for date <b>13-01-2018</b> added by <b>jay</b>","","","2018-01-13 00:00:00","0","0","5895","712","1","0","2018-01-13 15:52:33","0000-00-00 00:00:00");
INSERT INTO notification VALUES("66","1","super_stockist","6","dispatch_detail","Dispatch Message","4","Order <b>K/OUT/012</b> Dispatched","Dispatch No.<b>K/SS/DIS/006</b><br/>Items:<br/>Elbow(1/2\\&quot;) X 5","","","2018-01-13 00:00:00","0","0","1","0","1","0","2018-01-13 15:53:26","0000-00-00 00:00:00");
INSERT INTO notification VALUES("67","3","normal_user","7","dispatch_detail","Dispatch Message","4","Order <b>K/OUT/019</b> Dispatched","Dispatch No.<b>K/U/DIS/007</b><br/>Items:<br/>Elbow (1/2\\&quot;) X 50","","","2018-01-13 00:00:00","0","0","1","0","1","0","2018-01-13 15:57:27","0000-00-00 00:00:00");
INSERT INTO notification VALUES("68","1","normal_user","16","customer_order_request_info","Order Request Message","6","Order Request Notification.","Order Request of <b>Qty.50</b> for date <b>13-01-2018</b> added by <b>jay</b>","","","2018-01-13 15:58:20","0","0","5895","712","1","0","2018-01-13 15:58:20","0000-00-00 00:00:00");
INSERT INTO notification VALUES("69","3","customer","25","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.504</b> for date <b>13-01-2018</b> added by <b>admin</b> to your account","","","2018-01-13 00:00:00","0","0","1","0","1","0","2018-01-13 15:58:37","0000-00-00 00:00:00");
INSERT INTO notification VALUES("70","1","normal_user","20","orders","Order Message","5","Order Notification.","Order of <b>Rs.504</b> for date <b>13-01-2018</b> added by <b>jay</b>","","","2018-01-13 00:00:00","0","0","5895","712","1","0","2018-01-13 15:58:43","0000-00-00 00:00:00");
INSERT INTO notification VALUES("71","3","normal_user","8","dispatch_detail","Dispatch Message","4","Order <b>K/OUT/020</b> Dispatched","Dispatch No.<b>K/U/DIS/008</b><br/>Items:<br/>Elbow (1/2\\&quot;) X 10","","","2018-01-13 00:00:00","0","0","1","0","1","0","2018-01-13 15:59:07","0000-00-00 00:00:00");
INSERT INTO notification VALUES("72","3","","0","","Admin Message","2","hello","<p>hello</p>","","","2018-01-13 16:03:49","0","0","1","0","1","0","2018-01-13 16:03:50","0000-00-00 00:00:00");
INSERT INTO notification VALUES("73","3","","0","","Admin Message","2","hii","<p>hii</p>","","","2018-01-13 16:06:50","0","0","1","0","1","0","2018-01-13 16:06:50","0000-00-00 00:00:00");
INSERT INTO notification VALUES("74","3","normal_user","9","dispatch_detail","Dispatch Message","4","Order <b>K/OUT/020</b> Dispatched","Dispatch No.<b>K/U/DIS/009</b><br/>Items:<br/>Elbow (1/2\\&quot;) X 10","","","2018-01-13 00:00:00","0","0","1","0","1","0","2018-01-13 16:07:29","0000-00-00 00:00:00");
INSERT INTO notification VALUES("75","3","normal_user","10","dispatch_detail","Dispatch Message","4","Order <b>K/OUT/020</b> Dispatched","Dispatch No.<b>K/U/DIS/010</b><br/>Items:<br/>Elbow (1/2\\&quot;) X 30","","","2018-01-13 00:00:00","0","0","1","0","1","0","2018-01-13 16:08:30","0000-00-00 00:00:00");
INSERT INTO notification VALUES("76","1","normal_user","17","customer_order_request_info","Order Request Message","6","Order Request Notification.","Order Request of <b>Qty.50</b> for date <b>13-01-2018</b> added by <b>jay</b>","","","2018-01-13 16:14:16","0","0","5895","712","1","0","2018-01-13 16:14:16","0000-00-00 00:00:00");
INSERT INTO notification VALUES("77","3","customer","26","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.643</b> for date <b>13-01-2018</b> added by <b>admin</b> to your account","","","2018-01-13 00:00:00","0","0","1","0","1","0","2018-01-13 16:14:47","0000-00-00 00:00:00");
INSERT INTO notification VALUES("78","1","normal_user","18","customer_order_request_info","Order Request Message","6","Order Request Notification.","Order Request of <b>Qty.50</b> for date <b>13-01-2018</b> added by <b>jay</b>","","","2018-01-13 16:19:20","0","0","5895","712","1","0","2018-01-13 16:19:20","0000-00-00 00:00:00");
INSERT INTO notification VALUES("79","3","customer","27","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.617</b> for date <b>13-01-2018</b> added by <b>admin</b> to your account","","","2018-01-13 00:00:00","0","0","1","0","1","0","2018-01-13 16:20:11","0000-00-00 00:00:00");
INSERT INTO notification VALUES("80","1","normal_user","21","orders","Order Message","5","Order Notification.","Order of <b>Rs.617</b> for date <b>13-01-2018</b> added by <b>jay</b>","","","2018-01-13 00:00:00","0","0","5895","712","1","0","2018-01-13 16:20:55","0000-00-00 00:00:00");
INSERT INTO notification VALUES("81","3","normal_user","11","dispatch_detail","Dispatch Message","4","Order <b>K/OUT/021</b> Dispatched","Dispatch No.<b>K/U/DIS/011</b><br/>Items:<br/>Tee (1/2\\&quot;) X 20","","","2018-01-13 00:00:00","0","0","1","0","1","0","2018-01-13 16:21:34","0000-00-00 00:00:00");
INSERT INTO notification VALUES("82","3","normal_user","12","dispatch_detail","Dispatch Message","4","Order <b>K/OUT/021</b> Dispatched","Dispatch No.<b>K/U/DIS/012</b><br/>Items:<br/>Tee (1/2\\&quot;) X 30","","","2018-01-13 00:00:00","0","0","1","0","1","0","2018-01-13 16:22:00","0000-00-00 00:00:00");
INSERT INTO notification VALUES("83","1","normal_user","19","customer_order_request_info","Order Request Message","6","Order Request Notification.","Order Request of <b>Qty.50</b> for date <b>13-01-2018</b> added by <b>jay</b>","","","2018-01-13 16:24:55","0","0","5895","712","1","0","2018-01-13 16:24:56","0000-00-00 00:00:00");
INSERT INTO notification VALUES("84","3","customer","28","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.504</b> for date <b>13-01-2018</b> added by <b>admin</b> to your account","","","2018-01-13 00:00:00","0","0","1","0","1","0","2018-01-13 16:25:20","0000-00-00 00:00:00");
INSERT INTO notification VALUES("85","1","normal_user","20","customer_order_request_info","Order Request Message","6","Order Request Notification.","Order Request of <b>Qty.50</b> for date <b>15-01-2018</b> added by <b>jay</b>","","","2018-01-15 10:08:25","0","0","5895","712","1","0","2018-01-15 10:08:25","0000-00-00 00:00:00");
INSERT INTO notification VALUES("86","3","customer","29","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.462</b> for date <b>15-01-2018</b> added by <b>admin</b> to your account","","","2018-01-15 00:00:00","0","0","1","0","1","0","2018-01-15 10:09:40","0000-00-00 00:00:00");
INSERT INTO notification VALUES("87","1","normal_user","22","orders","Order Message","5","Order Notification.","Order of <b>Rs.462</b> for date <b>15-01-2018</b> added by <b>jay</b>","","","2018-01-15 00:00:00","0","0","5895","712","1","0","2018-01-15 10:10:21","0000-00-00 00:00:00");
INSERT INTO notification VALUES("88","1","normal_user","21","customer_order_request_info","Order Request Message","6","Order Request Notification.","Order Request of <b>Qty.50</b> for date <b>15-01-2018</b> added by <b>jay</b>","","","2018-01-15 10:48:56","0","0","5895","712","1","0","2018-01-15 10:48:56","0000-00-00 00:00:00");
INSERT INTO notification VALUES("89","3","customer","30","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.510</b> for date <b>15-01-2018</b> added by <b>admin</b> to your account","","","2018-01-15 00:00:00","0","0","1","0","1","0","2018-01-15 10:49:20","0000-00-00 00:00:00");
INSERT INTO notification VALUES("90","1","normal_user","23","orders","Order Message","5","Order Notification.","Order of <b>Rs.510</b> for date <b>15-01-2018</b> added by <b>jay</b>","","","2018-01-15 00:00:00","0","0","5895","712","1","0","2018-01-15 10:53:24","0000-00-00 00:00:00");
INSERT INTO notification VALUES("91","1","normal_user","24","orders","Order Message","5","Order Notification.","Order of <b>Rs.53</b> for date <b>15-01-2018</b> added by <b>Tejas</b>","","","2018-01-15 00:00:00","0","0","1","0","1","0","2018-01-15 10:53:59","0000-00-00 00:00:00");
INSERT INTO notification VALUES("92","1","normal_user","25","orders","Order Message","5","Order Notification.","Order of <b>Rs.510</b> for date <b>15-01-2018</b> added by <b>jay</b>","","","2018-01-15 00:00:00","0","0","1","0","1","0","2018-01-15 10:54:19","0000-00-00 00:00:00");
INSERT INTO notification VALUES("93","1","normal_user","26","orders","Order Message","5","Order Notification.","Order of <b>Rs.510</b> for date <b>15-01-2018</b> added by <b>jay</b>","","","2018-01-15 00:00:00","0","0","1","0","1","0","2018-01-15 10:54:39","0000-00-00 00:00:00");
INSERT INTO notification VALUES("94","1","normal_user","27","orders","Order Message","5","Order Notification.","Order of <b>Rs.510</b> for date <b>15-01-2018</b> added by <b>jay</b>","","","2018-01-15 00:00:00","0","0","1","0","1","0","2018-01-15 10:54:54","0000-00-00 00:00:00");
INSERT INTO notification VALUES("95","1","normal_user","28","orders","Order Message","5","Order Notification.","Order of <b>Rs.510</b> for date <b>15-01-2018</b> added by <b>jay</b>","","","2018-01-15 00:00:00","0","0","1","0","1","0","2018-01-15 10:55:09","0000-00-00 00:00:00");
INSERT INTO notification VALUES("96","1","normal_user","22","customer_order_request_info","Order Request Message","6","Order Request Notification.","Order Request of <b>Qty.50</b> for date <b>15-01-2018</b> added by <b>jay</b>","","","2018-01-15 10:57:50","0","0","5895","712","1","0","2018-01-15 10:57:50","0000-00-00 00:00:00");
INSERT INTO notification VALUES("97","3","customer","31","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.622</b> for date <b>15-01-2018</b> added by <b>admin</b> to your account","","","2018-01-15 00:00:00","0","0","1","0","1","0","2018-01-15 10:57:57","0000-00-00 00:00:00");
INSERT INTO notification VALUES("98","1","normal_user","29","orders","Order Message","5","Order Notification.","Order of <b>Rs.622</b> for date <b>15-01-2018</b> added by <b>jay</b>","","","2018-01-15 00:00:00","0","0","5895","712","1","0","2018-01-15 10:58:10","0000-00-00 00:00:00");
INSERT INTO notification VALUES("99","1","normal_user","1","customer_order_request_info","Order Request Message","6","Order Request Notification.","Order Request of <b>Qty.550</b> for date <b>15-01-2018</b> added by <b>jay</b>","","","2018-01-15 11:21:35","0","0","5895","712","1","0","2018-01-15 11:21:36","0000-00-00 00:00:00");
INSERT INTO notification VALUES("100","3","customer","1","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.7151</b> for date <b>15-01-2018</b> added by <b>admin</b> to your account","","","2018-01-15 00:00:00","0","0","1","0","1","0","2018-01-15 11:27:37","0000-00-00 00:00:00");
INSERT INTO notification VALUES("101","1","normal_user","1","orders","Order Message","5","Order Notification.","Order of <b>Rs.7151</b> for date <b>15-01-2018</b> added by <b>jay</b>","","","2018-01-15 00:00:00","0","0","5895","712","1","0","2018-01-15 11:32:24","0000-00-00 00:00:00");
INSERT INTO notification VALUES("102","1","normal_user","1","customer_order_request_info","Order Request Message","6","Order Request Notification.","Order Request of <b>Qty.550</b> for date <b>16-01-2018</b> added by <b>jay</b>","","","2018-01-16 15:54:08","0","0","5895","712","1","0","2018-01-16 15:54:08","0000-00-00 00:00:00");
INSERT INTO notification VALUES("103","3","customer","1","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.7151</b> for date <b>16-01-2018</b> added by <b>admin</b> to your account","","","2018-01-16 00:00:00","0","0","1","0","1","0","2018-01-16 15:55:10","0000-00-00 00:00:00");
INSERT INTO notification VALUES("104","1","normal_user","1","orders","Order Message","5","Order Notification.","Order of <b>Rs.7151</b> for date <b>16-01-2018</b> added by <b>jay</b>","","","2018-01-16 00:00:00","0","0","5895","712","1","0","2018-01-16 16:15:16","0000-00-00 00:00:00");
INSERT INTO notification VALUES("105","1","normal_user","2","customer_order_request_info","Order Request Message","6","Order Request Notification.","Order Request of <b>Qty.150</b> for date <b>16-01-2018</b> added by <b>jay</b>","","","2018-01-16 16:29:59","0","0","5895","712","1","0","2018-01-16 16:29:59","0000-00-00 00:00:00");
INSERT INTO notification VALUES("106","3","normal_user","1","dispatch_detail","Dispatch Message","4","Order <b>K/OUT/001</b> Dispatched","Dispatch No.<b>K/U/DIS/001</b><br/>Items:<br/>Elbow (1/2\\&quot;) X 250<br/>Elbow (3/4\\&quot;) X 300","","","2018-01-16 00:00:00","0","0","1","0","1","0","2018-01-16 17:01:52","0000-00-00 00:00:00");
INSERT INTO notification VALUES("107","1","","0","","Admin Message","2","New Notication","<p>dfadfasdfdasf</p>","","","2018-02-07 12:35:52","0","0","1","0","1","0","2018-02-07 12:35:52","0000-00-00 00:00:00");
INSERT INTO notification VALUES("108","1","normal_user","3","customer_order_request_info","Order Request Message","6","Order Request Notification.","Order Request of <b>Qty.250</b> for date <b>07-02-2018</b> added by <b>hardip</b>","","","2018-02-07 12:44:25","0","1","5895","712","","","2018-02-07 12:44:25","0000-00-00 00:00:00");
INSERT INTO notification VALUES("109","4","customer","2","proforma_invoice_info","Proforma Message","2","Proforma Invoice Notification.","Invoice of <b>Rs.2655</b> for date <b>07-02-2018</b> added by <b>admin</b> to your account","","","2018-02-07 00:00:00","0","1","1","0","","","2018-02-07 12:45:01","0000-00-00 00:00:00");
INSERT INTO notification VALUES("110","1","normal_user","2","orders","Order Message","5","Order Notification.","Order of <b>Rs.2655</b> for date <b>07-02-2018</b> added by <b>hardip</b>","","","2018-02-07 00:00:00","0","1","5895","712","","","2018-02-07 12:45:26","0000-00-00 00:00:00");
INSERT INTO notification VALUES("111","4","normal_user","2","dispatch_detail","Dispatch Message","4","Order <b>K/OUT/002</b> Dispatched","Dispatch No.<b>K/U/DIS/002</b><br/>Items:<br/>Elbow (1/2\\&quot;) X 50","","","2018-02-07 00:00:00","0","1","1","0","","","2018-02-07 12:46:00","0000-00-00 00:00:00");
INSERT INTO notification VALUES("112","1","super_stockist","3","orders","Order Message","5","Order Notification.","Order of <b>Rs.2655.0</b> for date <b>07-02-2018</b> added by <b>Jay</b>","","","2018-02-07 00:00:00","0","0","5895","712","1","0","2018-02-07 12:52:17","0000-00-00 00:00:00");
INSERT INTO notification VALUES("113","1","super_stockist","3","dispatch_detail","Dispatch Message","4","Order <b>K/OUT/003</b> Dispatched","Dispatch No.<b>K/SS/DIS/003</b><br/>Items:<br/>Elbow(1/2\\&quot;) X 50","","","2018-02-07 00:00:00","0","1","1","0","","","2018-02-07 12:52:58","0000-00-00 00:00:00");
INSERT INTO notification VALUES("114","4","customer","4","dispatch_detail","Dispatch Message","4","Order <b>K/OUT/002</b> Dispatched","Dispatch No.<b>K/U/DIS/004</b><br/>Items:<br/>Elbow (1/2\\&quot;) X 50","","","2018-02-07 00:00:00","0","1","1","0","","","2018-02-07 13:05:30","0000-00-00 00:00:00");
INSERT INTO notification VALUES("115","1","customer","4","customer_order_request_info","Order Request Message","6","Order Request Notification.","Order Request of <b>Qty.400</b> for date <b>07-02-2018</b> added by <b>hardip</b>","","","2018-02-07 13:10:33","0","1","5895","712","","","2018-02-07 13:10:34","0000-00-00 00:00:00");
INSERT INTO notification VALUES("116","4","sales_executive","6","expense","Expense Message","1","Expense Notification.","Expense of Rs.629998 for date 08-12-2018 Rejected by admin","","","2018-12-08 00:00:00","0","1","1","0","","","2018-12-08 10:21:35","0000-00-00 00:00:00");
INSERT INTO notification VALUES("117","4","sales_executive","7","expense","Expense Message","1","Expense Notification.","Expense of Rs.270197 for date 08-12-2018 Rejected by admin","","","2018-12-08 00:00:00","0","1","1","0","","","2018-12-08 10:22:13","0000-00-00 00:00:00");





CREATE TABLE `order_product_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL DEFAULT '0',
  `pro_id` int(11) NOT NULL DEFAULT '0',
  `weight_id` int(11) NOT NULL DEFAULT '0',
  `pro_name` varchar(200) DEFAULT NULL,
  `dispatched_qty` int(11) NOT NULL DEFAULT '0',
  `remaining_qty` int(11) NOT NULL DEFAULT '0',
  `inner_size` double NOT NULL,
  `outer_size` double NOT NULL,
  `pro_qty` int(11) NOT NULL DEFAULT '0',
  `unitprice` float NOT NULL DEFAULT '0',
  `totalprice` double NOT NULL DEFAULT '0',
  `discount` double NOT NULL DEFAULT '0',
  `discount_amount` double NOT NULL DEFAULT '0',
  `taxable` double NOT NULL DEFAULT '0',
  `cash_discount` double NOT NULL,
  `cash_discount_amount` double NOT NULL,
  `subtotal` double NOT NULL,
  `cgst_tax` double NOT NULL DEFAULT '0',
  `cgst_amount` double NOT NULL DEFAULT '0',
  `sgst_tax` double NOT NULL DEFAULT '0',
  `sgst_amount` double NOT NULL DEFAULT '0',
  `igst_tax` double NOT NULL DEFAULT '0',
  `igst_amount` double NOT NULL DEFAULT '0',
  `grandtotal` double NOT NULL,
  `box_qty` double NOT NULL,
  `adate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL DEFAULT '0',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` text,
  `modified_date` text,
  `local_id` int(11) NOT NULL DEFAULT '0',
  `modify_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO order_product_item VALUES("1","1","1","1","Elbow (1/2\")","250","0","50","0","250","9","2250","0","0","2250","0","0","2250","9","202.5","9","202.5","0","0","2655","5","2018-01-16 16:15:16","1","0","1","5895","712","1","0","2018-01-16 16:15:16","2018-01-16 17:01:51","0","2018-01-16 16:15:16");
INSERT INTO order_product_item VALUES("2","1","1","2","Elbow (3/4\")","300","0","50","0","300","12.7","3810","0","0","3810","0","0","3810","9","342.9","9","342.9","0","0","4495.8","6","2018-01-16 16:15:16","1","0","1","5895","712","1","0","2018-01-16 16:15:16","2018-01-16 17:01:51","0","2018-01-16 16:15:16");
INSERT INTO order_product_item VALUES("3","2","1","1","Elbow (1/2\")","100","150","50","0","250","9","2250","0","0","2250","0","0","2250","9","202.5","9","202.5","0","0","2655","5","2018-02-07 12:45:26","1","0","0","5895","712","1,1","0,0","2018-02-07 12:45:26","2018-02-07 12:46:00,2018-02-07 13:05:30","0","2018-02-07 12:45:26");
INSERT INTO order_product_item VALUES("4","3","1","1","Elbow(1/2\")","50","200","50","0","250","9","2655","0","0","2250","0","0","2250","9","202.5","9","202.5","0","0","2655","5","2018-02-07 12:52:16","1","0","0","5895","712","1","0","2018-02-07 12:52:17","2018-02-07 12:52:58","0","2018-02-07 12:52:17");





CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` varchar(50) NOT NULL,
  `customer_id` int(11) NOT NULL DEFAULT '0',
  `company_name` varchar(150) NOT NULL,
  `dealer_id` int(11) NOT NULL,
  `sales_id` int(11) NOT NULL DEFAULT '0',
  `sales_type` varchar(50) DEFAULT NULL,
  `class_id` int(11) NOT NULL DEFAULT '0',
  `proforma_invoice_id` int(11) NOT NULL DEFAULT '0',
  `class_name` varchar(150) NOT NULL,
  `area_id` int(11) NOT NULL DEFAULT '0',
  `area_name` varchar(150) NOT NULL,
  `customer_name` varchar(50) DEFAULT NULL,
  `customer_type` varchar(100) DEFAULT NULL,
  `contact_number` varchar(50) DEFAULT NULL,
  `address` text,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(250) NOT NULL,
  `country` varchar(250) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `order_date` date DEFAULT NULL,
  `dispatch_date` date DEFAULT NULL,
  `revised_date` date DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=pending,1=completed,2=dispatched,3=cancelled',
  `adate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `remarks` text NOT NULL,
  `reason_of_cancel_order` text NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  `item_total_price` double NOT NULL,
  `total_qty` int(11) NOT NULL DEFAULT '0',
  `taxable` double NOT NULL DEFAULT '0',
  `discount` double NOT NULL DEFAULT '0',
  `discount_amount` double NOT NULL DEFAULT '0',
  `subtotal` double NOT NULL,
  `cash_discount` double NOT NULL,
  `cash_discount_amount` double NOT NULL,
  `total_amount` double NOT NULL DEFAULT '0',
  `cgst_amount` double NOT NULL DEFAULT '0',
  `sgst_amount` double NOT NULL DEFAULT '0',
  `igst_amount` double NOT NULL DEFAULT '0',
  `grand_total` double NOT NULL DEFAULT '0',
  `roundoff` double NOT NULL,
  `total_taxamount` double NOT NULL,
  `grand_total_rounded` double NOT NULL,
  `local_id` int(11) NOT NULL DEFAULT '0',
  `taxable_amount` double NOT NULL DEFAULT '0',
  `discount_type` int(11) NOT NULL DEFAULT '0',
  `modify_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO orders VALUES("1","K/OUT/001","3","Prashant","0","0","normal_user","0","1","","0","","jay","normal_user","9824518363","Rajkot","Rajkot","Gujarat","India","jay@gmail.com","2018-01-16","","","2","0000-00-00 00:00:00","0","1","","","5895","712","5895,5895,1","458,458,0","2018-01-16 16:15:16","2018-01-16 16:15:16,2018-01-16 16:15:16,2018-01-16 17:01:52","0","550","6060","0","0","6060","0","0","6060","545.4","545.4","0","7150.8","0.19999999999982","0","7151","0","0","0","2018-01-16 16:15:16");
INSERT INTO orders VALUES("2","K/OUT/002","4","h","0","0","normal_user","0","2","","0","","hardip","normal_user","9979055113","fg","ydy","Gujarat","India","h@gmail.com","2018-02-07","","","0","0000-00-00 00:00:00","0","1","","","5895","712","5895,5895,1,1","458,458,0,0","2018-02-07 12:45:26","2018-02-07 12:45:26,2018-02-07 12:45:26,2018-02-07 12:46:00,2018-02-07 13:05:30","0","250","2250","0","0","2250","0","0","2250","202.5","202.5","0","2655","0","0","2655","0","0","0","2018-02-07 12:45:26");
INSERT INTO orders VALUES("3","K/OUT/003","1","Uma Polymer","2","1","sales_manager","1","0","","1","","Jay","super_stockist","8866189644","Panchayat Chowk, Rajkot","Rajkot","Gujarat","India","uma@gmail.com","2018-02-07","","","0","2018-02-07 12:52:16","0","1","","","5895","712","5895,1","458,0","2018-02-07 12:52:16","2018-02-07 12:52:17,2018-02-07 12:52:58","0","250","2250","0","0","2250","0","0","0","202.5","202.5","0","2655","0","0","2655","1","0","0","2018-02-07 12:52:16");





CREATE TABLE `page_admin_right` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) NOT NULL DEFAULT '0',
  `admin_id` int(11) NOT NULL DEFAULT '0',
  `view_flag` int(11) NOT NULL DEFAULT '0',
  `insert_flag` int(11) NOT NULL DEFAULT '0',
  `update_flag` int(11) NOT NULL DEFAULT '0',
  `delete_flag` int(11) NOT NULL DEFAULT '0',
  `isDelete` int(11) DEFAULT '0',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

INSERT INTO page_admin_right VALUES("1","554","40","1","1","1","1","0","1","0","","","2017-04-10 12:11:43","");
INSERT INTO page_admin_right VALUES("3","554","42","1","1","1","1","0","1","0","","","2017-04-10 12:12:11","");
INSERT INTO page_admin_right VALUES("4","555","40","1","1","1","1","0","1","0","","","2017-04-10 13:25:06","");
INSERT INTO page_admin_right VALUES("6","555","42","1","1","1","1","0","1","0","","","2017-04-10 13:25:34","");
INSERT INTO page_admin_right VALUES("12","566","1","1","1","1","1","0","1","0","","","2017-04-26 17:37:37","");
INSERT INTO page_admin_right VALUES("13","567","1","1","1","1","1","0","1","0","","","2017-04-26 17:40:21","");
INSERT INTO page_admin_right VALUES("15","566","2","1","1","1","1","0","1","0","1,1","0,0","2017-04-26 17:43:17","2017-06-13 17:35:14,2017-06-13 17:41:48");
INSERT INTO page_admin_right VALUES("17","565","4","1","1","1","1","0","1","0","","","2017-04-28 17:47:11","");
INSERT INTO page_admin_right VALUES("18","566","4","1","1","1","1","0","1","0","","","2017-04-28 17:47:15","");
INSERT INTO page_admin_right VALUES("20","568","1","1","1","1","1","0","1","0","","","2017-04-28 17:51:01","");
INSERT INTO page_admin_right VALUES("21","568","2","1","1","1","1","0","1","0","1","0","2017-04-28 18:15:38","2017-06-13 17:41:48");
INSERT INTO page_admin_right VALUES("22","569","2","1","1","1","1","0","1","0","1","0","2017-05-27 12:12:27","2017-06-13 17:41:48");
INSERT INTO page_admin_right VALUES("23","569","4","1","1","1","1","0","1","0","","","2017-05-27 12:12:45","");
INSERT INTO page_admin_right VALUES("29","555","2","1","1","1","1","0","1","0","1","0","2017-05-30 12:46:42","2017-06-13 17:41:48");
INSERT INTO page_admin_right VALUES("30","555","4","1","1","1","1","0","1","0","","","2017-05-30 14:52:45","");
INSERT INTO page_admin_right VALUES("33","560","2","1","1","1","1","0","1","0","1","0","2017-05-30 15:58:10","2017-06-13 17:41:48");
INSERT INTO page_admin_right VALUES("34","560","4","1","1","1","1","0","1","0","","","2017-05-30 16:09:03","");
INSERT INTO page_admin_right VALUES("35","571","2","1","1","1","1","0","1","0","1","0","2017-06-01 14:14:34","2017-06-13 17:41:48");
INSERT INTO page_admin_right VALUES("36","571","4","1","1","1","1","0","1","0","","","2017-06-01 14:15:03","");





CREATE TABLE `page_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(1000) DEFAULT NULL,
  `page_slug` varchar(100) DEFAULT NULL,
  `page_count` int(11) NOT NULL DEFAULT '0',
  `page_urls` text,
  `isActive` int(11) NOT NULL DEFAULT '1',
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `adate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=576 DEFAULT CHARSET=latin1;

INSERT INTO page_table VALUES("400","Dashboard Page","dashboard","0","manage_customer.php","1","0","0000-00-00 00:00:00","1","0","1,1","0,0","0000-00-00 00:00:00","2017-08-17 14:42:39,2017-08-17 14:42:41");
INSERT INTO page_table VALUES("401","My Account Page","my_account","1","my_account.php","0","0","0000-00-00 00:00:00","1","0","","","0000-00-00 00:00:00","");
INSERT INTO page_table VALUES("402","Login Page","login","1","index.php","1","0","0000-00-00 00:00:00","1","0","","","0000-00-00 00:00:00","");
INSERT INTO page_table VALUES("403","Logout Page","logout","1","logout.php","1","0","0000-00-00 00:00:00","1","0","","","0000-00-00 00:00:00","");
INSERT INTO page_table VALUES("404","(Special Page) Add Right to Admin Type Page","manage_admin_type","1","manage_admin_type.php","1","0","0000-00-00 00:00:00","1","0","","","0000-00-00 00:00:00","");
INSERT INTO page_table VALUES("405","Pages","app_pages","3","manage_page_table.php,ajax_get_page_table.php,add_page_table.php","1","0","2016-10-24 00:00:00","1","0","","","0000-00-00 00:00:00","");
INSERT INTO page_table VALUES("406","Admins","page_admin","3","manage_stern.php,ajax_get_stern.php,add_stern.php","1","0","2016-10-26 00:00:00","1","0","","","0000-00-00 00:00:00","");
INSERT INTO page_table VALUES("554","Page Employee","page_employee","9","add_employee.php,manage_employee.php,ajax_get_employee_salary.php,ajax_function_employee_salary.php,ajax_get_employee.php,ajax_genReport_employee.php,ajax_genReport_employee_salary.php,ajax_get_emp_information.php,ajax_get_emp_salary_information.php","1","0","2017-04-10 12:02:42","1","0","","","2017-04-10 12:02:42","");
INSERT INTO page_table VALUES("555","Page Executive","page_executive","10","executive_crud.php,executive_geT_ajax.php,executive_manage.php,executive_ajax_genReport.php,executive_branch_ajax_function.php,executive_branch_data_get_ajax.php,executive_contact_ajax_function.php,executive_contact_get_ajax.php,executive_form_function.php,find_city.php","1","0","2017-04-10 13:21:00","1","0","1","0","2017-04-10 13:21:00","2017-05-30 15:27:16");
INSERT INTO page_table VALUES("556","Page sales Executive","page_sales_executive","9","sales_executive_crud.php,sales_executive_get_ajax.php,sales_executive_manage.php,sales_executive_ajax_genReport.php,executive_contact_ajax_function.php,sales_executive_form_function.php,class.sales_executive.php","1","0","2017-04-19 13:21:00","1","0","1","0","2017-04-10 13:21:00","2017-04-20 10:33:32");
INSERT INTO page_table VALUES("557","Page Sales Executive Type","page_sales_executive_type","4","sales_executive_type_crud.php,sales_executive_type_get_ajax.php,sales_executive_type_manage.php,class.sales_executive_type.php","1","0","2017-04-19 13:21:00","1","0","1","0","2017-04-10 13:21:00","2017-04-26 12:37:20");
INSERT INTO page_table VALUES("558","page Class","page_class","4","class_crud.php,class_manage.php,class_get_ajax.php,class.class","1","0","2017-04-20 10:35:09","1","0","","","2017-04-20 10:35:09","");
INSERT INTO page_table VALUES("559","Product Page","page_product","3","product_cud.php,product_manage.php,product_get_ajax.php","1","0","2017-04-26 12:29:03","1","0","","","2017-04-26 12:29:03","");
INSERT INTO page_table VALUES("560","Order Page","page_order","5","orders_crud.php,orders_get_ajax.php,orders_info_genReport_ajax.php,orders_information_get_ajax.php,orders_manage.php","1","0","2017-04-26 12:31:31","1","0","","","2017-04-26 12:31:31","");
INSERT INTO page_table VALUES("561","Weight Page","page_weight","3","weight_crud.php,weight_manage.php,weight_get_ajax.php","1","0","2017-04-26 12:32:50","1","0","","","2017-04-26 12:32:50","");
INSERT INTO page_table VALUES("562","Category Page","page_category","3","category_crud.php,category_manage.php,category_get_ajax.php","1","0","2017-04-26 12:35:07","1","0","","","2017-04-26 12:35:07","");
INSERT INTO page_table VALUES("563","Class Find Page","page_find_class","1","find_class.php","1","0","2017-04-26 12:44:52","1","0","","","2017-04-26 12:44:52","");
INSERT INTO page_table VALUES("564","Area Find Page","page_find_area","1","find_area.php","1","0","2017-04-26 12:45:24","1","0","","","2017-04-26 12:45:24","");
INSERT INTO page_table VALUES("565","Page Dealer","page_dealer","2","dealer_orders_manage.php,orders_get_ajax.php,outlet_orders_get_ajax.php","1","0","2017-04-26 16:49:43","1","0","1,1,1","0,0,0","2017-04-26 16:49:43","2017-04-26 16:53:03,2017-04-26 17:03:02,2017-05-01 16:51:36");
INSERT INTO page_table VALUES("566","Page Order Ajax","page_order_ajax","1","order_ajax_get.php","1","0","2017-04-26 17:36:49","1","0","1","0","2017-04-26 17:36:49","2017-04-26 17:52:50");
INSERT INTO page_table VALUES("567","Page Product  Final","page_product_final","2","product_final_manage.php,product_final_get_ajax.php","1","0","2017-04-26 17:39:33","1","0","","","2017-04-26 17:39:33","");
INSERT INTO page_table VALUES("568","Page Super Stockist","page_super_stockist","1","ss_orders_manage.php","1","0","2017-04-26 17:45:56","1","0","","","2017-04-26 17:45:56","");
INSERT INTO page_table VALUES("569","Dispatch Pages","dispatch_pages","4","dispatch_crud.php,dispatch_get_ajax.php,dispatch_manage.php,dispatch_class.php","1","0","2017-05-27 12:11:10","1","0","","","2017-05-27 12:11:10","");
INSERT INTO page_table VALUES("570","Manage Customer","customer_manage","1","customer_manage.php","1","0","2017-05-30 12:38:56","1","0","","","2017-05-30 12:38:56","");
INSERT INTO page_table VALUES("571","Payment","payment","4","payment_manage.php,payment_get_Ajax.php,payment_crud.php","1","0","2017-06-01 14:13:57","1","0","","","2017-06-01 14:13:57","");
INSERT INTO page_table VALUES("572","Inquiry Page","no_order_inquiry_page","2","no_order_inquiry_manage.php,no_order_inquiry_get_ajax.php","1","0","0000-00-00 00:00:00","1","0","","","2017-08-08 18:42:41","");
INSERT INTO page_table VALUES("573","User","user","3","user_manage.php,user_get_ajax.php,user_crud.php","1","0","2017-10-13 11:44:47","1","0","","","2017-10-13 11:44:47","");
INSERT INTO page_table VALUES("574","Banner","banner","3","banner_manage.php,banner_get_ajax.php,banner_crud.php","1","0","2017-10-13 11:46:16","1","0","","","2017-10-13 11:46:16","");
INSERT INTO page_table VALUES("575","Customer Payment","customer_payment","4","customer_payment_manage.php,customer_payment_get_ajax.php,customer_payment_crud.php,class.customer_payment.php","1","0","2017-10-13 16:43:43","1","0","","","2017-10-13 16:43:43","");





CREATE TABLE `payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dealer_id` int(11) NOT NULL DEFAULT '0',
  `customer_id` int(11) NOT NULL DEFAULT '0',
  `dispatch_id` int(11) NOT NULL DEFAULT '0',
  `receipt_no` varchar(50) DEFAULT NULL,
  `order_id` int(11) NOT NULL DEFAULT '0',
  `paid_amount` double NOT NULL DEFAULT '0',
  `amount_remaining_that_time` double NOT NULL DEFAULT '0',
  `amount_paid_that_time` double DEFAULT '0',
  `payment_type` varchar(50) DEFAULT NULL,
  `remark` varchar(250) DEFAULT NULL,
  `payment_status` int(11) NOT NULL DEFAULT '0',
  `payment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `product` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cid` int(10) NOT NULL DEFAULT '0',
  `tcid` int(11) NOT NULL DEFAULT '1',
  `name` varchar(250) DEFAULT NULL,
  `gujrati_name` varchar(100) DEFAULT NULL,
  `slug` varchar(200) DEFAULT NULL,
  `packing` varchar(250) DEFAULT NULL,
  `cartoon` varchar(250) DEFAULT NULL,
  `weight` int(10) NOT NULL DEFAULT '0',
  `max_price` float(10,2) NOT NULL DEFAULT '0.00' COMMENT 'maximum retail price',
  `sell_price` float(10,2) NOT NULL DEFAULT '0.00' COMMENT 'selling price',
  `pro_tax` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'tax in percentage',
  `ship_days` int(10) unsigned NOT NULL DEFAULT '0',
  `local_ship_charge` float NOT NULL DEFAULT '0',
  `zonal_ship_charge` float NOT NULL DEFAULT '0',
  `national_ship_charge` float NOT NULL DEFAULT '0',
  `stock_qty` int(11) NOT NULL DEFAULT '0',
  `qty` int(10) unsigned NOT NULL DEFAULT '0',
  `min_qty_alert` int(10) unsigned NOT NULL DEFAULT '0',
  `image_path` varchar(250) DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0' COMMENT '0 = Available,1 = Out Of Stock',
  `descr` text,
  `attr` text,
  `rate` int(10) unsigned NOT NULL DEFAULT '0',
  `pro_tag` text,
  `subpid` int(10) unsigned NOT NULL DEFAULT '0',
  `spslug` varchar(250) DEFAULT NULL,
  `isDelete` tinyint(1) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `display_order` int(10) NOT NULL DEFAULT '0',
  `isAffiliate` tinyint(1) NOT NULL DEFAULT '0',
  `aff_url` text,
  `aff_image_path` text,
  `cgst` double NOT NULL DEFAULT '0',
  `sgst` double NOT NULL DEFAULT '0',
  `igst` double NOT NULL DEFAULT '0',
  `adate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`),
  KEY `cid` (`cid`),
  KEY `name` (`name`),
  KEY `price` (`max_price`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

INSERT INTO product VALUES("1","1","1","Elbow","","","","","0","0.00","0.00","0","0","0","0","0","0","0","0","3.jpg","0","","a:0:{}","0","","0","","0","1","1","0","","","9","9","18","0000-00-00 00:00:00","1","0","","","2017-12-28 11:19:10","");
INSERT INTO product VALUES("2","1","1","Tee","","","","","0","0.00","0.00","0","0","0","0","0","0","0","0","1.jpg","0","","a:0:{}","0","","0","","0","1","1","0","","","9","9","18","0000-00-00 00:00:00","1","0","","","2017-12-28 11:23:55","");
INSERT INTO product VALUES("3","1","1","Male Adapter","","","","","0","0.00","0.00","0","0","0","0","0","0","0","0","9.jpg","0","","a:0:{}","0","","0","","0","1","1","0","","","9","9","18","0000-00-00 00:00:00","1","0","","","2017-12-28 11:31:30","");
INSERT INTO product VALUES("4","1","1","Female Adapter","","","","","0","0.00","0.00","0","0","0","0","0","0","0","0","4.jpg","0","","a:0:{}","0","","0","","0","1","1","0","","","9","9","18","0000-00-00 00:00:00","1","0","1,1,1,1,1","0,0,0,0,0","2017-12-28 13:06:04","2017-12-28 13:06:35,2017-12-28 13:10:52,2017-12-28 13:11:10,2017-12-28 13:11:34,2017-12-28 13:11:50");
INSERT INTO product VALUES("5","1","1","45° Elbow","","","","","0","0.00","0.00","0","0","0","0","0","0","0","0","21.jpg","0","","a:0:{}","0","","0","","0","1","1","0","","","9","9","18","0000-00-00 00:00:00","1","0","","","2017-12-28 13:10:20","");
INSERT INTO product VALUES("6","1","1","Coupler","","","","","0","0.00","0.00","0","0","0","0","0","0","0","0","11.jpg","0","","a:0:{}","0","","0","","0","1","1","0","","","9","9","18","0000-00-00 00:00:00","1","0","","","2017-12-28 13:15:27","");
INSERT INTO product VALUES("7","1","1","End Cap","","","","","0","0.00","0.00","0","0","0","0","0","0","0","0","18.jpg","0","","a:0:{}","0","","0","","0","1","1","0","","","9","9","18","0000-00-00 00:00:00","1","0","","","2017-12-28 13:18:39","");
INSERT INTO product VALUES("8","1","1","Reducer Bush","","","","","0","0.00","0.00","0","0","0","0","0","0","0","0","17.jpg","0","","a:0:{}","0","","0","","0","1","1","0","","","9","9","18","0000-00-00 00:00:00","1","0","","","2017-12-28 13:25:43","");
INSERT INTO product VALUES("9","1","1","Reducer Sleev","","","","","0","0.00","0.00","0","0","0","0","0","0","0","0","12.jpg","0","","a:0:{}","0","","0","","0","1","1","0","","","9","9","18","0000-00-00 00:00:00","1","0","","","2017-12-28 13:40:57","");
INSERT INTO product VALUES("10","2","1","Elbow","","","","","0","0.00","0.00","0","0","0","0","0","0","0","0","16.jpg","0","","a:0:{}","0","","0","","0","1","1","0","","","9","9","18","0000-00-00 00:00:00","1","0","1,1,1","0,0,0","2017-12-28 13:48:00","2017-12-28 13:53:24,2017-12-28 19:05:01,2017-12-28 19:06:17");
INSERT INTO product VALUES("11","2","1","Tee","","","","","0","0.00","0.00","0","0","0","0","0","0","0","0","14.jpg","0","","a:0:{}","0","","0","","0","1","1","0","","","9","9","18","0000-00-00 00:00:00","1","0","1","0","2017-12-28 19:03:18","2017-12-28 19:07:17");
INSERT INTO product VALUES("12","2","1","Male Adapter","","","","","0","0.00","0.00","0","0","0","0","0","0","0","0","13.jpg","0","","a:0:{}","0","","0","","0","1","1","0","","","9","9","18","0000-00-00 00:00:00","1","0","","","2017-12-28 19:11:17","");
INSERT INTO product VALUES("13","2","1","Female Adapter","","","","","0","0.00","0.00","0","0","0","0","0","0","0","0","15.jpg","0","","a:0:{}","0","","0","","0","1","1","0","","","9","9","18","0000-00-00 00:00:00","1","0","","","2017-12-28 19:14:48","");
INSERT INTO product VALUES("14","2","1","Ball Valve","","","","","0","0.00","0.00","0","0","0","0","0","0","0","0","5.jpg","0","","a:0:{}","0","","0","","0","1","1","0","","","9","9","18","0000-00-00 00:00:00","1","0","","","2017-12-29 11:27:38","");
INSERT INTO product VALUES("15","2","1","Tank Nipple","","","","","0","0.00","0.00","0","0","0","0","0","0","0","0","6.jpg","0","","a:0:{}","0","","0","","0","1","1","0","","","9","9","18","0000-00-00 00:00:00","1","0","","","2017-12-29 11:29:59","");
INSERT INTO product VALUES("16","2","1","Union","","","","","0","0.00","0.00","0","0","0","0","0","0","0","0","7.jpg","0","","a:0:{}","0","","0","","0","1","1","0","","","9","9","18","0000-00-00 00:00:00","1","0","","","2017-12-29 11:32:09","");
INSERT INTO product VALUES("17","2","1","Tee Radius","","","","","0","0.00","0.00","0","0","0","0","0","0","0","0","1.jpg","0","","a:0:{}","0","","0","","0","1","1","0","","","9","9","18","0000-00-00 00:00:00","1","0","","","2017-12-29 11:36:38","");
INSERT INTO product VALUES("18","3","1","Pipes (3 MTRS)","","","","","0","0.00","0.00","0","0","0","0","0","0","0","0","23.jpg","0","","a:0:{}","0","","0","","0","1","1","0","","","9","9","18","0000-00-00 00:00:00","1","0","","","2017-12-29 11:43:13","");
INSERT INTO product VALUES("19","4","1","Pipes (3 MTRS)","","","","","0","0.00","0.00","0","0","0","0","0","0","0","0","23.jpg","0","","a:0:{}","0","","0","","0","1","1","0","","","9","9","18","0000-00-00 00:00:00","1","0","","","2017-12-29 11:47:21","");
INSERT INTO product VALUES("20","5","1","Tube","","","","","0","0.00","0.00","0","0","0","0","0","0","0","0","20.jpg","0","","a:0:{}","0","","0","","0","1","1","0","","","9","9","18","0000-00-00 00:00:00","1","0","1","0","2017-12-29 11:48:40","2017-12-29 11:50:29");
INSERT INTO product VALUES("21","5","1","Tin","","","","","0","0.00","0.00","0","0","0","0","0","0","0","0","20.jpg","0","","a:0:{}","0","","0","","0","1","1","0","","","9","9","18","0000-00-00 00:00:00","1","0","1,1","0,0","2017-12-29 12:45:10","2018-01-01 14:20:05,2018-01-01 14:24:29");





CREATE TABLE `product_weight_price` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL DEFAULT '0',
  `weight_id` int(11) NOT NULL DEFAULT '0',
  `inner_size` varchar(150) NOT NULL,
  `outer_size` varchar(150) NOT NULL,
  `price` double NOT NULL DEFAULT '0',
  `stock_qty` int(50) NOT NULL DEFAULT '0',
  `opening_stock_qty` int(50) NOT NULL DEFAULT '0',
  `min_qty` int(50) NOT NULL DEFAULT '0',
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `local` int(11) NOT NULL DEFAULT '0',
  `zonal` int(11) NOT NULL DEFAULT '0',
  `national` int(11) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=154 DEFAULT CHARSET=latin1;

INSERT INTO product_weight_price VALUES("1","1","1","50","","9","8544","10000","10","0","0","0","0","1","0","1,1,1,1,1,1,1,1,1,1,1,1,1,1","0,0,0,0,0,0,0,0,0,0,0,0,0,0","2017-12-28 11:19:10","2017-12-28 15:46:53,2017-12-28 15:47:44,2018-01-01 16:45:35,2018-01-05 18:14:49,2018-01-09 15:44:41,2018-01-13 15:53:26,2018-01-13 15:57:27,2018-01-13 15:59:07,2018-01-13 16:07:29,2018-01-13 16:08:30,2018-01-16 17:01:51,2018-02-07 12:46:00,2018-02-07 12:52:58,2018-02-07 13:05:30");
INSERT INTO product_weight_price VALUES("2","1","2","50","","12.7","9150","10000","10","0","0","0","0","1","0","1,1,1","0,0,0","2017-12-28 11:19:10","2018-01-01 16:45:35,2018-01-05 18:14:49,2018-01-16 17:01:51");
INSERT INTO product_weight_price VALUES("3","1","3","50","","27.5","8750","10000","10","0","0","0","0","1","0","1","0","2017-12-28 11:19:10","2018-01-05 18:14:49");
INSERT INTO product_weight_price VALUES("4","1","4","25","","48.7","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 11:19:10","");
INSERT INTO product_weight_price VALUES("5","1","5","25","","80","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 11:19:10","");
INSERT INTO product_weight_price VALUES("6","1","6","50","","34","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 11:19:10","");
INSERT INTO product_weight_price VALUES("7","2","1","50","","11","9950","10000","10","0","0","0","0","1","0","1,1","0,0","2017-12-28 11:23:55","2018-01-13 16:21:34,2018-01-13 16:21:59");
INSERT INTO product_weight_price VALUES("8","2","2","50","","20","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 11:23:55","");
INSERT INTO product_weight_price VALUES("9","2","3","50","","38.6","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 11:23:55","");
INSERT INTO product_weight_price VALUES("10","2","4","25","","70.5","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 11:23:55","");
INSERT INTO product_weight_price VALUES("11","2","5","25","","110","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 11:23:55","");
INSERT INTO product_weight_price VALUES("12","3","1","50","","8.25","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 11:31:30","");
INSERT INTO product_weight_price VALUES("13","3","2","50","","13.5","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 11:31:30","");
INSERT INTO product_weight_price VALUES("14","3","3","50","","22.3","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 11:31:30","");
INSERT INTO product_weight_price VALUES("15","3","4","25","","39","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 11:31:30","");
INSERT INTO product_weight_price VALUES("16","3","5","25","","60","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 11:31:30","");
INSERT INTO product_weight_price VALUES("17","3","7","50","","16","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 11:31:30","");
INSERT INTO product_weight_price VALUES("30","5","2","50","","17.6","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 13:10:20","");
INSERT INTO product_weight_price VALUES("31","5","3","50","","32.1","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 13:10:20","");
INSERT INTO product_weight_price VALUES("50","4","1","50","","10.75","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 13:11:50","");
INSERT INTO product_weight_price VALUES("51","4","2","50","","17.25","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 13:11:50","");
INSERT INTO product_weight_price VALUES("52","4","3","50","","29","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 13:11:50","");
INSERT INTO product_weight_price VALUES("53","4","4","25","","63.75","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 13:11:50","");
INSERT INTO product_weight_price VALUES("54","4","5","25","","75","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 13:11:50","");
INSERT INTO product_weight_price VALUES("55","4","7","50","","16.5","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 13:11:50","");
INSERT INTO product_weight_price VALUES("56","6","1","50","","7.4","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 13:15:27","");
INSERT INTO product_weight_price VALUES("57","6","2","50","","10.5","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 13:15:27","");
INSERT INTO product_weight_price VALUES("58","6","3","50","","18.5","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 13:15:27","");
INSERT INTO product_weight_price VALUES("59","6","4","25","","34","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 13:15:27","");
INSERT INTO product_weight_price VALUES("60","6","5","25","","59.1","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 13:15:27","");
INSERT INTO product_weight_price VALUES("61","7","1","50","","5.75","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 13:18:39","");
INSERT INTO product_weight_price VALUES("62","7","2","50","","9","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 13:18:39","");
INSERT INTO product_weight_price VALUES("63","7","3","50","","15.5","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 13:18:39","");
INSERT INTO product_weight_price VALUES("64","7","4","25","","26.5","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 13:18:39","");
INSERT INTO product_weight_price VALUES("65","7","5","25","","47.1","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 13:18:39","");
INSERT INTO product_weight_price VALUES("66","8","6","50","","12.5","0","0","0","0","0","0","0","1","0","","","2017-12-28 13:25:43","");
INSERT INTO product_weight_price VALUES("67","8","8","50","","22.5","0","0","0","0","0","0","0","1","0","","","2017-12-28 13:25:43","");
INSERT INTO product_weight_price VALUES("68","8","9","25","","40","0","0","0","0","0","0","0","1","0","","","2017-12-28 13:25:43","");
INSERT INTO product_weight_price VALUES("69","8","10","25","","28.75","0","0","0","0","0","0","0","1","0","","","2017-12-28 13:25:43","");
INSERT INTO product_weight_price VALUES("70","9","6","50","","18.5","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 13:40:57","");
INSERT INTO product_weight_price VALUES("71","9","8","25","","45.1","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 13:40:57","");
INSERT INTO product_weight_price VALUES("72","9","9","25","","57.5","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 13:40:57","");
INSERT INTO product_weight_price VALUES("73","9","10","25","","65","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 13:40:57","");
INSERT INTO product_weight_price VALUES("74","9","11","25","","42.8","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 13:40:57","");
INSERT INTO product_weight_price VALUES("96","10","1","25","","42","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 19:06:17","");
INSERT INTO product_weight_price VALUES("97","10","2","25","","73.25","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 19:06:17","");
INSERT INTO product_weight_price VALUES("98","10","3","25","","160","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 19:06:17","");
INSERT INTO product_weight_price VALUES("99","10","6","25","","95","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 19:06:17","");
INSERT INTO product_weight_price VALUES("100","10","7","25","","45","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 19:06:17","");
INSERT INTO product_weight_price VALUES("101","10","12","25","","71.5","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 19:06:17","");
INSERT INTO product_weight_price VALUES("102","11","1","25","","47.5","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 19:07:17","");
INSERT INTO product_weight_price VALUES("103","11","2","25","","70","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 19:07:17","");
INSERT INTO product_weight_price VALUES("104","11","3","25","","170","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 19:07:17","");
INSERT INTO product_weight_price VALUES("105","11","7","25","","56","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 19:07:17","");
INSERT INTO product_weight_price VALUES("106","11","12","25","","86","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 19:07:17","");
INSERT INTO product_weight_price VALUES("107","12","1","25","","53","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 19:11:17","");
INSERT INTO product_weight_price VALUES("108","12","2","25","","98","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 19:11:17","");
INSERT INTO product_weight_price VALUES("109","12","3","25","","150","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 19:11:17","");
INSERT INTO product_weight_price VALUES("110","12","7","25","","63","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 19:11:17","");
INSERT INTO product_weight_price VALUES("111","12","12","25","","82.3","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 19:11:17","");
INSERT INTO product_weight_price VALUES("112","13","1","25","","40.75","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 19:14:48","");
INSERT INTO product_weight_price VALUES("113","13","2","25","","81","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 19:14:48","");
INSERT INTO product_weight_price VALUES("114","13","3","25","","120","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 19:14:48","");
INSERT INTO product_weight_price VALUES("115","13","7","25","","45","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 19:14:48","");
INSERT INTO product_weight_price VALUES("116","13","12","25","","62","10000","10000","10","0","0","0","0","1","0","","","2017-12-28 19:14:48","");
INSERT INTO product_weight_price VALUES("117","14","2","1","","150","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:27:38","");
INSERT INTO product_weight_price VALUES("118","14","3","1","","199","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:27:38","");
INSERT INTO product_weight_price VALUES("119","14","4","1","","418.9","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:27:38","");
INSERT INTO product_weight_price VALUES("120","14","5","1","","661.5","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:27:38","");
INSERT INTO product_weight_price VALUES("121","14","13","1","","919.6","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:27:38","");
INSERT INTO product_weight_price VALUES("122","15","2","50","","53.5","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:29:59","");
INSERT INTO product_weight_price VALUES("123","15","3","25","","74","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:29:59","");
INSERT INTO product_weight_price VALUES("124","15","4","25","","115","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:29:59","");
INSERT INTO product_weight_price VALUES("125","15","5","25","","150","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:29:59","");
INSERT INTO product_weight_price VALUES("126","16","2","50","","65","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:32:09","");
INSERT INTO product_weight_price VALUES("127","16","3","50","","89.75","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:32:09","");
INSERT INTO product_weight_price VALUES("128","16","4","25","","147.75","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:32:09","");
INSERT INTO product_weight_price VALUES("129","16","5","25","","188","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:32:09","");
INSERT INTO product_weight_price VALUES("130","17","6","50","","36","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:36:38","");
INSERT INTO product_weight_price VALUES("131","17","8","25","","80","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:36:38","");
INSERT INTO product_weight_price VALUES("132","17","9","25","","125","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:36:38","");
INSERT INTO product_weight_price VALUES("133","17","10","25","","122.5","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:36:38","");
INSERT INTO product_weight_price VALUES("134","17","11","25","","85","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:36:38","");
INSERT INTO product_weight_price VALUES("135","18","1","75","","40.1","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:43:13","");
INSERT INTO product_weight_price VALUES("136","18","2","50","","69.35","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:43:13","");
INSERT INTO product_weight_price VALUES("137","18","3","30","","109.5","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:43:13","");
INSERT INTO product_weight_price VALUES("138","18","4","25","","164.45","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:43:13","");
INSERT INTO product_weight_price VALUES("139","18","5","15","","246.7","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:43:13","");
INSERT INTO product_weight_price VALUES("140","18","13","10","","372.2","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:43:13","");
INSERT INTO product_weight_price VALUES("141","19","1","75","","46.67","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:47:21","");
INSERT INTO product_weight_price VALUES("142","19","2","50","","79.6","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:47:21","");
INSERT INTO product_weight_price VALUES("143","19","3","30","","130","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:47:21","");
INSERT INTO product_weight_price VALUES("144","19","4","25","","188","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:47:21","");
INSERT INTO product_weight_price VALUES("145","19","5","15","","269.3","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:47:21","");
INSERT INTO product_weight_price VALUES("146","19","13","10","","436.3","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:47:21","");
INSERT INTO product_weight_price VALUES("147","20","14","50","","45","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:50:29","");
INSERT INTO product_weight_price VALUES("148","20","15","100","","75","10000","10000","10","0","0","0","0","1","0","","","2017-12-29 11:50:29","");
INSERT INTO product_weight_price VALUES("149","21","16","50","","85","10000","10000","10","0","0","0","0","1","0","","","2018-01-01 14:24:29","");
INSERT INTO product_weight_price VALUES("150","21","17","24","","155","10000","10000","10","0","0","0","0","1","0","","","2018-01-01 14:24:29","");
INSERT INTO product_weight_price VALUES("151","21","18","16","","300","10000","10000","10","0","0","0","0","1","0","","","2018-01-01 14:24:29","");
INSERT INTO product_weight_price VALUES("152","21","19","12","","550","10000","10000","10","0","0","0","0","1","0","","","2018-01-01 14:24:29","");
INSERT INTO product_weight_price VALUES("153","21","20","6","","1025","10000","10000","10","0","0","0","0","1","0","","","2018-01-01 14:24:29","");





CREATE TABLE `production_process` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `process_name` varchar(50) DEFAULT NULL,
  `description` text,
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






CREATE TABLE `proforma_invoice_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(150) NOT NULL,
  `request_id` int(11) NOT NULL DEFAULT '0',
  `customer_id` int(11) NOT NULL DEFAULT '0',
  `customer_name` varchar(150) NOT NULL,
  `company_name` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(150) NOT NULL,
  `country` varchar(150) NOT NULL,
  `state` varchar(150) NOT NULL,
  `city` varchar(150) NOT NULL,
  `total_qty` double NOT NULL DEFAULT '0',
  `item_totalprice` double NOT NULL,
  `discount` double NOT NULL DEFAULT '0',
  `taxable` double NOT NULL DEFAULT '0',
  `cash_discount` double NOT NULL,
  `cash_discount_amount` double NOT NULL,
  `subtotal` double NOT NULL DEFAULT '0',
  `cgst_tax_amount` double NOT NULL DEFAULT '0',
  `sgst_tax_amount` double NOT NULL DEFAULT '0',
  `igst_tax_amount` double NOT NULL DEFAULT '0',
  `grand_total` double NOT NULL DEFAULT '0',
  `remarks` text NOT NULL,
  `roundoff` double NOT NULL DEFAULT '0',
  `grand_total_rounded` double NOT NULL,
  `isActive` int(11) NOT NULL DEFAULT '1',
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `created_date` datetime NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '0=Pending 1=Accepted,2=Rejected',
  `modified_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_date` datetime NOT NULL,
  `invoice_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO proforma_invoice_info VALUES("1","K/U/IN/001","1","3","jay","Prashant","jay@gmail.com","Rajkot","9824518363","India","Gujarat","Rajkot","550","6060","0","6060","0","0","6060","545.4","545.4","0","7150.8","Against Order Request#1","0.19999999999982","7151","1","0","2018-01-16 15:55:10","1","0","0","1","0","0000-00-00 00:00:00","2018-01-16 00:00:00");
INSERT INTO proforma_invoice_info VALUES("2","K/U/IN/002","3","4","hardip","h","h@gmail.com","fg","9979055113","India","Gujarat","ydy","250","2250","0","2250","0","0","2250","202.5","202.5","0","2655","Against Order Request#3","0","2655","1","0","2018-02-07 12:45:01","1","0","0","1","0","0000-00-00 00:00:00","2018-02-07 00:00:00");





CREATE TABLE `proforma_invoice_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proforma_invoice_id` int(11) NOT NULL DEFAULT '0',
  `request_id` int(11) NOT NULL DEFAULT '0',
  `item_id` int(11) NOT NULL DEFAULT '0',
  `weight_id` int(11) NOT NULL DEFAULT '0',
  `customer_order_item_id` int(11) NOT NULL DEFAULT '0',
  `item_name` varchar(150) NOT NULL,
  `item_code` varchar(150) NOT NULL,
  `item_qty` double NOT NULL DEFAULT '0',
  `box_qty` double NOT NULL,
  `inner_size` double NOT NULL,
  `item_price` double NOT NULL DEFAULT '0',
  `item_totalprice` double NOT NULL,
  `discount` double NOT NULL DEFAULT '0',
  `discount_amount` double NOT NULL DEFAULT '0',
  `taxable` double NOT NULL DEFAULT '0',
  `cash_discount` double NOT NULL,
  `cash_discount_amount` double NOT NULL,
  `subtotal` double NOT NULL DEFAULT '0',
  `cgst_tax` double NOT NULL DEFAULT '0',
  `cgst_tax_amount` double NOT NULL DEFAULT '0',
  `sgst_tax` double NOT NULL DEFAULT '0',
  `sgst_tax_amount` double NOT NULL DEFAULT '0',
  `igst_tax` double NOT NULL DEFAULT '0',
  `igst_tax_amount` double NOT NULL DEFAULT '0',
  `grandtotal` double NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `created_date` datetime NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `modified_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO proforma_invoice_item VALUES("1","1","1","1","1","1","Elbow (1/2\\\")","","250","5","50","9","2250","0","0","2250","0","0","2250","9","202.5","9","202.5","0","0","2655","1","0","2018-01-16 15:55:10","1","0","0","0","0000-00-00 00:00:00");
INSERT INTO proforma_invoice_item VALUES("2","1","1","1","2","2","Elbow (3/4\\\")","","300","6","50","12.7","3810","0","0","3810","0","0","3810","9","342.9","9","342.9","0","0","4495.8","1","0","2018-01-16 15:55:10","1","0","0","0","0000-00-00 00:00:00");
INSERT INTO proforma_invoice_item VALUES("3","2","3","1","1","4","Elbow (1/2\\\")","","250","5","50","9","2250","0","0","2250","0","0","2250","9","202.5","9","202.5","0","0","2655","1","0","2018-02-07 12:45:01","1","0","0","0","0000-00-00 00:00:00");





CREATE TABLE `promotion` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250) NOT NULL,
  `url` varchar(250) NOT NULL,
  `target` varchar(20) NOT NULL DEFAULT '_SELF',
  `image_path` varchar(250) NOT NULL,
  `display_order` int(10) unsigned NOT NULL,
  `promo_type` tinyint(1) NOT NULL COMMENT '0=slideshow, 1=banner',
  `adate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `isDelete` tinyint(1) NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` int(11) NOT NULL DEFAULT '1',
  `modified_by_type` int(11) NOT NULL DEFAULT '0',
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO promotion VALUES("1","","","","1514523091_766327bn.jpg","1","1","0000-00-00 00:00:00","0","1","0","0","0","2017-12-28 15:36:09","0000-00-00 00:00:00");
INSERT INTO promotion VALUES("2","","","","1514522968_2064830bn.jpg","2","1","0000-00-00 00:00:00","0","1","0","0","0","2017-12-28 15:38:02","0000-00-00 00:00:00");
INSERT INTO promotion VALUES("3","","","","1514523156_2181187bn.jpg","3","1","0000-00-00 00:00:00","0","1","0","0","0","2017-12-28 15:38:30","0000-00-00 00:00:00");
INSERT INTO promotion VALUES("4","","","","1514523221_7127834bn.jpg","4","1","0000-00-00 00:00:00","0","1","0","0","0","2017-12-28 15:39:00","0000-00-00 00:00:00");
INSERT INTO promotion VALUES("5","","","","1514523281_9060891bn.jpg","5","1","0000-00-00 00:00:00","0","1","0","0","0","2017-12-28 15:39:46","0000-00-00 00:00:00");
INSERT INTO promotion VALUES("6","","","","1514523426_3006900bn.jpg","6","1","0000-00-00 00:00:00","0","1","0","0","0","2017-12-28 15:39:58","0000-00-00 00:00:00");





CREATE TABLE `refresh_token` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `refresh_token` text NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `imei` text NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` int(11) NOT NULL DEFAULT '1',
  `modified_by_type` int(11) NOT NULL DEFAULT '0',
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO refresh_token VALUES("1","c_EvJoIVZC0:APA91bEdnjgJ_WgHBNcKy3M81pskS8QPzgPgX0FP-WH5uYKGx1al9-xRvK6mVtuRCRSdvDCe9xu7RwMDnQZw3BodW7Osd5fUitUeKdBYhY5ux7yBTkAiMW95bPmtKQWkuV1RnzJI5lcf","3","866462030739861","5895","712","0","0","2017-12-28 12:39:48","0000-00-00 00:00:00");
INSERT INTO refresh_token VALUES("2","dWVxE7SVIFQ:APA91bEhSoFK3-n_WCuyCl9p-D6ijs9PS1XXBkK49HX-B8npq5TqOs-NhN-oEz7aIzZH_Lq5lPCYEWs8GTI3YuSZinvFfU0mLy_f7HhoKVlIbnsVKFE8QttU0Y3zmV36dEYrm_8jmQVc","4","352929080782455","5895","712","0","0","2017-12-28 12:50:24","0000-00-00 00:00:00");
INSERT INTO refresh_token VALUES("3","cieXLhQXUXM:APA91bHBjDih9o78RKwkpG_d4CsKM-VkVo7bHZooikLmUYlXZKvFQS5aZBx62LZVB_4Od2W1YtNPh9_Ur85PDI3iZ-WtkJ_FhdmziEsYyzNGr0uYD2NAUmi3OoWdQZ0_CAp7GxhV3TNb","2","","1","0","0","0","2018-01-13 15:20:06","0000-00-00 00:00:00");





CREATE TABLE `sales_executive` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` text,
  `phone` varchar(25) DEFAULT NULL,
  `address` text,
  `zip` varchar(20) DEFAULT NULL,
  `country` varchar(150) NOT NULL DEFAULT '0',
  `state` varchar(150) NOT NULL DEFAULT '0',
  `city` varchar(150) NOT NULL DEFAULT '0',
  `imei` varchar(250) DEFAULT NULL,
  `type` varchar(200) DEFAULT NULL,
  `refreshToken` text,
  `regDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `otp` varchar(25) DEFAULT NULL,
  `isVerify` int(11) NOT NULL DEFAULT '0',
  `isDelete` tinyint(1) NOT NULL DEFAULT '0',
  `last_ip` varchar(250) DEFAULT NULL,
  `last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `sm_id` int(11) NOT NULL DEFAULT '0',
  `asm_id` int(11) NOT NULL DEFAULT '0',
  `so_id` int(11) NOT NULL DEFAULT '0',
  `se_id` int(11) NOT NULL DEFAULT '0',
  `executive_in_min` varchar(150) NOT NULL,
  `executive_in_max` varchar(150) NOT NULL,
  `executive_out` varchar(150) NOT NULL,
  `super_stokist_order_insert_flag` int(11) NOT NULL,
  `super_stokist_order_update_flag` int(11) NOT NULL,
  `dealer_order_insert_flag` int(11) NOT NULL,
  `dealer_order_update_flag` int(11) NOT NULL,
  `outlets_order_insert_flag` int(11) NOT NULL,
  `outlets_order_update_flag` int(11) NOT NULL,
  `customer_insert_flag` int(11) NOT NULL,
  `customer_update_flag` int(11) NOT NULL,
  `inquiry_insert_flag` int(11) NOT NULL,
  `inquiry_update_flag` int(11) NOT NULL,
  `inquiry_delete_flag` int(11) NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`),
  KEY `isActive` (`isDelete`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO sales_executive VALUES("1","1","Tejas","tejas@gmail.com","tejas","21232f297a57a5a743894a0e4a801fc3","8000280311","","","India","Gujarat","Rajkot","352929080782455","sales_manager","dPhCSFPGSAo:APA91bHboWcoIreERZ5W7iY8LiH2zdopJC9sf5u-goxXGJZuRxG3zQ2oV4hDvtrsZfP3LcH2T07ZnEt_aj4Q5O75fb-N7eV2Y1UgyR9ZpYsBty_KHOq_TyQVkNFM6afPOgGRBSq84FWw","2017-12-28 13:32:59","","0","0","","0000-00-00 00:00:00","0","0","0","0","09:00","23:00","23:30","1","1","1","1","1","1","1","1","1","1","1","1","1","0","5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,5895,1,1,5895,5895,1,5895,5895,5895,5895,5895,1,5895,5895","458,458,458,458,458,458,458,458,458,458,458,458,458,458,458,458,458,458,0,0,458,458,0,458,458,458,458,458,0,458,458","2017-12-28 13:32:59","2017-12-28 13:33:12,2017-12-28 14:38:04,2017-12-28 14:42:06,2017-12-28 15:06:07,2017-12-28 15:08:44,2017-12-28 15:10:13,2017-12-28 18:06:47,2017-12-30 14:53:09,2018-01-01 16:51:50,2018-01-01 17:04:10,2018-01-01 17:16:10,2018-01-09 15:29:58,2018-01-12 10:58:34,2018-01-12 15:04:21,2018-01-12 15:43:17,2018-01-12 16:23:08,2018-01-18 15:35:52,2018-01-19 16:30:21,2018-02-07 12:51:02,2018-02-07 12:51:23,2018-02-07 12:51:36,2018-12-07 19:19:57,2018-12-08 10:11:41,2018-12-08 11:03:34,2018-12-08 12:33:43,2018-12-08 12:33:46,2018-12-08 12:33:54,2018-12-08 12:33:58,2018-12-08 12:34:17,2018-12-08 12:35:01,2018-12-08 12:35:54");
INSERT INTO sales_executive VALUES("2","1","Ravi","ravipatel.cb@gmail.com","ravi","e10adc3949ba59abbe56e057f20f883e","9978078494","","","","","","","area_sales_manager","","2018-01-12 16:21:07","","0","0","","0000-00-00 00:00:00","1","0","0","0","09:00","23:59","23:59","1","1","1","1","1","1","1","1","1","1","1","1","1","0","5895,1","458,0","2018-01-12 16:21:07","2018-01-12 16:21:22,2018-12-08 10:11:47");
INSERT INTO sales_executive VALUES("3","1","Kamal","ravi@gmail.com","kamal","e10adc3949ba59abbe56e057f20f883e","9978078495","","","","","","","sales_officer","","2018-01-12 16:25:02","","0","0","","0000-00-00 00:00:00","1","2","0","0","08:00","23:00","23:00","1","1","1","1","1","1","1","1","1","1","1","1","1","0","1","0","2018-01-12 16:25:02","2018-12-08 10:11:54");
INSERT INTO sales_executive VALUES("4","1","hardip","hardip@gmail.com","hardip","464a66f0f3b77ecfecfb54a018b27516","8866110548","","","India","Gujarat","Rajkot","868922033316262","sales_executive","doJ8v8U01XE:APA91bHSBPuDY0Ay4OZXgEn5utLw_CMjtPgBqBAKQTgXC6JlSZL8cAxLyCevaCFz5-ZpcXMalV4GTNGRfuKKLyG7iIfqWQ6ga0_gQ5a4XSSRenIPJWoXmBqKiFWsHanjrWFmJvHLlyEA","2018-12-08 10:13:12","","0","0","","0000-00-00 00:00:00","1","2","3","0","00:00","12:00","23:00","0","0","0","0","0","0","1","1","1","1","0","1","1","0","5895,1,5895","458,0,458","2018-12-08 10:13:12","2018-12-08 10:13:45,2018-12-08 10:14:36,2018-12-08 10:14:45");





CREATE TABLE `sales_executive_map_area` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL DEFAULT '0',
  `area_id` int(11) NOT NULL DEFAULT '0',
  `sales_executive_id` int(11) NOT NULL DEFAULT '0',
  `executive_type` varchar(100) DEFAULT NULL,
  `type_slug` varchar(100) DEFAULT NULL,
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO sales_executive_map_area VALUES("6","1","3","1","sales_manager","SalesManager","0","0","1","0","","","2018-12-08 10:11:41","");
INSERT INTO sales_executive_map_area VALUES("7","1","3","2","area_sales_manager","AreaSalesManager","0","0","1","0","","","2018-12-08 10:11:48","");
INSERT INTO sales_executive_map_area VALUES("8","1","3","3","sales_officer","SalesOfficer","0","0","1","0","","","2018-12-08 10:11:54","");
INSERT INTO sales_executive_map_area VALUES("10","1","3","4","sales_executive","SalesExecutive","0","0","1","0","","","2018-12-08 10:14:36","");





CREATE TABLE `sales_executive_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO sales_executive_type VALUES("1","Sales Manager","0","1","1","0","1","0","0000-00-00 00:00:00","2017-04-19 14:51:18");
INSERT INTO sales_executive_type VALUES("2","Area Sales Manager","0","1","1","0","1","0","0000-00-00 00:00:00","2017-04-19 14:51:11");
INSERT INTO sales_executive_type VALUES("3","Sales Officer","0","1","1","0","1","0","0000-00-00 00:00:00","2017-04-19 14:50:53");
INSERT INTO sales_executive_type VALUES("4","Sales Excecutive","0","1","1","0","1","0","0000-00-00 00:00:00","2017-04-19 14:50:42");
INSERT INTO sales_executive_type VALUES("6","dfgdfdfgdfg","1","1","1","0","1,1","0,0","2017-04-19 14:50:05","2017-04-19 14:50:11,2017-04-19 14:50:15");
INSERT INTO sales_executive_type VALUES("7","sa","1","1","1","0","1,1","0,0","2017-08-17 14:16:06","2017-08-17 14:16:11,2017-08-17 14:16:13");
INSERT INTO sales_executive_type VALUES("8","aaaaa","1","1","1","0","1,1","0,0","2017-08-17 15:17:26","2017-08-17 15:17:33,2017-08-17 15:18:03");
INSERT INTO sales_executive_type VALUES("9","Test","1","1","1","0","1","0","2017-10-12 11:57:08","2017-10-12 11:58:48");





CREATE TABLE `salesexecutive_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(150) NOT NULL DEFAULT 'tracking',
  `sales_executive_id` int(11) NOT NULL DEFAULT '0',
  `longitude` varchar(150) DEFAULT NULL,
  `latitude` varchar(150) DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=480 DEFAULT CHARSET=latin1;

INSERT INTO salesexecutive_tracking VALUES("1","login","1","70.7697274","22.2795732","2017-12-28 14:38:04","0","0","5895","712","","","2017-12-28 14:38:39","");
INSERT INTO salesexecutive_tracking VALUES("2","attandance","1","70.7697278","22.279576","2017-12-28 14:38:37","0","0","5895","712","","","2017-12-28 14:38:39","");
INSERT INTO salesexecutive_tracking VALUES("3","logout","1","70.7697286","22.2795773","2017-12-28 14:41:55","0","0","5895","712","","","2017-12-28 14:41:55","");
INSERT INTO salesexecutive_tracking VALUES("4","login","1","70.7697285","22.2795772","2017-12-28 14:42:06","0","0","5895","712","","","2017-12-28 14:42:26","");
INSERT INTO salesexecutive_tracking VALUES("5","attandance","1","70.7697285","22.2795772","2017-12-28 14:42:25","0","0","5895","712","","","2017-12-28 14:42:26","");
INSERT INTO salesexecutive_tracking VALUES("6","login","1","70.7697193","22.2795747","2017-12-28 15:05:25","0","0","5895","712","","","2017-12-28 15:06:27","");
INSERT INTO salesexecutive_tracking VALUES("7","attandance","1","70.7697113","22.2795692","2017-12-28 15:05:44","0","0","5895","712","","","2017-12-28 15:06:27","");
INSERT INTO salesexecutive_tracking VALUES("8","logout","1","70.7697327","22.2795679","2017-12-28 15:08:30","0","0","5895","712","","","2017-12-28 15:08:31","");
INSERT INTO salesexecutive_tracking VALUES("9","tracking","1","70.7697195","22.2795756","2017-12-28 15:05:51","0","0","5895","712","","","2017-12-28 15:08:49","");
INSERT INTO salesexecutive_tracking VALUES("10","add_expance","1","70.7697195","22.2795756","2017-12-28 15:06:11","0","0","5895","712","","","2017-12-28 15:08:49","");
INSERT INTO salesexecutive_tracking VALUES("11","logout","1","70.769719","22.2795804","2017-12-28 15:08:06","0","0","5895","712","","","2017-12-28 15:08:49","");
INSERT INTO salesexecutive_tracking VALUES("12","login","1","70.7697333","22.2795725","2017-12-28 15:08:44","0","0","5895","712","","","2017-12-28 15:09:01","");
INSERT INTO salesexecutive_tracking VALUES("13","attandance","1","70.7697333","22.2795725","2017-12-28 15:09:00","0","0","5895","712","","","2017-12-28 15:09:01","");
INSERT INTO salesexecutive_tracking VALUES("14","add_expance","1","70.7697297","22.2795661","2017-12-28 15:09:26","0","0","5895","712","","","2017-12-28 15:09:34","");
INSERT INTO salesexecutive_tracking VALUES("15","sync","1","70.7697297","22.2795661","2017-12-28 15:09:33","0","0","5895","712","","","2017-12-28 15:09:34","");
INSERT INTO salesexecutive_tracking VALUES("16","login","1","70.7697193","22.2795764","2017-12-28 15:09:43","0","0","5895","712","","","2017-12-28 15:40:26","");
INSERT INTO salesexecutive_tracking VALUES("17","attandance","1","70.7697189","22.2795529","2017-12-28 15:39:43","0","0","5895","712","","","2017-12-28 15:40:26","");
INSERT INTO salesexecutive_tracking VALUES("18","add_expance","1","70.7697191","22.2795761","2017-12-28 15:40:00","0","0","5895","712","","","2017-12-28 15:47:30","");
INSERT INTO salesexecutive_tracking VALUES("19","add_expance","1","70.7697318","22.2795731","2017-12-28 15:45:10","0","0","5895","712","","","2017-12-28 15:47:30","");
INSERT INTO salesexecutive_tracking VALUES("20","create_order","1","70.7697255","22.2795688","2017-12-28 15:46:46","0","0","5895","712","","","2017-12-28 15:47:30","");
INSERT INTO salesexecutive_tracking VALUES("21","sync","1","70.7697221","22.2795641","2017-12-28 15:46:47","0","0","5895","712","","","2017-12-28 15:47:30","");
INSERT INTO salesexecutive_tracking VALUES("22","tracking","1","70.7697194","22.2795759","2017-12-28 15:54:58","0","0","5895","712","","","2017-12-28 16:40:40","");
INSERT INTO salesexecutive_tracking VALUES("23","tracking","1","70.76994529925287","22.279579541645944","2017-12-28 16:06:10","0","0","5895","712","","","2017-12-28 16:40:40","");
INSERT INTO salesexecutive_tracking VALUES("24","tracking","1","70.76993633061647","22.27951940149069","2017-12-28 16:21:12","0","0","5895","712","","","2017-12-28 16:40:40","");
INSERT INTO salesexecutive_tracking VALUES("25","tracking","1","70.76969778165221","22.27956369984895","2017-12-28 16:36:16","0","0","5895","712","","","2017-12-28 16:40:40","");
INSERT INTO salesexecutive_tracking VALUES("26","sync_hour","1","70.7697191","22.2795774","2017-12-28 16:39:57","0","0","5895","712","","","2017-12-28 16:40:40","");
INSERT INTO salesexecutive_tracking VALUES("27","tracking","1","70.77080578543246","22.27947983890772","2017-12-28 16:51:20","0","0","5895","712","","","2017-12-28 17:40:40","");
INSERT INTO salesexecutive_tracking VALUES("28","tracking","1","70.77025718986988","22.2795619815588","2017-12-28 17:06:18","0","0","5895","712","","","2017-12-28 17:40:40","");
INSERT INTO salesexecutive_tracking VALUES("29","tracking","1","70.77057897113264","22.27909728884697","2017-12-28 17:21:20","0","0","5895","712","","","2017-12-28 17:40:40","");
INSERT INTO salesexecutive_tracking VALUES("30","tracking","1","70.7697205","22.2795812","2017-12-28 17:36:31","0","0","5895","712","","","2017-12-28 17:40:40","");
INSERT INTO salesexecutive_tracking VALUES("31","sync_hour","1","70.7697318","22.2795731","2017-12-28 17:39:57","0","0","5895","712","","","2017-12-28 17:40:40","");
INSERT INTO salesexecutive_tracking VALUES("32","login","1","70.8039187","22.2130697","2017-12-28 18:06:48","0","0","5895","712","","","2017-12-28 18:07:28","");
INSERT INTO salesexecutive_tracking VALUES("33","attandance","1","70.8039187","22.2130697","2017-12-28 18:07:27","0","0","5895","712","","","2017-12-28 18:07:28","");
INSERT INTO salesexecutive_tracking VALUES("34","tracking","1","70.8039187","22.2130697","2017-12-28 18:07:35","0","0","5895","712","","","2017-12-28 18:08:47","");
INSERT INTO salesexecutive_tracking VALUES("35","create_order","1","70.8039187","22.2130697","2017-12-28 18:08:45","0","0","5895","712","","","2017-12-28 18:08:47","");
INSERT INTO salesexecutive_tracking VALUES("36","sync","1","70.8039187","22.2130697","2017-12-28 18:08:46","0","0","5895","712","","","2017-12-28 18:08:47","");
INSERT INTO salesexecutive_tracking VALUES("37","logout","1","70.8039187","22.2130697","2017-12-28 18:09:50","0","0","5895","712","","","2017-12-28 18:09:52","");
INSERT INTO salesexecutive_tracking VALUES("38","tracking","1","70.769719","22.2795752","2017-12-28 17:51:33","0","0","5895","712","","","2017-12-28 18:40:45","");
INSERT INTO salesexecutive_tracking VALUES("39","tracking","1","70.7695048302412","22.279253737069666","2017-12-28 18:06:06","0","0","5895","712","","","2017-12-28 18:40:45","");
INSERT INTO salesexecutive_tracking VALUES("40","tracking","1","70.76953617855906","22.27928030770272","2017-12-28 18:06:33","0","0","5895","712","","","2017-12-28 18:40:45","");
INSERT INTO salesexecutive_tracking VALUES("41","tracking","1","70.76974748633802","22.279475354589522","2017-12-28 18:21:34","0","0","5895","712","","","2017-12-28 18:40:45","");
INSERT INTO salesexecutive_tracking VALUES("42","tracking","1","70.76965880580246","22.27922842372209","2017-12-28 18:36:36","0","0","5895","712","","","2017-12-28 18:40:45","");
INSERT INTO salesexecutive_tracking VALUES("43","sync_hour","1","70.7697203","22.2795781","2017-12-28 18:40:00","0","0","5895","712","","","2017-12-28 18:40:45","");
INSERT INTO salesexecutive_tracking VALUES("44","login","1","70.7696498","22.279588","2017-12-30 14:53:09","0","0","5895","712","","","2017-12-30 14:53:27","");
INSERT INTO salesexecutive_tracking VALUES("45","attandance","1","70.7696498","22.279588","2017-12-30 14:53:26","0","0","5895","712","","","2017-12-30 14:53:27","");
INSERT INTO salesexecutive_tracking VALUES("46","attandance","1","70.8039201","22.2130698","2018-01-01 16:25:34","0","0","5895","712","","","2018-01-01 16:25:36","");
INSERT INTO salesexecutive_tracking VALUES("47","logout","1","70.8039201","22.2130698","2018-01-01 16:25:40","0","0","5895","712","","","2018-01-01 16:25:41","");
INSERT INTO salesexecutive_tracking VALUES("48","tracking","1","70.8039201","22.2130698","2018-01-01 16:25:41","0","0","5895","712","","","2018-01-01 16:52:36","");
INSERT INTO salesexecutive_tracking VALUES("49","login","1","70.8039201","22.2130698","2018-01-01 16:51:49","0","0","5895","712","","","2018-01-01 16:52:36","");
INSERT INTO salesexecutive_tracking VALUES("50","attandance","1","70.8039201","22.2130698","2018-01-01 16:52:34","0","0","5895","712","","","2018-01-01 16:52:36","");
INSERT INTO salesexecutive_tracking VALUES("51","tracking","1","70.8039201","22.2130698","2018-01-01 16:52:46","0","0","5895","712","","","2018-01-01 16:56:42","");
INSERT INTO salesexecutive_tracking VALUES("52","create_order","1","70.8039201","22.2130698","2018-01-01 16:56:32","0","0","5895","712","","","2018-01-01 16:56:42","");
INSERT INTO salesexecutive_tracking VALUES("53","sync","1","70.8039201","22.2130698","2018-01-01 16:56:40","0","0","5895","712","","","2018-01-01 16:56:42","");
INSERT INTO salesexecutive_tracking VALUES("54","add_expance","1","70.8039201","22.2130698","2018-01-01 17:01:09","0","0","5895","712","","","2018-01-01 17:03:57","");
INSERT INTO salesexecutive_tracking VALUES("55","logout","1","70.8039201","22.2130698","2018-01-01 17:03:55","0","0","5895","712","","","2018-01-01 17:03:57","");
INSERT INTO salesexecutive_tracking VALUES("56","login","1","70.8039201","22.2130698","2018-01-01 17:04:10","0","0","5895","712","","","2018-01-01 17:04:27","");
INSERT INTO salesexecutive_tracking VALUES("57","attandance","1","70.8039201","22.2130698","2018-01-01 17:04:25","0","0","5895","712","","","2018-01-01 17:04:27","");
INSERT INTO salesexecutive_tracking VALUES("58","tracking","1","70.8039201","22.2130698","2018-01-01 17:04:27","0","0","5895","712","","","2018-01-01 17:06:15","");
INSERT INTO salesexecutive_tracking VALUES("59","add_inquiry","1","70.8039201","22.2130698","2018-01-01 17:06:09","0","0","5895","712","","","2018-01-01 17:06:15","");
INSERT INTO salesexecutive_tracking VALUES("60","sync","1","70.8039201","22.2130698","2018-01-01 17:06:15","0","0","5895","712","","","2018-01-01 17:06:15","");
INSERT INTO salesexecutive_tracking VALUES("61","logout","1","70.8039201","22.2130698","2018-01-01 17:06:52","0","0","5895","712","","","2018-01-01 17:06:53","");
INSERT INTO salesexecutive_tracking VALUES("62","login","1","70.8039201","22.2130698","2018-01-01 17:16:11","0","0","5895","712","","","2018-01-01 17:16:27","");
INSERT INTO salesexecutive_tracking VALUES("63","attandance","1","70.8039201","22.2130698","2018-01-01 17:16:26","0","0","5895","712","","","2018-01-01 17:16:27","");
INSERT INTO salesexecutive_tracking VALUES("64","tracking","1","70.8039201","22.2130698","2018-01-01 17:16:28","0","0","5895","712","","","2018-01-05 18:32:32","");
INSERT INTO salesexecutive_tracking VALUES("65","attandance","1","70.7845769","22.1631587","2018-01-05 18:32:31","0","0","5895","712","","","2018-01-05 18:32:32","");
INSERT INTO salesexecutive_tracking VALUES("66","tracking","1","70.7845769","22.1631587","2018-01-05 18:32:32","0","0","5895","712","","","2018-01-05 18:32:32","");
INSERT INTO salesexecutive_tracking VALUES("67","create_order","1","70.7845769","22.1631587","2018-01-05 18:33:59","0","0","5895","712","","","2018-01-05 18:34:06","");
INSERT INTO salesexecutive_tracking VALUES("68","sync","1","70.7845769","22.1631587","2018-01-05 18:34:06","0","0","5895","712","","","2018-01-05 18:34:06","");
INSERT INTO salesexecutive_tracking VALUES("69","tracking","1","70.78442742","22.16313865","2018-01-05 19:18:03","0","0","5895","712","","","2018-01-09 10:23:54","");
INSERT INTO salesexecutive_tracking VALUES("70","attandance","1","70.7694974","22.2791394","2018-01-09 10:23:53","0","0","5895","712","","","2018-01-09 10:23:54","");
INSERT INTO salesexecutive_tracking VALUES("71","create_order","1","70.7724144","22.2821274","2018-01-09 10:27:59","0","0","5895","712","","","2018-01-09 10:28:20","");
INSERT INTO salesexecutive_tracking VALUES("72","sync","1","70.7724144","22.2821274","2018-01-09 10:28:20","0","0","5895","712","","","2018-01-09 10:28:20","");
INSERT INTO salesexecutive_tracking VALUES("73","create_order","1","70.7694974","22.2791394","2018-01-09 10:31:30","0","0","5895","712","","","2018-01-09 10:31:32","");
INSERT INTO salesexecutive_tracking VALUES("74","sync","1","70.7694974","22.2791394","2018-01-09 10:31:31","0","0","5895","712","","","2018-01-09 10:31:32","");
INSERT INTO salesexecutive_tracking VALUES("75","tracking","1","70.76977068","22.27956558","2018-01-09 10:38:57","0","0","5895","712","","","2018-01-09 10:40:36","");
INSERT INTO salesexecutive_tracking VALUES("76","create_order","1","70.7969464","22.2964045","2018-01-09 10:40:34","0","0","5895","712","","","2018-01-09 10:40:36","");
INSERT INTO salesexecutive_tracking VALUES("77","sync","1","70.7624842","22.301589","2018-01-09 10:40:36","0","0","5895","712","","","2018-01-09 10:40:36","");
INSERT INTO salesexecutive_tracking VALUES("78","add_inquiry","1","70.7724144","22.2821274","2018-01-09 13:49:33","0","0","5895","712","","","2018-01-09 13:49:42","");
INSERT INTO salesexecutive_tracking VALUES("79","sync","1","70.7675827","22.2793913","2018-01-09 13:49:42","0","0","5895","712","","","2018-01-09 13:49:42","");
INSERT INTO salesexecutive_tracking VALUES("80","logout","1","70.7696512","22.2795848","2018-01-09 15:29:45","0","0","5895","712","","","2018-01-09 15:29:46","");
INSERT INTO salesexecutive_tracking VALUES("81","login","1","70.7696512","22.2795848","2018-01-09 15:29:59","0","0","5895","712","","","2018-01-09 15:30:22","");
INSERT INTO salesexecutive_tracking VALUES("82","attandance","1","70.7696558","22.2795862","2018-01-09 15:30:21","0","0","5895","712","","","2018-01-09 15:30:22","");
INSERT INTO salesexecutive_tracking VALUES("83","tracking","1","70.76960297","22.2795138","2018-01-09 15:30:28","0","0","5895","712","","","2018-01-09 15:33:21","");
INSERT INTO salesexecutive_tracking VALUES("84","create_order","1","70.7696515","22.2795851","2018-01-09 15:33:14","0","0","5895","712","","","2018-01-09 15:33:21","");
INSERT INTO salesexecutive_tracking VALUES("85","sync","1","70.7696515","22.2795851","2018-01-09 15:33:21","0","0","5895","712","","","2018-01-09 15:33:21","");
INSERT INTO salesexecutive_tracking VALUES("86","logout","1","70.7696498","22.2795847","2018-01-09 16:19:30","0","0","5895","712","","","2018-01-09 16:19:31","");
INSERT INTO salesexecutive_tracking VALUES("87","login","1","70.7696806","22.27958","2018-01-12 10:58:35","0","0","5895","712","","","2018-01-12 10:58:52","");
INSERT INTO salesexecutive_tracking VALUES("88","attandance","1","70.7696806","22.27958","2018-01-12 10:58:51","0","0","5895","712","","","2018-01-12 10:58:52","");
INSERT INTO salesexecutive_tracking VALUES("89","logout","1","70.769677","22.279579","2018-01-12 14:06:52","0","0","5895","712","","","2018-01-12 14:06:53","");
INSERT INTO salesexecutive_tracking VALUES("90","login","1","70.7696775","22.2795741","2018-01-12 15:04:22","0","0","5895","712","","","2018-01-12 15:05:15","");
INSERT INTO salesexecutive_tracking VALUES("91","attandance","1","70.7696631","22.2795813","2018-01-12 15:05:13","0","0","5895","712","","","2018-01-12 15:05:15","");
INSERT INTO salesexecutive_tracking VALUES("92","logout","1","70.7696858","22.2795802","2018-01-12 15:07:16","0","0","5895","712","","","2018-01-12 15:07:17","");
INSERT INTO salesexecutive_tracking VALUES("93","login","1","70.7696872","22.2795913","2018-01-12 15:43:16","0","0","5895","712","","","2018-01-12 15:44:44","");
INSERT INTO salesexecutive_tracking VALUES("94","attandance","1","70.7696674","22.2795692","2018-01-12 15:44:43","0","0","5895","712","","","2018-01-12 15:44:44","");
INSERT INTO salesexecutive_tracking VALUES("95","tracking","1","70.7696674","22.2795692","2018-01-12 15:44:48","0","0","5895","712","","","2018-01-12 16:18:46","");
INSERT INTO salesexecutive_tracking VALUES("96","tracking","1","70.7696574","22.2795853","2018-01-12 16:00:09","0","0","5895","712","","","2018-01-12 16:18:46","");
INSERT INTO salesexecutive_tracking VALUES("97","create_order","1","70.7696574","22.2795853","2018-01-12 16:00:28","0","0","5895","712","","","2018-01-12 16:18:46","");
INSERT INTO salesexecutive_tracking VALUES("98","tracking","1","70.7696632","22.279589","2018-01-12 16:15:18","0","0","5895","712","","","2018-01-12 16:18:46","");
INSERT INTO salesexecutive_tracking VALUES("99","logout","1","70.7696572","22.2795885","2018-01-12 16:18:46","0","0","5895","712","","","2018-01-12 16:18:46","");
INSERT INTO salesexecutive_tracking VALUES("100","login","2","70.7696618","22.279588","2018-01-12 16:21:22","0","0","5895","712","","","2018-01-12 16:21:42","");
INSERT INTO salesexecutive_tracking VALUES("101","attandance","2","70.7696618","22.279588","2018-01-12 16:21:40","0","0","5895","712","","","2018-01-12 16:21:42","");
INSERT INTO salesexecutive_tracking VALUES("102","tracking","2","70.7696619","22.2795885","2018-01-12 16:21:41","0","0","5895","712","","","2018-01-12 16:21:42","");
INSERT INTO salesexecutive_tracking VALUES("103","create_order","2","70.7696619","22.2795885","2018-01-12 16:22:16","0","0","5895","712","","","2018-01-12 16:22:18","");
INSERT INTO salesexecutive_tracking VALUES("104","sync","2","70.7696571","22.2795903","2018-01-12 16:22:18","0","0","5895","712","","","2018-01-12 16:22:18","");
INSERT INTO salesexecutive_tracking VALUES("105","logout","2","70.7696559","22.2795899","2018-01-12 16:22:46","0","0","5895","712","","","2018-01-12 16:22:48","");
INSERT INTO salesexecutive_tracking VALUES("106","login","1","70.7696548","22.2795868","2018-01-12 16:23:08","0","0","5895","712","","","2018-01-12 16:23:27","");
INSERT INTO salesexecutive_tracking VALUES("107","attandance","1","70.7696548","22.2795868","2018-01-12 16:23:26","0","0","5895","712","","","2018-01-12 16:23:27","");
INSERT INTO salesexecutive_tracking VALUES("108","tracking","1","70.7696552","22.2795868","2018-01-12 16:23:27","0","0","5895","712","","","2018-01-12 16:23:27","");
INSERT INTO salesexecutive_tracking VALUES("109","login","1","70.7696518","22.2796007","2018-01-18 15:35:33","0","0","5895","712","","","2018-01-18 15:36:07","");
INSERT INTO salesexecutive_tracking VALUES("110","attandance","1","70.7696545","22.279607","2018-01-18 15:35:47","0","0","5895","712","","","2018-01-18 15:36:07","");
INSERT INTO salesexecutive_tracking VALUES("111","tracking","1","70.7696484","22.2796005","2018-01-18 15:35:56","0","0","5895","712","","","2018-01-18 16:36:07","");
INSERT INTO salesexecutive_tracking VALUES("112","tracking","1","70.7696484","22.2796005","2018-01-18 15:51:10","0","0","5895","712","","","2018-01-18 16:36:07","");
INSERT INTO salesexecutive_tracking VALUES("113","tracking","1","70.7696484","22.2796005","2018-01-18 16:06:21","0","0","5895","712","","","2018-01-18 16:36:07","");
INSERT INTO salesexecutive_tracking VALUES("114","tracking","1","70.7696484","22.2796005","2018-01-18 16:10:34","0","0","5895","712","","","2018-01-18 16:36:07","");
INSERT INTO salesexecutive_tracking VALUES("115","tracking","1","70.7696484","22.2796005","2018-01-18 16:25:56","0","0","5895","712","","","2018-01-18 16:36:07","");
INSERT INTO salesexecutive_tracking VALUES("116","sync_hour","1","70.7696484","22.2796005","2018-01-18 16:35:47","0","0","5895","712","","","2018-01-18 16:36:07","");
INSERT INTO salesexecutive_tracking VALUES("117","login","1","70.769653","22.2795585","2018-01-19 16:30:02","0","0","5895","712","","","2018-01-19 16:30:33","");
INSERT INTO salesexecutive_tracking VALUES("118","attandance","1","70.769653","22.2795585","2018-01-19 16:30:13","0","0","5895","712","","","2018-01-19 16:30:33","");
INSERT INTO salesexecutive_tracking VALUES("119","tracking","1","70.769526","22.2794792","2018-01-19 16:44:18","0","0","5895","712","","","2018-01-19 17:30:32","");
INSERT INTO salesexecutive_tracking VALUES("120","tracking","1","70.76977615244687","22.27949257940054","2018-01-19 16:59:32","0","0","5895","712","","","2018-01-19 17:30:32","");
INSERT INTO salesexecutive_tracking VALUES("121","tracking","1","70.7696527","22.2795613","2018-01-19 17:14:24","0","0","5895","712","","","2018-01-19 17:30:32","");
INSERT INTO salesexecutive_tracking VALUES("122","tracking","1","70.769651","22.2795696","2018-01-19 17:29:33","0","0","5895","712","","","2018-01-19 17:30:32","");
INSERT INTO salesexecutive_tracking VALUES("123","sync_hour","1","70.7696547","22.2795749","2018-01-19 17:30:13","0","0","5895","712","","","2018-01-19 17:30:32","");
INSERT INTO salesexecutive_tracking VALUES("124","tracking","1","70.769188","22.2791228","2018-01-19 17:44:45","0","0","5895","712","","","2018-01-19 18:30:32","");
INSERT INTO salesexecutive_tracking VALUES("125","tracking","1","70.7698523439467","22.27958452887833","2018-01-19 17:59:47","0","0","5895","712","","","2018-01-19 18:30:32","");
INSERT INTO salesexecutive_tracking VALUES("126","tracking","1","70.7696559","22.2795805","2018-01-19 18:15:18","0","0","5895","712","","","2018-01-19 18:30:32","");
INSERT INTO salesexecutive_tracking VALUES("127","tracking","1","70.7696527","22.2795613","2018-01-19 18:26:10","0","0","5895","712","","","2018-01-19 18:30:32","");
INSERT INTO salesexecutive_tracking VALUES("128","sync_hour","1","70.7696527","22.2795613","2018-01-19 18:30:13","0","0","5895","712","","","2018-01-19 18:30:33","");
INSERT INTO salesexecutive_tracking VALUES("129","tracking","1","70.7696511","22.2795515","2018-01-19 18:41:22","0","0","5895","712","","","2018-01-20 09:48:22","");
INSERT INTO salesexecutive_tracking VALUES("130","tracking","1","70.7696488","22.279572","2018-01-19 18:56:35","0","0","5895","712","","","2018-01-20 09:48:22","");
INSERT INTO salesexecutive_tracking VALUES("131","tracking","1","70.7697823","22.279249","2018-01-19 18:57:01","0","0","5895","712","","","2018-01-20 09:48:22","");
INSERT INTO salesexecutive_tracking VALUES("132","tracking","1","70.77002869918942","22.2796819685027","2018-01-19 19:12:04","0","0","5895","712","","","2018-01-20 09:48:22","");
INSERT INTO salesexecutive_tracking VALUES("133","tracking","1","70.76979358680546","22.27960627991706","2018-01-19 19:23:35","0","0","5895","712","","","2018-01-20 09:48:22","");
INSERT INTO salesexecutive_tracking VALUES("134","tracking","1","70.7727861","22.2821729","2018-01-20 11:43:00","0","0","5895","712","","","2018-01-20 11:49:36","");
INSERT INTO salesexecutive_tracking VALUES("135","sync_hour","1","70.7696823","22.2795465","2018-01-20 11:49:16","0","0","5895","712","","","2018-01-20 11:49:36","");
INSERT INTO salesexecutive_tracking VALUES("136","tracking","1","70.76958973892033","22.27921220473945","2018-01-20 11:57:43","0","0","5895","712","","","2018-01-20 12:49:52","");
INSERT INTO salesexecutive_tracking VALUES("137","tracking","1","70.7696599","22.2796082","2018-01-20 12:11:10","0","0","5895","712","","","2018-01-20 12:49:52","");
INSERT INTO salesexecutive_tracking VALUES("138","tracking","1","70.7696283","22.2797394","2018-01-20 12:26:15","0","0","5895","712","","","2018-01-20 12:49:52","");
INSERT INTO salesexecutive_tracking VALUES("139","tracking","1","70.7696488","22.2796459","2018-01-20 12:41:27","0","0","5895","712","","","2018-01-20 12:49:52","");
INSERT INTO salesexecutive_tracking VALUES("140","tracking","1","70.7696055","22.2797735","2018-01-20 12:42:09","0","0","5895","712","","","2018-01-20 12:49:52","");
INSERT INTO salesexecutive_tracking VALUES("141","sync_hour","1","70.7696337","22.2796003","2018-01-20 12:49:31","0","0","5895","712","","","2018-01-20 12:49:52","");
INSERT INTO salesexecutive_tracking VALUES("142","tracking","1","70.7696527","22.2795613","2018-01-20 12:57:17","0","0","5895","712","","","2018-01-20 14:53:21","");
INSERT INTO salesexecutive_tracking VALUES("143","tracking","1","70.7696611","22.2795662","2018-01-20 13:12:11","0","0","5895","712","","","2018-01-20 14:53:22","");
INSERT INTO salesexecutive_tracking VALUES("144","tracking","1","70.7728398218751","22.27889080066234","2018-01-20 13:26:54","0","0","5895","712","","","2018-01-20 14:53:22","");
INSERT INTO salesexecutive_tracking VALUES("145","tracking","1","70.78516633249819","22.28019716218114","2018-01-20 13:57:07","0","0","5895","712","","","2018-01-20 14:53:22","");
INSERT INTO salesexecutive_tracking VALUES("146","tracking","1","70.7696556","22.2795683","2018-01-20 14:05:38","0","0","5895","712","","","2018-01-20 14:53:22","");
INSERT INTO salesexecutive_tracking VALUES("147","tracking","1","70.7695989","22.2798029","2018-01-20 14:20:34","0","0","5895","712","","","2018-01-20 14:53:22","");
INSERT INTO salesexecutive_tracking VALUES("148","tracking","1","70.7696527","22.2795613","2018-01-20 14:35:41","0","0","5895","712","","","2018-01-20 14:53:22","");
INSERT INTO salesexecutive_tracking VALUES("149","tracking","1","70.7695764","22.2798944","2018-01-20 14:50:52","0","0","5895","712","","","2018-01-20 14:53:22","");
INSERT INTO salesexecutive_tracking VALUES("150","sync_hour","1","70.7696133","22.2797747","2018-01-20 14:53:02","0","0","5895","712","","","2018-01-20 14:53:22","");
INSERT INTO salesexecutive_tracking VALUES("151","tracking","1","70.7696527","22.2795613","2018-01-20 15:06:12","0","0","5895","712","","","2018-01-20 15:53:20","");
INSERT INTO salesexecutive_tracking VALUES("152","tracking","1","70.7696527","22.2795613","2018-01-20 15:17:20","0","0","5895","712","","","2018-01-20 15:53:21","");
INSERT INTO salesexecutive_tracking VALUES("153","tracking","1","70.76984253711998","22.27951655164361","2018-01-20 15:32:03","0","0","5895","712","","","2018-01-20 15:53:21","");
INSERT INTO salesexecutive_tracking VALUES("154","tracking","1","70.76980607584119","22.279469277709723","2018-01-20 15:47:04","0","0","5895","712","","","2018-01-20 15:53:21","");
INSERT INTO salesexecutive_tracking VALUES("155","tracking","1","70.7696002","22.2798074","2018-01-20 15:47:21","0","0","5895","712","","","2018-01-20 15:53:21","");
INSERT INTO salesexecutive_tracking VALUES("156","sync_hour","1","70.7695992","22.2798425","2018-01-20 15:53:02","0","0","5895","712","","","2018-01-20 15:53:21","");
INSERT INTO salesexecutive_tracking VALUES("157","tracking","1","70.77029490843415","22.27917700074613","2018-01-20 16:02:14","0","0","5895","712","","","2018-01-20 16:53:39","");
INSERT INTO salesexecutive_tracking VALUES("158","tracking","1","70.77093260362744","22.27942598517984","2018-01-20 16:17:15","0","0","5895","712","","","2018-01-20 16:53:39","");
INSERT INTO salesexecutive_tracking VALUES("159","tracking","1","70.7696527","22.2795613","2018-01-20 16:17:40","0","0","5895","712","","","2018-01-20 16:53:39","");
INSERT INTO salesexecutive_tracking VALUES("160","tracking","1","70.7696527","22.2795613","2018-01-20 16:32:51","0","0","5895","712","","","2018-01-20 16:53:39","");
INSERT INTO salesexecutive_tracking VALUES("161","tracking","1","70.7696861","22.2794759","2018-01-20 16:48:02","0","0","5895","712","","","2018-01-20 16:53:39","");
INSERT INTO salesexecutive_tracking VALUES("162","sync_hour","1","70.7696384","22.2795985","2018-01-20 16:53:20","0","0","5895","712","","","2018-01-20 16:53:39","");
INSERT INTO salesexecutive_tracking VALUES("163","login","1","70.7696476","22.2796067","2018-02-07 12:51:37","0","0","5895","712","","","2018-02-07 12:51:46","");
INSERT INTO salesexecutive_tracking VALUES("164","attandance","1","70.7696523","22.2796141","2018-02-07 12:51:46","0","0","5895","712","","","2018-02-07 12:51:46","");
INSERT INTO salesexecutive_tracking VALUES("165","tracking","1","70.7696525","22.2796142","2018-02-07 12:51:56","0","0","5895","712","","","2018-02-07 12:52:16","");
INSERT INTO salesexecutive_tracking VALUES("166","create_order","1","70.7696525","22.2796142","2018-02-07 12:52:14","0","0","5895","712","","","2018-02-07 12:52:16","");
INSERT INTO salesexecutive_tracking VALUES("167","sync","1","70.7696476","22.2796067","2018-02-07 12:52:16","0","0","5895","712","","","2018-02-07 12:52:16","");
INSERT INTO salesexecutive_tracking VALUES("168","tracking","1","70.7698495","22.2796788","2018-02-07 13:05:54","0","0","5895","712","","","2018-02-07 14:52:38","");
INSERT INTO salesexecutive_tracking VALUES("169","login","1","70.7698386","22.2794089","2018-12-07 19:19:57","0","0","5895","712","","","2018-12-07 19:20:19","");
INSERT INTO salesexecutive_tracking VALUES("170","attandance","1","70.7698386","22.2794089","2018-12-07 19:20:18","0","0","5895","712","","","2018-12-07 19:20:19","");
INSERT INTO salesexecutive_tracking VALUES("171","sync","1","70.7696861","22.2795682","2018-12-07 19:23:41","0","0","5895","712","","","2018-12-07 19:23:41","");
INSERT INTO salesexecutive_tracking VALUES("172","sync","1","70.7696861","22.2795682","2018-12-07 19:30:59","0","0","5895","712","","","2018-12-08 10:01:39","");
INSERT INTO salesexecutive_tracking VALUES("173","sync","1","70.7696809","22.2795557","2018-12-07 19:31:46","0","0","5895","712","","","2018-12-08 10:01:39","");
INSERT INTO salesexecutive_tracking VALUES("174","tracking","1","70.7696861","22.2795682","2018-12-07 19:35:46","0","0","5895","712","","","2018-12-08 10:01:40","");
INSERT INTO salesexecutive_tracking VALUES("175","tracking","1","70.79839046","22.29639362","2018-12-07 20:01:27","0","0","5895","712","","","2018-12-08 10:01:40","");
INSERT INTO salesexecutive_tracking VALUES("176","tracking","1","70.75681944","22.28287967","2018-12-07 20:20:55","0","0","5895","712","","","2018-12-08 10:01:40","");
INSERT INTO salesexecutive_tracking VALUES("177","attandance","1","70.7696861","22.2795682","2018-12-08 10:01:26","0","0","5895","712","","","2018-12-08 10:01:40","");
INSERT INTO salesexecutive_tracking VALUES("178","tracking","1","70.7696861","22.2795682","2018-12-08 10:01:26","0","0","5895","712","","","2018-12-08 10:01:40","");
INSERT INTO salesexecutive_tracking VALUES("179","attandance","1","70.7696861","22.2795682","2018-12-08 10:01:38","0","0","5895","712","","","2018-12-08 10:01:40","");
INSERT INTO salesexecutive_tracking VALUES("180","logout","1","70.7696861","22.2795682","2018-12-08 10:13:36","0","0","5895","712","","","2018-12-08 10:13:36","");
INSERT INTO salesexecutive_tracking VALUES("181","login","4","70.7696861","22.2795682","2018-12-08 10:13:46","0","0","5895","712","","","2018-12-08 10:14:38","");
INSERT INTO salesexecutive_tracking VALUES("182","logout","4","70.7696971","22.2795645","2018-12-08 10:14:38","0","0","5895","712","","","2018-12-08 10:14:38","");
INSERT INTO salesexecutive_tracking VALUES("183","login","4","70.7696971","22.2795645","2018-12-08 10:14:46","0","0","5895","712","","","2018-12-08 10:14:51","");
INSERT INTO salesexecutive_tracking VALUES("184","attandance","4","70.7696816","22.2795416","2018-12-08 10:14:51","0","0","5895","712","","","2018-12-08 10:14:51","");
INSERT INTO salesexecutive_tracking VALUES("185","tracking","4","70.76974579","22.2795515","2018-12-08 10:14:55","0","0","5895","712","","","2018-12-08 10:16:43","");
INSERT INTO salesexecutive_tracking VALUES("186","tracking","4","70.76973559","22.27955469","2018-12-08 10:16:35","0","0","5895","712","","","2018-12-08 10:16:43","");
INSERT INTO salesexecutive_tracking VALUES("187","add_customer","4","70.7696861","22.2795682","2018-12-08 10:16:37","0","0","5895","712","","","2018-12-08 10:16:43","");
INSERT INTO salesexecutive_tracking VALUES("188","sync","4","70.7696861","22.2795682","2018-12-08 10:16:43","0","0","5895","712","","","2018-12-08 10:16:44","");
INSERT INTO salesexecutive_tracking VALUES("189","add_inquiry","4","70.7696861","22.2795682","2018-12-08 10:17:39","0","0","5895","712","","","2018-12-08 10:17:47","");
INSERT INTO salesexecutive_tracking VALUES("190","sync","4","70.7696861","22.2795682","2018-12-08 10:17:47","0","0","5895","712","","","2018-12-08 10:17:47","");
INSERT INTO salesexecutive_tracking VALUES("191","add_expance","4","70.7696861","22.2795682","2018-12-08 10:19:15","0","0","5895","712","","","2018-12-08 10:19:24","");
INSERT INTO salesexecutive_tracking VALUES("192","sync","4","70.7696861","22.2795682","2018-12-08 10:19:24","0","0","5895","712","","","2018-12-08 10:19:24","");
INSERT INTO salesexecutive_tracking VALUES("193","login","1","70.7694411","22.2803337","2018-12-08 11:04:05","0","0","5895","712","","","2018-12-08 11:03:57","");
INSERT INTO salesexecutive_tracking VALUES("194","login","1","70.7694411","22.2803337","2018-12-08 11:04:06","0","0","5895","712","","","2018-12-08 11:03:57","");
INSERT INTO salesexecutive_tracking VALUES("195","attandance","1","70.7696861","22.2795682","2018-12-08 11:04:26","0","0","5895","712","","","2018-12-08 11:03:57","");
INSERT INTO salesexecutive_tracking VALUES("196","add_expance","4","70.7696861","22.2795682","2018-12-08 10:22:06","0","0","5895","712","","","2018-12-08 11:04:41","");
INSERT INTO salesexecutive_tracking VALUES("197","tracking","4","70.76972101","22.27955932","2018-12-08 10:29:56","0","0","5895","712","","","2018-12-08 11:04:41","");
INSERT INTO salesexecutive_tracking VALUES("198","tracking","4","70.76972015","22.27956019","2018-12-08 10:31:36","0","0","5895","712","","","2018-12-08 11:04:41","");
INSERT INTO salesexecutive_tracking VALUES("199","sync","4","70.7742727","22.2834272","2018-12-08 11:04:41","0","0","5895","712","","","2018-12-08 11:04:41","");
INSERT INTO salesexecutive_tracking VALUES("200","sync_hour","4","70.7696861","22.2795682","2018-12-08 11:15:39","0","0","5895","712","","","2018-12-08 11:15:38","");
INSERT INTO salesexecutive_tracking VALUES("201","tracking","1","70.77019331976771","22.279343507252634","2018-12-08 11:04:28","0","0","5895","712","","","2018-12-08 11:34:23","");
INSERT INTO salesexecutive_tracking VALUES("202","tracking","1","70.7696829","22.2795697","2018-12-08 11:32:20","0","0","5895","712","","","2018-12-08 11:34:23","");
INSERT INTO salesexecutive_tracking VALUES("203","sync","1","70.7696831","22.2795682","2018-12-08 11:34:52","0","0","5895","712","","","2018-12-08 11:34:23","");
INSERT INTO salesexecutive_tracking VALUES("204","Satya Sai hospital road, above Royal uniform, opp. Shilpan app, Gujarat, India","1","70.7696825","22.2795682","2018-12-08 11:56:45","0","0","5895","712","","","2018-12-08 12:33:01","");
INSERT INTO salesexecutive_tracking VALUES("205","sync_hour","1","70.7696819","22.279572","2018-12-08 12:05:04","0","0","5895","712","","","2018-12-08 12:33:01","");
INSERT INTO salesexecutive_tracking VALUES("206","sync_hour","1","70.7696819","22.279572","2018-12-08 12:05:04","0","0","5895","712","","","2018-12-08 12:33:01","");
INSERT INTO salesexecutive_tracking VALUES("207","sync_hour","1","70.7696819","22.279572","2018-12-08 12:05:04","0","0","5895","712","","","2018-12-08 12:33:01","");
INSERT INTO salesexecutive_tracking VALUES("208","sync_hour","1","70.7696819","22.279572","2018-12-08 12:05:04","0","0","5895","712","","","2018-12-08 12:33:01","");
INSERT INTO salesexecutive_tracking VALUES("209","sync_hour","1","70.7696819","22.279572","2018-12-08 12:05:04","0","0","5895","712","","","2018-12-08 12:33:01","");
INSERT INTO salesexecutive_tracking VALUES("210","sync_hour","1","70.7696819","22.279572","2018-12-08 12:05:04","0","0","5895","712","","","2018-12-08 12:33:01","");
INSERT INTO salesexecutive_tracking VALUES("211","sync_hour","1","70.7696819","22.279572","2018-12-08 12:05:05","0","0","5895","712","","","2018-12-08 12:33:01","");
INSERT INTO salesexecutive_tracking VALUES("212","sync_hour","1","70.7696819","22.279572","2018-12-08 12:05:05","0","0","5895","712","","","2018-12-08 12:33:01","");
INSERT INTO salesexecutive_tracking VALUES("213","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:05","0","0","5895","712","","","2018-12-08 12:33:02","");
INSERT INTO salesexecutive_tracking VALUES("214","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:05","0","0","5895","712","","","2018-12-08 12:33:02","");
INSERT INTO salesexecutive_tracking VALUES("215","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:05","0","0","5895","712","","","2018-12-08 12:33:02","");
INSERT INTO salesexecutive_tracking VALUES("216","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:06","0","0","5895","712","","","2018-12-08 12:33:02","");
INSERT INTO salesexecutive_tracking VALUES("217","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:07","0","0","5895","712","","","2018-12-08 12:33:02","");
INSERT INTO salesexecutive_tracking VALUES("218","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:08","0","0","5895","712","","","2018-12-08 12:33:02","");
INSERT INTO salesexecutive_tracking VALUES("219","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:09","0","0","5895","712","","","2018-12-08 12:33:02","");
INSERT INTO salesexecutive_tracking VALUES("220","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:10","0","0","5895","712","","","2018-12-08 12:33:02","");
INSERT INTO salesexecutive_tracking VALUES("221","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:11","0","0","5895","712","","","2018-12-08 12:33:02","");
INSERT INTO salesexecutive_tracking VALUES("222","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:12","0","0","5895","712","","","2018-12-08 12:33:02","");
INSERT INTO salesexecutive_tracking VALUES("223","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:13","0","0","5895","712","","","2018-12-08 12:33:02","");
INSERT INTO salesexecutive_tracking VALUES("224","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:14","0","0","5895","712","","","2018-12-08 12:33:02","");
INSERT INTO salesexecutive_tracking VALUES("225","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:15","0","0","5895","712","","","2018-12-08 12:33:02","");
INSERT INTO salesexecutive_tracking VALUES("226","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:16","0","0","5895","712","","","2018-12-08 12:33:02","");
INSERT INTO salesexecutive_tracking VALUES("227","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:17","0","0","5895","712","","","2018-12-08 12:33:02","");
INSERT INTO salesexecutive_tracking VALUES("228","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:18","0","0","5895","712","","","2018-12-08 12:33:02","");
INSERT INTO salesexecutive_tracking VALUES("229","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:19","0","0","5895","712","","","2018-12-08 12:33:02","");
INSERT INTO salesexecutive_tracking VALUES("230","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:20","0","0","5895","712","","","2018-12-08 12:33:02","");
INSERT INTO salesexecutive_tracking VALUES("231","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:21","0","0","5895","712","","","2018-12-08 12:33:02","");
INSERT INTO salesexecutive_tracking VALUES("232","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:24","0","0","5895","712","","","2018-12-08 12:33:02","");
INSERT INTO salesexecutive_tracking VALUES("233","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:25","0","0","5895","712","","","2018-12-08 12:33:02","");
INSERT INTO salesexecutive_tracking VALUES("234","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:27","0","0","5895","712","","","2018-12-08 12:33:02","");
INSERT INTO salesexecutive_tracking VALUES("235","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:29","0","0","5895","712","","","2018-12-08 12:33:02","");
INSERT INTO salesexecutive_tracking VALUES("236","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:29","0","0","5895","712","","","2018-12-08 12:33:02","");
INSERT INTO salesexecutive_tracking VALUES("237","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:29","0","0","5895","712","","","2018-12-08 12:33:02","");
INSERT INTO salesexecutive_tracking VALUES("238","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:30","0","0","5895","712","","","2018-12-08 12:33:02","");
INSERT INTO salesexecutive_tracking VALUES("239","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:30","0","0","5895","712","","","2018-12-08 12:33:02","");
INSERT INTO salesexecutive_tracking VALUES("240","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:31","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("241","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:32","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("242","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:33","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("243","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:34","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("244","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:35","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("245","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:36","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("246","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:36","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("247","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:37","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("248","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:38","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("249","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:38","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("250","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:38","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("251","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:39","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("252","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:39","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("253","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:40","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("254","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:41","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("255","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:41","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("256","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:41","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("257","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:42","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("258","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:43","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("259","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:44","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("260","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:45","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("261","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:46","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("262","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:47","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("263","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:47","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("264","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:48","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("265","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:49","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("266","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:50","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("267","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:50","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("268","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:51","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("269","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:52","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("270","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:52","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("271","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:53","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("272","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:54","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("273","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:55","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("274","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:57","0","0","5895","712","","","2018-12-08 12:33:03","");
INSERT INTO salesexecutive_tracking VALUES("275","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:58","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("276","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:58","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("277","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:05:59","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("278","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:00","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("279","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:00","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("280","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:01","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("281","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:02","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("282","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:03","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("283","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:03","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("284","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:03","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("285","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:04","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("286","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:04","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("287","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:05","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("288","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:06","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("289","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:07","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("290","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:08","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("291","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:09","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("292","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:10","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("293","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:11","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("294","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:12","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("295","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:13","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("296","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:14","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("297","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:15","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("298","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:16","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("299","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:17","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("300","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:18","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("301","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:19","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("302","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:20","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("303","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:21","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("304","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:22","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("305","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:23","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("306","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:24","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("307","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:25","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("308","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:26","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("309","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:26","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("310","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:27","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("311","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:28","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("312","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:29","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("313","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:29","0","0","5895","712","","","2018-12-08 12:33:04","");
INSERT INTO salesexecutive_tracking VALUES("314","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:30","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("315","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:31","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("316","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:32","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("317","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:33","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("318","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:34","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("319","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:35","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("320","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:36","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("321","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:37","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("322","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:37","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("323","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:37","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("324","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:38","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("325","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:38","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("326","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:39","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("327","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:40","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("328","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:41","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("329","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:41","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("330","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:42","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("331","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:42","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("332","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:43","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("333","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:43","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("334","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:44","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("335","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:44","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("336","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:44","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("337","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:45","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("338","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:45","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("339","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:46","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("340","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:47","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("341","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:47","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("342","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:48","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("343","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:49","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("344","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:50","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("345","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:51","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("346","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:52","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("347","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:53","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("348","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:53","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("349","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:53","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("350","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:54","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("351","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:55","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("352","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:56","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("353","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:57","0","0","5895","712","","","2018-12-08 12:33:05","");
INSERT INTO salesexecutive_tracking VALUES("354","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:58","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("355","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:06:59","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("356","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:00","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("357","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:01","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("358","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:02","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("359","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:03","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("360","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:04","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("361","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:05","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("362","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:06","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("363","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:08","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("364","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:09","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("365","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:10","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("366","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:11","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("367","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:12","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("368","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:13","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("369","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:14","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("370","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:15","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("371","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:16","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("372","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:17","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("373","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:17","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("374","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:18","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("375","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:18","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("376","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:19","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("377","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:20","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("378","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:21","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("379","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:22","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("380","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:23","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("381","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:24","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("382","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:25","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("383","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:26","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("384","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:27","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("385","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:28","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("386","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:29","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("387","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:30","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("388","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:31","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("389","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:32","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("390","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:33","0","0","5895","712","","","2018-12-08 12:33:06","");
INSERT INTO salesexecutive_tracking VALUES("391","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:35","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("392","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:36","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("393","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:37","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("394","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:38","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("395","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:39","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("396","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:39","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("397","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:39","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("398","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:40","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("399","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:41","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("400","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:42","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("401","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:43","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("402","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:44","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("403","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:45","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("404","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:46","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("405","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:47","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("406","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:48","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("407","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:49","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("408","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:50","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("409","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:51","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("410","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:52","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("411","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:53","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("412","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:53","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("413","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:53","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("414","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:53","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("415","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:54","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("416","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:55","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("417","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:56","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("418","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:57","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("419","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:58","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("420","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:07:59","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("421","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:00","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("422","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:01","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("423","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:02","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("424","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:03","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("425","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:04","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("426","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:05","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("427","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:05","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("428","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:05","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("429","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:06","0","0","5895","712","","","2018-12-08 12:33:07","");
INSERT INTO salesexecutive_tracking VALUES("430","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:07","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("431","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:08","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("432","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:09","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("433","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:10","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("434","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:11","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("435","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:12","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("436","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:13","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("437","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:14","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("438","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:15","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("439","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:16","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("440","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:17","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("441","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:18","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("442","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:19","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("443","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:20","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("444","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:21","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("445","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:22","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("446","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:23","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("447","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:24","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("448","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:25","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("449","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:26","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("450","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:27","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("451","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:28","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("452","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:29","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("453","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:30","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("454","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:31","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("455","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:32","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("456","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:33","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("457","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:34","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("458","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:35","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("459","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:36","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("460","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:37","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("461","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:38","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("462","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:39","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("463","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:40","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("464","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:41","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("465","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:42","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("466","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:43","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("467","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:44","0","0","5895","712","","","2018-12-08 12:33:08","");
INSERT INTO salesexecutive_tracking VALUES("468","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:45","0","0","5895","712","","","2018-12-08 12:33:09","");
INSERT INTO salesexecutive_tracking VALUES("469","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:46","0","0","5895","712","","","2018-12-08 12:33:09","");
INSERT INTO salesexecutive_tracking VALUES("470","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:47","0","0","5895","712","","","2018-12-08 12:33:09","");
INSERT INTO salesexecutive_tracking VALUES("471","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:48","0","0","5895","712","","","2018-12-08 12:33:09","");
INSERT INTO salesexecutive_tracking VALUES("472","sync_hour","1","70.7696861","22.2795682","2018-12-08 12:08:49","0","0","5895","712","","","2018-12-08 12:33:09","");
INSERT INTO salesexecutive_tracking VALUES("473","Satya Sai hospital road, above Royal uniform, opp. Shilpan app, Gujarat, India","1","70.7696838","22.2795688","2018-12-08 12:08:59","0","0","5895","712","","","2018-12-08 12:33:09","");
INSERT INTO salesexecutive_tracking VALUES("474","Satya Sai hospital road, above Royal uniform, opp. Shilpan app, Gujarat, India","1","70.7696834","22.2795686","2018-12-08 12:10:30","0","0","5895","712","","","2018-12-08 12:33:09","");
INSERT INTO salesexecutive_tracking VALUES("475","Satya Sai hospital road, above Royal uniform, opp. Shilpan app, Gujarat, India","1","70.7696916","22.2795721","2018-12-08 12:25:09","0","0","5895","712","","","2018-12-08 12:33:09","");
INSERT INTO salesexecutive_tracking VALUES("476","402, Royal Hights, Above Royal Uniform, Opp Casa Copper, Near Rudra Super Market, Rajkot, Gujarat 360005, India","1","70.76982493512332","22.279563532210886","2018-12-08 12:28:50","0","0","5895","712","","","2018-12-08 12:33:09","");
INSERT INTO salesexecutive_tracking VALUES("477","Nr. Satya Sai Heart Hospital, Satya sai Hospital Rd, kalawad road, Rajkot, Gujarat 360005, India","1","70.76960055157542","22.279395684599876","2018-12-08 12:30:18","0","0","5895","712","","","2018-12-08 12:33:09","");
INSERT INTO salesexecutive_tracking VALUES("478","Satya Sai hospital road, above Royal uniform, opp. Shilpan app, Gujarat, India","1","70.7696831","22.2795678","2018-12-08 12:33:14","0","0","5895","712","","","2018-12-08 12:33:09","");
INSERT INTO salesexecutive_tracking VALUES("479","logout","1","70.7696831","22.2795678","2018-12-08 12:33:30","0","0","5895","712","","","2018-12-08 12:33:09","");





CREATE TABLE `security` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(14) DEFAULT NULL,
  `ltime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `attempts` int(10) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `adate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`),
  KEY `ip` (`ip`),
  KEY `attemps` (`attempts`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO security VALUES("1","24.24.25.233","2018-02-07 12:40:49","4","0","0000-00-00 00:00:00","5895","712","5895,5895,5895","458,458,458","2018-02-07 12:39:18","2018-02-07 12:39:58,2018-02-07 12:40:05,2018-02-07 12:40:49");





CREATE TABLE `state` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `country_id` int(11) NOT NULL DEFAULT '0',
  `isDelete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

INSERT INTO state VALUES("1","Gujarat","1","0");
INSERT INTO state VALUES("2","Arunachal Pradesh","1","0");
INSERT INTO state VALUES("3","Assam","1","0");
INSERT INTO state VALUES("4","Bihar","1","0");
INSERT INTO state VALUES("5","Chhattisgarh","1","0");
INSERT INTO state VALUES("6","Goa","1","0");
INSERT INTO state VALUES("7","Andhra Pradesh","1","0");
INSERT INTO state VALUES("8","Haryana","1","0");
INSERT INTO state VALUES("9","Himachal Pradesh","1","0");
INSERT INTO state VALUES("10","Jammu and Kashmir","1","0");
INSERT INTO state VALUES("11","Jharkhand","1","0");
INSERT INTO state VALUES("12","Karnataka","1","0");
INSERT INTO state VALUES("13","Kerala","1","0");
INSERT INTO state VALUES("14","Madhya Pradesh","1","0");
INSERT INTO state VALUES("15","Maharashtra","1","0");
INSERT INTO state VALUES("16","Manipur","1","0");
INSERT INTO state VALUES("17","Meghalaya","1","0");
INSERT INTO state VALUES("18","Mizoram","1","0");
INSERT INTO state VALUES("19","Nagaland","1","0");
INSERT INTO state VALUES("20","Odisha(Orissa)","1","0");
INSERT INTO state VALUES("21","Punjab","1","0");
INSERT INTO state VALUES("22","Rajasthan","1","0");
INSERT INTO state VALUES("23","Sikkim","1","0");
INSERT INTO state VALUES("24","Tamil Nadu","1","0");
INSERT INTO state VALUES("25","Tripura","1","0");
INSERT INTO state VALUES("26","Uttar Pradesh","1","0");
INSERT INTO state VALUES("27","Uttarakhand","1","0");
INSERT INTO state VALUES("28","West Bengal","1","0");
INSERT INTO state VALUES("29","Andaman and Nicobar Islands","1","0");
INSERT INTO state VALUES("30","Chandigarh","1","0");
INSERT INTO state VALUES("31","Dadra and Nagar Haveli","1","0");
INSERT INTO state VALUES("32","Daman and Diu","1","0");
INSERT INTO state VALUES("33","Delhi","1","0");
INSERT INTO state VALUES("34","Lakshadweep","1","0");
INSERT INTO state VALUES("35","Puducherry","1","0");





CREATE TABLE `table_information_schema` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table_slug` varchar(50) DEFAULT NULL,
  `table_code` int(11) NOT NULL DEFAULT '0',
  `last_modify_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `isDelete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO table_information_schema VALUES("1","weight","1","2018-01-01 14:22:21","0");
INSERT INTO table_information_schema VALUES("2","orders","2","2018-02-07 13:05:30","0");
INSERT INTO table_information_schema VALUES("3","product","3","2018-01-01 14:24:29","0");
INSERT INTO table_information_schema VALUES("4","product_weight_price","4","2018-02-07 13:05:30","0");
INSERT INTO table_information_schema VALUES("5","executive","5","2018-12-08 10:17:13","0");
INSERT INTO table_information_schema VALUES("6","no_order_inquiry","6","2018-12-08 12:33:02","0");
INSERT INTO table_information_schema VALUES("7","top_category_master","7","2017-10-11 11:01:16","0");
INSERT INTO table_information_schema VALUES("8","category_master","8","2017-10-10 16:52:51","0");





CREATE TABLE `tax` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `value` float NOT NULL DEFAULT '0',
  `applied_from` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `adate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO tax VALUES("1","VAT","200","0000-00-00 00:00:00","2017-03-29 16:06:54","0","1","0","1","0","2017-03-29 16:06:54","2017-06-21 18:29:54");
INSERT INTO tax VALUES("2","bbn","25000","0000-00-00 00:00:00","2017-06-21 18:29:31","0","1","0","","","2017-06-21 18:29:31","");
INSERT INTO tax VALUES("3","lpl","30000","0000-00-00 00:00:00","2017-06-21 18:29:46","0","1","0","","","2017-06-21 18:29:46","");
INSERT INTO tax VALUES("4","fd7/*","0","2017-07-05 17:34:47","2017-07-05 17:34:47","0","1","0","","","2017-07-05 17:34:47","");





CREATE TABLE `top_category_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `isDelete` tinyint(4) NOT NULL DEFAULT '0',
  `isActive` tinyint(4) NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO top_category_master VALUES("1","C-PVC","0","1","1","0","1","0","0000-00-00 00:00:00","2017-10-11 11:01:16");
INSERT INTO top_category_master VALUES("2","U-PVC","0","1","1","0","1,1,1","0,0,0","0000-00-00 00:00:00","2017-10-10 17:38:54,2017-10-10 17:39:00,2017-10-11 11:01:08");





CREATE TABLE `unit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `isActive` int(11) DEFAULT '1',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO unit VALUES("1","No","0","1","1","0","","","2017-03-24 17:24:41","");
INSERT INTO unit VALUES("2","PP","0","1","1","0","","","2017-03-24 17:24:53","");
INSERT INTO unit VALUES("3","SS","0","1","1","0","","","2017-03-24 17:24:59","");
INSERT INTO unit VALUES("4","mm","0","1","1","0","","","2017-06-21 18:30:20","");





CREATE TABLE `vendor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_type` varchar(100) DEFAULT NULL,
  `cname` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `tin` varchar(50) DEFAULT NULL,
  `pan` varchar(50) DEFAULT NULL,
  `gst` varchar(50) DEFAULT NULL,
  `vat` varchar(50) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `address` text,
  `zip` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `bank_name` varchar(50) DEFAULT NULL,
  `account_no` varchar(50) DEFAULT NULL,
  `ifsc_code` varchar(50) DEFAULT NULL,
  `adate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  `isDelete` tinyint(11) NOT NULL DEFAULT '0',
  `isActive` tinyint(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO vendor VALUES("0","1","Prashant Engineering","prashant@gmail.com","","","","","9033192319","Rajkot","360001","India","GUJARAT","Rajkot (360001)","","","","2017-10-12 11:07:51","1","0","1","0","2017-10-12 11:07:51","2017-11-30 12:48:08","0","1");





CREATE TABLE `vendor_branch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vid` int(11) NOT NULL DEFAULT '0',
  `branch_name` varchar(1000) DEFAULT NULL,
  `isDelete` int(11) NOT NULL DEFAULT '0',
  `adate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text,
  `modified_by_type` text,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` text,
  PRIMARY KEY (`id`),
  KEY `customer_id_index` (`vid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO vendor_branch VALUES("1","2","Branch2","0","2017-09-19 12:13:51","1","0","1","0","2017-09-19 12:13:51","2017-09-19 12:17:34");
INSERT INTO vendor_branch VALUES("2","2","Branch 1","0","2017-09-19 12:13:58","1","0","1,1,1","0,0,0","2017-09-19 12:13:58","2017-09-19 12:17:51,2017-09-19 12:17:54,2017-09-19 12:18:03");
INSERT INTO vendor_branch VALUES("3","2"," 	 Branch 1  	","0","2017-09-19 12:14:58","1","0","","","2017-09-19 12:14:58","");
INSERT INTO vendor_branch VALUES("4","2"," 	 Branch 2","0","2017-09-19 12:15:09","1","0","","","2017-09-19 12:15:09","");
INSERT INTO vendor_branch VALUES("5","2","branch 3","0","2017-09-19 12:17:21","1","0","","","2017-09-19 12:17:21","");





CREATE TABLE `vendor_contact_person` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vid` int(11) NOT NULL,
  `branch` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `adate` datetime NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text NOT NULL,
  `modified_by_type` text NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` text NOT NULL,
  `isDelete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COMMENT='// Contact Person for Customer or Comapny, Branch is from customer branch';

INSERT INTO vendor_contact_person VALUES("1","2","3","Sari","Employee","7383220934","S@mail.com","2017-09-19 12:25:45","1","0","1,1","0,0","2017-09-19 12:25:45","2017-09-19 12:26:16,2017-09-19 12:26:20","0");
INSERT INTO vendor_contact_person VALUES("2","2","4","Sarika","Employee","7383220934","s@mail.cpm","2017-09-19 12:26:38","1","0","","","2017-09-19 12:26:38","","0");





CREATE TABLE `weight` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `isDelete` int(11) NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text NOT NULL,
  `modified_by_type` text NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

INSERT INTO weight VALUES("1","1/2\"","0","1","0","","","2017-12-28 11:07:03","");
INSERT INTO weight VALUES("2","3/4\"","0","1","0","","","2017-12-28 11:07:18","");
INSERT INTO weight VALUES("3","1\"","0","1","0","","","2017-12-28 11:07:31","");
INSERT INTO weight VALUES("4","1.1/4\"","0","1","0","","","2017-12-28 11:07:52","");
INSERT INTO weight VALUES("5","1.1/2\"","0","1","0","","","2017-12-28 11:08:07","");
INSERT INTO weight VALUES("6","1\"x3/4\"","0","1","0","","","2017-12-28 11:10:29","");
INSERT INTO weight VALUES("7","3/4\"x1/2\"","0","1","0","1","0","2017-12-28 11:28:02","2017-12-28 13:26:29");
INSERT INTO weight VALUES("8","1.1/4\"x1\"","0","1","0","1","0","2017-12-28 13:20:04","2017-12-28 13:20:19");
INSERT INTO weight VALUES("9","1.1/2\"x1\"","0","1","0","","","2017-12-28 13:20:37","");
INSERT INTO weight VALUES("10","1.1/2\"x1.1/4\"","0","1","0","","","2017-12-28 13:20:53","");
INSERT INTO weight VALUES("11","1.1/4\"x3/4\"","0","1","0","","","2017-12-28 13:29:30","");
INSERT INTO weight VALUES("12","1\"x1/2\"","0","1","0","","","2017-12-28 19:05:21","");
INSERT INTO weight VALUES("13","2\"","0","1","0","","","2017-12-29 11:23:36","");
INSERT INTO weight VALUES("14","10ML","0","1","0","","","2017-12-29 11:49:04","");
INSERT INTO weight VALUES("15","20ML","0","1","0","","","2017-12-29 11:49:13","");
INSERT INTO weight VALUES("16","50ML","0","1","0","1","0","2018-01-01 14:21:11","2018-01-01 14:21:20");
INSERT INTO weight VALUES("17","125ML","0","1","0","","","2018-01-01 14:21:39","");
INSERT INTO weight VALUES("18","250ML","0","1","0","","","2018-01-01 14:21:53","");
INSERT INTO weight VALUES("19","500ML","0","1","0","","","2018-01-01 14:22:07","");
INSERT INTO weight VALUES("20","1LTR","0","1","0","","","2018-01-01 14:22:21","");





CREATE TABLE `working_shift` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `isDelete` int(11) NOT NULL,
  `isActive` int(11) DEFAULT '1',
  `created_by` int(11) NOT NULL DEFAULT '1',
  `created_by_type` int(11) NOT NULL DEFAULT '0',
  `modified_by` text NOT NULL,
  `modified_by_type` text NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;






<div class="col-md-6">
					<div class="form-group">
						<label for="class_id">Class Type </label>
						<select class="form-control" name="class_id" id="class_id" >
							<option value="">Select Class Type</option>
							<?php 
								$class_list_d=$db->rp_getData('class',"*","1=1","",0);
								while($class_list_r=mysqli_fetch_assoc($class_list_d))
								{
									?>
									<option <?php echo ($class_id==$class_list_r['id'])?"selected":"" ; ?> value="<?php echo $class_list_r['id']?>">
									<?php echo $class_list_r['name'];?>
									</option>
									<?php
								}
							?>
						</select>
					</div>
					</div>
<div class="col-md-12 col-sm-12">
		<div class="portlet grey-cascade box">
			<div class="portlet-title">
				<div class="caption">
				  <i class="fa fa-book"></i>Class map Area Information
				</div>
			   
			</div>
			<div class="portlet-body" style="min-height:150px;">
				<div class="row">
					<div class="col-md-12">
						<div class="row">																											
			<div class="col-md-12">
					
					<div class="row">
						<div class="form-body">
                                                
                                                <div class="form-group">
												<?php
                                                           /*$area_r=$db->rp_getData("area","id,name","isDelete=0 AND isActive=1","name ASC","0");                                                      // MAPED BUSES
                                                            $map_area=array();
                                                            $map_area_reply=$objClass->getArea($class_id,$id);
                                                            if($map_area_reply['ack']==1)
                                                            {
                                                                $result=$map_area_reply['result'];
                                                                foreach ($result as $b)
                                                                {
                                                                     $map_area[]=$b['id'];
                                                                }
                                                            }*/

                                                         ?>
                                                        <select multiple="multiple" class="multi-select" id="area_id" name="area_id[]">
                                                            <?php

                                                            if($area_r)
                                                            {
                                                                while($area=mysqli_fetch_assoc($area_r))
                                                                {
                                                                    ?>
                                                                     <option <?php echo (in_array($area['id'],$map_area))?"selected":"" ?> value="<?php echo $area['id']; ?>"><?php echo $area['name']; ?></option>
                                                                    <?php
                                                                }
                                                            }
                                                            else
                                                            {

                                                            }

                                                            ?>
                                                        </select>
                                                    </div>
                                                  
                                                </div>
                                                    <br/>
                                                    <br/>

                                                    <div class="form-actions noborder">
                                                            <button type="submit" name="submit" class="btn blue">Submit</button>

                                                    </div>
																			
					</div>
					<div class="row">
								
																			
					</div>
					
					
				
			</div>
		</div>
						
						</div>
				</div>
			</div>
		</div>
	</div>
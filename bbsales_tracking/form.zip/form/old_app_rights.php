<tbody>
							<tr>
								<td>Super Stockist</td>
								<td align="center"><input type="checkbox" data-count="1" class="row-check row-check1" name="super_stokist_order_view_flag" id="super_stokist_order_view_flag" value="1" <?php echo ($super_stokist_order_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>

								<td></td>
								<td></td>
								<td></td>
								
								<!-- <td align="center"><input type="checkbox" data-count="1" class="row-check row-check1" name="super_stokist_order_insert_flag" id="super_stokist_order_insert_flag" value="1" <?php echo ($super_stokist_order_insert_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td> -->
								
								<!-- <td align="center"><input type="checkbox" data-count="1" class="row-check row-check1" name="super_stokist_order_update_flag" id="super_stokist_order_update_flag" value="1" <?php echo ($super_stokist_order_update_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td> -->

								<!-- <td align="center"><input type="checkbox" data-count="1" class="row-check row-check1"  name="super_stokist_order_delete_flag" id="super_stokist_order_delete_flag" value="1" <?php echo ($super_stokist_order_delete_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td> -->
								
								<td align="center"><input type="checkbox" class="masterCheck masterCheck1" data-count="1" style="width:60px;text-align:center"></td>
								</tr>

								</tr>
							<tr>

							<tr>
								<td>Dealer</td>

								<td align="center"><input type="checkbox" data-count="2" class="row-check row-check2" name="outlets_order_view_flag" id="outlets_order_view_flag" value="1" <?php echo ($outlets_order_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>

								<td></td>
								<td></td>
								<td></td>

							<!-- 	<td align="center"><input type="checkbox" data-count="2" class="row-check row-check2" name="outlets_order_insert_flag" id="outlets_order_insert_flag" value="1" <?php echo ($outlets_order_insert_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								
								<td align="center"><input type="checkbox" data-count="2" class="row-check row-check2" name="outlets_order_update_flag" id="outlets_order_update_flag" value="1" <?php echo ($outlets_order_update_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								
								<td align="center"><input type="checkbox" data-count="2" class="row-check row-check2" name="outlets_order_delete_flag" id="outlets_order_delete_flag" value="1" <?php echo ($outlets_order_delete_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td> -->

								<td align="center"><input type="checkbox" class="masterCheck masterCheck2" data-count="2" style="width:60px;text-align:center"></td>
								</tr>
							</tr>
							
							<tr>
								<td>Distributor</td>

								<td align="center"><input type="checkbox" data-count="3" class="row-check row-check3" name="dealer_order_view_flag" id="dealer_order_view_flag" value="1" <?php echo ($dealer_order_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>

								<td></td>
								<td></td>
								<td></td>

							<!-- 	<td align="center"><input type="checkbox" data-count="3" class="row-check row-check3" name="dealer_order_insert_flag" id="dealer_order_insert_flag" value="1" <?php echo ($dealer_order_insert_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
									
								<td align="center"><input type="checkbox" data-count="3" class="row-check row-check3" name="dealer_order_update_flag" id="dealer_order_update_flag" value="1" <?php echo ($dealer_order_update_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
									
								<td align="center"><input type="checkbox" data-count="3" class="row-check row-check3" name="dealer_order_delete_flag" id="dealer_order_delete_flag" value="1" <?php echo ($dealer_order_delete_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td> -->

								<td align="center"><input type="checkbox" class="masterCheck masterCheck3" data-count="3" style="width:60px;text-align:center"></td>
								</tr>
							</tr>
							<tr>
								<td>B2B Customer</td>

								<td align="center"><input type="checkbox" data-count="4" class="row-check row-check4" name="project_order_view_flag" id="project_order_view_flag" value="1" <?php echo ($project_order_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>

								<td></td>
								<td></td>
								<td></td>

								<!-- <td align="center"><input type="checkbox" data-count="4" class="row-check row-check4" name="project_order_insert_flag" id="project_order_insert_flag" value="1" <?php echo ($project_order_insert_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
									
								<td align="center"><input type="checkbox" data-count="4" class="row-check row-check4" name="project_order_update_flag" id="project_order_update_flag" value="1" <?php echo ($project_order_update_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
									
								<td align="center"><input type="checkbox" data-count="4" class="row-check row-check4" name="project_order_delete_flag" id="project_order_delete_flag" value="1" <?php echo ($project_order_delete_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td> -->

								<td align="center"><input type="checkbox" class="masterCheck masterCheck4" data-count="4" style="width:60px;text-align:center"></td>
								</tr>
							</tr>
							<tr>
								<td>B2C Customer</td>

								<td align="center"><input type="checkbox" data-count="5" class="row-check row-check5" name="oem_order_view_flag" id="oem_order_view_flag" value="1" <?php echo ($oem_order_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>

								<td></td>
								<td></td>
								<td></td>

							<!-- 	<td align="center"><input type="checkbox" data-count="5" class="row-check row-check5" name="oem_order_insert_flag" id="oem_order_insert_flag" value="1" <?php echo ($oem_order_insert_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
									
								<td align="center"><input type="checkbox" data-count="5" class="row-check row-check5" name="oem_order_update_flag" id="oem_order_update_flag" value="1" <?php echo ($oem_order_update_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
									
								<td align="center"><input type="checkbox" data-count="5" class="row-check row-check5" name="oem_order_delete_flag" id="oem_order_delete_flag" value="1" <?php echo ($oem_order_delete_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td> -->

								<td align="center"><input type="checkbox" class="masterCheck masterCheck5" data-count="5" style="width:60px;text-align:center"></td>
								</tr>
							</tr>

							<tr>
								<td>Merchant Customer</td>

								<td align="center"><input type="checkbox" data-count="33" class="row-check row-check33" name="marchent_customer_view_flag" id="marchent_customer_view_flag" value="1" <?php echo ($marchent_customer_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td></td>
								<td></td>
								<td></td>
								<!-- <td align="center"><input type="checkbox" data-count="33" class="row-check row-check33" name="marchent_customer_insert_flag" id="marchent_customer_insert_flag" value="1" <?php echo ($marchent_customer_insert_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
									
								<td align="center"><input type="checkbox" data-count="33" class="row-check row-check33" name="marchent_customer_update_flag" id="marchent_customer_update_flag" value="1" <?php echo ($marchent_customer_update_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td> 
									
								<td align="center"><input type="checkbox" data-count="33" class="row-check row-check33" name="marchent_customer_delete_flag" id="marchent_customer_delete_flag" value="1" <?php echo ($marchent_customer_delete_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
							 -->
								<td align="center"><input type="checkbox" class="masterCheck masterCheck33" data-count="33" style="width:60px;text-align:center"></td>
								</tr>
							</tr>

							<tr>
								<td>Quotation</td>

								<td align="center"><input type="checkbox" data-count="31" class="row-check row-check31" name="quotation_view_flag" id="quotation_view_flag" value="1" <?php echo ($quotation_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>

								<td align="center"><input type="checkbox" data-count="31" class="row-check row-check31" name="quotation_insert_flag" id="quotation_insert_flag" value="1" <?php echo ($quotation_insert_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
									
								<td align="center"><input type="checkbox" data-count="31" class="row-check row-check31" name="quotation_update_flag" id="quotation_update_flag" value="1" <?php echo ($quotation_update_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
									
								<td align="center"><input type="checkbox" data-count="31" class="row-check row-check31" name="quotation_delete_flag" id="quotation_delete_flag" value="1" <?php echo ($quotation_delete_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>

								<td align="center"><input type="checkbox" class="masterCheck masterCheck31" data-count="31" style="width:60px;text-align:center"></td>
								</tr>
							</tr>

							<tr>
								<td>Raw Data</td>

								<td align="center"><input type="checkbox" data-count="32" class="row-check row-check32" name="prospact_view_flag" id="prospact_view_flag" value="1" <?php echo ($prospact_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>

								<td align="center"><input type="checkbox" data-count="32" class="row-check row-check32" name="prospact_insert_flag" id="prospact_insert_flag" value="1" <?php echo ($prospact_insert_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
									
								<td align="center"><input type="checkbox" data-count="32" class="row-check row-check32" name="prospact_update_flag" id="prospact_update_flag" value="1" <?php echo ($prospact_update_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
									
								<td align="center"><input type="checkbox" data-count="32" class="row-check row-check32" name="prospact_delete_flag" id="prospact_delete_flag" value="1" <?php echo ($prospact_delete_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>

								<td align="center"><input type="checkbox" class="masterCheck masterCheck32" data-count="32" style="width:60px;text-align:center"></td>
								</tr>
							</tr>
							
							<tr>
								<td>Inquiry</td>
								
								<td align="center"><input type="checkbox" data-count="6" class="row-check row-check6" name="survey_customer_view_flag" id="survey_customer_view_flag" value="1" <?php echo ($survey_customer_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>

								<td align="center"><input type="checkbox" data-count="6" class="row-check row-check6" name="survey_customer_insert_flag" id="survey_customer_insert_flag" value="1" <?php echo ($survey_customer_insert_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								
								<td align="center"><input type="checkbox" data-count="6" class="row-check row-check6" name="survey_customer_update_flag" id="survey_customer_update_flag" value="1" <?php echo ($survey_customer_update_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								
								<td align="center"><input type="checkbox" data-count="6" class="row-check row-check6" name="survey_customer_delete_flag" id="survey_customer_delete_flag" value="1" <?php echo ($survey_customer_delete_flag==1)?"checked":""; ?> 	style="width:60px;text-align:center"></td>

								<td align="center"><input type="checkbox" class="masterCheck masterCheck6" data-count="6" style="width:60px;text-align:center"></td>
							</tr>

							<tr>
								<td>Customer Leads</td>
								
								<td align="center"><input type="checkbox" data-count="7" class="row-check row-check7" name="customer_leads_view_flag" id="customer_leads_view_flag" value="1" <?php echo ($customer_leads_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>

								<td align="center"><input type="checkbox" data-count="7" class="row-check row-check7" name="customer_leads_insert_flag" id="customer_leads_insert_flag" value="1" <?php echo ($customer_leads_insert_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								
								<td align="center"><input type="checkbox" data-count="7" class="row-check row-check7" name="customer_leads_update_flag" id="customer_leads_update_flag" value="1" <?php echo ($customer_leads_update_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								
								<td align="center"><input type="checkbox" data-count="7" class="row-check row-check7" name="customer_leads_delete_flag" id="customer_leads_delete_flag" value="1" <?php echo ($customer_leads_delete_flag==1)?"checked":""; ?> 	style="width:60px;text-align:center"></td>

								<td align="center"><input type="checkbox" class="masterCheck masterCheck7" data-count="7" style="width:60px;text-align:center"></td>
							</tr>
							
							<tr>
								<td>Customer</td>

								<td align="center"><input type="checkbox" data-count="8" class="row-check row-check8" name="customer_view_flag" id="customer_view_flag" value="1" <?php echo ($customer_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>

								<td align="center"><input type="checkbox" data-count="8" class="row-check row-check8" name="customer_insert_flag" id="customer_insert_flag" value="1" <?php echo ($customer_insert_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>

								<td align="center"><input type="checkbox" data-count="8" class="row-check row-check8" name="customer_update_flag" id="customer_update_flag" value="1" <?php echo ($customer_update_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>

								<td align="center"><input type="checkbox" data-count="8" class="row-check row-check8" name="customer_delete_flag" id="customer_delete_flag" value="1" <?php echo ($customer_delete_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>

								<td align="center"><input type="checkbox" class="masterCheck masterCheck8" data-count="8" style="width:60px;text-align:center"></td>
							</tr>

							<tr>
							<td>Attendance </td>
							<td></td>
							<td align="center"><input type="checkbox" data-count="9" class="row-check row-check9" name="attendance_insert_flag" id="attendance_insert_flag" value="1" <?php echo ($attendance_insert_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
							<td></td>
							<td></td>
							<td align="center"><input type="checkbox" class="masterCheck masterCheck9" data-count="9" style="width:60px;text-align:center"></td>
							</tr>

							<tr>
							<td>My Followup</td>
								<td align="center"><input type="checkbox" data-count="10" class="row-check row-check10" name="followup_view_flag" id="followup_view_flag" value="1" <?php echo ($followup_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>

								<td align="center"><input type="checkbox" data-count="10" class="row-check row-check10" name="followup_insert_flag" id="followup_insert_flag" value="1" <?php echo ($followup_insert_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>

								<td></td>
								<td></td>
							
								<!-- <td align="center"><input type="checkbox" data-count="10" class="row-check row-check10" name="followup_update_flag" id="followup_update_flag" value="1" <?php echo ($followup_update_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>

								<td align="center"><input type="checkbox" data-count="10" class="row-check row-check10" name="followup_delete_flag" id="followup_delete_flag" value="1" <?php echo ($followup_delete_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td> -->

								<td align="center"><input type="checkbox" class="masterCheck masterCheck10" data-count="10" style="width:60px;text-align:center"></td>
							
							</tr>

							<tr>
								<td>Create Order</td>
								<td align="center"><input type="checkbox" data-count="11" class="row-check row-check11" name="create_order_view_flag" id="create_order_view_flag" value="1" <?php echo ($create_order_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>

								<td align="center"><input type="checkbox" data-count="11" class="row-check row-check11" name="create_order_insert_flag" id="create_order_insert_flag" value="1" <?php echo ($create_order_insert_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
							
								<td align="center"><input type="checkbox" data-count="11" class="row-check row-check11" name="create_order_update_flag" id="create_order_update_flag" value="1" <?php echo ($create_order_update_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>

								<td align="center"><input type="checkbox" data-count="11" class="row-check row-check11" name="create_order_delete_flag" id="create_order_delete_flag" value="1" <?php echo ($create_order_delete_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>

								<td align="center"><input type="checkbox" class="masterCheck masterCheck11" data-count="11" style="width:60px;text-align:center"></td>
							</tr>

							<tr>
								<td>Order History</td>
								<td align="center"><input type="checkbox" data-count="12" class="row-check row-check12" name="order_history_view_flag" id="order_history_view_flag" value="1" <?php echo ($order_history_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>

								<td align="center"><input type="checkbox" data-count="12" class="row-check row-check12" name="order_history_insert_flag" id="order_history_insert_flag" value="1" <?php echo ($order_history_insert_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
							
								<td align="center"><input type="checkbox" data-count="12" class="row-check row-check12" name="order_history_update_flag" id="order_history_update_flag" value="1" <?php echo ($order_history_update_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>

								<td align="center"><input type="checkbox" data-count="12" class="row-check row-check12" name="order_history_delete_flag" id="order_history_delete_flag" value="1" <?php echo ($order_history_delete_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>

								<td align="center"><input type="checkbox" class="masterCheck masterCheck12" data-count="12" style="width:60px;text-align:center"></td>
							</tr>

							<tr>
								<td>Complain</td>
								<td align="center"><input type="checkbox" data-count="13" class="row-check row-check13" name="complain_view_flag" id="complain_view_flag" value="1" <?php echo ($complain_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td align="center"><input type="checkbox" data-count="13" class="row-check row-check13" name="complain_insert_flag" id="complain_insert_flag" value="1" <?php echo ($complain_insert_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td align="center"><input type="checkbox" data-count="13" class="row-check row-check13" name="complain_update_flag" id="complain_update_flag" value="1" <?php echo ($complain_update_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td align="center"><input type="checkbox" data-count="13" class="row-check row-check13" name="complain_delete_flag" id="complain_delete_flag" value="1" <?php echo ($complain_delete_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td align="center"><input type="checkbox" class="masterCheck masterCheck13" data-count="13" style="width:60px;text-align:center"></td>
							</tr>

							<!-- <tr>
								<td>Request</td>
								<td align="center"><input type="checkbox" data-count="14" class="row-check row-check14" name="request_view_flag" id="request_view_flag" value="1" <?php echo ($request_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td align="center"><input type="checkbox" data-count="14" class="row-check row-check14" name="request_insert_flag" id="request_insert_flag" value="1" <?php echo ($request_insert_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td align="center"><input type="checkbox" data-count="14" class="row-check row-check14" name="request_update_flag" id="request_update_flag" value="1" <?php echo ($request_update_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td align="center"><input type="checkbox" data-count="14" class="row-check row-check14" name="request_delete_flag" id="request_delete_flag" value="1" <?php echo ($request_delete_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td align="center"><input type="checkbox" class="masterCheck masterCheck14" data-count="14" style="width:60px;text-align:center"></td>
							</tr> -->

							<tr>
								<td>Customer Meeting</td>
								<td align="center"><input type="checkbox" data-count="15" class="row-check row-check15" name="customer_meeting_view_flag" id="customer_meeting_view_flag" value="1" <?php echo ($customer_meeting_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td align="center"><input type="checkbox" data-count="15" class="row-check row-check15" name="customer_meeting_insert_flag" id="customer_meeting_insert_flag" value="1" <?php echo ($customer_meeting_insert_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td align="center"><input type="checkbox" data-count="15" class="row-check row-check15" name="customer_meeting_update_flag" id="customer_meeting_update_flag" value="1" <?php echo ($customer_meeting_update_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td align="center"><input type="checkbox" data-count="15" class="row-check row-check15" name="customer_meeting_delete_flag" id="customer_meeting_delete_flag" value="1" <?php echo ($customer_meeting_delete_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td align="center"><input type="checkbox" class="masterCheck masterCheck15" data-count="15" style="width:60px;text-align:center"></td>
							</tr>

							<tr>
								<td>Near By Me</td>
								<td align="center"><input type="checkbox" data-count="16" class="row-check row-check16" name="near_by_me_view_flag" id="near_by_me_view_flag" value="1" <?php echo ($near_by_me_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td align="center"></td>
								<td align="center"></td>
								<td align="center"></td>
								<td align="center"><input type="checkbox" class="masterCheck masterCheck16" data-count="16" style="width:60px;text-align:center"></td>
							</tr>

							<tr>
								<td>Change Root</td>
								<td align="center"><input type="checkbox" data-count="17" class="row-check row-check17" name="change_root_view_flag" id="change_root_view_flag" value="1" <?php echo ($change_root_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td></td>
								<td></td>
								<td></td>
								<!-- <td align="center"><input type="checkbox" data-count="17" class="row-check row-check17" name="change_root_insert_flag" id="change_root_insert_flag" value="1" <?php echo ($change_root_insert_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td align="center"><input type="checkbox" data-count="17" class="row-check row-check17" name="change_root_update_flag" id="change_root_update_flag" value="1" <?php echo ($change_root_update_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td align="center"><input type="checkbox" data-count="17" class="row-check row-check17" name="change_root_delete_flag" id="change_root_delete_flag" value="1" <?php echo ($change_root_delete_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td> -->
								<td align="center"><input type="checkbox" class="masterCheck masterCheck17" data-count="17" style="width:60px;text-align:center"></td>
							</tr>

							<tr>
								<td>My Expense</td>
								<td align="center"><input type="checkbox" data-count="18" class="row-check row-check18" name="expense_view_flag" id="expense_view_flag" value="1" <?php echo ($expense_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td align="center"><input type="checkbox" data-count="18" class="row-check row-check18" name="expense_insert_flag" id="expense_insert_flag" value="1" <?php echo ($expense_insert_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td></td>
								<!-- <td align="center"><input type="checkbox" data-count="18" class="row-check row-check18" name="expense_update_flag" id="expense_update_flag" value="1" <?php echo ($expense_update_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td> -->
								<td align="center"><input type="checkbox" data-count="18" class="row-check row-check18" name="expense_delete_flag" id="expense_delete_flag" value="1" <?php echo ($expense_delete_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td align="center"><input type="checkbox" class="masterCheck masterCheck18" data-count="18" style="width:60px;text-align:center"></td>
							</tr>

							<tr>
								<td>My Leave</td>
								<td align="center"><input type="checkbox" data-count="19" class="row-check row-check19" name="leave_view_flag" id="leave_view_flag" value="1" <?php echo ($leave_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td align="center"><input type="checkbox" data-count="19" class="row-check row-check19" name="leave_insert_flag" id="leave_insert_flag" value="1" <?php echo ($leave_insert_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td align="center"><input type="checkbox" data-count="19" class="row-check row-check19" name="leave_update_flag" id="leave_update_flag" value="1" <?php echo ($leave_update_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td align="center"><input type="checkbox" data-count="19" class="row-check row-check19" name="leave_delete_flag" id="leave_delete_flag" value="1" <?php echo ($leave_delete_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td align="center"><input type="checkbox" class="masterCheck masterCheck19" data-count="19" style="width:60px;text-align:center"></td>
							</tr>

							<tr>
								<td>My Area</td>
								<td align="center"><input type="checkbox" data-count="20" class="row-check row-check20" name="area_view_flag" id="area_view_flag" value="1" <?php echo ($area_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td align="center"><input type="checkbox" data-count="20" class="row-check row-check20" name="area_insert_flag" id="area_insert_flag" value="1" <?php echo ($area_insert_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td align="center"><input type="checkbox" data-count="20" class="row-check row-check20" name="area_update_flag" id="area_update_flag" value="1" <?php echo ($area_update_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td align="center"><input type="checkbox" data-count="20" class="row-check row-check20" name="area_delete_flag" id="area_delete_flag" value="1" <?php echo ($area_delete_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td align="center"><input type="checkbox" class="masterCheck masterCheck20" data-count="20" style="width:60px;text-align:center"></td>
							</tr>

							<tr>
								<td>Visit</td>
								<td align="center"><input type="checkbox" data-count="21" class="row-check row-check21" name="visit_view_flag" id="visit_view_flag" value="1" <?php echo ($visit_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td align="center"><input type="checkbox" data-count="21" class="row-check row-check21" name="visit_insert_flag" id="visit_insert_flag" value="1" <?php echo ($visit_insert_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td></td>
								<!-- <td align="center"><input type="checkbox" data-count="21" class="row-check row-check21" name="visit_update_flag" id="visit_update_flag" value="1" <?php echo ($visit_update_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td> -->
								<td align="center"><input type="checkbox" data-count="21" class="row-check row-check21" name="visit_delete_flag" id="visit_delete_flag" value="1" <?php echo ($visit_delete_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td align="center"><input type="checkbox" class="masterCheck masterCheck21" data-count="21" style="width:60px;text-align:center"></td>
							</tr>

							<tr>
								<td>Price List </td>
								<td align="center"><input type="checkbox" data-count="22" class="row-check row-check22" name="price_list_view_flag" id="price_list_view_flag" value="1" <?php echo ($price_list_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td></td>
								<td></td>
								<td></td>
								<td align="center"><input type="checkbox" class="masterCheck masterCheck22" data-count="22" style="width:60px;text-align:center"></td>
							</tr>

							<tr>
								<td>Bank Detail</td>
								<td align="center"><input type="checkbox" data-count="23" class="row-check row-check23" name="bank_detail_view_flag" id="bank_detail_view_flag" value="1" <?php echo ($bank_detail_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td></td>
								<td></td>
								<td></td>
								<td align="center"><input type="checkbox" class="masterCheck masterCheck23" data-count="23" style="width:60px;text-align:center"></td>
							</tr>

							<tr>
								<td>Scheme</td>
								<td align="center"><input type="checkbox" data-count="24" class="row-check row-check24" name="scheme_view_flag" id="scheme_view_flag" value="1" <?php echo ($scheme_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td></td>
								<td></td>
								<td></td>
								<td align="center"><input type="checkbox" class="masterCheck masterCheck24" data-count="24" style="width:60px;text-align:center"></td>
							</tr>

							<tr>
								<td>Discount Dealer</td>
								<td align="center"><input type="checkbox" data-count="25" class="row-check row-check25" name="discount_dealer_view_flag" id="discount_dealer_view_flag" value="1" <?php echo ($discount_dealer_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td></td>
								<td></td>
								<td></td>
								<td align="center"><input type="checkbox" class="masterCheck masterCheck25" data-count="25" style="width:60px;text-align:center"></td>
							</tr>

							<tr>
								<td>Discount Distributor</td>
								<td align="center"><input type="checkbox" data-count="26" class="row-check row-check26" name="discount_distributor_view_flag" id="discount_distributor_view_flag" value="1" <?php echo ($discount_distributor_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td></td>
								<td></td>
								<td></td>
								<td align="center"><input type="checkbox" class="masterCheck masterCheck26" data-count="26" style="width:60px;text-align:center"></td>
							</tr>

							<tr>
								<td>Gst Details</td>
								<td align="center"><input type="checkbox" data-count="27" class="row-check row-check27" name="gst_view_flag" id="gst_view_flag" value="1" <?php echo ($gst_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td></td>
								<td></td>
								<td></td>
								<td align="center"><input type="checkbox" class="masterCheck masterCheck27" data-count="27" style="width:60px;text-align:center"></td>
							</tr>

							<tr>
								<td>My Visting Card</td>
								<td align="center"><input type="checkbox" data-count="28" class="row-check row-check28" name="visit_card_view_flag" id="visit_card_view_flag" value="1" <?php echo ($visit_card_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td></td>
								<td></td>
								<td></td>
								<td align="center"><input type="checkbox" class="masterCheck masterCheck28" data-count="28" style="width:60px;text-align:center"></td>
							</tr>

							<tr>
								<td>Traveling</td>
								<td align="center"><input type="checkbox" data-count="29" class="row-check row-check29" name="traveling_view_flag" id="traveling_view_flag" value="1" <?php echo ($traveling_view_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td></td>
								<td></td>
								<td></td>
								<td align="center"><input type="checkbox" class="masterCheck masterCheck29" data-count="29" style="width:60px;text-align:center"></td>
							</tr>

							<tr>
								<td>Tracking</td>
								<td align="center"><input type="checkbox" data-count="30" class="row-check row-check30" name="tracking_flag" id="tracking_flag" value="1" <?php echo ($tracking_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
								<td></td>
								<td></td>
								<td></td>
								<td align="center"><input type="checkbox" class="masterCheck masterCheck30" data-count="30" style="width:60px;text-align:center"></td>
							</tr>

							<!-- <tr>
							<td>Export Database</td>
							<td align="center"><input type="checkbox" name="export_db_insert_flag" id="export_db_insert_flag" value="1" <?php echo ($export_db_insert_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
							<td></td>
							<td></td>
							</tr>

							<tr>
							<td>Reports</td>
							<td align="center"><input type="checkbox" name="reports_insert_flag" id="reports_insert_flag" value="1" <?php echo ($reports_insert_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
							<td></td>
							<td></td>
							</tr> -->

							

							

							<!-- <tr>
							<td>Task</td>
							<td align="center"><input type="checkbox" name="task_insert_flag" id="task_insert_flag" value="1" <?php echo ($task_insert_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
							<td></td>
							<td></td>
							</tr>

							<tr>
							<td>Discount</td>
							<td align="center"><input type="checkbox" name="discount_insert_flag" id="discount_insert_flag" value="1" <?php echo ($discount_insert_flag==1)?"checked":""; ?> style="width:60px;text-align:center"></td>
							<td></td>
							<td></td>
							</tr> -->


						</tbody>